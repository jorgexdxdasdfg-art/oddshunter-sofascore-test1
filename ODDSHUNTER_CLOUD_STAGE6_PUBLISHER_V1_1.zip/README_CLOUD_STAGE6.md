# OddsHunter Cloud Stage6 Publisher V1.1

Corrección exacta de Stage6 V1 después del run `logs_89304887834.zip`.

## Fallo V1

Los secrets, el preflight remoto, el runtime y Stage5 pasaron. Stage6 alcanzó Turso y falló en la capa de transporte Hrana v2:

`Turso HTTP 400: JSON parse error: invalid type: string "2.32", expected f64`

V1 serializaba un float como:

`{"type":"float","value":"2.32"}`

Turso espera:

`{"type":"float","value":2.32}`

## Cambio V1.1

Solo se corrige `encode_arg()` para que `float.value` sea un número JSON/f64. No se cambia la lógica de identidad, Stage5, SQLite, fuentes, modelos ni selección de partidos.

## Seguridad

- No toca la DB oficial de Windows.
- No entrena.
- Working SQLite sigue read-only durante el publisher.
- Preflight remoto antes de escribir.
- Exige Stage5 PASS del mismo runner con committed>=1, technical_errors=0 y source_unavailable=0.
- Exige SHA exacto de la DB producida por Stage5.
- UPSERT incremental; no hace DROP.
- Puede rerun después del fallo parcial de V1: vuelve a auditar el remoto y los UPSERT son idempotentes.

## Gate nuevo

El workflow exige `HRANA_FLOAT_ARG_GATE=PASS` antes de contactar al publicador.

## Cierre esperado

`STAGE5_PASS = True`
`STAGE6_PASS = True`
`FINAL=PASS_STAGE6_PUBLISHER`
