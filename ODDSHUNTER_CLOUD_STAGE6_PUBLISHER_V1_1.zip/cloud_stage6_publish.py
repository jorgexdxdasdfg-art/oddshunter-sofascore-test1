from __future__ import annotations

import argparse
import base64
import hashlib
import json
import math
import os
import re
import sqlite3
import time
import urllib.error
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
DB = DATA / "oddshunter.db"
REGISTRY = DATA / "competitions.json"
ARTIFACTS = ROOT / "artifacts"
STAGE5_REPORT = ARTIFACTS / "cloud_stage5_cycle.json"
STAGE6_REPORT = ARTIFACTS / "cloud_stage6_publisher.json"
NEXT_STATE_ZIP = ARTIFACTS / "ODDSHUNTER_CLOUD_WORKING_STATE_STAGE6.zip"

REQUIRED_REMOTE_TABLES = (
    "leagues",
    "teams",
    "team_competition_memberships",
    "matches",
    "team_match_stats",
    "mobile_events",
    "mobile_analysis_docs",
    "mobile_competitions",
    "mobile_sync_meta",
)

IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def safe_dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def pct(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if 0 <= number <= 1:
        return round(number * 100.0, 1)
    return round(number, 1)


def compact_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} no contiene un objeto JSON")
    return value


def headline_from_goals(goals: dict[str, Any]) -> dict[str, Any]:
    models = safe_dict(goals.get("models"))
    learned = safe_dict(models.get("MODELO_APRENDIDO"))
    if not learned:
        learned = safe_dict(models.get("MODELO_GOLES"))
    outcome = safe_dict(learned.get("outcome_probabilities"))
    return {
        "home_win": pct(outcome.get("home_win")),
        "draw": pct(outcome.get("draw")),
        "away_win": pct(outcome.get("away_win")),
        "model": learned.get("model_name"),
    }


def ident(name: str) -> str:
    if not IDENT_RE.fullmatch(str(name)):
        raise ValueError(f"Identificador SQL inseguro: {name!r}")
    return '"' + str(name) + '"'


def encode_arg(value: Any) -> dict[str, Any]:
    if value is None:
        return {"type": "null"}
    if isinstance(value, bool):
        return {"type": "integer", "value": "1" if value else "0"}
    if isinstance(value, int):
        return {"type": "integer", "value": str(value)}
    if isinstance(value, float):
        if not math.isfinite(value):
            return {"type": "null"}
        # Hrana v2 expects float.value as a JSON number (f64), not a string.
        # V1 used repr(value), producing e.g. {"type":"float","value":"2.32"},
        # which Turso rejected with HTTP 400 "expected f64".
        return {"type": "float", "value": float(value)}
    if isinstance(value, (bytes, bytearray, memoryview)):
        return {"type": "blob", "base64": base64.b64encode(bytes(value)).decode("ascii")}
    return {"type": "text", "value": str(value)}


def decode_cell(cell: Any) -> Any:
    if not isinstance(cell, dict):
        return cell
    kind = str(cell.get("type") or "")
    if kind == "null":
        return None
    if kind == "blob":
        raw = str(cell.get("base64") or "")
        return base64.b64decode(raw) if raw else b""
    raw = cell.get("value")
    if kind == "integer":
        try:
            return int(raw)
        except (TypeError, ValueError):
            return raw
    if kind == "float":
        try:
            return float(raw)
        except (TypeError, ValueError):
            return raw
    return raw


class TursoClient:
    def __init__(self, url: str, token: str, timeout: float = 20.0):
        raw = str(url or "").strip().rstrip("/")
        if raw.startswith("libsql://"):
            raw = "https://" + raw[len("libsql://"):]
        elif raw.startswith("turso://"):
            raw = "https://" + raw[len("turso://"):]
        if not raw.startswith(("https://", "http://")):
            raise RuntimeError("TURSO_DATABASE_URL inválida")
        if not str(token or "").strip():
            raise RuntimeError("Falta TURSO_AUTH_TOKEN")
        self.base = raw
        self.token = str(token).strip()
        self.timeout = float(timeout)

    def health(self) -> bool:
        req = urllib.request.Request(
            self.base + "/health",
            headers={
                "Authorization": f"Bearer {self.token}",
                "User-Agent": "OddsHunter-Stage6/1.0",
            },
            method="GET",
        )
        try:
            with urllib.request.urlopen(req, timeout=min(self.timeout, 10.0)) as resp:
                return 200 <= int(resp.status) < 300
        except Exception:
            return False

    def _pipeline(self, requests_payload: list[dict[str, Any]]) -> list[dict[str, Any]]:
        payload = {"requests": requests_payload + [{"type": "close"}]}
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(
            self.base + "/v2/pipeline",
            data=data,
            headers={
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "OddsHunter-Stage6/1.0",
            },
            method="POST",
        )
        last: Exception | None = None
        for attempt in range(1, 5):
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    raw = resp.read()
                doc = json.loads(raw.decode("utf-8", errors="replace"))
                results = doc.get("results")
                if not isinstance(results, list):
                    raise RuntimeError("Respuesta Turso sin results")
                return results[: len(requests_payload)]
            except urllib.error.HTTPError as exc:
                detail = exc.read().decode("utf-8", errors="replace")[:1200]
                last = RuntimeError(f"Turso HTTP {exc.code}: {detail}")
                transient = exc.code in {408, 425, 429, 500, 502, 503, 504}
                if not transient or attempt == 4:
                    raise last
            except Exception as exc:
                last = exc
                if attempt == 4:
                    raise RuntimeError(f"Turso pipeline falló: {type(exc).__name__}: {exc}") from exc
            time.sleep(min(2 ** attempt, 8))
        raise RuntimeError(f"Turso pipeline falló: {last}")

    @staticmethod
    def _stmt(sql: str, params: Sequence[Any] | None = None) -> dict[str, Any]:
        stmt: dict[str, Any] = {"sql": str(sql)}
        if params:
            stmt["args"] = [encode_arg(v) for v in params]
        return {"type": "execute", "stmt": stmt}

    @staticmethod
    def _parse_result(result: dict[str, Any]) -> tuple[list[str], list[list[Any]]]:
        if result.get("type") != "ok":
            raise RuntimeError(f"Turso devolvió error: {result}")
        response = result.get("response") or {}
        inner = response.get("result") or {}
        cols = [str(c.get("name") or "") for c in (inner.get("cols") or [])]
        rows = [[decode_cell(cell) for cell in row] for row in (inner.get("rows") or [])]
        return cols, rows

    def query(self, sql: str, params: Sequence[Any] | None = None) -> list[dict[str, Any]]:
        result = self._pipeline([self._stmt(sql, params)])[0]
        cols, rows = self._parse_result(result)
        return [dict(zip(cols, row)) for row in rows]

    def execute(self, sql: str, params: Sequence[Any] | None = None) -> None:
        result = self._pipeline([self._stmt(sql, params)])[0]
        self._parse_result(result)

    def execute_many(self, statements: Iterable[tuple[str, Sequence[Any]]], chunk: int = 20) -> int:
        pending: list[dict[str, Any]] = []
        count = 0
        for sql, params in statements:
            pending.append(self._stmt(sql, params))
            if len(pending) >= chunk:
                results = self._pipeline(pending)
                for result in results:
                    self._parse_result(result)
                count += len(pending)
                pending = []
        if pending:
            results = self._pipeline(pending)
            for result in results:
                self._parse_result(result)
            count += len(pending)
        return count


def local_connect(read_only: bool = True) -> sqlite3.Connection:
    if not DB.is_file():
        raise FileNotFoundError(f"Falta {DB}")
    if read_only:
        uri = f"file:{DB.resolve().as_posix()}?mode=ro"
        con = sqlite3.connect(uri, uri=True, timeout=60)
        con.execute("PRAGMA query_only=ON")
    else:
        con = sqlite3.connect(DB, timeout=60)
    con.row_factory = sqlite3.Row
    return con


def local_checks(con: sqlite3.Connection) -> dict[str, Any]:
    result = {
        "quick_check": str(con.execute("PRAGMA quick_check").fetchone()[0]),
        "foreign_key_errors": len(con.execute("PRAGMA foreign_key_check").fetchall()),
    }
    for table in ("leagues", "teams", "matches", "team_match_stats"):
        result[table] = int(con.execute(f"SELECT COUNT(*) FROM {ident(table)}").fetchone()[0])
    return result


def local_table_info(con: sqlite3.Connection, table: str) -> list[dict[str, Any]]:
    return [dict(row) for row in con.execute(f"PRAGMA table_info({ident(table)})").fetchall()]


def remote_table_info(client: TursoClient, table: str) -> list[dict[str, Any]]:
    return client.query(f"PRAGMA table_info({ident(table)})")


def local_unique_indexes(con: sqlite3.Connection, table: str) -> list[list[str]]:
    found: list[list[str]] = []
    for row in con.execute(f"PRAGMA index_list({ident(table)})").fetchall():
        # PRAGMA index_list: seq, name, unique, origin, partial
        if int(row[2] or 0) != 1:
            continue
        index_name = str(row[1])
        cols = [str(x[2]) for x in con.execute(f"PRAGMA index_info({ident(index_name)})").fetchall()]
        if cols:
            found.append(cols)
    return found


def remote_unique_indexes(client: TursoClient, table: str) -> list[list[str]]:
    found: list[list[str]] = []
    for row in client.query(f"PRAGMA index_list({ident(table)})"):
        unique_value = row.get("unique")
        if int(unique_value or 0) != 1:
            continue
        index_name = str(row.get("name") or "")
        if not index_name:
            continue
        cols = [str(x.get("name") or "") for x in client.query(f"PRAGMA index_info({ident(index_name)})")]
        cols = [x for x in cols if x]
        if cols:
            found.append(cols)
    return found


def assert_schema_compatible(con: sqlite3.Connection, client: TursoClient, table: str) -> dict[str, Any]:
    local = local_table_info(con, table)
    remote = remote_table_info(client, table)
    if not local:
        raise RuntimeError(f"Tabla local ausente: {table}")
    if not remote:
        raise RuntimeError(f"Tabla remota ausente: {table}")
    local_cols = [str(x["name"]) for x in local]
    remote_cols = [str(x["name"]) for x in remote]
    missing = [c for c in local_cols if c not in remote_cols]
    if missing:
        raise RuntimeError(f"Schema remoto {table} no contiene columnas locales: {missing}")

    conflict_key = [
        str(x["name"])
        for x in sorted(local, key=lambda r: int(r.get("pk") or 0))
        if int(x.get("pk") or 0) > 0
    ]
    key_kind = "PRIMARY_KEY"

    # team_competition_memberships no tiene PRIMARY KEY en OddsHunter; su
    # identidad real es el UNIQUE(team_id,tournament_id,season_id) creado por
    # database.py. Para cualquier otra tabla sin PK, usamos solo un UNIQUE
    # que exista idéntico tanto local como remoto.
    if not conflict_key:
        local_unique = local_unique_indexes(con, table)
        remote_unique = remote_unique_indexes(client, table)
        candidates = [cols for cols in local_unique if cols in remote_unique]
        preferred = ["team_id", "sofascore_tournament_id", "sofascore_season_id"]
        if preferred in candidates:
            conflict_key = preferred
        elif candidates:
            candidates.sort(key=lambda cols: (len(cols), cols))
            conflict_key = candidates[0]
        if not conflict_key:
            raise RuntimeError(f"Tabla {table} sin PK/UNIQUE común detectable entre local y Turso")
        key_kind = "UNIQUE_INDEX"

    return {
        "local_columns": local_cols,
        "remote_columns": remote_cols,
        "pk": conflict_key,
        "conflict_key_kind": key_kind,
    }


def upsert_sql(table: str, columns: list[str], pk: list[str]) -> str:
    cols = ",".join(ident(c) for c in columns)
    qmarks = ",".join("?" for _ in columns)
    non_pk = [c for c in columns if c not in pk]
    if non_pk:
        update = ",".join(f"{ident(c)}=excluded.{ident(c)}" for c in non_pk)
        conflict = ",".join(ident(c) for c in pk)
        return f"INSERT INTO {ident(table)} ({cols}) VALUES ({qmarks}) ON CONFLICT ({conflict}) DO UPDATE SET {update}"
    return f"INSERT OR IGNORE INTO {ident(table)} ({cols}) VALUES ({qmarks})"


def row_equal(a: Any, b: Any) -> bool:
    if isinstance(a, (int, float)) and isinstance(b, (int, float)) and not isinstance(a, bool) and not isinstance(b, bool):
        return math.isclose(float(a), float(b), rel_tol=1e-10, abs_tol=1e-10)
    if isinstance(a, (bytes, bytearray, memoryview)) or isinstance(b, (bytes, bytearray, memoryview)):
        try:
            return bytes(a) == bytes(b)
        except Exception:
            return False
    return a == b


def verify_remote_row(client: TursoClient, table: str, row: dict[str, Any], pk: list[str], columns: list[str]) -> None:
    where = " AND ".join(f"{ident(c)} IS ?" for c in pk)
    remote_rows = client.query(
        f"SELECT {','.join(ident(c) for c in columns)} FROM {ident(table)} WHERE {where} LIMIT 1",
        [row[c] for c in pk],
    )
    if len(remote_rows) != 1:
        raise RuntimeError(f"Verificación {table} PK={[(c,row[c]) for c in pk]} devolvió {len(remote_rows)} filas")
    got = remote_rows[0]
    mismatches = []
    for c in columns:
        if not row_equal(row.get(c), got.get(c)):
            mismatches.append({"column": c, "local": row.get(c), "remote": got.get(c)})
    if mismatches:
        raise RuntimeError(f"Verificación exacta falló {table}: {mismatches[:8]}")


def fetch_local_rows(con: sqlite3.Connection, sql: str, params: Sequence[Any] = ()) -> list[dict[str, Any]]:
    return [dict(r) for r in con.execute(sql, params).fetchall()]


def registry_rows() -> list[dict[str, Any]]:
    doc = read_json(REGISTRY)
    rows = []
    for item in doc.get("competitions", []):
        if not isinstance(item, dict):
            continue
        key = str(item.get("key") or "").strip()
        if key:
            rows.append({"competition_key": key, "json_text": compact_json(item)})
    return rows


def build_mobile_for_targets(stage5: dict[str, Any]) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[str]]:
    event_rows: list[dict[str, Any]] = []
    doc_rows: list[dict[str, Any]] = []
    invalid: list[str] = []
    seen: set[tuple[str, int]] = set()

    for target in stage5.get("analysis", []):
        if not isinstance(target, dict):
            continue
        key = str(target.get("competition_key") or "").strip()
        try:
            event_id = int(target.get("event_id"))
        except (TypeError, ValueError):
            continue
        pair = (key, event_id)
        if not key or pair in seen:
            continue
        seen.add(pair)
        folder = DATA / "analisis" / key / str(event_id)
        if not folder.is_dir():
            raise RuntimeError(f"Falta carpeta de análisis Stage5: {folder}")

        parsed: dict[str, dict[str, Any]] = {}
        for path in sorted(folder.glob("*.json"), key=lambda p: p.name.casefold()):
            try:
                value = json.loads(path.read_text(encoding="utf-8-sig"))
            except Exception as exc:
                invalid.append(f"{path}: {type(exc).__name__}: {exc}")
                continue
            if not isinstance(value, dict):
                invalid.append(f"{path}: JSON no es objeto")
                continue
            name = path.stem
            parsed[name] = value
            doc_rows.append({
                "competition_key": key,
                "event_id": event_id,
                "doc_name": name,
                "json_text": compact_json(value),
                "source_mtime": datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat(),
            })

        input_doc = safe_dict(parsed.get("input_match"))
        analysis_doc = safe_dict(parsed.get("analysis"))
        status_doc = safe_dict(parsed.get("status"))
        event = safe_dict(input_doc.get("upcoming_match")) or safe_dict(input_doc.get("evento"))
        if not event:
            event = safe_dict(analysis_doc.get("upcoming_match"))
        if not event:
            raise RuntimeError(f"No hay identidad de evento en {folder}")

        try:
            canonical_event_id = int(event.get("event_id") or event_id)
        except (TypeError, ValueError):
            canonical_event_id = event_id

        headline = headline_from_goals(safe_dict(parsed.get("goals")))
        event_rows.append({
            "competition_key": key,
            "event_id": canonical_event_id,
            "competition_name": event.get("competition_name") or key,
            "season_name": event.get("season_name"),
            "round_name": event.get("round_name"),
            "stage": event.get("stage"),
            "kickoff": event.get("kickoff"),
            "status": event.get("status"),
            "status_description": event.get("status_description"),
            "home_team_id": event.get("home_team_id"),
            "home_team": event.get("home_team"),
            "away_team_id": event.get("away_team_id"),
            "away_team": event.get("away_team"),
            "home_score": event.get("home_score"),
            "away_score": event.get("away_score"),
            "analysis_status": status_doc.get("status") or analysis_doc.get("status"),
            "headline_json": compact_json(headline),
        })

    return event_rows, doc_rows, invalid


def remote_count(client: TursoClient, table: str) -> int:
    rows = client.query(f"SELECT COUNT(*) AS n FROM {ident(table)}")
    return int(rows[0]["n"]) if rows else 0


def remote_max(client: TursoClient, table: str, column: str) -> int | None:
    rows = client.query(f"SELECT MAX({ident(column)}) AS n FROM {ident(table)}")
    if not rows or rows[0].get("n") is None:
        return None
    return int(rows[0]["n"])


def collect_core_rows(con: sqlite3.Connection, stage5: dict[str, Any], client: TursoClient) -> tuple[dict[str, list[dict[str, Any]]], dict[str, Any]]:
    committed_ids: set[int] = set()
    for sync in stage5.get("result_sync", []):
        if not isinstance(sync, dict):
            continue
        source_report = safe_dict(sync.get("source_report"))
        for event in source_report.get("events", []):
            if isinstance(event, dict) and event.get("result") == "COMMITTED" and event.get("match_id") is not None:
                committed_ids.add(int(event["match_id"]))

    local_match_count = int(con.execute("SELECT COUNT(*) FROM matches").fetchone()[0])
    local_match_max = int(con.execute("SELECT COALESCE(MAX(match_id),0) FROM matches").fetchone()[0])
    remote_match_count = remote_count(client, "matches")
    remote_match_max_value = remote_max(client, "matches", "match_id") or 0

    if remote_match_count > local_match_count:
        raise RuntimeError(
            f"Turso matches está por delante de working SQLite: remote={remote_match_count} local={local_match_count}. "
            "No se sobrescribe a ciegas."
        )

    tail_ids: set[int] = set()
    if remote_match_count < local_match_count:
        if local_match_max <= remote_match_max_value:
            raise RuntimeError(
                "Hay diferencia de conteo en matches pero no es un delta de cola seguro. STOP."
            )
        tail_rows = con.execute(
            "SELECT match_id FROM matches WHERE match_id>? ORDER BY match_id",
            (remote_match_max_value,),
        ).fetchall()
        tail_ids = {int(r[0]) for r in tail_rows}
        expected_delta = local_match_count - remote_match_count
        if len(tail_ids) != expected_delta or expected_delta > 50:
            raise RuntimeError(
                f"Delta matches no es cola segura: expected_delta={expected_delta}, tail_ids={len(tail_ids)}, "
                f"remote_max={remote_match_max_value}, local_max={local_match_max}"
            )

    match_ids = sorted(committed_ids | tail_ids)
    if not committed_ids:
        raise RuntimeError("Stage6 exige al menos un match_id COMMITTED producido por Stage5")

    match_rows: list[dict[str, Any]] = []
    stat_rows: list[dict[str, Any]] = []
    league_ids: set[int] = set()
    team_ids: set[int] = set()

    for match_id in match_ids:
        rows = fetch_local_rows(con, "SELECT * FROM matches WHERE match_id=?", (match_id,))
        if len(rows) != 1:
            raise RuntimeError(f"match_id={match_id} no existe exactamente una vez")
        m = rows[0]
        match_rows.append(m)
        league_ids.add(int(m["league_id"]))
        team_ids.add(int(m["home_team_id"]))
        team_ids.add(int(m["away_team_id"]))
        stat_rows.extend(fetch_local_rows(con, "SELECT * FROM team_match_stats WHERE match_id=? ORDER BY team_id", (match_id,)))

    league_rows: list[dict[str, Any]] = []
    for league_id in sorted(league_ids):
        league_rows.extend(fetch_local_rows(con, "SELECT * FROM leagues WHERE league_id=?", (league_id,)))

    team_rows: list[dict[str, Any]] = []
    for team_id in sorted(team_ids):
        team_rows.extend(fetch_local_rows(con, "SELECT * FROM teams WHERE team_id=?", (team_id,)))

    membership_rows: list[dict[str, Any]] = []
    for team_id in sorted(team_ids):
        for league_id in sorted(league_ids):
            membership_rows.extend(fetch_local_rows(
                con,
                "SELECT * FROM team_competition_memberships WHERE team_id=? AND league_id=? ORDER BY 1",
                (team_id, league_id),
            ))

    rows_by_table = {
        "leagues": league_rows,
        "teams": team_rows,
        "team_competition_memberships": membership_rows,
        "matches": match_rows,
        "team_match_stats": stat_rows,
    }
    meta = {
        "committed_match_ids": sorted(committed_ids),
        "safe_tail_match_ids": sorted(tail_ids),
        "published_match_ids": match_ids,
        "local_match_count": local_match_count,
        "remote_match_count_before": remote_match_count,
        "local_match_max": local_match_max,
        "remote_match_max_before": remote_match_max_value,
    }
    return rows_by_table, meta


def publish_rows(con: sqlite3.Connection, client: TursoClient, rows_by_table: dict[str, list[dict[str, Any]]], schemas: dict[str, dict[str, Any]]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for table in ("leagues", "teams", "team_competition_memberships", "matches", "team_match_stats"):
        rows = rows_by_table.get(table, [])
        schema = schemas[table]
        columns = schema["local_columns"]
        pk = schema["pk"]
        sql = upsert_sql(table, columns, pk)
        statements = []
        for row in rows:
            statements.append((sql, [row.get(c) for c in columns]))
        if statements:
            client.execute_many(statements, chunk=12)
        for row in rows:
            verify_remote_row(client, table, row, pk, columns)
        counts[table] = len(rows)
    return counts


def publish_mobile(client: TursoClient, stage5: dict[str, Any]) -> dict[str, Any]:
    event_rows, doc_rows, invalid = build_mobile_for_targets(stage5)
    if invalid:
        raise RuntimeError(f"JSON inválido en targets Stage5: {invalid[:5]}")
    if not event_rows:
        raise RuntimeError("Stage6 no encontró mobile_events para publicar")
    if not doc_rows:
        raise RuntimeError("Stage6 no encontró mobile_analysis_docs para publicar")

    competition_rows = registry_rows()
    if not competition_rows:
        raise RuntimeError("competitions.json no produjo filas")

    mobile_specs = {
        "mobile_events": ([
            "competition_key", "event_id", "competition_name", "season_name", "round_name", "stage",
            "kickoff", "status", "status_description", "home_team_id", "home_team", "away_team_id",
            "away_team", "home_score", "away_score", "analysis_status", "headline_json",
        ], ["competition_key", "event_id"]),
        "mobile_analysis_docs": (["competition_key", "event_id", "doc_name", "json_text", "source_mtime"], ["competition_key", "event_id", "doc_name"]),
        "mobile_competitions": (["competition_key", "json_text"], ["competition_key"]),
        "mobile_sync_meta": (["key", "value"], ["key"]),
    }

    def do_rows(table: str, rows: list[dict[str, Any]]) -> None:
        columns, pk = mobile_specs[table]
        sql = upsert_sql(table, columns, pk)
        client.execute_many([(sql, [row.get(c) for c in columns]) for row in rows], chunk=15)

    do_rows("mobile_analysis_docs", doc_rows)
    do_rows("mobile_events", event_rows)
    do_rows("mobile_competitions", competition_rows)

    meta_rows = [
        {"key": "stage6_last_publish_at", "value": utc_now()},
        {"key": "stage6_source_db_sha", "value": sha256(DB)},
        {"key": "stage6_event_upserts", "value": str(len(event_rows))},
        {"key": "stage6_doc_upserts", "value": str(len(doc_rows))},
        {"key": "stage6_competition_upserts", "value": str(len(competition_rows))},
    ]
    do_rows("mobile_sync_meta", meta_rows)

    # Verificación exacta de los targets publicados.
    for row in event_rows:
        cols, pk = mobile_specs["mobile_events"]
        verify_remote_row(client, "mobile_events", row, pk, cols)

    by_target: dict[tuple[str, int], list[dict[str, Any]]] = {}
    for row in doc_rows:
        by_target.setdefault((str(row["competition_key"]), int(row["event_id"])), []).append(row)
    for (key, event_id), expected_rows in by_target.items():
        remote = client.query(
            "SELECT competition_key,event_id,doc_name,json_text,source_mtime "
            "FROM mobile_analysis_docs WHERE competition_key=? AND event_id=? ORDER BY doc_name",
            [key, event_id],
        )
        expected = sorted(expected_rows, key=lambda x: str(x["doc_name"]))
        if len(remote) < len(expected):
            raise RuntimeError(f"Docs remotos incompletos {key}/{event_id}: remote={len(remote)} expected>={len(expected)}")
        remote_by_name = {str(r["doc_name"]): r for r in remote}
        for row in expected:
            got = remote_by_name.get(str(row["doc_name"]))
            if got is None:
                raise RuntimeError(f"Falta doc remoto {key}/{event_id}/{row['doc_name']}")
            for col in mobile_specs["mobile_analysis_docs"][0]:
                if not row_equal(row.get(col), got.get(col)):
                    raise RuntimeError(f"Doc remoto distinto {key}/{event_id}/{row['doc_name']} col={col}")

    remote_comp_rows = client.query("SELECT competition_key,json_text FROM mobile_competitions ORDER BY competition_key")
    remote_comp = {str(r["competition_key"]): str(r["json_text"]) for r in remote_comp_rows}
    for row in competition_rows:
        if remote_comp.get(str(row["competition_key"])) != str(row["json_text"]):
            raise RuntimeError(f"mobile_competitions mismatch: {row['competition_key']}")

    return {
        "event_rows": len(event_rows),
        "doc_rows": len(doc_rows),
        "competition_rows": len(competition_rows),
        "invalid_json": invalid,
        "targets": [f"{r['competition_key']}/{r['event_id']}" for r in event_rows],
    }


def create_next_state_zip(report: dict[str, Any]) -> dict[str, Any]:
    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    manifest = {
        "generated_at": utc_now(),
        "purpose": "OddsHunter cloud working SQLite COPY after Stage6 publisher",
        "source_stage": "Stage6",
        "source_db_modified_by_publisher": False,
        "working_copy_sha": sha256(DB),
        "working_copy_checks": report.get("local_after"),
        "stage6_pass": report.get("stage6_pass"),
        "remote_after": report.get("remote_after"),
    }
    include_files: list[tuple[Path, str]] = []
    for path, arc in (
        (DB, "data/oddshunter.db"),
        (REGISTRY, "data/competitions.json"),
        (DATA / "team_identity_registry.json", "data/team_identity_registry.json"),
        (DATA / "manifests" / "source_profiles.json", "data/manifests/source_profiles.json"),
    ):
        if path.is_file():
            include_files.append((path, arc))
    trained = DATA / "trained_models"
    if trained.is_dir():
        for path in trained.rglob("*"):
            if path.is_file():
                include_files.append((path, path.relative_to(ROOT).as_posix()))

    with zipfile.ZipFile(NEXT_STATE_ZIP, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        z.writestr("CLOUD_WORKING_STATE_MANIFEST.json", json.dumps(manifest, ensure_ascii=False, indent=2))
        for path, arc in include_files:
            z.write(path, arc)

    return {
        "path": str(NEXT_STATE_ZIP),
        "sha256": sha256(NEXT_STATE_ZIP),
        "bytes": NEXT_STATE_ZIP.stat().st_size,
        "files": 1 + len(include_files),
    }


def remote_snapshot(client: TursoClient) -> dict[str, Any]:
    snap: dict[str, Any] = {"health": client.health()}
    for table in ("leagues", "teams", "matches", "team_match_stats", "mobile_events", "mobile_analysis_docs", "mobile_competitions"):
        snap[table] = remote_count(client, table)
    return snap


def preflight(client: TursoClient) -> dict[str, Any]:
    if not DB.is_file():
        raise FileNotFoundError(f"Falta working DB: {DB}")
    if not REGISTRY.is_file():
        raise FileNotFoundError(f"Falta registry: {REGISTRY}")
    with local_connect() as con:
        checks = local_checks(con)
        if checks["quick_check"] != "ok" or checks["foreign_key_errors"] != 0:
            raise RuntimeError(f"Working DB no está sana: {checks}")
        schemas = {}
        for table in REQUIRED_REMOTE_TABLES:
            # mobile_* no existen en la working SQLite; solo verificamos existencia remota.
            if table.startswith("mobile_"):
                info = remote_table_info(client, table)
                if not info:
                    raise RuntimeError(f"Tabla remota ausente: {table}")
                remote_cols = [str(x["name"]) for x in info]
                required_mobile_columns = {
                    "mobile_events": [
                        "competition_key", "event_id", "competition_name", "season_name",
                        "round_name", "stage", "kickoff", "status", "status_description",
                        "home_team_id", "home_team", "away_team_id", "away_team",
                        "home_score", "away_score", "analysis_status", "headline_json",
                    ],
                    "mobile_analysis_docs": [
                        "competition_key", "event_id", "doc_name", "json_text", "source_mtime",
                    ],
                    "mobile_competitions": ["competition_key", "json_text"],
                    "mobile_sync_meta": ["key", "value"],
                }[table]
                missing = [c for c in required_mobile_columns if c not in remote_cols]
                if missing:
                    raise RuntimeError(f"Schema remoto {table} incompleto: faltan {missing}")
                schemas[table] = {"remote_columns": remote_cols}
            else:
                schemas[table] = assert_schema_compatible(con, client, table)
    remote = remote_snapshot(client)
    if not remote.get("health"):
        raise RuntimeError("Turso /health no respondió OK")
    return {"local": checks, "remote": remote, "schemas": schemas}


def main() -> int:
    parser = argparse.ArgumentParser(description="OddsHunter Stage6: publicador incremental working SQLite -> Turso")
    parser.add_argument("--preflight-only", action="store_true")
    args = parser.parse_args()

    url = os.environ.get("TURSO_DATABASE_URL") or ""
    token = os.environ.get("TURSO_AUTH_TOKEN") or ""
    client = TursoClient(url, token)
    ARTIFACTS.mkdir(parents=True, exist_ok=True)

    print("=" * 78)
    print("ODDSHUNTER CLOUD STAGE6 - PUBLISHER INCREMENTAL A TURSO")
    print("Working SQLite local -> Turso oddshunter-mobile-v2")
    print("NO toca la DB oficial de Windows. NO entrena. NO borra tablas mobile_*.")
    print("=" * 78)

    pf = preflight(client)
    print("PREFLIGHT_REMOTE=PASS")
    print("LOCAL_CHECKS =", pf["local"])
    print("REMOTE_BEFORE =", pf["remote"])

    if args.preflight_only:
        print("STAGE6_PREFLIGHT_ONLY=PASS")
        return 0

    if os.environ.get("ODDSHUNTER_STAGE6_ALLOW_TURSO_WRITE") != "1":
        raise RuntimeError("WRITE GATE cerrado: define ODDSHUNTER_STAGE6_ALLOW_TURSO_WRITE=1")
    if not STAGE5_REPORT.is_file():
        raise FileNotFoundError(f"Falta reporte Stage5 del mismo run: {STAGE5_REPORT}")

    stage5 = read_json(STAGE5_REPORT)
    if stage5.get("stage5_pass") is not True:
        raise RuntimeError("Stage6 exige stage5_pass=True en el MISMO runner")
    sync_counts = safe_dict(stage5.get("sync_result_counts"))
    if int(sync_counts.get("committed") or 0) < 1:
        raise RuntimeError("Stage6 exige committed>=1 en Stage5 del mismo run")
    if int(sync_counts.get("technical_errors") or 0) != 0:
        raise RuntimeError("Stage6 bloqueado: Stage5 technical_errors != 0")
    if int(sync_counts.get("source_unavailable") or 0) != 0:
        raise RuntimeError("Stage6 bloqueado: Stage5 source_unavailable != 0")

    db_sha_before = sha256(DB)
    stage5_db_sha_after = str(stage5.get("db_sha_after") or "").strip().upper()
    if not stage5_db_sha_after:
        raise RuntimeError("Stage5 no reportó db_sha_after; no se publica una DB de procedencia incierta")
    if stage5_db_sha_after != db_sha_before:
        raise RuntimeError(
            "La DB que va a publicar Stage6 no coincide con la salida exacta de Stage5 del mismo run: "
            f"stage5={stage5_db_sha_after} actual={db_sha_before}"
        )

    with local_connect() as con:
        local_before = local_checks(con)
        schemas = {
            table: assert_schema_compatible(con, client, table)
            for table in ("leagues", "teams", "team_competition_memberships", "matches", "team_match_stats")
        }
        rows_by_table, core_meta = collect_core_rows(con, stage5, client)
        core_counts = publish_rows(con, client, rows_by_table, schemas)

    remote_after_core = remote_snapshot(client)
    if remote_after_core["matches"] != local_before["matches"]:
        raise RuntimeError(
            f"Después del core publish, matches remoto != local: remote={remote_after_core['matches']} local={local_before['matches']}"
        )
    if remote_after_core["team_match_stats"] != local_before["team_match_stats"]:
        raise RuntimeError(
            "Después del core publish, team_match_stats remoto != local: "
            f"remote={remote_after_core['team_match_stats']} local={local_before['team_match_stats']}"
        )

    mobile = publish_mobile(client, stage5)
    remote_after = remote_snapshot(client)

    for table in ("mobile_events", "mobile_analysis_docs", "mobile_competitions"):
        if int(remote_after[table]) < int(pf["remote"][table]):
            raise RuntimeError(f"Conteo remoto disminuyó en {table}")

    db_sha_after = sha256(DB)
    with local_connect() as con:
        local_after = local_checks(con)

    criteria = {
        "stage5_same_run_pass": stage5.get("stage5_pass") is True,
        "stage5_committed_at_least_1": int(sync_counts.get("committed") or 0) >= 1,
        "stage5_technical_errors_zero": int(sync_counts.get("technical_errors") or 0) == 0,
        "publisher_input_sha_matches_stage5": stage5_db_sha_after == db_sha_before,
        "turso_health": bool(remote_after.get("health")),
        "core_matches_remote_equals_working": int(remote_after["matches"]) == int(local_after["matches"]),
        "core_stats_remote_equals_working": int(remote_after["team_match_stats"]) == int(local_after["team_match_stats"]),
        "mobile_event_upsert_at_least_1": int(mobile["event_rows"]) >= 1,
        "mobile_docs_upsert_at_least_1": int(mobile["doc_rows"]) >= 1,
        "mobile_counts_not_decreased": all(
            int(remote_after[t]) >= int(pf["remote"][t])
            for t in ("mobile_events", "mobile_analysis_docs", "mobile_competitions")
        ),
        "working_db_unchanged_by_publisher": db_sha_before == db_sha_after,
        "working_db_quick_check_ok": local_after["quick_check"] == "ok",
        "working_db_fk_zero": local_after["foreign_key_errors"] == 0,
        "training_not_invoked": True,
        "official_windows_db_touched": False,
        "no_mobile_drop_or_recreate": True,
    }

    report: dict[str, Any] = {
        "generated_at": utc_now(),
        "stage": "Stage6",
        "source": "working SQLite from same runner after Stage5 V4 producer",
        "target": "Turso oddshunter-mobile-v2",
        "training_invoked": False,
        "official_pc_db_touched": False,
        "publisher_write_gate": True,
        "stage5_sync_result_counts": sync_counts,
        "stage5_db_sha_after": stage5_db_sha_after,
        "db_sha_before_publisher": db_sha_before,
        "db_sha_after_publisher": db_sha_after,
        "local_before": local_before,
        "local_after": local_after,
        "remote_before": pf["remote"],
        "remote_after_core": remote_after_core,
        "remote_after": remote_after,
        "core_meta": core_meta,
        "core_rows_published": core_counts,
        "mobile": mobile,
        "criteria": criteria,
        "stage6_pass": all(criteria.values()),
    }

    if report["stage6_pass"]:
        report["next_working_state"] = create_next_state_zip(report)

    STAGE6_REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    print("REPORT =", STAGE6_REPORT)
    print("STAGE6_PASS =", report["stage6_pass"])
    if report.get("next_working_state"):
        print("NEXT_WORKING_STATE =", report["next_working_state"])
    print("FINAL=" + ("PASS_STAGE6_PUBLISHER" if report["stage6_pass"] else "FAIL_STAGE6_PUBLISHER"))
    return 0 if report["stage6_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
