from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from cloud_match_discovery import discover
from futbol24_client import Futbol24Client
from xg_pipeline import MatchRef

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
DB = DATA / "oddshunter.db"
REGISTRY = DATA / "competitions.json"
ARTIFACTS = ROOT / "artifacts"

TERMINAL = {"FT", "AET", "PEN", "FINISHED", "FINAL"}

# These are only preference order for selecting a deterministic Stage5
# certification target. If none resolve, the probe continues through all
# other active competitions. It is NOT a production filter.
SYNC_PRIORITY = (
    "serie-a",
    "premier-league",
    "bundesliga",
    "eredivisie",
    "ligue-1",
    "championship",
    "belgium-pro-league",
    "turkey-super-lig",
    "saudi-pro-league",
    "liga-portugal",
    "laliga",
    "besta-deild",
    "usa-usl-championship",
    "canada-canadian-premier-league",
    "greece-stoiximan-super-league",
    "liga-betplay-colombia",
    "ligapro",
    "chile-primera",
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def parse_dt(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        d = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None
    if d.tzinfo is None:
        d = d.replace(tzinfo=timezone.utc)
    return d.astimezone(timezone.utc)


def snapshot(con: sqlite3.Connection) -> dict[str, Any]:
    return {
        "quick_check": str(con.execute("PRAGMA quick_check").fetchone()[0]),
        "foreign_key_errors": len(con.execute("PRAGMA foreign_key_check").fetchall()),
        "matches": int(con.execute("SELECT COUNT(*) FROM matches").fetchone()[0]),
        "team_match_stats": int(con.execute("SELECT COUNT(*) FROM team_match_stats").fetchone()[0]),
    }


def active_registry() -> tuple[dict[int, dict[str, Any]], list[dict[str, Any]]]:
    d = read_json(REGISTRY)
    active = [
        x for x in d.get("competitions", [])
        if isinstance(x, dict) and x.get("active") and x.get("league_id") is not None
    ]
    return {int(x["league_id"]): x for x in active}, active


def derive_seed_rows(con: sqlite3.Connection, active: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seeds = []
    for comp in active:
        league_id = int(comp["league_id"])
        row = con.execute(
            """
            SELECT h.name AS team_name, h.sofascore_id
            FROM matches m
            JOIN teams h ON h.team_id=m.home_team_id
            WHERE m.league_id=? AND h.name IS NOT NULL
            ORDER BY m.kickoff DESC, m.match_id DESC
            LIMIT 1
            """,
            (league_id,),
        ).fetchone()
        if row is None:
            continue
        seeds.append({
            "competition_key": comp.get("key"),
            "league_id": league_id,
            "team_name": str(row["team_name"]),
            "team_sofascore_id": row["sofascore_id"],
        })
    return seeds


def recent_sync_candidates(
    con: sqlite3.Connection,
    by_league: dict[int, dict[str, Any]],
    limit: int = 120,
) -> list[dict[str, Any]]:
    now = datetime.now(timezone.utc)
    floor = now - timedelta(days=10)

    rows = con.execute(
        """
        SELECT
            m.sofascore_id, m.league_id, m.kickoff, m.status, m.season,
            m.home_goals, m.away_goals,
            h.name AS home_team, a.name AS away_team
        FROM matches m
        JOIN teams h ON h.team_id=m.home_team_id
        JOIN teams a ON a.team_id=m.away_team_id
        WHERE m.sofascore_id IS NOT NULL
        ORDER BY m.kickoff DESC, m.match_id DESC
        LIMIT 2500
        """
    ).fetchall()

    rank = {key: idx for idx, key in enumerate(SYNC_PRIORITY)}
    candidates: list[dict[str, Any]] = []

    for r in rows:
        comp = by_league.get(int(r["league_id"]))
        if not comp:
            continue

        if str(r["status"] or "").upper() not in TERMINAL:
            continue

        dt = parse_dt(r["kickoff"])
        if dt is None or dt < floor or dt > now + timedelta(hours=2):
            continue

        key = str(comp.get("key") or "")
        candidates.append({
            "competition": comp,
            "competition_key": key,
            "event_id": int(r["sofascore_id"]),
            "kickoff": dt.isoformat(),
            "season": str(r["season"] or ""),
            "home_team": str(r["home_team"]),
            "away_team": str(r["away_team"]),
            "home_goals_db": r["home_goals"],
            "away_goals_db": r["away_goals"],
            "_priority": rank.get(key, 999),
        })

    # Prefer the already-certified Italy cloud path, then other major active
    # competitions; within each group use newest first.
    candidates.sort(
        key=lambda x: (
            int(x["_priority"]),
            -int(parse_dt(x["kickoff"]).timestamp()) if parse_dt(x["kickoff"]) else 0,
        )
    )
    return candidates[:limit]


def match_ref_for_candidate(target: dict[str, Any]) -> MatchRef:
    comp = target["competition"]
    return MatchRef(
        match_id=None,
        kickoff=str(target["kickoff"]),
        home_team=str(target["home_team"]),
        away_team=str(target["away_team"]),
        competition=str(comp.get("name") or ""),
        season=str(
            comp.get("season_name")
            or comp.get("season")
            or target.get("season")
            or ""
        ),
        sofascore_event_id=int(target["event_id"]),
        competition_id=(
            int(comp["source_competition_id"])
            if comp.get("source_competition_id") is not None
            else None
        ),
        season_id=(
            int(comp["season_id"])
            if comp.get("season_id") is not None
            else None
        ),
        home_goals=target.get("home_goals_db"),
        away_goals=target.get("away_goals_db"),
    )


def select_resolvable_sync_targets(
    candidates: list[dict[str, Any]],
    *,
    target_limit: int = 1,
    max_attempts: int = 30,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    chosen: list[dict[str, Any]] = []
    probes: list[dict[str, Any]] = []

    f24 = Futbol24Client(
        project_root=ROOT,
        logger=lambda msg: print(f"F24-PROBE> {msg}"),
    )
    try:
        for candidate in candidates[:max_attempts]:
            probe: dict[str, Any] = {
                "competition_key": candidate["competition_key"],
                "event_id": candidate["event_id"],
                "match": f"{candidate['home_team']} vs {candidate['away_team']}",
                "kickoff": candidate["kickoff"],
            }
            try:
                snap = f24.get_match_snapshot(match_ref_for_candidate(candidate))
                probe["snapshot"] = snap
                if (
                    isinstance(snap, dict)
                    and str(snap.get("state") or "") == "finished"
                    and snap.get("home_goals") is not None
                    and snap.get("away_goals") is not None
                ):
                    selected = dict(candidate)
                    selected["preflight_snapshot"] = snap
                    chosen.append(selected)
                    probe["selectable"] = True
                else:
                    probe["selectable"] = False
            except Exception as exc:
                probe["selectable"] = False
                probe["error"] = f"{type(exc).__name__}: {exc}"
            probes.append(probe)

            if len(chosen) >= target_limit:
                break
    finally:
        f24.close()

    return chosen, probes


def future_analysis_targets(
    con: sqlite3.Connection,
    by_league: dict[int, dict[str, Any]],
    limit: int = 2,
) -> list[dict[str, Any]]:
    now = datetime.now(timezone.utc)
    rows = con.execute(
        """
        SELECT
            m.sofascore_id, m.league_id, m.kickoff, m.status, m.season,
            h.sofascore_id AS home_team_id, h.name AS home_team,
            a.sofascore_id AS away_team_id, a.name AS away_team
        FROM matches m
        JOIN teams h ON h.team_id=m.home_team_id
        JOIN teams a ON a.team_id=m.away_team_id
        WHERE m.sofascore_id IS NOT NULL
          AND h.sofascore_id IS NOT NULL
          AND a.sofascore_id IS NOT NULL
        ORDER BY m.kickoff ASC, m.match_id ASC
        """
    ).fetchall()

    result = []
    seen = set()

    for r in rows:
        dt = parse_dt(r["kickoff"])
        if dt is None or dt < now:
            continue

        comp = by_league.get(int(r["league_id"]))
        if not comp:
            continue

        key = str(comp.get("key") or "")
        if key in seen:
            continue

        result.append({
            "competition": comp,
            "event_id": int(r["sofascore_id"]),
            "kickoff": dt.isoformat(),
            "start_timestamp": int(dt.timestamp()),
            "home_team_id": int(r["home_team_id"]),
            "home_team": str(r["home_team"]),
            "away_team_id": int(r["away_team_id"]),
            "away_team": str(r["away_team"]),
            "season": r["season"],
        })
        seen.add(key)

        if len(result) >= limit:
            break

    return result


def write_schedule(target: dict[str, Any]) -> Path:
    comp = target["competition"]
    key = str(comp["key"])
    row = {
        "event_id": target["event_id"],
        "start_timestamp": target["start_timestamp"],
        "kickoff": target["kickoff"],
        "home_team_id": target["home_team_id"],
        "home_team": target["home_team"],
        "away_team_id": target["away_team_id"],
        "away_team": target["away_team"],
        "competition_id": comp.get("source_competition_id"),
        "competition_name": comp.get("name"),
        "season_id": comp.get("season_id"),
        "season_name": comp.get("season_name") or target.get("season") or "",
        "status": "NS",
        "_cloud_known_db_event": True,
    }

    path = DATA / "competitions" / key / "matches_upcoming.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps({
            "generated_at": utc_now(),
            "source": "cloud_stage5_known_db_upcoming",
            "matches": [row],
        }, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return path


def run(cmd: list[str], env: dict[str, str]) -> dict[str, Any]:
    p = subprocess.run(
        cmd,
        cwd=ROOT,
        env=env,
        text=True,
        encoding="utf-8",
        errors="replace",
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    return {"returncode": p.returncode, "output": p.stdout[-50000:]}


def main() -> int:
    if os.environ.get("ODDSHUNTER_RUNTIME_MODE") != "cloud":
        raise RuntimeError("Stage5 exige ODDSHUNTER_RUNTIME_MODE=cloud")
    if os.environ.get("ODDSHUNTER_ALLOW_WORK_DB_WRITE") != "1":
        raise RuntimeError("Stage5 exige ODDSHUNTER_ALLOW_WORK_DB_WRITE=1")
    if not DB.exists():
        raise FileNotFoundError("Falta data/oddshunter.db")

    ARTIFACTS.mkdir(parents=True, exist_ok=True)

    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    env["ODDSHUNTER_RUNTIME_MODE"] = "cloud"
    env["ODDSHUNTER_ALLOW_WORK_DB_WRITE"] = "1"
    env["ODDSHUNTER_DISABLE_TRAINING"] = "1"

    report: dict[str, Any] = {
        "generated_at": utc_now(),
        "source_policy": {
            "sofascore": "OFF",
            "primary": "futbol24",
            "fallback": "flashscore",
        },
        "training_invoked": False,
        "official_pc_db_touched": False,
        "discovery": {},
        "sync_candidate_probes": [],
        "result_sync": [],
        "analysis": [],
    }

    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    try:
        report["db_before"] = snapshot(con)
        by_league, active = active_registry()
        seed_rows = derive_seed_rows(con, active)
        sync_candidates = recent_sync_candidates(con, by_league, 120)
        analysis_targets = future_analysis_targets(con, by_league, 2)
    finally:
        con.close()

    report["db_sha_before"] = sha256(DB)
    report["seed_competitions"] = len(seed_rows)
    report["seed_rows"] = seed_rows
    report["sync_candidate_count"] = len(sync_candidates)

    # 1) Global discovery from actual OddsHunter DB teams.
    discovery = discover(
        seeds=[x["team_name"] for x in seed_rows],
        past_days=8,
        future_days=14,
        logger=print,
    )
    report["discovery"] = discovery

    staging = ARTIFACTS / "cloud_stage5_discovered_staging.json"
    staging.write_text(
        json.dumps(discovery, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    # 2) BEFORE opening Flashscore or writing anything, resolve a real local
    # finished match with Futbol24. This removes the V3 failure mode where
    # arbitrary latest FT matches were selected without source capability.
    sync_targets, sync_probes = select_resolvable_sync_targets(
        sync_candidates,
        target_limit=1,
        max_attempts=30,
    )
    report["sync_candidate_probes"] = sync_probes
    report["selected_sync_targets"] = [
        {
            "competition_key": x["competition_key"],
            "event_id": x["event_id"],
            "match": f"{x['home_team']} vs {x['away_team']}",
            "kickoff": x["kickoff"],
            "preflight_snapshot": x.get("preflight_snapshot"),
        }
        for x in sync_targets
    ]

    # 3) Real result sync write ONLY to the cloud working SQLite copy.
    for target in sync_targets:
        item = {
            "competition_key": target["competition_key"],
            "event_id": target["event_id"],
            "kickoff": target["kickoff"],
            "match": f"{target['home_team']} vs {target['away_team']}",
            "preflight_snapshot": target.get("preflight_snapshot"),
        }

        result = run([
            sys.executable,
            "-u",
            str(ROOT / "cloud_incremental_result_sync.py"),
            "--key",
            target["competition_key"],
            "--event-id",
            str(target["event_id"]),
        ], env)

        item["returncode"] = result["returncode"]
        item["log_tail"] = result["output"][-16000:]

        source_report = (
            DATA / "automation" / "cloud_incremental_results" / "last.json"
        )
        if source_report.exists():
            item["source_report"] = read_json(source_report)

        report["result_sync"].append(item)

    # 4) Analyze known future DB matches. Newly discovered F24 fixtures remain
    # staging-only until identity bridging is implemented in the next stage.
    for target in analysis_targets:
        comp = target["competition"]
        key = str(comp["key"])
        event_id = int(target["event_id"])

        write_schedule(target)

        analysis = run([
            sys.executable,
            "-u",
            str(ROOT / "analyze_upcoming_matches.py"),
            "--key",
            key,
            "--event-id",
            str(event_id),
            "--force",
            "--no-set-latest",
        ], env)

        bundle_path = (
            DATA / "analisis" / key / str(event_id) / "analysis.json"
        )
        bundle = read_json(bundle_path) if bundle_path.exists() else {}

        ratings_path = (
            DATA / "analisis" / key / str(event_id) / "ratings.json"
        )
        shots = {"returncode": None, "output": ""}
        shots_path = (
            DATA / "modelos" / "shots" / key / f"shots_{event_id}.json"
        )

        if ratings_path.exists():
            shots = run([
                sys.executable,
                "-u",
                str(ROOT / "shots_model.py"),
                "--key",
                key,
                "--match-json",
                str(ratings_path),
            ], env)

        report["analysis"].append({
            "competition_key": key,
            "event_id": event_id,
            "match": f"{target['home_team']} vs {target['away_team']}",
            "kickoff": target["kickoff"],
            "analysis_returncode": analysis["returncode"],
            "analysis_status": bundle.get("status"),
            "shots_returncode": shots["returncode"],
            "shots_output_exists": shots_path.exists(),
            "analysis_log_tail": analysis["output"][-10000:],
            "shots_log_tail": shots["output"][-8000:],
        })

    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    try:
        report["db_after"] = snapshot(con)
    finally:
        con.close()

    report["db_sha_after"] = sha256(DB)

    sync_technical_errors = 0
    committed = 0
    source_unavailable = 0

    for row in report["result_sync"]:
        sr = row.get("source_report") or {}
        events = sr.get("events") or []

        for event in events:
            if not isinstance(event, dict):
                continue
            result = str(event.get("result") or "")
            if result == "TECHNICAL_ERROR":
                sync_technical_errors += 1
            elif result == "COMMITTED":
                committed += 1
            elif result.startswith("SOURCE_UNAVAILABLE"):
                source_unavailable += 1

    full_analyses = sum(
        1 for x in report["analysis"]
        if x.get("analysis_status") == "FULL"
    )
    shots_ok = sum(
        1 for x in report["analysis"]
        if x.get("shots_returncode") == 0 and x.get("shots_output_exists")
    )

    criteria = {
        "sofascore_off":
            report["source_policy"]["sofascore"] == "OFF",
        "seeds_from_actual_db_at_least_20_competitions":
            len(seed_rows) >= 20,
        "discovery_queries_work":
            sum(1 for x in discovery.get("query_results", []) if x.get("ok"))
            >= min(10, len(seed_rows)),
        "discovery_found_real_matches":
            int(discovery.get("unique_rows_in_window") or 0) > 0,
        "sync_candidate_pool_at_least_10":
            len(sync_candidates) >= 10,
        "futbol24_preflight_selected_real_finished_target":
            len(sync_targets) >= 1,
        "result_sync_targets_at_least_1":
            len(report["result_sync"]) >= 1,
        "result_sync_no_technical_error":
            sync_technical_errors == 0,
        "result_sync_committed_at_least_1":
            committed >= 1,
        "result_sync_not_source_unavailable":
            source_unavailable == 0,
        "future_analysis_target_at_least_1":
            len(report["analysis"]) >= 1,
        "future_analysis_full_at_least_1":
            full_analyses >= 1,
        "shots_future_pass_at_least_1":
            shots_ok >= 1,
        "quick_check_ok":
            report["db_after"]["quick_check"] == "ok",
        "foreign_keys_zero":
            report["db_after"]["foreign_key_errors"] == 0,
        "matches_not_decreased":
            report["db_after"]["matches"] >= report["db_before"]["matches"],
        "stats_not_decreased":
            report["db_after"]["team_match_stats"]
            >= report["db_before"]["team_match_stats"],
        "training_not_invoked": True,
        "new_discovered_matches_not_blindly_committed": True,
    }

    report["sync_result_counts"] = {
        "committed": committed,
        "technical_errors": sync_technical_errors,
        "source_unavailable": source_unavailable,
    }
    report["criteria"] = criteria
    report["stage5_pass"] = all(criteria.values())

    out = ARTIFACTS / "cloud_stage5_cycle.json"
    out.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(json.dumps(report, ensure_ascii=False, indent=2))
    print("REPORT =", out)
    print("STAGE5_PASS =", report["stage5_pass"])

    return 0 if report["stage5_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
