# OddsHunter Cloud Stage4 + Stage5

Stage4:
- Uses ONLY a copied cloud working SQLite database.
- quick_check + foreign keys + core counts.
- Runs real OddsHunter model probes: ratings, goals, corners, cards and shots.
- Stage4 does not write SQLite and requires the DB to remain byte-identical.
- No training.

Stage5:
- Derives discovery seeds from actual teams in the copied DB across active competitions.
- Futbol24 primary, Flashscore residual, SofaScore OFF.
- Result synchronization writes ONLY to the cloud working DB copy.
- Runs analysis for known future DB events.
- Newly discovered Futbol24 fixtures are staged only; they are NOT blindly inserted using fake SofaScore IDs.
- No training.

The official Windows DB is never present in the GitHub runner. Only ODDSHUNTER_CLOUD_WORKING_STATE.zip is used.


## V3 correction
- Stage4 now probes ONLY genuine future PREPARTIDO DB events.
- Historical FT matches are never rewritten as fake upcoming probes.
- Up to 12 future events can be tried; the probe stops early after FULL + shots PASS.


## V4 Stage5 correction
- Stage4 V3 was already PASS.
- Stage5 no longer picks arbitrary latest FT matches for result sync.
- It preflights up to 30 recent local FT candidates with Futbol24 and selects only a positively resolved finished match with a complete score.
- The write gate requires an actual COMMITTED result; SOURCE_UNAVAILABLE is not accepted as success.
- Flashscore/Chromium is launched lazily only after Futbol24 resolves the match, avoiding Playwright pending-task warnings on unavailable candidates.
