# OddsHunter Cloud Stage6 Publisher V1

Objetivo: publicar de forma controlada el delta producido por Stage5 sobre la **working SQLite cloud** hacia Turso `oddshunter-mobile-v2`, sin tocar la DB oficial de Windows y sin entrenar modelos.

## Seguridad

- Requiere `TURSO_DATABASE_URL` y `TURSO_AUTH_TOKEN` por variables de entorno/secrets. No contiene credenciales.
- Preflight remoto antes de cualquier write.
- El write gate solo abre con `ODDSHUNTER_STAGE6_ALLOW_TURSO_WRITE=1`.
- Exige un `cloud_stage5_cycle.json` del mismo runner con `stage5_pass=true`, `committed>=1`, `technical_errors=0` y `source_unavailable=0`.
- Exige que el SHA de `data/oddshunter.db` coincida exactamente con `db_sha_after` reportado por Stage5.
- La working SQLite se abre read-only durante el publisher y debe quedar byte-identical durante Stage6.
- No hace `DROP` ni recrea `mobile_*`; usa UPSERT incremental.
- No inventa IDs, no convierte NULL a 0, no activa SofaScore cloud y no ejecuta entrenamiento.

## Publicación core

Sincroniza únicamente las filas necesarias de:

- `leagues`
- `teams`
- `team_competition_memberships`
- `matches`
- `team_match_stats`

Incluye el/los `match_id` realmente `COMMITTED` por Stage5 y, solo si existe una diferencia de cola demostrable y pequeña, los `matches` faltantes posteriores al `MAX(match_id)` remoto.

## Publicación Mobile

Publica incrementalmente los análisis generados por Stage5 en:

- `mobile_events`
- `mobile_analysis_docs`
- `mobile_competitions`
- `mobile_sync_meta`

Después relee Turso y verifica exactamente las filas objetivo publicadas.

## Salidas

- `artifacts/cloud_stage6_publisher.json`
- `artifacts/ODDSHUNTER_CLOUD_WORKING_STATE_STAGE6.zip`

El segundo archivo conserva la working SQLite ya modificada por el Stage5 del mismo run para que el siguiente stage no pierda el estado al terminar el runner efímero de GitHub Actions.
