from __future__ import annotations

import argparse
import importlib
import json
import os
import platform
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from cloud_source_policy import (
    SOFASCORE_ENABLED,
    STATUS_SCORE_ORDER,
    TEAM_METRIC_ORDER,
)
from flashscore_xg_client import FlashscoreXGClient, find_browser_executable
from futbol24_client import Futbol24Client
from xg_pipeline import MatchRef


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
REPORT_DIR = ROOT / "artifacts"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def db_readonly_health(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {"exists": False, "expected_at_stage1": False}
    uri = f"file:{path.resolve().as_posix()}?mode=ro"
    con = sqlite3.connect(uri, uri=True, timeout=30)
    try:
        quick = con.execute("PRAGMA quick_check").fetchone()[0]
        tables = con.execute(
            "SELECT COUNT(*) FROM sqlite_master WHERE type='table'"
        ).fetchone()[0]
        return {
            "exists": True,
            "read_only": True,
            "quick_check": quick,
            "tables": int(tables),
        }
    finally:
        con.close()


def static_checks() -> dict[str, Any]:
    required = [
        "futbol24_client.py",
        "flashscore_xg_client.py",
        "cloud_incremental_result_sync.py",
        "import_competition_stats.py",
        "ratings.py",
        "poisson_dixon_coles.py",
        "corners_model.py",
        "cards_model.py",
        "shots_model.py",
        "data/competitions.json",
        "data/team_identity_registry.json",
    ]
    files = {item: (ROOT / item).exists() for item in required}
    modules = [
        "team_identity_registry",
        "xg_estimator",
        "xg_pipeline",
        "match_stats_pipeline",
        "futbol24_client",
        "flashscore_xg_client",
        "ratings",
        "corners_model",
        "cards_model",
        "shots_model",
        "poisson_dixon_coles",
        "analyze_upcoming_matches",
        "cloud_incremental_result_sync",
    ]
    imports: dict[str, str] = {}
    for module in modules:
        try:
            importlib.import_module(module)
            imports[module] = "PASS"
        except Exception as exc:
            imports[module] = f"FAIL {type(exc).__name__}: {exc}"

    competitions = json.loads(
        (DATA / "competitions.json").read_text(encoding="utf-8-sig")
    )
    identity = json.loads(
        (DATA / "team_identity_registry.json").read_text(encoding="utf-8-sig")
    )
    return {
        "files": files,
        "imports": imports,
        "competitions_count": len(competitions.get("competitions", [])),
        "identity_top_type": type(identity).__name__,
        "browser_executable": (
            str(find_browser_executable())
            if find_browser_executable() is not None
            else "PLAYWRIGHT_MANAGED_CHROMIUM"
        ),
    }


def network_checks() -> dict[str, Any]:
    test_match = MatchRef(
        match_id=None,
        kickoff="2026-08-24T16:30:00+00:00",
        home_team="Bologna",
        away_team="Lazio",
        competition="Serie A",
        season="2026/2027",
        sofascore_event_id=16283049,
    )

    result: dict[str, Any] = {}
    f24 = Futbol24Client(
        project_root=ROOT,
        logger=lambda msg: print(f"F24> {msg}"),
    )
    try:
        snapshot = f24.get_match_snapshot(test_match)
        xg = f24.get_direct_xg(test_match)
        metrics = f24.get_match_stats(test_match)
        result["futbol24"] = {
            "snapshot": snapshot,
            "xg": None if xg is None else {"home": xg.home, "away": xg.away},
            "metrics": {
                key: {"home": value.home, "away": value.away}
                for key, value in metrics.items()
            },
        }
    finally:
        f24.close()

    from playwright.sync_api import sync_playwright

    with sync_playwright() as playwright:
        flash = FlashscoreXGClient(
            playwright,
            project_root=ROOT,
            logger=lambda msg: print(f"FLASH> {msg}"),
        )
        try:
            xg = flash.get_direct_xg(test_match)
            metrics = flash.get_match_stats(test_match)
            result["flashscore"] = {
                "xg": None if xg is None else {"home": xg.home, "away": xg.away},
                "metrics": {
                    key: {"home": value.home, "away": value.away}
                    for key, value in metrics.items()
                },
            }
        finally:
            flash.close()
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--network", action="store_true")
    args = parser.parse_args()

    report: dict[str, Any] = {
        "generated_at": utc_now(),
        "python": sys.version,
        "platform": platform.platform(),
        "source_policy": {
            "sofascore_enabled": SOFASCORE_ENABLED,
            "status_score_order": list(STATUS_SCORE_ORDER),
            "team_metric_order": list(TEAM_METRIC_ORDER),
        },
        "static": static_checks(),
        "database": db_readonly_health(DATA / "oddshunter.db"),
    }
    if args.network:
        report["network"] = network_checks()

    static_ok = (
        all(report["static"]["files"].values())
        and all(value == "PASS" for value in report["static"]["imports"].values())
        and report["source_policy"]["sofascore_enabled"] is False
    )
    report["static_pass"] = bool(static_ok)

    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    out = REPORT_DIR / "cloud_stage1_preflight.json"
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    print(f"REPORT={out}")
    return 0 if static_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
