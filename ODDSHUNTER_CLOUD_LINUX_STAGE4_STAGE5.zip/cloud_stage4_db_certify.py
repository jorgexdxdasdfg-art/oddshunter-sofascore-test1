from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
DB = DATA / "oddshunter.db"
REGISTRY = DATA / "competitions.json"
ARTIFACTS = ROOT / "artifacts"
PRIORITY = (
    "premier-league",
    "serie-a",
    "championship",
    "bundesliga",
    "eredivisie",
    "ligue-1",
    "saudi-pro-league",
    "turkey-super-lig",
    "canada-canadian-premier-league",
    "greece-stoiximan-super-league",
)

TERMINAL = {"FT", "AET", "PEN", "FINISHED", "FINAL"}


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def parse_dt(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        d = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None
    if d.tzinfo is None:
        d = d.replace(tzinfo=timezone.utc)
    return d.astimezone(timezone.utc)


def db_snapshot(con: sqlite3.Connection) -> dict[str, Any]:
    required = ("leagues", "teams", "matches", "team_match_stats")
    tables = {
        str(r[0])
        for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")
    }
    counts = {}
    for table in required:
        counts[table] = (
            int(con.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])
            if table in tables else None
        )
    return {
        "quick_check": str(con.execute("PRAGMA quick_check").fetchone()[0]),
        "foreign_key_errors": len(con.execute("PRAGMA foreign_key_check").fetchall()),
        "tables_present": {t: t in tables for t in required},
        "counts": counts,
    }


def registry_maps() -> tuple[dict[int, dict[str, Any]], list[dict[str, Any]]]:
    doc = load_json(REGISTRY)
    active = [
        x for x in doc.get("competitions", [])
        if isinstance(x, dict) and bool(x.get("active")) and x.get("league_id") is not None
    ]
    by_league = {}
    for x in active:
        by_league.setdefault(int(x["league_id"]), x)
    return by_league, active


def fetch_candidates(con: sqlite3.Connection, by_league: dict[int, dict[str, Any]]) -> list[dict[str, Any]]:
    rows = con.execute(
        """
        SELECT
            m.match_id, m.sofascore_id, m.league_id, m.season, m.kickoff, m.status,
            h.sofascore_id AS home_team_id, h.name AS home_team,
            a.sofascore_id AS away_team_id, a.name AS away_team
        FROM matches m
        JOIN teams h ON h.team_id=m.home_team_id
        JOIN teams a ON a.team_id=m.away_team_id
        WHERE m.sofascore_id IS NOT NULL
          AND h.sofascore_id IS NOT NULL
          AND a.sofascore_id IS NOT NULL
        ORDER BY m.kickoff DESC, m.match_id DESC
        LIMIT 5000
        """
    ).fetchall()
    raw = [dict(r) for r in rows]
    result = []
    seen = set()
    priority_rank = {k: i for i, k in enumerate(PRIORITY)}
    for row in raw:
        comp = by_league.get(int(row["league_id"]))
        if not comp:
            continue
        key = str(comp.get("key") or "")
        if key in seen:
            continue
        if str(row.get("status") or "").upper() not in TERMINAL:
            continue
        kickoff = parse_dt(row.get("kickoff"))
        if kickoff is None:
            continue
        row["_competition"] = comp
        result.append(row)
        seen.add(key)
    result.sort(key=lambda r: (priority_rank.get(str(r["_competition"].get("key")), 999), str(r.get("kickoff") or "")), reverse=False)
    return result


def schedule_row(row: dict[str, Any]) -> dict[str, Any]:
    comp = row["_competition"]
    dt = parse_dt(row["kickoff"])
    assert dt is not None
    return {
        "event_id": int(row["sofascore_id"]),
        "start_timestamp": int(dt.timestamp()),
        "kickoff": dt.isoformat(),
        "home_team_id": int(row["home_team_id"]),
        "home_team": str(row["home_team"]),
        "away_team_id": int(row["away_team_id"]),
        "away_team": str(row["away_team"]),
        "competition_id": comp.get("source_competition_id"),
        "competition_name": comp.get("name"),
        "season_id": comp.get("season_id"),
        "season_name": comp.get("season_name") or row.get("season") or "",
        "status": "NS",
        "_cloud_probe": True,
        "_original_db_match_id": int(row["match_id"]),
        "_original_status": row.get("status"),
    }


def write_schedule(key: str, match: dict[str, Any]) -> Path:
    path = DATA / "competitions" / key / "matches_upcoming.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({
        "generated_at": now(),
        "source": "cloud_stage4_retrospective_probe",
        "matches": [match],
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def run(cmd: list[str], env: dict[str, str] | None = None) -> dict[str, Any]:
    p = subprocess.run(
        cmd, cwd=ROOT, text=True, encoding="utf-8", errors="replace",
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env
    )
    return {"returncode": p.returncode, "output": p.stdout[-30000:]}


def main() -> int:
    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    report: dict[str, Any] = {
        "generated_at": now(),
        "runtime_mode": os.environ.get("ODDSHUNTER_RUNTIME_MODE"),
        "db_path": str(DB),
        "official_pc_db_touched": False,
        "training_invoked": False,
        "probes": [],
    }

    if os.environ.get("ODDSHUNTER_RUNTIME_MODE") != "cloud":
        raise RuntimeError("Stage4 exige ODDSHUNTER_RUNTIME_MODE=cloud")
    if not DB.exists():
        raise FileNotFoundError("Falta data/oddshunter.db: sube el WORKING STATE ZIP.")

    before_hash = sha256(DB)
    report["db_sha_before"] = before_hash

    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    try:
        before = db_snapshot(con)
        by_league, active = registry_maps()
        existing_leagues = {
            int(r[0]) for r in con.execute("SELECT league_id FROM leagues")
        }
        mapped_active = [x for x in active if int(x["league_id"]) in existing_leagues]
        report["registry_active_competitions"] = len(active)
        report["registry_active_leagues_present_in_db"] = len(mapped_active)
        report["db_before"] = before
        report["trained_model_files"] = len(list((DATA / "trained_models").rglob("*.json"))) if (DATA / "trained_models").exists() else 0

        candidates = fetch_candidates(con, by_league)
    finally:
        con.close()

    for row in candidates[:2]:
        comp = row["_competition"]
        key = str(comp["key"])
        event_id = int(row["sofascore_id"])
        match = schedule_row(row)
        schedule = write_schedule(key, match)

        analysis = run([
            sys.executable, "-u", str(ROOT / "analyze_upcoming_matches.py"),
            "--key", key, "--event-id", str(event_id), "--force", "--no-set-latest",
        ])
        bundle_path = DATA / "analisis" / key / str(event_id) / "analysis.json"
        bundle = load_json(bundle_path) if bundle_path.exists() else {}

        shots = {"returncode": None, "output": ""}
        ratings_path = DATA / "analisis" / key / str(event_id) / "ratings.json"
        shots_path = DATA / "modelos" / "shots" / key / f"shots_{event_id}.json"
        if ratings_path.exists():
            shots = run([
                sys.executable, "-u", str(ROOT / "shots_model.py"),
                "--key", key, "--match-json", str(ratings_path),
            ])

        report["probes"].append({
            "competition_key": key,
            "event_id": event_id,
            "match": f"{row['home_team']} vs {row['away_team']}",
            "kickoff": row["kickoff"],
            "schedule": str(schedule),
            "analysis_returncode": analysis["returncode"],
            "analysis_status": bundle.get("status"),
            "analysis_errors": bundle.get("errors"),
            "shots_returncode": shots["returncode"],
            "shots_output_exists": shots_path.exists(),
            "analysis_log_tail": analysis["output"][-8000:],
            "shots_log_tail": shots["output"][-8000:],
        })

    after_hash = sha256(DB)
    report["db_sha_after"] = after_hash
    report["db_byte_identical_after_model_probes"] = before_hash == after_hash

    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    try:
        report["db_after"] = db_snapshot(con)
    finally:
        con.close()

    full = sum(1 for x in report["probes"] if x.get("analysis_status") == "FULL")
    shots_ok = sum(1 for x in report["probes"] if x.get("shots_returncode") == 0 and x.get("shots_output_exists"))
    criteria = {
        "quick_check_ok": report["db_after"]["quick_check"] == "ok",
        "foreign_keys_zero": report["db_after"]["foreign_key_errors"] == 0,
        "required_tables_present": all(report["db_after"]["tables_present"].values()),
        "core_counts_nonzero": all((report["db_after"]["counts"].get(k) or 0) > 0 for k in ("leagues", "teams", "matches", "team_match_stats")),
        "active_registry_leagues_present_at_least_20": report["registry_active_leagues_present_in_db"] >= 20,
        "at_least_one_full_model_probe": full >= 1,
        "at_least_one_shots_probe": shots_ok >= 1,
        "db_unchanged_by_analysis": report["db_byte_identical_after_model_probes"] is True,
        "training_not_invoked": True,
    }
    report["criteria"] = criteria
    report["stage4_pass"] = all(criteria.values())

    out = ARTIFACTS / "cloud_stage4_db_certification.json"
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    print("REPORT =", out)
    print("STAGE4_PASS =", report["stage4_pass"])
    return 0 if report["stage4_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
