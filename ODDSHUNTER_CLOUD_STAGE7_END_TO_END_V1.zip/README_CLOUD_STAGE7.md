# OddsHunter Cloud Stage7 End-to-End V1

Stage7 parte del working state certificado que produjo Stage6 V1.2 y ejecuta un ciclo completo sobre GitHub Actions:

1. Recupera el artifact inmutable de Stage6 PASS.
2. Verifica SHA del working state Stage6.
3. Monta runtime V4 + publisher Stage6 V1.2.
4. Preflight Turso READ ONLY.
5. Ejecuta Stage5 V4: discovery + result sync COMMITTED + análisis.
6. Ejecuta el publisher Stage6 V1.2 hacia Turso.
7. Certifica Vercel `/api/health`.
8. Certifica que los targets mobile publicados se sirven por `/api/match/...`.
9. Certifica `quick_check=ok`, FK=0 y consistencia SHA.
10. Genera `ODDSHUNTER_CLOUD_WORKING_STATE_STAGE7.zip`.

No toca la DB oficial de Windows y no entrena modelos.

## Base Stage6 inmutable

- Run ID: `32970390866`
- Artifact ID: `9607438463`
- Artifact name: `oddshunter-cloud-stage6-publisher-v1-2-report`
- Working state SHA256:
  `CA39C0706D19AEA5B154C59D593EA736C1E2F9A48FCE5837373F910EB7BDCB26`
- Working DB SHA256:
  `960286BA8C6AA399A23948C6C7E9081331F2C1E2DB9FD91C0E130C41090B2058`

El workflow usa `actions: read` y `github.token` para recuperar ese artifact del mismo repo; no requiere un PAT nuevo.

## Cierre esperado

`STAGE7_SELF_TEST=PASS`
`HRANA_FLOAT_ARG_GATE=PASS`
`STAGE6_BOOLEAN_GATE=PASS`
`STAGE5_PASS=True`
`STAGE6_PASS=True`
`STAGE7_PASS=True`
`FINAL=PASS_STAGE7_END_TO_END`
