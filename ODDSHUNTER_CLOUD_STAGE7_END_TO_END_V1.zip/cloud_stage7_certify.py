from __future__ import annotations

import argparse
import hashlib
import json
import os
import sqlite3
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
DB = DATA / "oddshunter.db"
REGISTRY = DATA / "competitions.json"
ARTIFACTS = ROOT / "artifacts"

STAGE5_REPORT = ARTIFACTS / "cloud_stage5_cycle.json"
STAGE6_REPORT = ARTIFACTS / "cloud_stage6_publisher.json"
STAGE7_REPORT = ARTIFACTS / "cloud_stage7_certification.json"
NEXT_STATE_ZIP = ARTIFACTS / "ODDSHUNTER_CLOUD_WORKING_STATE_STAGE7.zip"

MOBILE_BASE_URL = os.environ.get(
    "ODDSHUNTER_MOBILE_BASE_URL",
    "https://oddshunter-mobile.vercel.app",
).rstrip("/")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def read_json(path: Path) -> dict[str, Any]:
    obj = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(obj, dict):
        raise RuntimeError(f"JSON raíz no es objeto: {path}")
    return obj


def sqlite_snapshot() -> dict[str, Any]:
    if not DB.is_file():
        raise FileNotFoundError(f"Falta working SQLite: {DB}")

    uri = f"file:{DB.as_posix()}?mode=ro"
    con = sqlite3.connect(uri, uri=True)
    try:
        quick = con.execute("PRAGMA quick_check;").fetchone()
        fk_rows = con.execute("PRAGMA foreign_key_check;").fetchall()
        tables = {
            str(r[0])
            for r in con.execute(
                "SELECT name FROM sqlite_master WHERE type='table';"
            ).fetchall()
        }
        required = {"leagues", "teams", "matches", "team_match_stats"}
        missing = sorted(required - tables)
        if missing:
            raise RuntimeError(f"Faltan tablas core: {missing}")

        return {
            "quick_check": str(quick[0]) if quick else None,
            "foreign_key_errors": len(fk_rows),
            "leagues": int(con.execute("SELECT COUNT(*) FROM leagues;").fetchone()[0]),
            "teams": int(con.execute("SELECT COUNT(*) FROM teams;").fetchone()[0]),
            "matches": int(con.execute("SELECT COUNT(*) FROM matches;").fetchone()[0]),
            "team_match_stats": int(
                con.execute("SELECT COUNT(*) FROM team_match_stats;").fetchone()[0]
            ),
        }
    finally:
        con.close()


def http_json(
    url: str,
    *,
    attempts: int = 10,
    delay_seconds: float = 5.0,
    timeout: float = 20.0,
) -> tuple[dict[str, Any], int]:
    errors: list[str] = []
    for attempt in range(1, attempts + 1):
        try:
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "OddsHunter-Stage7-Certification/1.0",
                    "Accept": "application/json",
                    "Cache-Control": "no-cache",
                },
            )
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                status = int(getattr(resp, "status", 200))
                body = resp.read()
            if status != 200:
                raise RuntimeError(f"HTTP {status}")
            obj = json.loads(body.decode("utf-8"))
            if not isinstance(obj, dict):
                raise RuntimeError("Respuesta JSON raíz no es objeto")
            return obj, attempt
        except Exception as exc:
            errors.append(f"{type(exc).__name__}: {exc}")
            if attempt < attempts:
                time.sleep(delay_seconds)

    raise RuntimeError(
        f"HTTP JSON falló tras {attempts} intentos: {url}; "
        f"últimos errores={errors[-3:]}"
    )


def vercel_health_criteria(
    health: dict[str, Any],
    remote_after: dict[str, Any],
) -> dict[str, bool]:
    analysis_docs = int(health.get("analysis_docs") or 0)
    mobile_events = int(health.get("mobile_events") or 0)
    expected_docs = int(remote_after.get("mobile_analysis_docs") or 0)
    expected_events = int(remote_after.get("mobile_events") or 0)

    return {
        "vercel_health_ok": health.get("ok") is True,
        "vercel_source_turso": str(health.get("source") or "") == "turso",
        "vercel_read_only": health.get("read_only") is True,
        "vercel_remote_health": health.get("remote_health") is True,
        "vercel_tables_present": int(health.get("tables") or 0) >= 32,
        "vercel_analysis_docs_cover_turso":
            analysis_docs >= expected_docs and expected_docs > 0,
        "vercel_mobile_events_cover_turso":
            mobile_events >= expected_events and expected_events > 0,
    }


def probe_vercel_targets(targets: list[str]) -> list[dict[str, Any]]:
    if not targets:
        raise RuntimeError("Stage6 no reportó targets mobile para certificar en Vercel")

    probes: list[dict[str, Any]] = []
    for target in targets:
        if "/" not in target:
            raise RuntimeError(f"Target mobile inválido: {target!r}")
        competition_key, event_id_raw = target.rsplit("/", 1)
        event_id = int(event_id_raw)
        encoded_key = urllib.parse.quote(competition_key, safe="")
        url = f"{MOBILE_BASE_URL}/api/match/{encoded_key}/{event_id}"
        payload, used_attempts = http_json(
            url,
            attempts=8,
            delay_seconds=5.0,
            timeout=25.0,
        )
        event = payload.get("event")
        if not isinstance(event, dict):
            raise RuntimeError(f"Vercel target sin event: {target}")
        if str(event.get("competition_key") or "") != competition_key:
            raise RuntimeError(
                f"Vercel competition_key mismatch para {target}: "
                f"{event.get('competition_key')!r}"
            )
        if int(event.get("event_id") or 0) != event_id:
            raise RuntimeError(
                f"Vercel event_id mismatch para {target}: {event.get('event_id')!r}"
            )

        probes.append({
            "target": target,
            "url": url,
            "attempts": used_attempts,
            "analysis_status": payload.get("analysis_status"),
            "event_status": event.get("status"),
            "served": True,
        })
    return probes


def create_next_state_zip(report: dict[str, Any]) -> dict[str, Any]:
    ARTIFACTS.mkdir(parents=True, exist_ok=True)

    manifest = {
        "generated_at": utc_now(),
        "purpose": "OddsHunter cloud working SQLite COPY after Stage7 end-to-end certification",
        "source_stage": "Stage7",
        "source_db_modified_by_stage7_certifier": False,
        "working_copy_sha": sha256(DB),
        "working_copy_checks": report.get("working_sqlite"),
        "stage5_pass": report.get("stage5_pass"),
        "stage6_pass": report.get("stage6_pass"),
        "stage7_pass": report.get("stage7_pass"),
        "turso_remote_after": report.get("turso_remote_after"),
        "vercel_health": report.get("vercel_health"),
    }

    include_files: list[tuple[Path, str]] = []
    for path, arc in (
        (DB, "data/oddshunter.db"),
        (REGISTRY, "data/competitions.json"),
        (DATA / "team_identity_registry.json", "data/team_identity_registry.json"),
        (DATA / "manifests" / "source_profiles.json", "data/manifests/source_profiles.json"),
    ):
        if path.is_file():
            include_files.append((path, arc))

    trained = DATA / "trained_models"
    if trained.is_dir():
        for path in trained.rglob("*"):
            if path.is_file():
                include_files.append((path, path.relative_to(ROOT).as_posix()))

    with zipfile.ZipFile(
        NEXT_STATE_ZIP,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=6,
    ) as z:
        z.writestr(
            "CLOUD_WORKING_STATE_MANIFEST.json",
            json.dumps(manifest, ensure_ascii=False, indent=2),
        )
        for path, arc in include_files:
            z.write(path, arc)

    return {
        "path": str(NEXT_STATE_ZIP),
        "sha256": sha256(NEXT_STATE_ZIP),
        "bytes": NEXT_STATE_ZIP.stat().st_size,
        "files": 1 + len(include_files),
    }


def synthetic_self_test() -> int:
    remote = {
        "health": True,
        "mobile_analysis_docs": 13771,
        "mobile_events": 1694,
    }
    health = {
        "ok": True,
        "source": "turso",
        "read_only": True,
        "remote_health": True,
        "tables": 32,
        "analysis_docs": 13771,
        "mobile_events": 1694,
    }
    checks = vercel_health_criteria(health, remote)
    if not all(checks.values()):
        raise RuntimeError(f"Self-test health falló: {checks}")

    fake_event = {"competition_key": "premier-league", "event_id": 123}
    if fake_event["competition_key"] != "premier-league":
        raise RuntimeError("Self-test competition_key")
    if int(fake_event["event_id"]) != 123:
        raise RuntimeError("Self-test event_id")

    print("STAGE7_SELF_TEST=PASS")
    return 0


def certify() -> dict[str, Any]:
    if not STAGE5_REPORT.is_file():
        raise FileNotFoundError(f"Falta {STAGE5_REPORT}")
    if not STAGE6_REPORT.is_file():
        raise FileNotFoundError(f"Falta {STAGE6_REPORT}")

    stage5 = read_json(STAGE5_REPORT)
    stage6 = read_json(STAGE6_REPORT)
    local = sqlite_snapshot()
    db_sha = sha256(DB)

    sync = stage5.get("sync_result_counts") or {}
    discovery = stage5.get("discovery") or {}
    analyses = stage5.get("analysis") or []
    stage5_criteria = stage5.get("criteria") or {}
    stage6_criteria = stage6.get("criteria") or {}
    remote_after = stage6.get("remote_after") or {}
    core_rows = stage6.get("core_rows_published") or {}
    mobile = stage6.get("mobile") or {}

    full_analysis = any(
        isinstance(x, dict) and x.get("analysis_status") == "FULL"
        for x in analyses
    )
    shots_pass = any(
        isinstance(x, dict)
        and x.get("shots_returncode") == 0
        and x.get("shots_output_exists") is True
        for x in analyses
    )

    health_url = f"{MOBILE_BASE_URL}/api/health"
    health, health_attempts = http_json(
        health_url,
        attempts=12,
        delay_seconds=5.0,
        timeout=25.0,
    )
    health_checks = vercel_health_criteria(health, remote_after)

    targets = [
        str(x)
        for x in (mobile.get("targets") or [])
        if isinstance(x, str) and x.strip()
    ]
    vercel_target_probes = probe_vercel_targets(targets)

    criteria: dict[str, bool] = {
        "stage5_pass": stage5.get("stage5_pass") is True,
        "stage5_all_internal_criteria_true":
            bool(stage5_criteria) and all(v is True for v in stage5_criteria.values()),
        "stage5_discovery_found_real_matches":
            int(discovery.get("unique_rows_in_window") or 0) > 0,
        "stage5_result_sync_committed_at_least_1":
            int(sync.get("committed") or 0) >= 1,
        "stage5_result_sync_technical_errors_zero":
            int(sync.get("technical_errors") or 0) == 0,
        "stage5_result_sync_source_unavailable_zero":
            int(sync.get("source_unavailable") or 0) == 0,
        "stage5_future_analysis_full_at_least_1": full_analysis,
        "stage5_shots_pass_at_least_1": shots_pass,

        "stage6_pass": stage6.get("stage6_pass") is True,
        "stage6_all_internal_criteria_true":
            bool(stage6_criteria) and all(v is True for v in stage6_criteria.values()),
        "stage6_input_sha_matches_stage5":
            str(stage6.get("stage5_db_sha_after") or "").upper()
            == str(stage5.get("db_sha_after") or "").upper()
            == str(stage6.get("db_sha_before_publisher") or "").upper(),
        "stage6_publisher_kept_working_db_byte_identical":
            str(stage6.get("db_sha_before_publisher") or "").upper()
            == str(stage6.get("db_sha_after_publisher") or "").upper()
            == db_sha,
        "stage6_turso_health": remote_after.get("health") is True,
        "stage6_turso_matches_equal_working":
            int(remote_after.get("matches") or -1) == int(local["matches"]),
        "stage6_turso_stats_equal_working":
            int(remote_after.get("team_match_stats") or -1)
            == int(local["team_match_stats"]),
        "stage6_core_match_published":
            int(core_rows.get("matches") or 0) >= 1,
        "stage6_core_stats_published":
            int(core_rows.get("team_match_stats") or 0) >= 2,
        "stage6_mobile_events_published":
            int(mobile.get("event_rows") or 0) >= 1,
        "stage6_mobile_docs_published":
            int(mobile.get("doc_rows") or 0) >= 1,
        "stage6_no_invalid_mobile_json":
            len(mobile.get("invalid_json") or []) == 0,

        "working_sqlite_quick_check_ok": local["quick_check"] == "ok",
        "working_sqlite_fk_zero": int(local["foreign_key_errors"]) == 0,
        "working_sqlite_matches_not_empty": int(local["matches"]) > 0,
        "working_sqlite_stats_not_empty": int(local["team_match_stats"]) > 0,

        "training_not_invoked":
            stage5.get("training_invoked") is False
            and stage6.get("training_invoked") is False,
        "official_windows_db_untouched":
            stage5.get("official_pc_db_touched") is False
            and stage6.get("official_pc_db_touched") is False,

        **health_checks,
        "vercel_all_stage6_mobile_targets_served":
            len(vercel_target_probes) == len(targets)
            and len(targets) >= 1
            and all(x.get("served") is True for x in vercel_target_probes),
    }

    report: dict[str, Any] = {
        "generated_at": utc_now(),
        "stage": "Stage7",
        "purpose": (
            "End-to-end certification: discovery -> result sync COMMITTED -> "
            "analysis -> Turso publish -> Vercel/API health -> SQLite integrity"
        ),
        "mobile_base_url": MOBILE_BASE_URL,
        "training_invoked": False,
        "official_pc_db_touched": False,
        "stage5_pass": stage5.get("stage5_pass"),
        "stage6_pass": stage6.get("stage6_pass"),
        "stage5_sync_result_counts": sync,
        "stage5_discovery": {
            "upcoming_count": discovery.get("upcoming_count"),
            "finished_count": discovery.get("finished_count"),
            "unique_rows_in_window": discovery.get("unique_rows_in_window"),
        },
        "stage5_analysis": [
            {
                "competition_key": x.get("competition_key"),
                "event_id": x.get("event_id"),
                "analysis_status": x.get("analysis_status"),
                "shots_returncode": x.get("shots_returncode"),
                "shots_output_exists": x.get("shots_output_exists"),
            }
            for x in analyses
            if isinstance(x, dict)
        ],
        "working_sqlite": local,
        "working_db_sha256": db_sha,
        "turso_remote_before": stage6.get("remote_before"),
        "turso_remote_after": remote_after,
        "core_rows_published": core_rows,
        "mobile_publish": mobile,
        "vercel_health_url": health_url,
        "vercel_health_attempts": health_attempts,
        "vercel_health": health,
        "vercel_target_probes": vercel_target_probes,
        "criteria": criteria,
        "stage7_pass": all(criteria.values()),
    }

    if report["stage7_pass"]:
        report["next_working_state"] = create_next_state_zip(report)

    return report


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()

    if args.self_test:
        return synthetic_self_test()

    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    print("=" * 78)
    print("ODDSHUNTER CLOUD STAGE7 - CERTIFICACION END-TO-END")
    print("Stage5 -> Stage6/Turso -> Vercel/API -> integridad working SQLite")
    print("NO toca la DB oficial de Windows. NO entrena.")
    print("=" * 78)

    try:
        report = certify()
    except Exception as exc:
        report = {
            "generated_at": utc_now(),
            "stage": "Stage7",
            "training_invoked": False,
            "official_pc_db_touched": False,
            "fatal_error": f"{type(exc).__name__}: {exc}",
            "stage7_pass": False,
        }

    STAGE7_REPORT.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(json.dumps(report, ensure_ascii=False, indent=2))
    print("REPORT =", STAGE7_REPORT)
    print("STAGE7_PASS =", report.get("stage7_pass"))
    if report.get("next_working_state"):
        print("NEXT_WORKING_STATE =", report["next_working_state"])
    print(
        "FINAL="
        + (
            "PASS_STAGE7_END_TO_END"
            if report.get("stage7_pass")
            else "FAIL_STAGE7_END_TO_END"
        )
    )
    return 0 if report.get("stage7_pass") else 1


if __name__ == "__main__":
    raise SystemExit(main())
