# OddsHunter Stage9 — APK DEV V1

Objetivo: generar **solo una APK Android de desarrollo**, instalable manualmente.
No publica en Google Play, no exige Play Console, no genera AAB como objetivo y
no requiere pagar la tarifa de Google Play.

## Arquitectura de esta APK

La APK es un contenedor Android de Capacitor que abre directamente:

`https://oddshunter-mobile.vercel.app`

Por eso es especialmente útil mientras OddsHunter sigue en desarrollo:
los cambios del frontend publicados en Vercel aparecen dentro de la APK sin
tener que recompilarla cada vez. Solo hace falta recompilar cuando cambie la
capa Android/nativa.

## Identidad Android

- App name: `OddsHunter`
- Application ID: `com.oddshunter.mobile`
- Capacitor: `8.5.0`
- Tipo: debug APK
- Firma: debug key generada automáticamente por Gradle/GitHub Actions
- Google Play: NO
- AAB: NO requerido

## Gates del workflow

1. SHA exacto del paquete Stage9.
2. Verificación estática de config.
3. Health real de Vercel/Turso antes de construir.
4. Instalación exacta de Capacitor 8.5.0.
5. Creación y sincronización Android.
6. Verificación de HTTPS / no mixed content.
7. `assembleDebug`.
8. Verificación criptográfica de firma APK con `apksigner`.
9. SHA256 + tamaño del APK.
10. Artifact GitHub con `OddsHunter-DEV.apk` y reporte JSON.

Cierre esperado:

`STAGE9_APK_BUILD=PASS`
`STAGE9_APK_SIGNATURE=PASS`
`FINAL=PASS_STAGE9_APK_DEV`

Después se descarga el artifact y se instala el APK directamente en Android.
