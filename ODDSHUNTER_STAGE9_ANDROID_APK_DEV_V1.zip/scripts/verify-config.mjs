import fs from "node:fs";

const pkg = JSON.parse(fs.readFileSync("package.json", "utf8"));
const cap = JSON.parse(fs.readFileSync("capacitor.config.json", "utf8"));

const fail = (msg) => {
  console.error("STAGE9_CONFIG_ERROR:", msg);
  process.exit(1);
};

if (cap.appId !== "com.oddshunter.mobile") fail("appId inesperado");
if (cap.appName !== "OddsHunter") fail("appName inesperado");
if (cap.webDir !== "www") fail("webDir inesperado");
if (cap.server?.url !== "https://oddshunter-mobile.vercel.app") fail("server.url inesperada");
if (cap.server?.cleartext !== false) fail("cleartext debe ser false");
if (cap.server?.androidScheme !== "https") fail("androidScheme debe ser https");
if (!Array.isArray(cap.server?.allowNavigation) ||
    !cap.server.allowNavigation.includes("oddshunter-mobile.vercel.app")) {
  fail("allowNavigation no contiene Vercel");
}
if (cap.android?.allowMixedContent !== false) fail("allowMixedContent debe ser false");

for (const name of ["@capacitor/core", "@capacitor/android"]) {
  if (pkg.dependencies?.[name] !== "8.5.0") fail(`${name} no está fijado a 8.5.0`);
}
if (pkg.devDependencies?.["@capacitor/cli"] !== "8.5.0") fail("@capacitor/cli no está fijado a 8.5.0");

if (!fs.existsSync("www/index.html")) fail("falta fallback www/index.html");

console.log("STAGE9_CONFIG_GATE=PASS");
console.log("STAGE9_MODE=DEVELOPMENT_APK_ONLY");
console.log("STAGE9_GOOGLE_PLAY=NO");
console.log("STAGE9_AAB_REQUIRED=NO");
