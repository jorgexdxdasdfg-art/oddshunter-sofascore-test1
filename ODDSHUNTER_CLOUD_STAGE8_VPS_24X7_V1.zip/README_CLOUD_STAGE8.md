# OddsHunter Cloud Stage8 VPS 24/7 V1

Stage8 instala el runtime cloud ya certificado por Stage7 en un VPS Ubuntu 24.04 x86_64 y lo deja administrado por systemd.

## Base inmutable

Stage7 PASS:
- GitHub run: `32971592299`
- Artifact ID: `9607872792`
- Artifact: `oddshunter-cloud-stage7-end-to-end-v1-report`
- Working state: `ODDSHUNTER_CLOUD_WORKING_STATE_STAGE7.zip`
- Working state SHA256: `64546C16BA9676CE0243D2560EEE3193272451D6246D7712BD58CAF886C8CA26`
- Working DB SHA256: `809E93FBF664F8CD86B6C21D9D0AC0E47BBE134BBBD0CE1A2FB6AF8981E1171F`

## Arquitectura instalada

`systemd -> stage8_daemon.py -> Stage5 V4 -> Stage6 V1.2 -> Turso -> Vercel`

El daemon:
- arranca inmediatamente al boot;
- ejecuta un ciclo cada 15 minutos por defecto;
- reintenta fallos operativos cada 2 minutos;
- nunca invoca entrenamiento;
- usa Futbol24 como principal y Flashscore/Chromium como fallback mediante el runtime ya certificado;
- guarda SQLite y artefactos en `/var/lib/oddshunter`;
- conserva código en releases bajo `/opt/oddshunter/releases`;
- usa `Restart=always`.

## VPS exigido por V1

- Ubuntu 24.04
- x86_64
- mínimo 2 vCPU
- mínimo ~4 GB RAM
- mínimo 12 GB libres en disco al instalar
- systemd
- usuario SSH root o usuario con `sudo -n`

## Secrets GitHub necesarios para desplegar

Ya existentes:
- `TURSO_DATABASE_URL`
- `TURSO_AUTH_TOKEN`

Nuevos:
- `VPS_HOST`
- `VPS_USER`
- `VPS_SSH_PRIVATE_KEY`

Opcional:
- `VPS_PORT` (si falta usa 22)

El workflow nunca imprime el token Turso ni la clave SSH.

## Gate de cierre Stage8

Después del deploy, el workflow espera el primer ciclo real y exige:
- servicio systemd active + enabled;
- `Restart=always`;
- Stage5 PASS;
- sync COMMITTED >= 1;
- technical_errors=0;
- source_unavailable=0;
- Stage6 PASS;
- Turso health;
- SQLite quick_check=ok y FK=0;
- Vercel source=turso, read_only=true, remote_health=true;
- targets publicados servidos por `/api/match`;
- training_not_invoked=true;
- official Windows DB untouched=true.

Cierre esperado:

`STAGE8_PASS = True`
`FINAL=PASS_STAGE8_VPS_24X7`
