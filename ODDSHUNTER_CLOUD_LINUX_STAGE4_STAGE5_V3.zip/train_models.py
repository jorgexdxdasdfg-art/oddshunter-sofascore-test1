from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
CORE_SCRIPT = BASE_DIR / "train_models_core.py"
SHOTS_SCRIPT = BASE_DIR / "train_shots_models.py"
SYNC_ELO_SCRIPT = BASE_DIR / "sync_elo.py"
ELO_FIT_SCRIPT = BASE_DIR / "elo_goals_fit.py"
WRAPPER_MARKER = "ODDSHUNTER_ELO_TRAIN_WRAPPER_V1"


def configure_utf8() -> None:
    os.environ.setdefault("PYTHONUTF8", "1")
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass


def extract_arguments(arguments: list[str]) -> tuple[str, str | None]:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--key", required=True)
    parser.add_argument("--holdout")
    known, _ = parser.parse_known_args(arguments)
    return str(known.key), known.holdout


def run(command: list[str]) -> int:
    print("$ " + " ".join(command), flush=True)
    return subprocess.call(
        command,
        cwd=BASE_DIR,
        env={
            **os.environ,
            "PYTHONUTF8": "1",
            "PYTHONIOENCODING": "utf-8",
        },
    )


def main() -> int:
    configure_utf8()
    arguments = sys.argv[1:]
    key, holdout = extract_arguments(arguments)

    for path in (CORE_SCRIPT, SHOTS_SCRIPT, SYNC_ELO_SCRIPT, ELO_FIT_SCRIPT):
        if not path.exists():
            print(f"ERROR: no existe el módulo requerido: {path}")
            return 1

    code = run([sys.executable, "-u", str(SYNC_ELO_SCRIPT), "--key", key])
    if code != 0:
        return code

    code = run([sys.executable, "-u", str(CORE_SCRIPT), *arguments])
    if code != 0:
        return code

    shots_command = [sys.executable, "-u", str(SHOTS_SCRIPT), "--key", key]
    if holdout is not None:
        shots_command.extend(["--holdout", str(holdout)])
    code = run(shots_command)
    if code != 0:
        return code

    elo_command = [sys.executable, "-u", str(ELO_FIT_SCRIPT), "--key", key]
    if holdout is not None:
        elo_command.extend(["--holdout", str(holdout)])
    code = run(elo_command)
    if code != 0:
        return code

    print()
    print("=" * 84)
    print("ENTRENAMIENTO AMPLIADO CON ELO TERMINADO")
    print("=" * 84)
    latest_path = BASE_DIR / "data" / "trained_models" / key / "latest_model.json"
    try:
        latest = json.loads(latest_path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        latest = {}
    learned_markets = [
        label
        for field, label in (
            ("goals", "goles"),
            ("corners", "córners"),
            ("cards", "tarjetas"),
        )
        if isinstance(latest.get(field), dict)
    ]
    print(
        "Modelo aprendido actualizado: "
        + (", ".join(learned_markets) or "ningún mercado")
        + ". Remates y remates a puerta se entrenaron por su modelo "
        "independiente; ELO conserva el estado validado disponible."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
