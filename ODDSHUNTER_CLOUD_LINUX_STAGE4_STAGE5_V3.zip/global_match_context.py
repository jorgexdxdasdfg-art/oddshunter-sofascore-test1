from __future__ import annotations

import json
import math
import re
import sqlite3
import unicodedata
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
DB = DATA / "oddshunter.db"
REGISTRY = DATA / "competitions.json"

TEAM_METRICS = (
    "goals_for", "goals_against", "xg_for", "xg_against", "shots",
    "shots_on_target", "corners_for", "corners_against", "yellow_cards",
    "red_cards", "goals_1h_for", "goals_1h_against", "goals_2h_for",
    "goals_2h_against",
)
WEIGHTS = {
    "goals_for": 1.174603, "goals_against": 1.174603,
    "xg_for": 1.174603, "xg_against": 1.174603,
    "corners_for": 1.076923, "corners_against": 1.076923,
    "yellow_cards": 1.0, "red_cards": 1.0,
    "shots": 1.636364, "shots_on_target": 1.636364,
    "goals_1h_for": 1.174603, "goals_1h_against": 1.174603,
    "goals_2h_for": 1.174603, "goals_2h_against": 1.174603,
}

def _json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception:
        return default

def _cols(con: sqlite3.Connection, table: str) -> set[str]:
    return {str(r[1]) for r in con.execute(f"PRAGMA table_info({table})")}

def _pick(cols: set[str], *names: str) -> str | None:
    return next((n for n in names if n in cols), None)

def _num(value: Any) -> float | None:
    if value is None:
        return None
    try:
        x = float(value)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None

def _int(value: Any) -> int | None:
    x = _num(value)
    return int(x) if x is not None else None

def _dt(value: Any) -> datetime | None:
    if value in (None, ""):
        return None
    text = str(value).strip().replace("Z", "+00:00")
    try:
        out = datetime.fromisoformat(text)
    except ValueError:
        try:
            return datetime.fromtimestamp(float(value), tz=timezone.utc)
        except Exception:
            return None
    return out.replace(tzinfo=timezone.utc) if out.tzinfo is None else out

def _registry_row(key: str) -> dict[str, Any]:
    doc = _json(REGISTRY, {"competitions": []})
    for row in doc.get("competitions", []):
        if isinstance(row, dict) and str(row.get("key") or "") == key:
            return dict(row)
    return {}

def _league_row(con: sqlite3.Connection, reg: dict[str, Any]) -> dict[str, Any]:
    cols = _cols(con, "leagues")
    if reg.get("league_id") is not None:
        row = con.execute("SELECT * FROM leagues WHERE league_id=?", (int(reg["league_id"]),)).fetchone()
        if row:
            return dict(row)
    tc = _pick(cols, "source_tournament_id", "source_competition_id", "tournament_id")
    sc = _pick(cols, "source_season_id", "season_id")
    if tc and sc and reg.get("source_competition_id") is not None and reg.get("season_id") is not None:
        row = con.execute(
            f"SELECT * FROM leagues WHERE {tc}=? AND {sc}=? ORDER BY league_id DESC LIMIT 1",
            (int(reg["source_competition_id"]), int(reg["season_id"])),
        ).fetchone()
        if row:
            return dict(row)
    return {}

def _schedule_match(key: str, event_id: int) -> dict[str, Any]:
    reg = _registry_row(key)
    keys = [key]
    sk = str(reg.get("schedule_source_key") or "").strip()
    if sk and sk not in keys:
        keys.append(sk)
    # Exact tournament+season aliases are safe schedule fallbacks. No fuzzy matching.
    docreg = _json(REGISTRY, {"competitions": []})
    tid = reg.get("source_competition_id")
    sid = reg.get("season_id")
    for item in docreg.get("competitions", []):
        if not isinstance(item, dict):
            continue
        if str(item.get("source_competition_id")) == str(tid) and str(item.get("season_id")) == str(sid):
            k = str(item.get("key") or "").strip()
            if k and k not in keys:
                keys.append(k)
    for candidate in keys:
        doc = _json(DATA / "competitions" / candidate / "matches_upcoming.json", {})
        rows = doc if isinstance(doc, list) else doc.get("matches", []) if isinstance(doc, dict) else []
        for row in rows:
            if not isinstance(row, dict):
                continue
            try:
                rid = int(row.get("event_id") or row.get("id") or 0)
            except Exception:
                continue
            if rid == event_id:
                out = dict(row)
                out.setdefault("schedule_source_key", candidate)
                return out
    return {}

def _db_match(con: sqlite3.Connection, event_id: int) -> dict[str, Any]:
    cols = _cols(con, "matches")
    ec = _pick(cols, "sofascore_id", "event_id", "source_event_id")
    if not ec:
        return {}
    row = con.execute(f"SELECT * FROM matches WHERE {ec}=? ORDER BY match_id DESC LIMIT 1", (event_id,)).fetchone()
    return dict(row) if row else {}

def _source_team_id(row: dict[str, Any], side: str) -> int | None:
    for key in (
        f"{side}_sofascore_id",
        f"{side}_source_id",
        f"{side}_team_sofascore_id",
        f"{side}_team_id",
        f"{side}TeamId",
    ):
        if row.get(key) not in (None, ""):
            return _int(row[key])
    nested = row.get(side) or row.get(f"{side}_team")
    if isinstance(nested, dict):
        for key in ("id", "sofascore_id", "source_id"):
            if nested.get(key) not in (None, ""):
                return _int(nested[key])
    return None

def _resolve_team(con: sqlite3.Connection, source_id: int | None) -> int | None:
    if source_id is None:
        return None
    cols = _cols(con, "teams")
    sc = _pick(cols, "sofascore_id", "source_team_id", "source_id")
    if not sc:
        return None
    rows = con.execute(f"SELECT team_id FROM teams WHERE {sc}=?", (source_id,)).fetchall()
    ids = sorted({int(r[0]) for r in rows})
    return ids[0] if len(ids) == 1 else None

def _team_meta(con: sqlite3.Connection, team_id: int) -> tuple[str, int | None]:
    cols = _cols(con, "teams")
    nc = _pick(cols, "name", "team_name", "canonical_name")
    sc = _pick(cols, "sofascore_id", "source_team_id", "source_id")
    select = ",".join(x for x in (nc, sc) if x)
    if not select:
        return str(team_id), None
    row = con.execute(f"SELECT {select} FROM teams WHERE team_id=?", (team_id,)).fetchone()
    if not row:
        return str(team_id), None
    vals = dict(zip([x for x in (nc, sc) if x], row))
    return str(vals.get(nc) or team_id), _int(vals.get(sc)) if sc else None

def _scope(con: sqlite3.Connection, primary: dict[str, Any], team_id: int, reg: dict[str, Any] | None = None) -> list[int]:
    cols = _cols(con, "leagues")
    tc = _pick(cols, "source_tournament_id", "source_competition_id", "tournament_id")
    sc = _pick(cols, "source_season_id", "season_id")
    cc = _pick(cols, "country", "country_name")
    fc = _pick(cols, "competition_family")
    rc = _pick(cols, "context_role")
    ids: set[int] = set()
    if tc and primary.get(tc) is not None:
        ids.update(int(r[0]) for r in con.execute(f"SELECT league_id FROM leagues WHERE {tc}=?", (primary[tc],)).fetchall())
    elif primary.get("league_id") is not None:
        ids.add(int(primary["league_id"]))

    # Honor exact registry source-pair declarations. This is how split tournaments
    # (for example Colombia) retain their full domestic continuity without fuzzy joins.
    specification = reg if isinstance(reg, dict) else {}
    if tc and sc:
        for field in ("history_source_pairs", "profile_history_source_pairs"):
            for item in specification.get(field, []) or []:
                if not isinstance(item, dict):
                    continue
                tids = item.get("tournament_id", item.get("source_tournament_id"))
                sids = item.get("season_id", item.get("source_season_id"))
                try:
                    tids = int(tids); sids = int(sids)
                except (TypeError, ValueError):
                    continue
                allowed = item.get("team_sofascore_ids")
                if isinstance(allowed, list) and allowed:
                    _, team_sid = _team_meta(con, team_id)
                    try:
                        allowed_ids = {int(x) for x in allowed}
                    except Exception:
                        allowed_ids = set()
                    if team_sid is None or int(team_sid) not in allowed_ids:
                        continue
                rows = con.execute(
                    f"SELECT league_id FROM leagues WHERE {tc}=? AND {sc}=? ORDER BY league_id",
                    (tids, sids),
                ).fetchall()
                for row in rows:
                    lid = int(row[0])
                    if con.execute(
                        "SELECT 1 FROM matches WHERE league_id=? AND (home_team_id=? OR away_team_id=?) LIMIT 1",
                        (lid, team_id, team_id),
                    ).fetchone():
                        ids.add(lid)

    # Only explicit promoted/history profile contexts can extend a domestic scope.
    if rc:
        rows = con.execute(
            f"SELECT * FROM leagues WHERE UPPER(COALESCE({rc},'')) LIKE '%PROFILE%' OR UPPER(COALESCE({rc},'')) LIKE '%PROMOTED%'"
        ).fetchall()
        for rr in rows:
            r = dict(rr)
            if cc and primary.get(cc) and str(r.get(cc) or '').casefold() != str(primary.get(cc) or '').casefold():
                continue
            if fc and primary.get(fc) and r.get(fc) not in (None, "", primary.get(fc)):
                continue
            lid = int(r["league_id"])
            if con.execute(
                "SELECT 1 FROM matches WHERE league_id=? AND (home_team_id=? OR away_team_id=?) LIMIT 1",
                (lid, team_id, team_id),
            ).fetchone():
                ids.add(lid)
    return sorted(ids)

def _history(con: sqlite3.Connection, team_id: int, league_ids: list[int], cutoff: datetime | None) -> list[dict[str, Any]]:
    if not league_ids:
        return []
    mc = _cols(con, "matches")
    sc = _cols(con, "team_match_stats")
    # Score-derived goals are authoritative. Never overwrite them from team_match_stats.
    sfields = [c for c in (
        "xg_for", "xg_against", "shots", "shots_on_target",
        "corners_for", "corners_against", "yellow_cards", "red_cards", "data_quality"
    ) if c in sc]
    hfields = [c for c in ("home_goals_1h", "away_goals_1h", "home_goals_2h", "away_goals_2h") if c in mc]
    ph = ",".join("?" for _ in league_ids)
    q = f"""
    SELECT m.match_id,m.league_id,m.kickoff,m.home_team_id,m.away_team_id,m.home_goals,m.away_goals
           {''.join(',m.'+c for c in hfields)}
           {''.join(',s.'+c+' AS s_'+c for c in sfields)}
    FROM matches m LEFT JOIN team_match_stats s ON s.match_id=m.match_id AND s.team_id=?
    WHERE m.league_id IN ({ph}) AND (m.home_team_id=? OR m.away_team_id=?)
      AND m.home_goals IS NOT NULL AND m.away_goals IS NOT NULL
    """
    params: list[Any] = [team_id, *league_ids, team_id, team_id]
    if cutoff:
        q += " AND m.kickoff < ?"
        params.append(cutoff.isoformat())
    q += " ORDER BY m.kickoff DESC,m.match_id DESC LIMIT 300"
    out = []
    for rr in con.execute(q, params).fetchall():
        r = dict(rr); home = int(r["home_team_id"]) == team_id
        gf = int(r["home_goals"] if home else r["away_goals"]); ga = int(r["away_goals"] if home else r["home_goals"])
        x = {"match_id": int(r["match_id"]), "league_id": int(r["league_id"]), "kickoff": r["kickoff"],
             "venue": "HOME" if home else "AWAY", "goals_for": gf, "goals_against": ga,
             "result": "W" if gf > ga else "D" if gf == ga else "L"}
        for c in sfields:
            x[c] = r.get("s_" + c)
        if all(c in r for c in ("home_goals_1h", "away_goals_1h")):
            x["goals_1h_for"] = _int(r.get("home_goals_1h") if home else r.get("away_goals_1h"))
            x["goals_1h_against"] = _int(r.get("away_goals_1h") if home else r.get("home_goals_1h"))
        else:
            x["goals_1h_for"] = x["goals_1h_against"] = None
        if all(c in r for c in ("home_goals_2h", "away_goals_2h")):
            x["goals_2h_for"] = _int(r.get("home_goals_2h") if home else r.get("away_goals_2h"))
            x["goals_2h_against"] = _int(r.get("away_goals_2h") if home else r.get("home_goals_2h"))
        else:
            x["goals_2h_for"] = x["goals_2h_against"] = None
        out.append(x)
    return out

def _weighted(rows: list[dict[str, Any]], metric: str) -> float | None:
    vals = [(i, _num(r.get(metric))) for i, r in enumerate(rows[:15])]
    vals = [(i, v) for i, v in vals if v is not None]
    if not vals:
        return None
    mult = WEIGHTS.get(metric, 1.0)
    num = den = 0.0
    for i, v in vals:
        w = mult if i < 5 else 1.0
        num += float(v) * w; den += w
    return num / den if den else None

def _profile(rows: list[dict[str, Any]]) -> dict[str, Any]:
    rows = rows[:15]
    return {
        "matches": len(rows),
        "match_ids": [r["match_id"] for r in rows],
        "averages": {m: _weighted(rows, m) for m in TEAM_METRICS},
        "available_values": {m: sum(r.get(m) is not None for r in rows) for m in TEAM_METRICS},
        "form": {k: sum(r["result"] == v for r in rows) for k, v in (("wins","W"),("draws","D"),("losses","L"))},
        "rows": rows,
    }

def _rate(rows: list[dict[str, Any]], fn) -> float | None:
    if not rows:
        return None
    vals = []
    for r in rows[:15]:
        try: vals.append(bool(fn(r)))
        except Exception: pass
    return sum(vals) / len(vals) if vals else None

def _markets(rows: list[dict[str, Any]]) -> dict[str, float | None]:
    rows = rows[:15]
    total = lambda r: int(r["goals_for"]) + int(r["goals_against"])
    h1rows = [r for r in rows if r.get("goals_1h_for") is not None and r.get("goals_1h_against") is not None]
    h2rows = [r for r in rows if r.get("goals_2h_for") is not None and r.get("goals_2h_against") is not None]
    return {
        "win": _rate(rows, lambda r: r["result"] == "W"),
        "draw": _rate(rows, lambda r: r["result"] == "D"),
        "loss": _rate(rows, lambda r: r["result"] == "L"),
        "win_or_draw": _rate(rows, lambda r: r["result"] in ("W", "D")),
        "btts_yes": _rate(rows, lambda r: int(r["goals_for"]) > 0 and int(r["goals_against"]) > 0),
        "btts_no": _rate(rows, lambda r: not (int(r["goals_for"]) > 0 and int(r["goals_against"]) > 0)),
        "over_1_5": _rate(rows, lambda r: total(r) > 1.5),
        "under_1_5": _rate(rows, lambda r: total(r) < 1.5),
        "over_2_5": _rate(rows, lambda r: total(r) > 2.5),
        "under_2_5": _rate(rows, lambda r: total(r) < 2.5),
        "over_3_5": _rate(rows, lambda r: total(r) > 3.5),
        "under_3_5": _rate(rows, lambda r: total(r) < 3.5),
        "first_half_over_0_5": _rate(h1rows, lambda r: int(r["goals_1h_for"]) + int(r["goals_1h_against"]) > .5),
        "first_half_over_1_5": _rate(h1rows, lambda r: int(r["goals_1h_for"]) + int(r["goals_1h_against"]) > 1.5),
        "second_half_over_0_5": _rate(h2rows, lambda r: int(r["goals_2h_for"]) + int(r["goals_2h_against"]) > .5),
    }

def _player_name_col(con: sqlite3.Connection) -> str | None:
    return _pick(_cols(con, "players"), "name", "player_name", "canonical_name", "display_name")

def _players(con: sqlite3.Connection, team_id: int, match_ids: list[int]) -> list[dict[str, Any]]:
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if not match_ids or "player_match_stats" not in tables or "players" not in tables:
        return []
    nc = _player_name_col(con)
    if not nc: return []
    ph = ",".join("?" for _ in match_ids)
    rows = con.execute(f"""
        SELECT pms.match_id,pms.player_id,p.{nc} player_name,pms.is_starter,pms.minutes_played,
               pms.shots,pms.shots_on_target,pms.source
        FROM player_match_stats pms JOIN players p ON p.player_id=pms.player_id
        WHERE pms.team_id=? AND pms.match_id IN ({ph})
          AND pms.shots IS NOT NULL AND pms.shots_on_target IS NOT NULL
    """, (team_id, *match_ids)).fetchall()
    agg: dict[int, dict[str, Any]] = {}
    for rr in rows:
        r = dict(rr); pid = int(r["player_id"])
        a = agg.setdefault(pid, {"player_id": pid, "name": str(r["player_name"]), "appearances": 0,
                                 "starts": 0, "shots": 0, "shots_on_target": 0, "minutes": 0, "sources": set()})
        a["appearances"] += 1; a["starts"] += int(bool(r.get("is_starter")))
        a["shots"] += int(r.get("shots") or 0); a["shots_on_target"] += int(r.get("shots_on_target") or 0)
        a["minutes"] += int(r.get("minutes_played") or 0)
        if r.get("source"): a["sources"].add(str(r["source"]))
    out=[]
    for a in agg.values():
        n=a["appearances"]; a["sot_per_appearance"] = a["shots_on_target"] / n if n else None
        a["shots_per_appearance"] = a["shots"] / n if n else None; a["sources"] = sorted(a["sources"]); out.append(a)
    return sorted(out, key=lambda a: (-a["shots_on_target"], -a["shots"], a["name"]))

def _lineup(con: sqlite3.Connection, team_id: int, match_ids: list[int]) -> dict[str, Any]:
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if not match_ids or "match_lineups" not in tables: return {"match_id": None, "players": []}
    nc = _player_name_col(con)
    if not nc: return {"match_id": None, "players": []}
    ph=",".join("?" for _ in match_ids)
    mid = con.execute(f"""
        SELECT ml.match_id FROM match_lineups ml JOIN matches m ON m.match_id=ml.match_id
        WHERE ml.team_id=? AND ml.match_id IN ({ph}) GROUP BY ml.match_id
        ORDER BY MAX(m.kickoff) DESC,ml.match_id DESC LIMIT 1
    """, (team_id,*match_ids)).fetchone()
    if not mid: return {"match_id": None, "players": []}
    mid=int(mid[0])
    rows=con.execute(f"""
        SELECT ml.player_id,p.{nc} player_name,ml.is_starter,ml.is_substitute,ml.position,
               ml.shirt_number,ml.formation,ml.lineup_order,ml.source
        FROM match_lineups ml JOIN players p ON p.player_id=ml.player_id
        WHERE ml.team_id=? AND ml.match_id=?
        ORDER BY CASE WHEN ml.is_starter=1 THEN 0 ELSE 1 END,COALESCE(ml.lineup_order,999),p.{nc}
    """, (team_id,mid)).fetchall()
    return {"match_id": mid, "players": [dict(r) for r in rows]}

def build_global_context(base_dir: Path | str, competition_key: str, event_id: int, *,
                         bundle: dict[str, Any] | None = None, match_hint: dict[str, Any] | None = None) -> dict[str, Any]:
    global ROOT, DATA, DB, REGISTRY
    ROOT = Path(base_dir); DATA=ROOT/"data"; DB=DATA/"oddshunter.db"; REGISTRY=DATA/"competitions.json"
    result = {"version":"GLOBAL_CONTEXT_V1_3", "competition_key":str(competition_key), "event_id":int(event_id),
              "generated_at":datetime.now(timezone.utc).isoformat(), "status":"UNAVAILABLE"}
    con=sqlite3.connect(DB.resolve().as_uri()+"?mode=ro", uri=True); con.row_factory=sqlite3.Row
    try:
        reg=_registry_row(str(competition_key)); primary=_league_row(con,reg)
        if not primary: result["error"]="PRIMARY_LEAGUE_NOT_RESOLVED"; return result
        dbm=_db_match(con,int(event_id)); sched=dict(match_hint or {}) or _schedule_match(str(competition_key),int(event_id))
        hid=_int(dbm.get("home_team_id")) if dbm else None; aid=_int(dbm.get("away_team_id")) if dbm else None
        if hid is None: hid=_resolve_team(con,_source_team_id(sched,"home"))
        if aid is None: aid=_resolve_team(con,_source_team_id(sched,"away"))
        if hid is None or aid is None: result["error"]="TEAM_IDENTITY_NOT_RESOLVED"; return result
        # Normal UI events use their own kickoff as the pre-match cutoff.
        # Certification may explicitly ask for the CURRENT window so a historical
        # identity row can be used only to resolve the two teams without forcing
        # an obsolete pre-event window.
        explicit_cutoff=(match_hint or {}).get("reference_cutoff") if isinstance(match_hint,dict) else None
        cutoff=_dt(explicit_cutoff or (dbm or {}).get("kickoff") or sched.get("kickoff") or sched.get("start_timestamp"))
        hs=_scope(con,primary,hid,reg); as_=_scope(con,primary,aid,reg)
        ha=_history(con,hid,hs,cutoff); aa=_history(con,aid,as_,cutoff)

        # Administrative results remain official in matches, but explicitly
        # certified performance exclusions must never enter the statistical Window15.
        exclude_match_ids=set()
        for value in reg.get("performance_exclude_match_ids",[]) or []:
            try: exclude_match_ids.add(int(value))
            except Exception: pass
        ec=_pick(_cols(con,"matches"),"sofascore_id","event_id","source_event_id")
        if ec:
            for value in reg.get("performance_exclude_event_ids",[]) or []:
                try:
                    erow=con.execute(f"SELECT match_id FROM matches WHERE {ec}=? ORDER BY match_id DESC LIMIT 1",(int(value),)).fetchone()
                    if erow: exclude_match_ids.add(int(erow[0]))
                except Exception:
                    pass
        if exclude_match_ids:
            ha=[r for r in ha if int(r["match_id"]) not in exclude_match_ids]
            aa=[r for r in aa if int(r["match_id"]) not in exclude_match_ids]
        hg=ha[:15]; hh=[r for r in ha if r["venue"]=="HOME"][:15]
        ag=aa[:15]; aw=[r for r in aa if r["venue"]=="AWAY"][:15]
        hids=list(dict.fromkeys([r["match_id"] for r in hg+hh])); aids=list(dict.fromkeys([r["match_id"] for r in ag+aw]))
        hn,hsid=_team_meta(con,hid); an,asid=_team_meta(con,aid)
        ratings=(bundle or {}).get("ratings") if isinstance(bundle,dict) else None
        result.update({
            "status":"OK",
            "registry":{"key":reg.get("key"),"league_id":int(primary["league_id"]),"source_competition_id":reg.get("source_competition_id"),
                        "season_id":reg.get("season_id"),"name":reg.get("name") or primary.get("name"),"country":reg.get("country") or primary.get("country")},
            "match":{"event_id":int(event_id),"kickoff":cutoff.isoformat() if cutoff else None,"home_team_id":hid,"away_team_id":aid,
                     "home_team":hn,"away_team":an,"home_sofascore_id":hsid,"away_sofascore_id":asid},
            "scope":{"home_league_ids":hs,"away_league_ids":as_,"policy":"HOME=15 GENERAL+15 HOME; AWAY=15 GENERAL+15 AWAY; exact registry source pairs + explicit profile contexts"},
            "coverage":{"home_general":len(hg),"home_home":len(hh),"away_general":len(ag),"away_away":len(aw)},
            "profiles":{"home_general":_profile(hg),"home_relevant":_profile(hh),"away_general":_profile(ag),"away_relevant":_profile(aw)},
            "derived":{"home_general":_markets(hg),"home_relevant":_markets(hh),"away_general":_markets(ag),"away_relevant":_markets(aw)},
            "players":{"home":_players(con,hid,hids),"away":_players(con,aid,aids)},
            "lineups":{"home":_lineup(con,hid,hids),"away":_lineup(con,aid,aids)},
            "engine_profiles":{"home":(ratings or {}).get("home_team_analysis") if isinstance(ratings,dict) else None,
                               "away":(ratings or {}).get("away_team_analysis") if isinstance(ratings,dict) else None},
        })
        return result
    finally:
        con.close()
