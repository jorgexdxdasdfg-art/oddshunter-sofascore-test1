from __future__ import annotations

import json
import math
import re
import sqlite3
import unicodedata
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import numpy as np
try:
    from scipy.optimize import minimize
    from scipy.special import gammaln
    from scipy.stats import nbinom, poisson
except ImportError:  # La ruta bayesiana de producción no necesita SciPy.
    minimize = None
    gammaln = None
    nbinom = None
    poisson = None


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "oddshunter.db"
REGISTRY_PATH = DATA_DIR / "competitions.json"

MATCH_WINDOW = 15
RECENT_WINDOW = 5
MIN_PRIOR = 3
EPS = 1e-9

FEATURE_NAMES = (
    "intercept",
    "own_recent_for",
    "own_older_for",
    "opponent_recent_against",
    "opponent_older_against",
    "own_venue_recent_for",
    "own_venue_older_for",
    "opponent_venue_recent_against",
    "opponent_venue_older_against",
    "home_indicator",
)


def require_scipy() -> None:
    if any(item is None for item in (minimize, gammaln, nbinom, poisson)):
        raise RuntimeError(
            "El modelo aprendido de remates requiere SciPy. "
            "La ruta bayesiana de producción puede ejecutarse sin esa dependencia."
        )


@dataclass(frozen=True)
class Record:
    venue: str
    shots_for: float | None
    shots_against: float | None
    sot_for: float | None
    sot_against: float | None


@dataclass(frozen=True)
class CountObservation:
    kickoff: str
    match_id: int
    event_id: int | None
    team_id: int
    opponent_id: int
    team_name: str
    opponent_name: str
    venue: str
    target: int
    features: tuple[float, ...]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def slugify(text: str) -> str:
    value = str(text or "").strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-")


def read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"No se encontró:\n{path}")
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"{path.name} no contiene un objeto JSON.")
    return data


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def get_connection() -> sqlite3.Connection:
    if not DB_PATH.exists():
        raise FileNotFoundError(f"No se encontró la base SQLite:\n{DB_PATH}")
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def load_registry() -> dict[str, Any]:
    registry = read_json(REGISTRY_PATH)
    if not isinstance(registry.get("competitions"), list):
        raise ValueError("competitions.json no contiene la lista 'competitions'.")
    return registry


def find_competition(key: str) -> dict[str, Any]:
    normalized = slugify(key)
    for competition in load_registry()["competitions"]:
        if slugify(competition.get("key", "")) == normalized:
            return competition
    raise ValueError(f"No existe la competición '{key}'.")


def _normalize_name(value: Any) -> str:
    text = unicodedata.normalize("NFKD", str(value or ""))
    text = text.encode("ascii", "ignore").decode("ascii").lower()
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def resolve_leagues(
    connection: sqlite3.Connection,
    competition: dict[str, Any],
) -> list[dict[str, Any]]:
    name = str(competition.get("name") or "").strip()
    season_name = str(competition.get("season_name") or "").strip()
    rows = connection.execute(
        """
        SELECT league_id, name, country, season,
               source_tournament_id, source_season_id
        FROM leagues
        ORDER BY league_id DESC
        """
    ).fetchall()

    source_tournament_id = competition.get("source_competition_id")
    source_season_id = competition.get("season_id")
    tournament_rows = [
        row
        for row in rows
        if source_tournament_id is not None
        and row["source_tournament_id"] is not None
        and int(row["source_tournament_id"]) == int(source_tournament_id)
    ]
    exact_source = [
        row
        for row in tournament_rows
        if source_season_id is not None
        and row["source_season_id"] is not None
        and int(row["source_season_id"]) == int(source_season_id)
    ]
    selected = exact_source or tournament_rows

    # Liga MX conserva temporadas anteriores como historial.
    if not selected:
        names = {
            _normalize_name(value)
            for value in (
                name,
                competition.get("source_name"),
                *(competition.get("aliases") or []),
            )
            if _normalize_name(value)
        }
        named = [row for row in rows if _normalize_name(row["name"]) in names]
        exact_season = [
            row
            for row in named
            if season_name
            and _normalize_name(row["season"]) == _normalize_name(season_name)
        ]
        selected = exact_season or named

    if not selected:
        raise RuntimeError(
            f"No se encontró '{name}' en la tabla leagues."
        )

    unique: dict[int, dict[str, Any]] = {}
    for row in selected:
        unique[int(row["league_id"])] = {
            "league_id": int(row["league_id"]),
            "name": str(row["name"] or ""),
            "country": str(row["country"] or ""),
            "season": str(row["season"] or ""),
            "source_tournament_id": row["source_tournament_id"],
            "source_season_id": row["source_season_id"],
        }

    return list(unique.values())


def resolve_training_leagues(
    connection: sqlite3.Connection,
    competition: dict[str, Any],
) -> list[dict[str, Any]]:
    """Une la temporada objetivo actual con su histórico de entrenamiento.

    ``history_source_pairs`` amplía la muestra; nunca sustituye la temporada
    que ``resolve_leagues`` selecciona para la competición activa. De otro
    modo una liga con histórico explícito podía entrenar remates con una sola
    campaña antigua e ignorar todos los partidos de la campaña actual.
    """
    pairs: list[tuple[int, int]] = []
    for item in competition.get("history_source_pairs") or []:
        if not isinstance(item, dict):
            continue
        try:
            pair = (
                int(item.get("tournament_id")),
                int(item.get("season_id")),
            )
        except (TypeError, ValueError):
            continue
        if pair not in pairs:
            pairs.append(pair)

    selected: dict[int, dict[str, Any]] = {
        int(row["league_id"]): row
        for row in resolve_leagues(connection, competition)
    }
    if not pairs:
        return [selected[key] for key in sorted(selected)]

    for tournament_id, season_id in pairs:
        rows = connection.execute(
            """
            SELECT league_id, name, country, season,
                   source_tournament_id, source_season_id
            FROM leagues
            WHERE source_tournament_id = ?
              AND source_season_id = ?
            ORDER BY league_id;
            """,
            (tournament_id, season_id),
        ).fetchall()
        for row in rows:
            selected[int(row["league_id"])] = {
                "league_id": int(row["league_id"]),
                "name": str(row["name"] or ""),
                "country": str(row["country"] or ""),
                "season": str(row["season"] or ""),
                "source_tournament_id": row["source_tournament_id"],
                "source_season_id": row["source_season_id"],
            }

    return [selected[key] for key in sorted(selected)]


def load_match_rows(
    connection: sqlite3.Connection,
    league_ids: Iterable[int],
) -> list[dict[str, Any]]:
    ids = [int(value) for value in league_ids]
    if not ids:
        return []

    placeholders = ",".join("?" for _ in ids)
    query = f"""
        SELECT
            m.match_id,
            m.sofascore_id AS event_id,
            m.kickoff,
            m.league_id,
            m.home_team_id,
            m.away_team_id,
            home.sofascore_id AS home_source_id,
            away.sofascore_id AS away_source_id,
            home.name AS home_team,
            away.name AS away_team,
            hs.shots AS home_shots,
            hs.shots_on_target AS home_sot,
            aws.shots AS away_shots,
            aws.shots_on_target AS away_sot
        FROM matches AS m
        INNER JOIN teams AS home ON home.team_id = m.home_team_id
        INNER JOIN teams AS away ON away.team_id = m.away_team_id
        INNER JOIN team_match_stats AS hs
            ON hs.match_id = m.match_id AND hs.venue = 'HOME'
        INNER JOIN team_match_stats AS aws
            ON aws.match_id = m.match_id AND aws.venue = 'AWAY'
        WHERE
            m.league_id IN ({placeholders})
            AND UPPER(COALESCE(m.status, '')) IN ('FT','FINISHED')
        ORDER BY m.kickoff ASC, m.match_id ASC;
    """
    return [
        dict(row)
        for row in connection.execute(query, ids).fetchall()
    ]


def load_profile_training_rows(
    connection: sqlite3.Connection,
    competition: dict[str, Any],
) -> tuple[list[dict[str, Any]], list[int]]:
    """Carga contexto shots/SOT por equipo; nunca lo convierte en TARGET."""
    league_to_team_ids: dict[int, set[int]] = {}
    for item in competition.get("profile_history_source_pairs") or []:
        if not isinstance(item, dict):
            continue
        try:
            tournament_id = int(item.get("tournament_id"))
            season_id = int(item.get("season_id"))
        except (TypeError, ValueError):
            continue

        team_ids: set[int] = set()
        for value in item.get("team_sofascore_ids") or []:
            try:
                team_ids.add(int(value))
            except (TypeError, ValueError):
                continue
        if not team_ids:
            continue

        rows = connection.execute(
            """
            SELECT league_id
            FROM leagues
            WHERE source_tournament_id = ?
              AND source_season_id = ?
            ORDER BY league_id;
            """,
            (tournament_id, season_id),
        ).fetchall()
        for row in rows:
            league_to_team_ids.setdefault(int(row["league_id"]), set()).update(
                team_ids
            )

    if not league_to_team_ids:
        return [], []

    raw_rows = load_match_rows(connection, league_to_team_ids)
    context_rows: list[dict[str, Any]] = []
    for raw in raw_rows:
        allowed = league_to_team_ids.get(int(raw["league_id"]), set())
        participating = {
            int(value)
            for value in (
                raw.get("home_source_id"),
                raw.get("away_source_id"),
            )
            if value is not None and int(value) in allowed
        }
        if not participating:
            continue
        row = dict(raw)
        row["_training_allowed_source_ids"] = sorted(participating)
        context_rows.append(row)

    return context_rows, sorted(league_to_team_ids)


def finite(value: Any) -> float | None:
    if value is None:
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(number) or number < 0:
        return None
    return number


def mean(values: Iterable[float | None]) -> float | None:
    clean = [float(v) for v in values if v is not None and math.isfinite(float(v))]
    return float(np.mean(clean)) if clean else None


def _record_value(record: Record, target: str, kind: str) -> float | None:
    if target == "shots":
        return record.shots_for if kind == "for" else record.shots_against
    return record.sot_for if kind == "for" else record.sot_against


def _split_means(
    history: tuple[Record, ...],
    venue_history: tuple[Record, ...],
    target: str,
    kind: str,
    fallback: float,
) -> tuple[float, float, float, float]:
    values = [
        _record_value(record, target, kind)
        for record in history
        if _record_value(record, target, kind) is not None
    ]
    recent = mean(values[-RECENT_WINDOW:])
    older = mean(values[:-RECENT_WINDOW])

    venue_values = [
        _record_value(record, target, kind)
        for record in venue_history
        if _record_value(record, target, kind) is not None
    ]
    venue_recent = mean(venue_values[-RECENT_WINDOW:])
    venue_older = mean(venue_values[:-RECENT_WINDOW])

    all_mean = mean(values)
    base = all_mean if all_mean is not None else fallback

    return (
        float(recent if recent is not None else base),
        float(older if older is not None else base),
        float(venue_recent if venue_recent is not None else base),
        float(venue_older if venue_older is not None else base),
    )


def build_features(
    own_history: tuple[Record, ...],
    opponent_history: tuple[Record, ...],
    own_venue_history: tuple[Record, ...],
    opponent_venue_history: tuple[Record, ...],
    target: str,
    own_venue: str,
    league_mean: float,
) -> tuple[float, ...]:
    safe_league = max(float(league_mean), 0.25)

    own_recent, own_older, own_venue_recent, own_venue_older = _split_means(
        own_history,
        own_venue_history,
        target,
        "for",
        safe_league,
    )
    opp_recent, opp_older, opp_venue_recent, opp_venue_older = _split_means(
        opponent_history,
        opponent_venue_history,
        target,
        "against",
        safe_league,
    )

    def ratio_log(value: float) -> float:
        return math.log((max(value, 0.0) + 0.5) / (safe_league + 0.5))

    return (
        1.0,
        ratio_log(own_recent),
        ratio_log(own_older),
        ratio_log(opp_recent),
        ratio_log(opp_older),
        ratio_log(own_venue_recent),
        ratio_log(own_venue_older),
        ratio_log(opp_venue_recent),
        ratio_log(opp_venue_older),
        1.0 if own_venue == "HOME" else 0.0,
    )


def build_observations(
    rows: list[dict[str, Any]],
    target: str,
    context_rows: list[dict[str, Any]] | None = None,
    context_lookback_days: int = 730,
) -> list[CountObservation]:
    """Walk-forward estricto con ventanas GENERAL y HOME/AWAY independientes."""
    context_rows = list(context_rows or [])
    lookback_seconds = max(1, int(context_lookback_days)) * 86400.0
    histories: dict[
        tuple[str, int],
        list[tuple[float, int, str, Record]],
    ] = {}
    observations: list[CountObservation] = []

    ordered = sorted(
        rows,
        key=lambda row: (
            str(row.get("kickoff") or ""),
            int(row.get("match_id") or 0),
        ),
    )

    def kickoff_timestamp(value: Any) -> float:
        text = str(value or "").strip().replace("Z", "+00:00")
        parsed = datetime.fromisoformat(text)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return float(parsed.timestamp())

    def identity(row: dict[str, Any], side: str) -> tuple[str, int]:
        source_id = row.get(f"{side}_source_id")
        if source_id is not None:
            return "source", int(source_id)
        return "internal", int(row[f"{side}_team_id"])

    def records(row: dict[str, Any]) -> tuple[Record, Record]:
        return (
            Record(
                venue="HOME",
                shots_for=finite(row["home_shots"]),
                shots_against=finite(row["away_shots"]),
                sot_for=finite(row["home_sot"]),
                sot_against=finite(row["away_sot"]),
            ),
            Record(
                venue="AWAY",
                shots_for=finite(row["away_shots"]),
                shots_against=finite(row["home_shots"]),
                sot_for=finite(row["away_sot"]),
                sot_against=finite(row["home_sot"]),
            ),
        )

    def add_history(row: dict[str, Any], source_kind: str) -> None:
        cutoff = kickoff_timestamp(row["kickoff"])
        match_id = int(row["match_id"])
        home_record, away_record = records(row)
        allowed_values = row.get("_training_allowed_source_ids")
        allowed = (
            {int(value) for value in allowed_values}
            if allowed_values is not None
            else None
        )
        for side, record in (("home", home_record), ("away", away_record)):
            source_id = row.get(f"{side}_source_id")
            if allowed is not None and (
                source_id is None or int(source_id) not in allowed
            ):
                continue
            histories.setdefault(identity(row, side), []).append(
                (cutoff, match_id, source_kind, record)
            )

    for row in context_rows:
        add_history(row, "context")
    for row in ordered:
        add_history(row, "target")
    for entries in histories.values():
        entries.sort(key=lambda item: (item[0], item[1]))

    def history_before(
        team_identity: tuple[str, int],
        cutoff: float,
        venue: str | None = None,
    ) -> tuple[Record, ...]:
        floor = cutoff - lookback_seconds
        entries = [
            item
            for item in histories.get(team_identity, [])
            if item[0] < cutoff
            and (item[2] == "target" or item[0] >= floor)
            and (venue is None or item[3].venue == venue)
        ]
        return tuple(item[3] for item in entries[-MATCH_WINDOW:])

    grouped: dict[float, list[dict[str, Any]]] = {}
    for row in ordered:
        grouped.setdefault(kickoff_timestamp(row["kickoff"]), []).append(row)

    for cutoff in sorted(grouped):
        prior_rows = [
            row
            for row in ordered
            if kickoff_timestamp(row["kickoff"]) < cutoff
        ]
        target_home_values = [
            finite(row["home_shots"] if target == "shots" else row["home_sot"])
            for row in prior_rows
        ]
        target_away_values = [
            finite(row["away_shots"] if target == "shots" else row["away_sot"])
            for row in prior_rows
        ]
        default_mean = 12.0 if target == "shots" else 4.0
        league_home = float(mean(target_home_values) or default_mean)
        league_away = float(mean(target_away_values) or default_mean)

        for row in grouped[cutoff]:
            home_id = int(row["home_team_id"])
            away_id = int(row["away_team_id"])
            home_identity = identity(row, "home")
            away_identity = identity(row, "away")
            home_history = history_before(home_identity, cutoff)
            away_history = history_before(away_identity, cutoff)
            home_venue_history = history_before(home_identity, cutoff, "HOME")
            away_venue_history = history_before(away_identity, cutoff, "AWAY")

            valid_home = sum(
                _record_value(record, target, "for") is not None
                for record in home_history
            )
            valid_away = sum(
                _record_value(record, target, "for") is not None
                for record in away_history
            )
            if valid_home < MIN_PRIOR or valid_away < MIN_PRIOR:
                continue

            home_target = finite(
                row["home_shots"] if target == "shots" else row["home_sot"]
            )
            away_target = finite(
                row["away_shots"] if target == "shots" else row["away_sot"]
            )
            common = {
                "kickoff": str(row["kickoff"]),
                "match_id": int(row["match_id"]),
                "event_id": (
                    int(row["event_id"])
                    if row.get("event_id") is not None
                    else None
                ),
            }
            if home_target is not None:
                observations.append(
                    CountObservation(
                        **common,
                        team_id=home_id,
                        opponent_id=away_id,
                        team_name=str(row["home_team"]),
                        opponent_name=str(row["away_team"]),
                        venue="HOME",
                        target=int(round(home_target)),
                        features=build_features(
                            home_history,
                            away_history,
                            home_venue_history,
                            away_venue_history,
                            target,
                            "HOME",
                            league_home,
                        ),
                    )
                )
            if away_target is not None:
                observations.append(
                    CountObservation(
                        **common,
                        team_id=away_id,
                        opponent_id=home_id,
                        team_name=str(row["away_team"]),
                        opponent_name=str(row["home_team"]),
                        venue="AWAY",
                        target=int(round(away_target)),
                        features=build_features(
                            away_history,
                            home_history,
                            away_venue_history,
                            home_venue_history,
                            target,
                            "AWAY",
                            league_away,
                        ),
                    )
                )

    return observations

def _design(observations: list[CountObservation]) -> tuple[np.ndarray, np.ndarray]:
    x = np.asarray([item.features for item in observations], dtype=float)
    y = np.asarray([item.target for item in observations], dtype=float)
    return x, y


def _poisson_objective(beta: np.ndarray, x: np.ndarray, y: np.ndarray) -> float:
    eta = np.clip(x @ beta, -4.0, 5.0)
    mu = np.exp(eta)
    nll = np.sum(mu - y * eta + gammaln(y + 1.0))
    penalty = 0.03 * float(np.sum(beta[1:] ** 2))
    return float(nll + penalty)


def _nb_objective(params: np.ndarray, x: np.ndarray, y: np.ndarray) -> float:
    beta = params[:-1]
    size = float(np.exp(np.clip(params[-1], -3.0, 6.0)))
    eta = np.clip(x @ beta, -4.0, 5.0)
    mu = np.exp(eta)
    probability = size / (size + mu)
    log_pmf = nbinom.logpmf(y, size, probability)
    if not np.all(np.isfinite(log_pmf)):
        return 1e12
    penalty = 0.03 * float(np.sum(beta[1:] ** 2))
    return float(-np.sum(log_pmf) + penalty)


def _initial_beta(y: np.ndarray, feature_count: int) -> np.ndarray:
    beta = np.zeros(feature_count, dtype=float)
    beta[0] = math.log(max(float(np.mean(y)), 0.25))
    return beta


def fit_models(observations: list[CountObservation]) -> dict[str, Any]:
    require_scipy()
    if len(observations) < 40:
        raise RuntimeError(
            f"Se requieren al menos 40 observaciones y solo hay {len(observations)}."
        )

    x, y = _design(observations)
    beta0 = _initial_beta(y, x.shape[1])

    poisson_result = minimize(
        _poisson_objective,
        beta0,
        args=(x, y),
        method="L-BFGS-B",
        bounds=[(-4.0, 5.0)] + [(-2.5, 2.5)] * (x.shape[1] - 1),
        options={"maxiter": 1000},
    )
    if not poisson_result.success:
        raise RuntimeError(
            f"Poisson no convergió: {poisson_result.message}"
        )

    nb0 = np.concatenate([poisson_result.x, np.array([math.log(8.0)])])
    nb_result = minimize(
        _nb_objective,
        nb0,
        args=(x, y),
        method="L-BFGS-B",
        bounds=(
            [(-4.0, 5.0)]
            + [(-2.5, 2.5)] * (x.shape[1] - 1)
            + [(-3.0, 6.0)]
        ),
        options={"maxiter": 1200},
    )
    if not nb_result.success:
        # El modelo Poisson sigue siendo válido aunque NB no converja.
        nb_beta = poisson_result.x.copy()
        nb_size = None
        nb_converged = False
    else:
        nb_beta = nb_result.x[:-1]
        nb_size = float(np.exp(nb_result.x[-1]))
        nb_converged = True

    return {
        "poisson": {
            "coefficients": [float(v) for v in poisson_result.x],
            "converged": True,
        },
        "negative_binomial": {
            "coefficients": [float(v) for v in nb_beta],
            "size": nb_size,
            "converged": nb_converged,
        },
    }


def predict_mean(model: dict[str, Any], features: Iterable[float]) -> float:
    beta = np.asarray(model["coefficients"], dtype=float)
    x = np.asarray(tuple(features), dtype=float)
    return float(np.exp(np.clip(x @ beta, -4.0, 5.0)))


def observation_log_loss(
    family: str,
    model: dict[str, Any],
    observations: list[CountObservation],
) -> float:
    require_scipy()
    losses: list[float] = []
    for item in observations:
        mu = predict_mean(model, item.features)
        if family == "poisson":
            probability = float(poisson.pmf(item.target, mu))
        else:
            size = model.get("size")
            if size is None:
                continue
            p = float(size) / (float(size) + mu)
            probability = float(nbinom.pmf(item.target, float(size), p))
        losses.append(-math.log(max(probability, 1e-12)))
    return float(np.mean(losses)) if losses else float("inf")


def regression_metrics(
    model: dict[str, Any],
    observations: list[CountObservation],
) -> dict[str, float]:
    errors: list[float] = []
    for item in observations:
        errors.append(predict_mean(model, item.features) - item.target)
    array = np.asarray(errors, dtype=float)
    return {
        "mae": float(np.mean(np.abs(array))) if len(array) else float("nan"),
        "rmse": float(np.sqrt(np.mean(array ** 2))) if len(array) else float("nan"),
    }


def train_target(
    observations: list[CountObservation],
    holdout: float,
) -> dict[str, Any]:
    if len(observations) < 60:
        raise RuntimeError(
            f"Muestra insuficiente: {len(observations)} observaciones."
        )

    desired = int(round(len(observations) * (1.0 - holdout)))
    candidates = [
        index
        for index in range(40, len(observations) - 20 + 1)
        if observations[index - 1].kickoff < observations[index].kickoff
    ]
    if not candidates:
        raise RuntimeError("No existe frontera temporal group-safe para remates.")
    split = min(
        candidates,
        key=lambda index: (abs(index - desired), index),
    )
    train = observations[:split]
    validation = observations[split:]

    models = fit_models(train)

    poisson_loss = observation_log_loss(
        "poisson",
        models["poisson"],
        validation,
    )
    nb_loss = observation_log_loss(
        "negative_binomial",
        models["negative_binomial"],
        validation,
    )

    selected = (
        "negative_binomial"
        if models["negative_binomial"].get("converged")
        and nb_loss + 0.002 < poisson_loss
        else "poisson"
    )

    for family in ("poisson", "negative_binomial"):
        model = models[family]
        loss = observation_log_loss(family, model, validation)
        metrics = regression_metrics(model, validation)
        model["validation_metrics"] = {
            "exact_count_log_loss": round(loss, 8)
            if math.isfinite(loss)
            else None,
            "mae": round(metrics["mae"], 8),
            "rmse": round(metrics["rmse"], 8),
            "observations": len(validation),
        }

    return {
        "selected_family": selected,
        "feature_names": list(FEATURE_NAMES),
        "train_observations": len(train),
        "validation_observations": len(validation),
        "first_validation_kickoff": validation[0].kickoff,
        "last_validation_kickoff": validation[-1].kickoff,
        **models,
    }


def build_histories(
    rows: list[dict[str, Any]],
) -> tuple[dict[int, tuple[Record, ...]], dict[str, dict[str, float]]]:
    histories: dict[int, list[Record]] = {}
    league_values = {
        "shots": {"HOME": [], "AWAY": []},
        "shots_on_target": {"HOME": [], "AWAY": []},
    }

    for row in rows:
        home_id = int(row["home_team_id"])
        away_id = int(row["away_team_id"])

        home_record = Record(
            venue="HOME",
            shots_for=finite(row["home_shots"]),
            shots_against=finite(row["away_shots"]),
            sot_for=finite(row["home_sot"]),
            sot_against=finite(row["away_sot"]),
        )
        away_record = Record(
            venue="AWAY",
            shots_for=finite(row["away_shots"]),
            shots_against=finite(row["home_shots"]),
            sot_for=finite(row["away_sot"]),
            sot_against=finite(row["home_sot"]),
        )

        histories.setdefault(home_id, []).append(home_record)
        histories.setdefault(away_id, []).append(away_record)

        if home_record.shots_for is not None:
            league_values["shots"]["HOME"].append(home_record.shots_for)
        if away_record.shots_for is not None:
            league_values["shots"]["AWAY"].append(away_record.shots_for)
        if home_record.sot_for is not None:
            league_values["shots_on_target"]["HOME"].append(home_record.sot_for)
        if away_record.sot_for is not None:
            league_values["shots_on_target"]["AWAY"].append(away_record.sot_for)

    frozen = {
        team_id: tuple(records[-MATCH_WINDOW:])
        for team_id, records in histories.items()
    }
    league_means = {
        target: {
            venue: float(np.mean(values))
            if values
            else (12.0 if target == "shots" else 4.0)
            for venue, values in venues.items()
        }
        for target, venues in league_values.items()
    }
    return frozen, league_means


def resolve_internal_team_id(
    connection: sqlite3.Connection,
    source_or_internal_id: Any,
    name: Any = None,
) -> int:
    try:
        value = int(source_or_internal_id)
    except (TypeError, ValueError):
        value = -1

    if value >= 0:
        row = connection.execute(
            "SELECT team_id FROM teams WHERE sofascore_id = ? LIMIT 1",
            (value,),
        ).fetchone()
        if row:
            return int(row["team_id"])

        row = connection.execute(
            "SELECT team_id FROM teams WHERE team_id = ? LIMIT 1",
            (value,),
        ).fetchone()
        if row:
            return int(row["team_id"])

    if name:
        row = connection.execute(
            "SELECT team_id FROM teams WHERE LOWER(name) = LOWER(?) ORDER BY team_id DESC LIMIT 1",
            (str(name),),
        ).fetchone()
        if row:
            return int(row["team_id"])

    raise RuntimeError(
        f"No se pudo resolver el equipo: id={source_or_internal_id}, nombre={name}"
    )



# ---------------------------------------------------------------------------
# NÚCLEO COMPARTIDO DE PRODUCCIÓN / REPLAY DE REMATES
# ---------------------------------------------------------------------------
DEFAULT_RECENT_WEIGHT_SHOTS = 1.6363636363636365
DEFAULT_RECENT_WEIGHT_SOT = 1.6363636363636365
# Se consultan suficientes candidatos para poder formar ventanas reales de
# 15 HOME/AWAY por mercado incluso cuando algunas filas carecen de remates.
# El cálculo final continúa limitado por MATCH_WINDOW = 15.
PROFILE_QUERY_LIMIT = 250
SAMPLE_PRIOR_MATCHES = 5.0


def recent_share_to_weight(share: float) -> float:
    """Convierte la cuota del bloque 5/15 al multiplicador por partido reciente."""
    value = float(share)
    if not 0.0 < value < 1.0:
        raise ValueError("La cuota reciente debe estar entre 0 y 1.")
    return (2.0 * value) / (1.0 - value)


def recent_weight_to_share(weight: float) -> float:
    """Convierte el multiplicador por partido a cuota del bloque cuando N=15."""
    value = float(weight)
    if value <= 0.0:
        raise ValueError("El multiplicador reciente debe ser positivo.")
    return value / (value + 2.0)


def source_team_id(match: dict[str, Any], side: str) -> int | None:
    for key in (
        f"{side}_team_id",
        f"{side}_source_team_id",
        f"{side}_sofascore_id",
    ):
        try:
            value = int(match.get(key))
        except (TypeError, ValueError):
            continue
        if value > 0:
            return value
    return None


def production_league_ids(
    connection: sqlite3.Connection,
    competition_key: str,
) -> list[int]:
    """Resuelve el alcance doméstico autorizado por el registro."""
    specification = find_competition(competition_key)
    history_ids = _bundesliga_pair_league_ids(
        connection,
        specification.get("history_source_pairs"),
    )
    if history_ids:
        return history_ids
    return sorted(
        int(item["league_id"])
        for item in resolve_leagues(connection, specification)
    )


def _bundesliga_pair_league_ids(
    connection: sqlite3.Connection,
    pairs: Any,
) -> list[int]:
    """Resuelve solo los pares domésticos declarados para Bundesliga."""
    if not isinstance(pairs, list):
        return []
    resolved: set[int] = set()
    for item in pairs:
        if not isinstance(item, dict):
            continue
        try:
            tournament_id = int(item.get("tournament_id"))
            season_id = int(item.get("season_id"))
        except (TypeError, ValueError):
            continue
        rows = connection.execute(
            """
            SELECT league_id
            FROM leagues
            WHERE source_tournament_id = ?
              AND source_season_id = ?
            ORDER BY league_id
            """,
            (tournament_id, season_id),
        ).fetchall()
        resolved.update(int(row[0]) for row in rows if row[0] is not None)
    return sorted(resolved)


def _bundesliga_profile_league_ids(
    connection: sqlite3.Connection,
    competition_key: str,
    source_id: int,
) -> list[int] | None:
    """Perfil anterior explícito para un ascendido, sin mezclar ligas."""
    if slugify(competition_key) != "bundesliga":
        return None
    specification = find_competition(competition_key)
    selected: list[dict[str, Any]] = []
    for item in specification.get("profile_history_source_pairs") or []:
        if not isinstance(item, dict):
            continue
        team_ids = item.get("team_sofascore_ids")
        if not isinstance(team_ids, list):
            continue
        try:
            allowed = {int(value) for value in team_ids}
        except (TypeError, ValueError):
            continue
        if int(source_id) in allowed:
            selected.append(item)
    resolved = _bundesliga_pair_league_ids(connection, selected)
    return resolved or None


def internal_team_ids(
    connection: sqlite3.Connection,
    source_id: int,
) -> list[int]:
    rows = connection.execute(
        "SELECT team_id FROM teams WHERE sofascore_id = ? ORDER BY team_id DESC",
        (source_id,),
    ).fetchall()
    return [int(row[0]) for row in rows]


def _sql_number(value: Any) -> float | None:
    try:
        result = float(str(value).replace(",", "."))
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def weighted_average_sqlite(
    rows: list[sqlite3.Row],
    field: str,
    preferred_venue: str,
    recent_weight: float,
) -> float | None:
    valid = [row for row in rows if _sql_number(row[field]) is not None]
    preferred = [
        row
        for row in valid
        if str(row["venue"] or "").upper() == preferred_venue
    ]
    selected = (preferred if len(preferred) >= 3 else valid)[:MATCH_WINDOW]

    total = 0.0
    weight_total = 0.0
    for index, row in enumerate(selected):
        value = _sql_number(row[field])
        if value is None:
            continue
        weight = float(recent_weight) if index < RECENT_WINDOW else 1.0
        total += value * weight
        weight_total += weight
    return total / weight_total if weight_total > 0 else None


def selected_sample_size_sqlite(
    rows: list[sqlite3.Row],
    preferred_venue: str,
) -> int:
    valid = [row for row in rows if _sql_number(row["shots"]) is not None]
    preferred = [
        row
        for row in valid
        if str(row["venue"] or "").upper() == preferred_venue
    ]
    selected = preferred if len(preferred) >= 3 else valid
    return min(MATCH_WINDOW, len(selected))


def team_profile_sqlite(
    connection: sqlite3.Connection,
    source_id: int,
    venue: str,
    league_ids: list[int] | None,
    cutoff_kickoff: str | None,
    shots_recent_weight: float = DEFAULT_RECENT_WEIGHT_SHOTS,
    sot_recent_weight: float = DEFAULT_RECENT_WEIGHT_SOT,
) -> dict[str, float | int | None]:
    ids = internal_team_ids(connection, source_id)
    if not ids:
        return {
            "shots_for": None,
            "shots_allowed": None,
            "target_for": None,
            "target_allowed": None,
            "matches": 0,
        }

    placeholders = ",".join("?" for _ in ids)
    filters = [f"s.team_id IN ({placeholders})", "UPPER(COALESCE(m.status, '')) IN ('FT','FINISHED')"]
    parameters: list[Any] = list(ids)

    if league_ids is not None:
        league_placeholders = ",".join("?" for _ in league_ids)
        filters.append(f"m.league_id IN ({league_placeholders})")
        parameters.extend(int(value) for value in league_ids)

    # Regla temporal única: el objetivo y cualquier kickoff simultáneo quedan fuera.
    if cutoff_kickoff:
        filters.append("m.kickoff < ?")
        parameters.append(str(cutoff_kickoff))

    where = " AND ".join(filters)
    rows = connection.execute(
        f"""
        SELECT
            s.venue,
            s.shots,
            s.shots_on_target,
            opponent.shots AS opponent_shots,
            opponent.shots_on_target AS opponent_shots_on_target,
            m.kickoff,
            m.match_id
        FROM team_match_stats AS s
        INNER JOIN matches AS m ON m.match_id = s.match_id
        LEFT JOIN team_match_stats AS opponent
          ON opponent.match_id = s.match_id
         AND opponent.team_id <> s.team_id
        WHERE {where}
        ORDER BY m.kickoff DESC, m.match_id DESC
        LIMIT {PROFILE_QUERY_LIMIT}
        """,
        tuple(parameters),
    ).fetchall()

    return {
        "shots_for": weighted_average_sqlite(
            rows, "shots", venue, shots_recent_weight
        ),
        "shots_allowed": weighted_average_sqlite(
            rows, "opponent_shots", venue, shots_recent_weight
        ),
        "target_for": weighted_average_sqlite(
            rows, "shots_on_target", venue, sot_recent_weight
        ),
        "target_allowed": weighted_average_sqlite(
            rows, "opponent_shots_on_target", venue, sot_recent_weight
        ),
        # Se conserva exactamente la semántica de producción V4.4.5 para shrinkage.
        "matches": selected_sample_size_sqlite(rows, venue),
    }


def blend_attack_allowed(
    attack: float | None,
    opponent_allowed: float | None,
) -> float | None:
    if (
        attack is not None
        and opponent_allowed is not None
        and attack >= 0
        and opponent_allowed >= 0
    ):
        return math.sqrt(max(0.0, attack) * max(0.0, opponent_allowed))
    return attack if attack is not None else opponent_allowed


def shrink_to_baseline(
    value: float | None,
    baseline: float | None,
    matches: int,
    prior_matches: float = SAMPLE_PRIOR_MATCHES,
) -> float | None:
    if baseline is None:
        return value
    if value is None:
        return baseline
    weight = max(0.0, float(matches)) / (
        max(0.0, float(matches)) + float(prior_matches)
    )
    return weight * value + (1.0 - weight) * baseline


def league_shot_means_before(
    connection: sqlite3.Connection,
    league_ids: list[int] | None,
    cutoff_kickoff: str | None,
) -> dict[str, float | None]:
    if not league_ids:
        return {}
    placeholders = ",".join("?" for _ in league_ids)
    parameters: list[Any] = [int(value) for value in league_ids]
    kickoff_filter = ""
    if cutoff_kickoff:
        kickoff_filter = " AND m.kickoff < ?"
        parameters.append(str(cutoff_kickoff))

    row = connection.execute(
        f"""
        SELECT
            AVG(home_stats.shots) AS home_shots,
            AVG(away_stats.shots) AS away_shots,
            AVG(home_stats.shots_on_target) AS home_targets,
            AVG(away_stats.shots_on_target) AS away_targets
        FROM matches AS m
        LEFT JOIN team_match_stats AS home_stats
          ON home_stats.match_id = m.match_id
         AND home_stats.venue = 'HOME'
        LEFT JOIN team_match_stats AS away_stats
          ON away_stats.match_id = m.match_id
         AND away_stats.venue = 'AWAY'
        WHERE m.league_id IN ({placeholders})
          AND UPPER(COALESCE(m.status, '')) IN ('FT','FINISHED')
          {kickoff_filter}
        """,
        tuple(parameters),
    ).fetchone()
    if row is None:
        return {}
    return {
        key: (float(row[key]) if row[key] is not None else None)
        for key in (
            "home_shots",
            "away_shots",
            "home_targets",
            "away_targets",
        )
    }


def predict_shots_sqlite(
    connection: sqlite3.Connection,
    home_source_id: int,
    away_source_id: int,
    competition_key: str,
    cutoff_kickoff: str | None,
    shots_recent_weight: float = DEFAULT_RECENT_WEIGHT_SHOTS,
    sot_recent_weight: float = DEFAULT_RECENT_WEIGHT_SOT,
) -> tuple[float | None, float | None, float | None, float | None]:
    league_ids = production_league_ids(connection, competition_key)
    home_league_ids = (
        _bundesliga_profile_league_ids(
            connection,
            competition_key,
            int(home_source_id),
        )
        or league_ids
    )
    away_league_ids = (
        _bundesliga_profile_league_ids(
            connection,
            competition_key,
            int(away_source_id),
        )
        or league_ids
    )
    home = team_profile_sqlite(
        connection,
        int(home_source_id),
        "HOME",
        home_league_ids,
        cutoff_kickoff,
        shots_recent_weight,
        sot_recent_weight,
    )
    away = team_profile_sqlite(
        connection,
        int(away_source_id),
        "AWAY",
        away_league_ids,
        cutoff_kickoff,
        shots_recent_weight,
        sot_recent_weight,
    )
    means = league_shot_means_before(connection, league_ids, cutoff_kickoff)

    home_matches = int(home.get("matches") or 0)
    away_matches = int(away.get("matches") or 0)

    return (
        blend_attack_allowed(
            shrink_to_baseline(home["shots_for"], means.get("home_shots"), home_matches),
            shrink_to_baseline(away["shots_allowed"], means.get("home_shots"), away_matches),
        ),
        blend_attack_allowed(
            shrink_to_baseline(away["shots_for"], means.get("away_shots"), away_matches),
            shrink_to_baseline(home["shots_allowed"], means.get("away_shots"), home_matches),
        ),
        blend_attack_allowed(
            shrink_to_baseline(home["target_for"], means.get("home_targets"), home_matches),
            shrink_to_baseline(away["target_allowed"], means.get("home_targets"), away_matches),
        ),
        blend_attack_allowed(
            shrink_to_baseline(away["target_for"], means.get("away_targets"), away_matches),
            shrink_to_baseline(home["target_allowed"], means.get("away_targets"), home_matches),
        ),
    )


def database_prediction(
    match: dict[str, Any],
    competition_key: str,
    shots_recent_weight: float = DEFAULT_RECENT_WEIGHT_SHOTS,
    sot_recent_weight: float = DEFAULT_RECENT_WEIGHT_SOT,
    db_path: Path | None = None,
) -> tuple[float | None, float | None, float | None, float | None]:
    home_id = source_team_id(match, "home")
    away_id = source_team_id(match, "away")
    path = Path(db_path) if db_path is not None else DB_PATH
    if home_id is None or away_id is None or not path.exists():
        return None, None, None, None

    connection = sqlite3.connect(path)
    connection.row_factory = sqlite3.Row
    try:
        return predict_shots_sqlite(
            connection,
            home_id,
            away_id,
            competition_key,
            str(match.get("kickoff") or "") or None,
            shots_recent_weight,
            sot_recent_weight,
        )
    finally:
        connection.close()

def count_pmf(
    family: str,
    mean_value: float,
    size: float | None,
    maximum: int,
) -> np.ndarray:
    require_scipy()
    values = np.arange(maximum + 1)
    if family == "negative_binomial" and size is not None:
        probability = float(size) / (float(size) + mean_value)
        pmf = nbinom.pmf(values, float(size), probability)
    else:
        pmf = poisson.pmf(values, mean_value)

    pmf = np.asarray(pmf, dtype=float)
    tail = max(0.0, 1.0 - float(pmf.sum()))
    pmf[-1] += tail
    total = float(pmf.sum())
    return pmf / total if total > 0 else pmf


def threshold_rows(
    pmf: np.ndarray,
    lines: Iterable[float],
) -> list[dict[str, Any]]:
    rows = []
    for line in lines:
        minimum = int(math.floor(float(line))) + 1
        probability = float(pmf[minimum:].sum()) if minimum < len(pmf) else 0.0
        rows.append(
            {
                "line": float(line),
                "minimum_count": minimum,
                "probability": round(probability, 6),
            }
        )
    return rows

# ============================================================================
# ODDSHUNTER_SHOTS_PROFILE_SCOPE_RUNTIME_FIX_V2_2
# Explicit registry profile scope for affected domestic competitions.
# Bundesliga/Premier/Ligue1 remain on their existing production paths.
# ============================================================================
_OH_V22_ORIGINAL_DATABASE_PREDICTION = database_prediction

def _oh_v22_shots_pair_ids(_conn, _pairs):
    _ids = set()
    if not isinstance(_pairs, list):
        return []
    _sql = (
        "SELECT league_id FROM leagues "
        "WHERE source_tournament_id=? AND source_season_id=? "
        "ORDER BY league_id"
    )
    for _item in _pairs:
        if not isinstance(_item, dict):
            continue
        try:
            _tid = int(_item.get("tournament_id"))
            _season = int(_item.get("season_id"))
        except Exception:
            continue
        for _row in _conn.execute(_sql, (_tid, _season)).fetchall():
            try:
                _value = _row["league_id"]
            except Exception:
                _value = _row[0]
            if _value is not None:
                _ids.add(int(_value))
    return sorted(_ids)

def _oh_v22_shots_profile_ids(_conn, _spec, _source_id):
    _selected = []
    try:
        _source_id = int(_source_id)
    except Exception:
        return []
    for _item in (_spec.get("profile_history_source_pairs") or []):
        if not isinstance(_item, dict):
            continue
        try:
            _teams = {int(_x) for _x in (_item.get("team_sofascore_ids") or [])}
        except Exception:
            continue
        if _source_id in _teams:
            _selected.append(_item)
    return _oh_v22_shots_pair_ids(_conn, _selected)

def _oh_v22_shots_generic_profile_prediction(
    _conn,
    _home_id,
    _away_id,
    _competition_key,
    _cutoff,
    _shots_recent_weight,
    _sot_recent_weight,
):
    _key = slugify(_competition_key)
    _allowed = {
        "greece-stoiximan-super-league",
        "championship",
        "turkey-super-lig",
        "saudi-pro-league",
        "serie-a",
    }
    if _key not in _allowed:
        return None

    try:
        _spec = find_competition(_competition_key)
    except Exception:
        return None
    if not isinstance(_spec, dict):
        return None

    _history_pairs = [
        _item
        for _item in (_spec.get("history_source_pairs") or [])
        if isinstance(_item, dict)
    ]
    _history_ids = _oh_v22_shots_pair_ids(_conn, _history_pairs)
    if not _history_ids:
        return None

    _current_pairs = [
        _item
        for _item in _history_pairs
        if str(_item.get("role") or "").strip().upper() == "CURRENT"
    ]
    if not _current_pairs and _history_pairs:
        _current_pairs = [_history_pairs[0]]
    _primary_ids = _oh_v22_shots_pair_ids(_conn, _current_pairs)
    if not _primary_ids:
        _primary_ids = list(_history_ids)

    _home_profile_ids = _oh_v22_shots_profile_ids(_conn, _spec, _home_id)
    _away_profile_ids = _oh_v22_shots_profile_ids(_conn, _spec, _away_id)

    if not _home_profile_ids and not _away_profile_ids:
        return None

    _home_scope = (
        sorted(set(_primary_ids) | set(_home_profile_ids))
        if _home_profile_ids
        else list(_history_ids)
    )
    _away_scope = (
        sorted(set(_primary_ids) | set(_away_profile_ids))
        if _away_profile_ids
        else list(_history_ids)
    )

    _home = team_profile_sqlite(
        _conn,
        int(_home_id),
        "HOME",
        _home_scope,
        _cutoff,
        _shots_recent_weight,
        _sot_recent_weight,
    )
    _away = team_profile_sqlite(
        _conn,
        int(_away_id),
        "AWAY",
        _away_scope,
        _cutoff,
        _shots_recent_weight,
        _sot_recent_weight,
    )

    _means = league_shot_means_before(
        _conn,
        _history_ids,
        _cutoff,
    )

    _hm = int(_home.get("matches") or 0)
    _am = int(_away.get("matches") or 0)
    if _hm <= 0 or _am <= 0:
        return None

    _hs = blend_attack_allowed(
        shrink_to_baseline(_home.get("shots_for"), _means.get("home_shots"), _hm),
        shrink_to_baseline(_away.get("shots_allowed"), _means.get("home_shots"), _am),
    )
    _aws = blend_attack_allowed(
        shrink_to_baseline(_away.get("shots_for"), _means.get("away_shots"), _am),
        shrink_to_baseline(_home.get("shots_allowed"), _means.get("away_shots"), _hm),
    )
    _hst = blend_attack_allowed(
        shrink_to_baseline(_home.get("target_for"), _means.get("home_targets"), _hm),
        shrink_to_baseline(_away.get("target_allowed"), _means.get("home_targets"), _am),
    )
    _awst = blend_attack_allowed(
        shrink_to_baseline(_away.get("target_for"), _means.get("away_targets"), _am),
        shrink_to_baseline(_home.get("target_allowed"), _means.get("away_targets"), _hm),
    )

    if any(_x is None for _x in (_hs, _aws, _hst, _awst)):
        return None

    _hs = max(0.0, float(_hs))
    _aws = max(0.0, float(_aws))
    _hst = min(_hs, max(0.0, float(_hst)))
    _awst = min(_aws, max(0.0, float(_awst)))

    print(
        "[PROFILE_HISTORY_SCOPE_V2_2_SHOTS] "
        f"key={_key} "
        f"home_sid={int(_home_id)} home_ids={_home_scope} "
        f"away_sid={int(_away_id)} away_ids={_away_scope}"
    )
    return (_hs, _aws, _hst, _awst)

def database_prediction(
    match,
    competition_key,
    shots_recent_weight=DEFAULT_RECENT_WEIGHT_SHOTS,
    sot_recent_weight=DEFAULT_RECENT_WEIGHT_SOT,
    db_path=None,
):
    _home_id = source_team_id(match, "home")
    _away_id = source_team_id(match, "away")
    _path = Path(db_path) if db_path is not None else DB_PATH

    if _home_id is not None and _away_id is not None and _path.exists():
        _conn = sqlite3.connect(_path)
        _conn.row_factory = sqlite3.Row
        try:
            _result = _oh_v22_shots_generic_profile_prediction(
                _conn,
                _home_id,
                _away_id,
                competition_key,
                str(match.get("kickoff") or "") or None,
                shots_recent_weight,
                sot_recent_weight,
            )
        finally:
            _conn.close()

        if (
            isinstance(_result, (tuple, list))
            and len(_result) == 4
            and all(_x is not None for _x in _result)
        ):
            return tuple(_result)

    return _OH_V22_ORIGINAL_DATABASE_PREDICTION(
        match,
        competition_key,
        shots_recent_weight=shots_recent_weight,
        sot_recent_weight=sot_recent_weight,
        db_path=db_path,
    )
