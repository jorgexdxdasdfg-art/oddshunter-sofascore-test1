from __future__ import annotations

# OddsHunter Flashscore: registro central de identidad 1.1 + alias Conference validados

import json
import math
import os
import re
import time
import unicodedata
from datetime import datetime, timedelta, timezone
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Callable
from urllib.parse import parse_qsl, urlencode, urljoin, urlsplit, urlunsplit

try:
    from playwright.sync_api import (
        BrowserContext,
        Page,
        Playwright,
        TimeoutError as PlaywrightTimeoutError,
    )
except ModuleNotFoundError:  # permite probar el parser sin abrir navegador
    BrowserContext = Any  # type: ignore[misc,assignment]
    Page = Any  # type: ignore[misc,assignment]
    Playwright = Any  # type: ignore[misc,assignment]
    PlaywrightTimeoutError = TimeoutError  # type: ignore[misc,assignment]

from xg_estimator import AggregateStats
from xg_pipeline import (
    DirectXG,
    MatchAggregateStats,
    MatchRef,
)
from match_stats_pipeline import MetricPair
from team_identity_registry import get_default_team_identity_registry


_TEAM_IDENTITY_REGISTRY = get_default_team_identity_registry(
    Path(__file__).resolve().parent
)


HOME_URL = "https://www.flashscore.es/"
SEARCH_INPUT_SELECTOR = "section.dialog--search input.searchInput__input"
SEARCH_MODAL_SELECTOR = "section.dialog--search"
SEARCH_CARD_SELECTOR = "section.dialog--search .searchResults a.searchResult"
SEARCH_NAME_SELECTOR = ".searchResult__participantName"
SEARCH_CATEGORY_SELECTOR = ".searchResult__participantCategory"
DEFAULT_SEARCH_TIMEOUT_SECONDS = 20
DEFAULT_MATCH_TIMEOUT_SECONDS = 120
DEFAULT_MAX_MATCHES_PER_CYCLE = 4
DEFAULT_CIRCUIT_TIMEOUTS = 3
DEFAULT_CIRCUIT_COOLDOWN_SECONDS = 120
DEFAULT_CYCLE_BUDGET_SECONDS = 9 * 60
DEFAULT_BROWSER_TABS = 3

CLICK_BLOCKED = "CLICK_BLOCKED"
SELECTOR_NOT_FOUND = "SELECTOR_NOT_FOUND"
NAVIGATION_TIMEOUT = "NAVIGATION_TIMEOUT"
NAVIGATION_FAILED = "NAVIGATION_FAILED"
CACHE_WRITE_FAILED = "CACHE_WRITE_FAILED"
STALE_CACHE_URL = "STALE_CACHE_URL"
CACHE_URL_MISMATCH = "CACHE_URL_MISMATCH"
REDIRECTED_TO_WRONG_MATCH = "REDIRECTED_TO_WRONG_MATCH"
MATCH_IDENTITY_MISMATCH = "MATCH_IDENTITY_MISMATCH"
STATISTICS_TAB_NOT_FOUND = "STATISTICS_TAB_NOT_FOUND"
NO_STATISTICS_RECEIVED = "NO_STATISTICS_RECEIVED"
SEARCH_RESULTS_NOT_DETECTED = "SEARCH_RESULTS_NOT_DETECTED"
TEAM_SEARCH_NO_MATCH = "TEAM_SEARCH_NO_MATCH"
FLASHSCORE_ERROR_PAGE = "FLASHSCORE_ERROR_PAGE"
TEAM_IDENTITY_MISMATCH = "TEAM_IDENTITY_MISMATCH"
TEAM_RESULTS_ROUTE_INVALID = "TEAM_RESULTS_ROUTE_INVALID"
EXPECTED_MATCH_NOT_FOUND = "EXPECTED_MATCH_NOT_FOUND"
MATCH_NOT_FOUND = "MATCH_NOT_FOUND"
MATCH_VERIFICATION_FAILED = "MATCH_VERIFICATION_FAILED"
RETRYABLE = "RETRYABLE"


def _env_value(project_root: Path, key_name: str) -> str | None:
    raw_value = os.environ.get(key_name)
    if raw_value is not None:
        return raw_value.strip().strip("\"'")
    try:
        lines = (project_root / ".env").read_text(encoding="utf-8").splitlines()
    except OSError:
        return None
    for line in lines:
        key, separator, value = line.partition("=")
        if separator and key.strip() == key_name:
            return value.strip().strip("\"'")
    return None


def _int_setting(
    project_root: Path,
    key_name: str,
    default: int,
    minimum: int,
    maximum: int,
) -> int:
    try:
        value = int(_env_value(project_root, key_name) or default)
    except (TypeError, ValueError):
        value = default
    return max(minimum, min(value, maximum))

# RC3 1.3: las métricas se aceptan únicamente por etiqueta de fila exacta.
# La normalización elimina tildes y puntuación, pero nunca convierte xGOT,
# xGOT enfrentados ni Goles evitados en xG directo.
DIRECT_XG_EXACT_LABELS = (
    "Goles esperados (xG)",
    "Expected goals (xG)",
    "xG",
)
STAT_EXACT_LABELS = {
    "total_shots": (
        "Remates totales",
        "Tiros totales",
        "Total de remates",
        "Total shots",
    ),
    "shots_on_target": (
        "Remates a puerta",
        "Tiros a puerta",
        "Remates al arco",
        "Tiros al arco",
        "Shots on target",
    ),
    "shots_off_target": (
        "Remates fuera",
        "Tiros fuera",
        "Remates desviados",
        "Shots off target",
    ),
    "blocked_shots": (
        "Remates rechazados",
        "Remates bloqueados",
        "Tiros rechazados",
        "Tiros bloqueados",
        "Blocked shots",
    ),
    "corners": (
        "Córneres",
        "Córners",
        "Corneres",
        "Saques de esquina",
        "Corners",
        "Corner kicks",
    ),
    "yellow_cards": (
        "Tarjetas amarillas",
        "Amarillas",
        "Yellow cards",
    ),
    "red_cards": (
        "Tarjetas rojas",
        "Rojas",
        "Red cards",
    ),
    "possession": (
        "Posesión",
        "Posesión del balón",
        "Posesión de balón",
        "Ball possession",
        "Possession",
    ),
    "fouls": (
        "Faltas",
        "Fouls",
        "Fouls committed",
    ),
    "offsides": (
        "Fueras de juego",
        "Offsides",
    ),
    "big_chances": (
        "Grandes ocasiones",
        "Grandes oportunidades",
        "Big chances",
    ),
}
# Alias conservados solo para compatibilidad de imports externos. El parser
# interno de RC3 1.3 usa siempre las colecciones EXACT_LABELS anteriores.
DIRECT_XG_ALIASES = DIRECT_XG_EXACT_LABELS
STAT_ALIASES = STAT_EXACT_LABELS
GENERIC_TEAM_WORDS = {
    "afc",
    "cd",
    "cf",
    "club",
    "de",
    "fc",
    "fk",
    "sc",
    "sk",
    "the",
}


def _browser_tab_limit(project_root: Path) -> int:
    """Límite configurable y seguro: mínimo 1, máximo 12 pestañas."""

    return _int_setting(
        project_root,
        "ODDSHUNTER_BRAVE_TABS",
        DEFAULT_BROWSER_TABS,
        1,
        3,
    )


def _normalize(value: Any) -> str:
    text = unicodedata.normalize(
        "NFKD",
        str(value or "").casefold(),
    )
    text = "".join(
        character
        for character in text
        if not unicodedata.combining(character)
    )
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return " ".join(text.split())


def _slugify(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "-", _normalize(value)).strip("-")


def _normalize_flashscore_url(value: Any) -> str:
    """Normaliza URLs relativas o dañadas sin eliminar el identificador útil."""

    raw = str(value or "").strip()
    if not raw:
        return ""
    absolute = urljoin(HOME_URL, raw)
    parsed = urlsplit(absolute)
    scheme = parsed.scheme if parsed.scheme in {"http", "https"} else "https"
    netloc = parsed.netloc or "www.flashscore.es"
    path = re.sub(r"/{2,}", "/", parsed.path or "/")
    filtered_query = []
    for key, item in parse_qsl(parsed.query, keep_blank_values=True):
        lowered = key.casefold()
        if lowered.startswith("utm_") or lowered in {"fbclid", "gclid"}:
            continue
        filtered_query.append((key, item))
    return urlunsplit(
        (scheme, netloc, path, urlencode(filtered_query), "")
    )


def _exception_code(exc: Exception, default: str) -> str:
    name = type(exc).__name__.casefold()
    message = str(exc).casefold()
    if "timeout" in name or "timeout" in message:
        return NAVIGATION_TIMEOUT
    if "selector" in message or "locator" in message:
        return SELECTOR_NOT_FOUND
    navigation_markers = (
        "navigation",
        "page.goto",
        "net::err",
        "connection",
        "aborted",
        "target closed",
        "browser has been closed",
        "page closed",
    )
    if any(marker in message for marker in navigation_markers):
        return NAVIGATION_FAILED
    return default


def _team_tokens(value: Any) -> list[str]:
    tokens = [
        token
        for token in _normalize(value).split()
        if token not in GENERIC_TEAM_WORDS
    ]
    expanded: list[str] = []
    for token in tokens:
        if token == "kc":
            expanded.extend(("kansas", "city"))
        elif token == "utd":
            expanded.append("united")
        else:
            expanded.append(token)
    return expanded


def _team_core(value: Any) -> str:
    return " ".join(_team_tokens(value))


def _tokens(value: Any) -> set[str]:
    return set(_team_tokens(value))


# Equivalencia explícita y limitada aprobada para la prevalidación de BOT 10.4 RC3 final.
# No baja el umbral general ni autoriza categorías de otros países.
SAFE_TEAM_NAME_EQUIVALENTS: frozenset[frozenset[str]] = frozenset(
    {
        frozenset({"la galaxy", "los angeles galaxy"}),
        # UEFA Champions League: equivalencias explícitas y cerradas.
        # La aceptación final continúa exigiendo rival, fecha y contexto UEFA.
        frozenset({"sabah fk", "sabah baku"}),
        frozenset({"the new saints", "tns"}),
        # Champions: SofaScore usa Club Brugge KV; Flashscore ES muestra Club Brujas.
        frozenset({"club brugge kv", "club brujas"}),
        frozenset({"club brugge", "club brujas"}),
        # ODDSHUNTER CHAMPIONS HISTORICAL ALIASES V1
        # Alias cerrados confirmados por diagnósticos reales.
        # No reducen el umbral general de identidad.
        frozenset({"fc struga trim lum", "struga"}),
        frozenset({"ac sparta praha", "sparta praga"}),
        frozenset({"apoel nicosia", "apoel"}),
        frozenset({"ss virtus", "virtus"}),
        frozenset({"malmo ff", "malmo"}),
        # ODDSHUNTER CHAMPIONS SLAVIA ALIASES V1
        # Alias cerrados confirmados por diagnóstico real.
        frozenset({"sk slavia praha", "slavia praga"}),
        frozenset({"slavia prague", "slavia praga"}),
        frozenset({"slavia praha", "slavia praga"}),
        # Nombres distintos entre SofaScore y Flashscore.
        # Se aceptan solo como equivalencias cerradas; la URL final aún debe
        # coincidir con rival, fecha, orientación y contexto de competición.
        frozenset({"inter club d escaldes", "inter escaldes"}),
        frozenset({"lincoln red imps", "lincoln"}),
        frozenset({"fk vardar skopje", "vardar"}),
        frozenset({"kuopion palloseura", "kups"}),
        # Champions: alias confirmados por los diagnósticos reales de la ronda 1.
        frozenset({"floriana fc", "floriana"}),
        frozenset({"sp tre fiori", "tre fiori"}),
        frozenset({"larne fc", "larne"}),
        frozenset({"levski sofia", "levski"}),
        frozenset({"klaksvikar itrottarfelag", "klaksvik if"}),
        # Flashscore muestra el primer equipo como "Klaksvik" en la fila
        # del partido y como "Klaksvik (FAI)" cuando añade el país.
        # Esta equivalencia cerrada no reduce el umbral general: la URL final
        # todavía debe coincidir con Bissen, fecha y orientación local/visitante.
        frozenset({"klaksvikar itrottarfelag", "klaksvik"}),
        frozenset({"klaksvikar itrottarfelag", "ki klaksvik"}),
        frozenset({"atert bissen", "bissen"}),
        # UEFA Conference League: equivalencias cerradas confirmadas por
        # los diagnósticos reales. No reducen el umbral general y la URL
        # final sigue exigiendo rival, fecha, orientación y competición.
        frozenset({"zir fk", "zira"}),
        frozenset({"zir fk", "zire"}),
        frozenset({"differdange fc 03", "differdange"}),
        frozenset({"fc differdange 03", "differdange"}),
        frozenset({"fc torpedo kutaisi", "torpedo kutaisi"}),
        frozenset({"ilves tampere", "ilves"}),
        # CONMEBOL Sudamericana: nombre oficial y abreviaturas de
        # Independiente Santa Fe. La URL final continúa exigiendo rival y fecha.
        frozenset({"independiente santa fe", "ind santa fe"}),
        frozenset({"independiente santa fe", "santa fe"}),
        # PrvaLiga 2026/27: aliases explicitly confirmed by the real cycle.
        frozenset({"kalcer radomlje", "radomlje"}),
        frozenset({"nk bravo", "bravo"}),
        frozenset({"fc koper", "koper"}),
        frozenset({"brinje grosuplje", "grosuplje"}),
        frozenset({"nk olimpija ljubljana", "olimpija ljubljana"}),
        frozenset({"nk aluminij kidricevo", "aluminij"}),
        frozenset({"nk aluminij", "aluminij"}),
    }
)


# ODDSHUNTER_FLASHSCORE_SAFE_ALIASES_V1_1
SAFE_TEAM_NAME_EQUIVALENTS = frozenset(
    set(SAFE_TEAM_NAME_EQUIVALENTS)
    |
    {
        # Premier League:
        # OddsHunter/SofaScore -> Flashscore
        frozenset(
            {
                "tottenham hotspur",
                "tottenham",
            }
        ),

        # Bundesliga Austria:
        # OddsHunter/SofaScore -> Flashscore ES
        frozenset(
            {
                "fk austria wien",
                "austria viena",
            }
        ),

        frozenset(
            {
                "austria wien",
                "austria viena",
            }
        ),
    }
)


UNSAFE_GENERIC_TEAM_QUERIES: frozenset[str] = frozenset(
    {
        "inter",
        "united",
        "city",
        "real",
        "sporting",
        "club",
    }
)


def _is_unsafe_generic_team_query(value: Any) -> bool:
    normalized = _normalize(value)
    return normalized in UNSAFE_GENERIC_TEAM_QUERIES



def _safe_team_identity_name(value: Any) -> str:
    """
    Limpia únicamente el sufijo contextual que Flashscore agrega al
    encabezado, por ejemplo "(AZE)" o "(WAL)".

    Esta limpieza solo se usa contra la lista cerrada de equivalencias
    SAFE_TEAM_NAME_EQUIVALENTS. No reduce el umbral general.
    """
    text = str(value or "").strip()
    text = re.sub(r"\s*\([^()]{2,24}\)\s*$", "", text).strip()
    return _normalize(text)




# LIGA_PORTUGAL_PROMOVIDOS_V5
_LIGA_PORTUGAL_PROMOTED_EQUIVALENTS: frozenset[frozenset[str]] = frozenset(
    {
        frozenset({"cs maritimo", "maritimo"}),
        frozenset({"cs maritimo", "maritimo m"}),
        frozenset({"academico viseu fc", "academico viseu"}),
        frozenset({"academico viseu fc", "academico"}),
    }
)

def _is_safe_team_name_equivalent(expected: Any, candidate: Any) -> bool:
    if _TEAM_IDENTITY_REGISTRY.are_equivalent(expected, candidate):
        return True
    pair = frozenset(
        {
            _safe_team_identity_name(expected),
            _safe_team_identity_name(candidate),
        }
    )
    return bool(pair) and (
        pair in SAFE_TEAM_NAME_EQUIVALENTS
        or pair in _LIGA_PORTUGAL_PROMOTED_EQUIVALENTS
    )


def _name_score(expected: Any, candidate: Any) -> float:
    if _is_safe_team_name_equivalent(expected, candidate):
        return 1.0

    left = _team_core(expected)
    right = _team_core(candidate)
    if not left or not right:
        return 0.0
    if left == right:
        return 1.0

    left_tokens = set(left.split())
    right_tokens = set(right.split())
    token_score = (
        len(left_tokens & right_tokens)
        / max(len(left_tokens | right_tokens), 1)
    )
    containment = 0.0
    if left in right or right in left:
        smaller = left_tokens if len(left_tokens) <= len(right_tokens) else right_tokens
        # A single shared word is not enough to identify a multi-word club.
        # Explicit one-word aliases are handled above by SAFE_TEAM_NAME_EQUIVALENTS.
        if len(smaller) >= 2:
            containment = 0.92
    sequence = SequenceMatcher(None, left, right).ratio()
    score = max(token_score, containment, sequence)
    if (
        len(left_tokens & right_tokens) == 1
        and max(len(left_tokens), len(right_tokens)) >= 2
        and not _is_safe_team_name_equivalent(expected, candidate)
    ):
        score = min(score, 0.69)

    candidate_norm = _normalize(candidate)
    expected_norm = _normalize(expected)
    reserve_markers = (
        " ii",
        " 2",
        "sub 23",
        "sub 21",
        "sub 20",
        "u23",
        "femenino",
    )
    if any(marker in f" {candidate_norm}" for marker in reserve_markers) and not any(
        marker in f" {expected_norm}" for marker in reserve_markers
    ):
        score -= 0.18
    if candidate_norm.endswith(" f") and not expected_norm.endswith(" f"):
        score -= 0.18
    return max(0.0, min(1.0, score))


COUNTRY_HINT_ALIASES: dict[str, tuple[str, ...]] = {
    "mexico": ("mexico", "liga mx", "copa mx"),
    "estados unidos": (
        "estados unidos",
        "usa",
        "mls",
        "major league soccer",
        "us open cup",
    ),
    "colombia": ("colombia", "liga betplay", "copa colombia"),
    "ecuador": ("ecuador", "liga pro", "ligapro"),
    "argentina": ("argentina", "liga profesional", "copa argentina"),
    "brasil": ("brasil", "brasileirao", "serie a brasil"),
    "chile": ("chile", "primera division chile", "copa chile"),
    "peru": ("peru", "liga 1 peru"),
    "uruguay": ("uruguay", "primera division uruguay"),
    "espana": ("espana", "la liga", "copa del rey"),
    "inglaterra": ("inglaterra", "premier league", "fa cup", "efl"),
    "alemania": ("alemania", "bundesliga", "dfb pokal"),
    "italia": ("italia", "serie a", "coppa italia"),
    "francia": ("francia", "ligue 1", "coupe de france"),
    "paises bajos": ("paises bajos", "eredivisie"),
    "portugal": ("portugal", "primeira liga", "taca de portugal"),
    "belgica": ("belgica", "jupiler", "pro league"),
    "eslovenia": ("eslovenia", "slovenia", "prvaliga", "prva liga"),
}


def _competition_country_hints(competition: Any) -> set[str]:
    normalized = _normalize(competition)
    hints: set[str] = set()
    for country, aliases in COUNTRY_HINT_ALIASES.items():
        if any(_normalize(alias) in normalized for alias in aliases):
            hints.add(country)
    return hints


CONTEXTUAL_TEAM_COUNTRY_HINTS: dict[str, set[str]] = {
    "independiente santa fe": {"colombia"},
    "ind santa fe": {"colombia"},
    "santa fe": {"colombia"},
    "caracas fc": {"venezuela"},
    "caracas": {"venezuela"},
    # UEFA: pistas cerradas para nombres abreviados de Flashscore.
    "inter club d escaldes": {"andorra"},
    "inter escaldes": {"andorra"},
    "lincoln red imps": {"gibraltar"},
    "lincoln": {"gibraltar"},
    "fk vardar skopje": {"macedonia del norte"},
    "vardar": {"macedonia del norte"},
    "kuopion palloseura": {"finlandia"},
    "kups": {"finlandia"},
    "floriana fc": {"malta"},
    "floriana": {"malta"},
    "shamrock rovers": {"irlanda"},
    "sp tre fiori": {"san marino"},
    "tre fiori": {"san marino"},
    "larne fc": {"irlanda del norte"},
    "larne": {"irlanda del norte"},
    "fk borac banja luka": {"bosnia y herzegovina"},
    "borac banja luka": {"bosnia y herzegovina"},
    "levski sofia": {"bulgaria"},
    "levski": {"bulgaria"},
    "klaksvikar itrottarfelag": {"islas feroe"},
    "klaksvik if": {"islas feroe"},
    "klaksvik": {"islas feroe"},
    "ki klaksvik": {"islas feroe"},
    "atert bissen": {"luxemburgo"},
    "bissen": {"luxemburgo"},
    # UEFA Conference League: países cerrados para evitar homónimos.
    "zir fk": {"azerbaiyan"},
    "zira": {"azerbaiyan"},
    "zire": {"azerbaiyan"},
    "fc torpedo kutaisi": {"georgia"},
    "torpedo kutaisi": {"georgia"},
    "differdange fc 03": {"luxemburgo"},
    "fc differdange 03": {"luxemburgo"},
    "differdange": {"luxemburgo"},
    "ilves tampere": {"finlandia"},
    "ilves": {"finlandia"},
}


def _contextual_team_country_hints(
    team_name: Any,
    match: MatchRef | None,
) -> set[str]:
    """
    Sudamericana abarca varios países, por lo que el nombre de la competición
    no basta para resolver homónimos. Solo se añaden pistas cerradas para los
    clubes demostrados en el diagnóstico; el resto conserva la lógica previa.
    """
    registry_hints = _TEAM_IDENTITY_REGISTRY.country_hints(team_name)
    if registry_hints:
        return set(registry_hints)
    normalized_team = _normalize(team_name)
    hints = CONTEXTUAL_TEAM_COUNTRY_HINTS.get(normalized_team)
    if hints:
        return set(hints)
    return _competition_country_hints(
        match.competition if match is not None else ""
    )


def _contextual_team_search_variants(
    team_name: Any,
    match: MatchRef | None,
) -> list[str]:
    original = str(team_name or "").strip()
    variants = [original] if original else []
    variants.extend(_TEAM_IDENTITY_REGISTRY.search_variants(original))
    competition = _normalize(
        match.competition if match is not None else ""
    )
    normalized_team = _normalize(original)
    # LIGA_PORTUGAL_PROMOVIDOS_V5_SEARCH
    if normalized_team in {"cs maritimo", "maritimo", "maritimo m"}:
        variants.extend(("Maritimo", "Marítimo"))
    elif normalized_team in {"academico viseu fc", "academico viseu", "academico"}:
        variants.extend(("Academico Viseu", "Académico Viseu"))
    if (
        "sudamericana" in competition
        and normalized_team == "independiente santa fe"
    ):
        variants.extend(("Santa Fe", "Ind. Santa Fe"))
    elif normalized_team == "inter club d escaldes":
        variants.append("Inter Escaldes")
    elif normalized_team == "lincoln red imps":
        variants.append("Lincoln")
    elif normalized_team == "fk vardar skopje":
        variants.extend(("Vardar", "Vardar Skopje"))
    elif normalized_team == "kuopion palloseura":
        variants.append("KuPS")
    elif normalized_team == "floriana fc":
        variants.append("Floriana")
    elif normalized_team == "sp tre fiori":
        variants.append("Tre Fiori")
    elif normalized_team == "larne fc":
        variants.append("Larne")
    elif normalized_team == "levski sofia":
        variants.append("Levski")
    elif normalized_team == "klaksvikar itrottarfelag":
        variants.extend(("Klaksvik IF", "Klaksvik"))
    elif normalized_team == "atert bissen":
        variants.append("Bissen")
    elif normalized_team in {"zir fk", "zira", "zire"}:
        variants.extend(("Zira", "Zire"))
    elif normalized_team in {"differdange fc 03", "fc differdange 03"}:
        variants.extend(("Differdange", "Differdange 03"))
    elif normalized_team == "fc torpedo kutaisi":
        variants.append("Torpedo Kutaisi")
    elif normalized_team == "ilves tampere":
        variants.append("Ilves")
    return list(dict.fromkeys(value for value in variants if value))


def _competition_results_pages(match: MatchRef) -> list[str]:
    normalized = _normalize(match.competition)
    if "sudamericana" in normalized:
        return [
            "https://www.flashscore.es/futbol/sudamerica/"
            "copa-sudamericana/resultados/",
            "https://www.flashscore.es/futbol/sudamerica/"
            "copa-sudamericana/archive/",
        ]
    if "conference" in normalized:
        return [
            "https://www.flashscore.es/futbol/europa/"
            "conference-league/resultados/",
            "https://www.flashscore.es/futbol/europa/"
            "conference-league/archive/",
        ]
    return []


def _category_country_matches(category: Any, country_hints: set[str]) -> bool:
    """Devuelve True cuando la categoría pertenece al país esperado.

    Con un país conocido, RC3 1.3 descarta candidatos de otro país en lugar de
    compensar el error con una similitud alta de nombre. Así LA Galaxy (MLS)
    nunca puede resolverse como Galaxy de Lesoto.
    """

    if not country_hints:
        return True
    normalized = _normalize(category)
    return any(_normalize(country) in normalized for country in country_hints)


def _category_is_association_football(category: Any) -> bool:
    """Acepta solo fútbol de campo y rechaza futsal u otros deportes.

    Flashscore mezcla en el mismo buscador clubes de fútbol, fútbol sala,
    baloncesto y otros deportes. Un nombre idéntico no puede compensar una
    categoría deportiva incorrecta, por ejemplo Levski Sofia de fútbol sala.
    """

    normalized = _normalize(category)
    if not normalized:
        return False
    forbidden = (
        "futbol sala",
        "futsal",
        # ODDSHUNTER CONFERENCE BLOCK 11-15 V1: reject non-field football
        "futbol playa",
        "football playa",
        "beach soccer",
        "soccer playa",
        "baloncesto",
        "basketball",
        "balonmano",
        "handball",
        "hockey",
        "voleibol",
        "volleyball",
        "tenis",
        "tennis",
    )
    if any(marker in normalized for marker in forbidden):
        return False
    return (
        normalized == "futbol"
        or normalized.startswith("futbol ")
        or normalized == "football"
        or normalized.startswith("football ")
    )


def _category_context_score(category: Any, country_hints: set[str]) -> float:
    if not country_hints:
        return 0.0
    return 0.08 if _category_country_matches(category, country_hints) else -1.0

def _candidate_country(category: Any) -> str:
    value = str(category or "").strip()
    if not value:
        return ""
    parts = [part.strip() for part in re.split(r"[,|]", value) if part.strip()]
    return parts[-1] if len(parts) >= 2 else value


def _candidate_variant_mismatch(expected: Any, candidate: Any) -> str | None:
    expected_norm = _normalize(expected)
    candidate_norm = _normalize(candidate)
    female_markers = (" femenino", " women", " w", " f")
    # ODDSHUNTER CONFERENCE BLOCK 11-15 V1: reject youth variants
    reserve_markers = (
        " ii",
        " iii",
        " iv",
        " 2",
        " u23",
        " u21",
        " u20",
        " u19",
        " u18",
        " u17",
        " sub 23",
        " sub 21",
        " sub 20",
        " sub 19",
        " sub 18",
        " sub 17",
        " juvenil",
        " youth",
    )
    expected_female = any(expected_norm.endswith(marker) for marker in female_markers)
    candidate_female = any(candidate_norm.endswith(marker) for marker in female_markers)
    if candidate_female and not expected_female:
        return "GENDER_MISMATCH"
    expected_reserve = any(marker in f" {expected_norm}" for marker in reserve_markers)
    candidate_reserve = any(marker in f" {candidate_norm}" for marker in reserve_markers)
    if candidate_reserve and not expected_reserve:
        return "RESERVE_TEAM_MISMATCH"
    return None


def _candidate_name_context_valid(expected: Any, candidate: Any, score: float) -> bool:
    if _is_safe_team_name_equivalent(expected, candidate):
        return True
    left = _team_core(expected)
    right = _team_core(candidate)
    if left and left == right:
        return True
    left_tokens = set(left.split())
    right_tokens = set(right.split())
    overlap = len(left_tokens & right_tokens)
    return bool(score >= 0.78 and overlap >= 2)


def _flashscore_page_snapshot(page: Page) -> dict[str, Any]:
    try:
        value = page.evaluate(
            r"""
            () => {
                const visible = element => Boolean(
                    element && (
                        element.offsetWidth ||
                        element.offsetHeight ||
                        element.getClientRects().length
                    )
                );
                const text = element => (element?.innerText || '').trim();
                const headers = [];
                const headerSelectors = [
                    'h1',
                    '.heading__name',
                    '[class*="heading__name"]',
                    '[class*="teamHeader"] [class*="name"]',
                    '[class*="teamHeader"]',
                    '[class*="participant__participantName"]'
                ];
                for (const selector of headerSelectors) {
                    for (const element of document.querySelectorAll(selector)) {
                        if (!visible(element)) continue;
                        const value = text(element);
                        if (value && !headers.includes(value)) headers.push(value);
                    }
                }
                const resultsLinks = [];
                for (const anchor of document.querySelectorAll('a[href]')) {
                    if (!visible(anchor)) continue;
                    const label = text(anchor).toLocaleLowerCase('es');
                    const href = (anchor.href || '').trim();
                    const normalizedHref = href.toLocaleLowerCase('es');
                    if (
                        label === 'resultados' ||
                        label === 'results' ||
                        label.startsWith('resultados ') ||
                        normalizedHref.includes('/resultados/') ||
                        normalizedHref.includes('/results/')
                    ) {
                        resultsLinks.push({label, href});
                    }
                }
                const matchLinks = Array.from(document.querySelectorAll(
                    'a[href*="/partido/futbol/"],a[href*="/match/football/"]'
                )).filter(visible).length;
                const eventRows = Array.from(document.querySelectorAll(
                    '[class*="event__match"],[class*="eventRow"],[data-testid*="event"]'
                )).filter(visible).length;
                const errorNodes = Array.from(document.querySelectorAll(
                    '[class*="error"], [data-testid*="error"]'
                )).filter(visible).map(text).filter(Boolean).slice(0, 20);
                return {
                    url: location.href,
                    title: document.title || '',
                    body_text: (document.body?.innerText || '').slice(0, 12000),
                    headers: headers.slice(0, 20),
                    results_links: resultsLinks.slice(0, 30),
                    match_link_count: matchLinks,
                    event_row_count: eventRows,
                    error_nodes: errorNodes
                };
            }
            """
        )
    except Exception:
        value = {}
    if not isinstance(value, dict):
        value = {}
    value.setdefault("url", str(getattr(page, "url", "") or ""))
    value.setdefault("title", "")
    value.setdefault("body_text", "")
    value.setdefault("headers", [])
    value.setdefault("results_links", [])
    value.setdefault("match_link_count", 0)
    value.setdefault("event_row_count", 0)
    value.setdefault("error_nodes", [])
    return value


def flashscore_page_health(
    page: Page,
    *,
    expected_team: str | None = None,
    require_results: bool = False,
) -> dict[str, Any]:
    snapshot = _flashscore_page_snapshot(page)
    url = str(snapshot.get("url") or getattr(page, "url", "") or "")
    title = _normalize(snapshot.get("title"))
    body = _normalize(snapshot.get("body_text"))
    error_nodes = _normalize(" ".join(str(value) for value in snapshot.get("error_nodes", [])))
    explicit_markers = (
        "la pagina solicitada no puede ser mostrada",
        "requested page cannot be displayed",
        "pagina no encontrada",
        "page not found",
    )
    explicit_error = any(marker in body or marker in title or marker in error_nodes for marker in explicit_markers)
    generic_error = bool(
        title in {"error", "flashscore error"}
        or body.startswith("error ")
        or error_nodes.startswith("error ")
    )
    parsed = urlsplit(url)
    redirected_home = bool(
        (expected_team or require_results)
        and parsed.netloc.endswith("flashscore.es")
        and parsed.path.rstrip("/") == ""
        and not parsed.query
    )
    headers = [str(value) for value in snapshot.get("headers", []) if str(value).strip()]
    raw_title = str(snapshot.get("title") or "").strip()
    if raw_title:
        headers.append(raw_title)
    header_score = max(
        (_name_score(expected_team, value) for value in headers),
        default=0.0,
    ) if expected_team else 1.0
    heading_missing = bool(expected_team and header_score < 0.72)
    route_norm = _normalize(parsed.path)
    results_section_present = bool(
        snapshot.get("results_links")
        or "resultados" in route_norm
        or "results" in route_norm
    )
    real_match_count = max(
        int(snapshot.get("match_link_count") or 0),
        int(snapshot.get("event_row_count") or 0),
    )
    results_missing = bool(
        require_results
        and (not results_section_present or real_match_count <= 0)
    )
    is_error = bool(
        explicit_error
        or generic_error
        or redirected_home
        or heading_missing
        or results_missing
    )
    return {
        **snapshot,
        "is_error": is_error,
        "explicit_error": explicit_error,
        "generic_error": generic_error,
        "redirected_home": redirected_home,
        "heading_missing": heading_missing,
        "header_score": round(header_score, 4),
        "results_section_present": results_section_present,
        "real_match_count": real_match_count,
        "results_missing": results_missing,
    }


def is_flashscore_error_page(
    page: Page,
    *,
    expected_team: str | None = None,
    require_results: bool = False,
) -> bool:
    return bool(
        flashscore_page_health(
            page,
            expected_team=expected_team,
            require_results=require_results,
        ).get("is_error")
    )


def _competition_identity_tokens(value: Any) -> set[str]:
    ignored = {
        "de", "del", "la", "el", "liga", "copa", "cup", "league",
        "futbol", "football", "primera", "division", "temporada",
        "apertura", "clausura", "uefa", "conmebol", "the",
    }
    return {
        token
        for token in _normalize(value).split()
        if token not in ignored and not token.isdigit() and len(token) > 2
    }


def _row_date_state(text: Any, kickoff: Any) -> tuple[bool | None, float]:
    parsed = _parse_kickoff(str(kickoff or ""))
    allowed: set[str] = set()
    for offset in (-1, 0, 1):
        value = parsed + timedelta(days=offset)
        allowed.update(
            {
                value.strftime("%d/%m/%Y"),
                value.strftime("%d.%m.%Y"),
                value.strftime("%d/%m"),
                value.strftime("%d.%m"),
            }
        )
    found = re.findall(
        r"\b\d{1,2}[./]\d{1,2}(?:[./]\d{2,4})?\b",
        str(text or ""),
    )
    if not found:
        return None, 0.0
    if any(item in allowed for item in found):
        return True, 0.10
    return False, -1.0


def _name_score_in_text(expected: Any, text: Any) -> float:
    expected_core = _team_core(expected)
    normalized_text = _normalize(text)
    if expected_core and re.search(
        rf"(?:^|\s){re.escape(expected_core)}(?:$|\s)",
        normalized_text,
    ):
        return 1.0
    lines = [
        line.strip()
        for line in str(text or "").splitlines()
        if line.strip()
    ]
    return max(
        [_name_score(expected, line) for line in lines]
        + [_name_score(expected, text)]
    )


def _match_row_score(
    match: MatchRef,
    text: Any,
) -> tuple[float, dict[str, Any]]:
    """
    Puntúa una fila individual, no un bloque global. Exige que local y
    visitante aparezcan en el orden correcto; así el partido de vuelta no puede
    representar al partido de ida aunque contenga los mismos clubes.
    """
    row_text = str(text or "")
    lines = [
        line.strip()
        for line in row_text.splitlines()
        if line.strip()
    ]

    best_home = 0.0
    best_away = 0.0
    ordered_pair: tuple[int, int] | None = None
    for home_index, home_line in enumerate(lines):
        home_score = _name_score(match.home_team, home_line)
        if home_score < 0.72:
            continue
        for away_index in range(
            home_index + 1,
            min(len(lines), home_index + 7),
        ):
            away_score = _name_score(
                match.away_team,
                lines[away_index],
            )
            if away_score < 0.72:
                continue
            if (
                home_score + away_score
                > best_home + best_away
            ):
                best_home = home_score
                best_away = away_score
                ordered_pair = (home_index, away_index)

    if ordered_pair is None:
        return 0.0, {
            "home_score": round(
                _name_score_in_text(match.home_team, row_text),
                4,
            ),
            "away_score": round(
                _name_score_in_text(match.away_team, row_text),
                4,
            ),
            "orientation_match": False,
            "date_match": None,
            "competition_overlap": 0,
        }

    date_match, date_bonus = _row_date_state(
        row_text,
        match.kickoff,
    )
    if date_match is False:
        return 0.0, {
            "home_score": round(best_home, 4),
            "away_score": round(best_away, 4),
            "orientation_match": True,
            "date_match": False,
            "competition_overlap": 0,
        }

    competition_tokens = _competition_identity_tokens(
        match.competition
    )
    row_tokens = set(_normalize(row_text).split())
    competition_overlap = len(
        competition_tokens & row_tokens
    )
    competition_bonus = min(
        0.05,
        competition_overlap * 0.02,
    )
    score = (
        best_home * 0.45
        + best_away * 0.45
        + date_bonus
        + competition_bonus
    )
    return round(min(score, 1.0), 4), {
        "home_score": round(best_home, 4),
        "away_score": round(best_away, 4),
        "orientation_match": True,
        "ordered_line_indexes": list(ordered_pair),
        "date_match": date_match,
        "competition_overlap": competition_overlap,
    }


def _team_result_from_search_item(
    item: dict[str, Any],
) -> dict[str, Any] | None:
    """Normaliza una tarjeta real del modal de búsqueda de Flashscore."""

    text = str(item.get("text") or "").strip()
    display_name = str(item.get("name") or "").strip()
    if not display_name and text:
        display_name = text.splitlines()[0].strip()
    raw_href = str(
        item.get("raw_href")
        or item.get("href")
        or ""
    ).strip()
    category = str(item.get("category") or "").strip()
    if not display_name or not raw_href:
        return None

    identifier = ""
    slug = ""
    query_match = re.search(r"[?&]r=3:([A-Za-z0-9]+)", raw_href)
    if query_match is not None:
        identifier = query_match.group(1)
        slug = _slugify(display_name)
    else:
        parsed = urlsplit(raw_href)
        parts = [part for part in parsed.path.split("/") if part]
        for marker in ("equipo", "team"):
            if marker not in parts:
                continue
            position = parts.index(marker)
            if len(parts) > position + 2:
                slug = parts[position + 1]
                identifier = parts[position + 2]
            break

    if not identifier:
        return None
    if not slug:
        slug = _slugify(display_name)

    team_url = (
        _normalize_flashscore_url(raw_href)
        if "/equipo/" in raw_href or "/team/" in raw_href
        else f"https://www.flashscore.es/equipo/{slug}/{identifier}/"
    )
    return {
        "id": identifier,
        "name": display_name,
        "slug": slug,
        "url": team_url,
        "raw_href": raw_href,
        "category": category,
        "selector": str(item.get("selector") or SEARCH_CARD_SELECTOR),
        "index": int(item.get("index") or 0),
    }


def _parse_kickoff(value: str) -> datetime:
    text = str(value or "").strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        parsed = datetime.now(timezone.utc)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _number(value: Any, *, integer: bool) -> float | int | None:
    if value is None or isinstance(value, bool):
        return None
    pattern = (
        r"(?<![\d.,])(\d{1,3})(?![\d.,])"
        if integer
        else r"(?<![\d.,])(\d{1,2}(?:[.,]\d{1,3})?)(?![\d.,])"
    )
    match = re.search(pattern, str(value))
    if match is None:
        return None
    try:
        parsed = float(match.group(1).replace(",", "."))
    except ValueError:
        return None
    if not math.isfinite(parsed) or parsed < 0:
        return None
    return int(parsed) if integer else parsed


def _label_equals(text: Any, aliases: tuple[str, ...]) -> bool:
    normalized = _normalize(text)
    return bool(normalized) and normalized in {_normalize(alias) for alias in aliases}


def _extract_exact_pair_from_lines(
    lines: list[str],
    aliases: tuple[str, ...],
    *,
    integer: bool,
) -> tuple[float | int, float | int] | None:
    """Extrae exclusivamente valor local -> etiqueta exacta -> visitante.

    No busca subcadenas. Por tanto una fila ``xG a puerta (xGOT)`` nunca puede
    satisfacer la etiqueta exacta ``xG`` o ``Goles esperados (xG)``.
    """

    normalized_aliases = {_normalize(alias) for alias in aliases}
    for index, line in enumerate(lines):
        normalized_line = _normalize(line)
        # También admite una fila compacta en una sola línea, pero solo si al
        # retirar sus dos valores el texto restante coincide EXACTAMENTE con
        # una etiqueta aprobada. Ej.: "12 Remates totales 10". Una fila xGOT
        # no puede pasar esta comprobación para la etiqueta xG.
        compact_values = [
            _number(token, integer=integer)
            for token in re.findall(r"\d+(?:[.,]\d+)?", line)
        ]
        compact_values = [value for value in compact_values if value is not None]
        label_only = re.sub(r"\d+(?:[.,]\d+)?%?", " ", line)
        if (
            _normalize(label_only) in normalized_aliases
            and len(compact_values) >= 2
        ):
            return compact_values[0], compact_values[-1]

        if normalized_line not in normalized_aliases:
            continue

        before: float | int | None = None
        after: float | int | None = None
        # Flashscore suele presentar local / etiqueta / visitante. Se limita
        # la búsqueda a tres líneas para no mezclar filas vecinas.
        for position in range(index - 1, max(-1, index - 4), -1):
            parsed = _number(lines[position], integer=integer)
            if parsed is not None:
                before = parsed
                break
            if lines[position].strip():
                break
        for position in range(index + 1, min(len(lines), index + 4)):
            parsed = _number(lines[position], integer=integer)
            if parsed is not None:
                after = parsed
                break
            if lines[position].strip():
                break
        if before is not None and after is not None:
            return before, after
    return None


def _extract_exact_pair(
    rows: list[dict[str, Any]],
    body_lines: list[str],
    aliases: tuple[str, ...],
    *,
    integer: bool,
) -> tuple[float | int, float | int] | None:
    """Extrae una pareja desde filas DOM exactas y usa texto como respaldo."""

    normalized_aliases = {_normalize(alias) for alias in aliases}
    ranked: list[tuple[int, tuple[float | int, float | int]]] = []
    for row in rows:
        label = str(row.get("label") or "")
        if _normalize(label) not in normalized_aliases:
            continue
        home = _number(row.get("home"), integer=integer)
        away = _number(row.get("away"), integer=integer)
        if home is not None and away is not None:
            ranked.append((int(row.get("line_count") or 999), (home, away)))
            continue
        row_lines = [
            line.strip()
            for line in str(row.get("text") or "").splitlines()
            if line.strip()
        ]
        pair = _extract_exact_pair_from_lines(row_lines, aliases, integer=integer)
        if pair is not None:
            ranked.append((len(row_lines), pair))
    if ranked:
        ranked.sort(key=lambda item: item[0])
        return ranked[0][1]
    return _extract_exact_pair_from_lines(body_lines, aliases, integer=integer)


# ODDSHUNTER VERIFIED ZERO YELLOW CARDS V1: LABEL PRESENCE
def _exact_stat_label_present(
    rows: list[dict[str, Any]],
    body_lines: list[str],
    aliases: tuple[str, ...],
) -> bool:
    # Distingue una fila ausente de una fila presente pero ilegible.
    # Si la etiqueta existe y no se puede parsear, nunca se inventa 0-0.
    normalized_aliases = {_normalize(alias) for alias in aliases}

    for row in rows:
        label = str(row.get("label") or "")
        if _normalize(label) in normalized_aliases:
            return True

        for line in str(row.get("text") or "").splitlines():
            if _normalize(line) in normalized_aliases:
                return True

    for line in body_lines:
        if _normalize(line) in normalized_aliases:
            return True

        label_only = re.sub(r"\d+(?:[.,]\d+)?%?", " ", str(line))
        if _normalize(label_only) in normalized_aliases:
            return True

    return False

def _extract_pair(
    candidates: list[dict[str, Any]],
    body_lines: list[str],
    aliases: tuple[str, ...],
    *,
    integer: bool,
) -> tuple[float | int, float | int] | None:
    """Compatibilidad estricta para pruebas y módulos antiguos."""

    # Primero conserva filas DOM/candidatos con local -> etiqueta -> visitante.
    pair = _extract_exact_pair(candidates, [], aliases, integer=integer)
    if pair is not None:
        return pair

    normalized_aliases = {_normalize(alias) for alias in aliases}
    sources = [
        [line.strip() for line in str(candidate.get("text") or "").splitlines() if line.strip()]
        for candidate in candidates
    ]
    sources.append([line.strip() for line in body_lines if line.strip()])
    # Compatibilidad con etiqueta -> local -> visitante. Se verifica antes del
    # fallback local/etiqueta/visitante para no tomar el valor final de la fila
    # anterior como local de la fila actual.
    for lines in sources:
        for index, line in enumerate(lines):
            if _normalize(line) not in normalized_aliases:
                continue
            after: list[float | int] = []
            for position in range(index + 1, min(len(lines), index + 4)):
                parsed = _number(lines[position], integer=integer)
                if parsed is None:
                    break
                after.append(parsed)
            if len(after) >= 2:
                return after[0], after[1]

    return _extract_exact_pair([], body_lines, aliases, integer=integer)


def _env_bool(project_root: Path, key_name: str, default: bool) -> bool:
    raw = _env_value(project_root, key_name)
    if raw is None:
        return bool(default)
    return str(raw).strip().lower() in {"1", "true", "yes", "on", "si", "sí"}


def find_browser_executable() -> Path | None:
    """Devuelve un Chromium/Chrome explícito si existe.

    En Linux cloud es válido devolver ``None``: Playwright usará el Chromium
    administrado por ``python -m playwright install chromium``.
    """

    explicit = str(os.environ.get("ODDSHUNTER_BROWSER_EXECUTABLE") or "").strip()
    if explicit:
        candidate = Path(explicit).expanduser()
        if candidate.exists():
            return candidate
        raise FileNotFoundError(
            f"ODDSHUNTER_BROWSER_EXECUTABLE no existe: {candidate}"
        )

    candidates: list[Path] = []

    # Windows / OddsHunter Desktop.
    for base, relative in (
        (
            os.environ.get("PROGRAMFILES"),
            "BraveSoftware/Brave-Browser/Application/brave.exe",
        ),
        (
            os.environ.get("PROGRAMFILES(X86)"),
            "BraveSoftware/Brave-Browser/Application/brave.exe",
        ),
        (
            os.environ.get("LOCALAPPDATA"),
            "BraveSoftware/Brave-Browser/Application/brave.exe",
        ),
    ):
        if base:
            candidates.append(Path(base) / relative)

    # Linux VPS / runners.
    for value in (
        "/usr/bin/chromium",
        "/usr/bin/chromium-browser",
        "/usr/bin/google-chrome",
        "/usr/bin/google-chrome-stable",
        "/usr/bin/brave-browser",
        "/snap/bin/chromium",
    ):
        candidates.append(Path(value))

    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def find_brave() -> Path:
    """Compatibilidad con llamadas históricas del Desktop."""
    candidate = find_browser_executable()
    if candidate is not None:
        return candidate
    raise FileNotFoundError(
        "No se encontró navegador del sistema. En Linux cloud instala el "
        "Chromium administrado por Playwright o define "
        "ODDSHUNTER_BROWSER_EXECUTABLE."
    )


class FlashscoreXGClient:
    name = "flashscore"

    def __init__(
        self,
        playwright: Playwright,
        *,
        project_root: str | Path,
        logger: Callable[[str], None] | None = None,
    ) -> None:
        self.playwright = playwright
        self.project_root = Path(project_root)
        self.logger = logger or (lambda _message: None)
        self.identity_registry = get_default_team_identity_registry(
            self.project_root
        )
        self.profile_dir = (
            self.project_root
            / "data"
            / "flashscore_xg_profile"
        )
        self.cache_path = (
            self.project_root
            / "data"
            / "cache"
            / "flashscore_match_cache.json"
        )
        self.profile_dir.mkdir(parents=True, exist_ok=True)
        self.context: BrowserContext | None = None
        self.pages: list[Page] = []
        self.page: Page | None = None
        self._active_page: Page | None = None
        self._page_cursor = -1
        self._assigned_match_pages: dict[str, Page] = {}
        self.max_tabs = _browser_tab_limit(self.project_root)
        self.search_timeout_seconds = _int_setting(
            self.project_root,
            "ODDSHUNTER_FLASHSCORE_SEARCH_TIMEOUT",
            DEFAULT_SEARCH_TIMEOUT_SECONDS,
            3,
            30,
        )
        self.match_timeout_seconds = _int_setting(
            self.project_root,
            "ODDSHUNTER_FLASHSCORE_MATCH_TIMEOUT",
            DEFAULT_MATCH_TIMEOUT_SECONDS,
            10,
            90,
        )
        self.max_matches_per_cycle = _int_setting(
            self.project_root,
            "ODDSHUNTER_FLASHSCORE_MAX_MATCHES_PER_CYCLE",
            DEFAULT_MAX_MATCHES_PER_CYCLE,
            0,
            50,
        )
        self.circuit_timeout_limit = _int_setting(
            self.project_root,
            "ODDSHUNTER_FLASHSCORE_CIRCUIT_TIMEOUTS",
            DEFAULT_CIRCUIT_TIMEOUTS,
            1,
            10,
        )
        budget_file = _env_value(
            self.project_root,
            "ODDSHUNTER_FLASHSCORE_BUDGET_FILE",
        )
        self.budget_file = Path(budget_file) if budget_file else None
        self.recovery_cooldown_seconds = _int_setting(
            self.project_root,
            "ODDSHUNTER_FLASHSCORE_RECOVERY_COOLDOWN",
            DEFAULT_CIRCUIT_COOLDOWN_SECONDS,
            0,
            600,
        )
        self.cycle_budget_seconds = _int_setting(
            self.project_root,
            "ODDSHUNTER_FLASHSCORE_CYCLE_BUDGET",
            DEFAULT_CYCLE_BUDGET_SECONDS,
            60,
            15 * 60,
        )
        self._configured_max_tabs = self.max_tabs
        self._effective_max_tabs = self.max_tabs
        self._successful_recovery_attempts = 0
        self._cycle_started_at = time.monotonic()
        self._cycle_budget_exhausted_flag = False
        self._sleep = time.sleep
        self._attempted_matches = 0
        self._consecutive_timeouts = 0
        self._circuit_open = False
        self._circuit_message_emitted = False
        self._last_attempt_timed_out = False
        self._match_deadline: float | None = None
        self._current_match_for_debug: MatchRef | None = None
        self._last_team_search_failure_code: str | None = None
        self._last_navigation_trace: dict[str, Any] = {}
        self._navigation_traces_by_key: dict[str, dict[str, Any]] = {}
        self._active_event_id: int | None = None
        self._event_temporary_state: dict[str, Any] = {}
        self.team_cache: dict[str, dict[str, Any]] = {}
        self.match_cache = self._read_cache()
        self._prepared: dict[
            str,
            tuple[
                DirectXG | None,
                MatchAggregateStats | None,
                dict[str, MetricPair],
            ],
        ] = {}

    def _event_id(self, match: MatchRef) -> int | None:
        value = match.sofascore_event_id or match.match_id
        try:
            return int(value) if value is not None else None
        except (TypeError, ValueError):
            return None


    def _new_navigation_trace(self, match: MatchRef) -> dict[str, Any]:
        event_id = self._event_id(match)
        return {
            "event_id": event_id,
            "expected_home": match.home_team,
            "expected_away": match.away_team,
            "expected_date": _parse_kickoff(match.kickoff).date().isoformat(),
            "home_team": match.home_team,
            "away_team": match.away_team,
            "state_reset_for_event": True,
            "inherited_url": False,
            "candidate_url": None,
            "found_home": None,
            "found_away": None,
            "found_date": None,
            "verification_result": "PENDING",
            "cache_status": "NOT_CHECKED",
            "cache_invalidated": False,
            "cache_invalidation_persisted": False,
            "wrong_match_metrics_blocked": False,
            "team_searches": [],
            "team_profile_opened": False,
            "team_profile_verified": False,
            "results_opened": False,
            "flashscore_error_page_detected": False,
            "invalid_results_route_saved": False,
            "team_base_page_verified": False,
            "real_results_link_discovered": False,
            "team_results_route_valid": False,
            "wrong_country_candidate_opened": False,
            "team_clicks": [],
            "match_identity_verified": False,
            "match_url_resolved": False,
            "statistics_opened": False,
            "metrics_received": [],
            "metric_values": {},
            "metrics_received_any": False,
            "cache_reused": False,
            "cache_saved": False,
            "cache_write_ok": False,
            "stale_cache_recovered": False,
        }


    def _reset_event_state(self, match: MatchRef) -> None:
        """Reinicia todo estado temporal que nunca debe cruzar event_id."""
        event_id = self._event_id(match)
        key = self._match_key(match)
        self._active_event_id = event_id
        self._last_team_search_failure_code = None
        self._current_match_for_debug = match
        self._last_navigation_trace = self._new_navigation_trace(match)
        self._navigation_traces_by_key[key] = dict(self._last_navigation_trace)
        self._event_temporary_state = {
            "event_id": event_id,
            "current_match_url": None,
            "statistics_url": None,
            "cached_match_url": None,
            "last_valid_url": None,
            "search_results": [],
            "temporary_metrics": {},
            "verification_state": "PENDING",
        }
        # Ninguna referencia a una pestaña del evento anterior se considera activa.
        self._active_page = None
        self.page = None


    def _remember_navigation_trace(self, match: MatchRef) -> None:
        key = self._match_key(match)
        try:
            snapshot = json.loads(
                json.dumps(self._last_navigation_trace, ensure_ascii=False, default=str)
            )
        except Exception:
            snapshot = dict(self._last_navigation_trace)
        self._navigation_traces_by_key[key] = snapshot


    def navigation_trace_for(self, match: MatchRef) -> dict[str, Any]:
        return dict(self._navigation_traces_by_key.get(self._match_key(match), {}))

    def _read_budget(self) -> dict[str, Any]:
        path = getattr(self, "budget_file", None)
        if path is None:
            return {}
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}
        return value if isinstance(value, dict) else {}

    def _write_budget(self, state: dict[str, Any]) -> None:
        path = getattr(self, "budget_file", None)
        if path is None:
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_text(
            json.dumps(state, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        temporary.replace(path)

    def _cycle_budget_exhausted(self) -> bool:
        started = float(getattr(self, "_cycle_started_at", time.monotonic()))
        budget = float(
            getattr(
                self,
                "cycle_budget_seconds",
                DEFAULT_CYCLE_BUDGET_SECONDS,
            )
        )
        exhausted = time.monotonic() - started >= budget
        if exhausted:
            self._cycle_budget_exhausted_flag = True
        return exhausted

    def _reserve_cycle_attempt(self) -> bool:
        max_attempts = int(
            getattr(
                self,
                "max_matches_per_cycle",
                DEFAULT_MAX_MATCHES_PER_CYCLE,
            )
        )
        if self._cycle_budget_exhausted():
            return False
        if bool(getattr(self, "_circuit_open", False)):
            return False
        state = self._read_budget()
        attempted = int(
            state.get(
                "attempted_matches",
                getattr(self, "_attempted_matches", 0),
            )
            or 0
        )
        if max_attempts <= 0 or attempted >= max_attempts:
            return False
        attempted += 1
        self._attempted_matches = attempted
        state.update(
            {
                "attempted_matches": attempted,
                "max_matches": max_attempts,
                "consecutive_timeouts": int(
                    state.get(
                        "consecutive_timeouts",
                        getattr(self, "_consecutive_timeouts", 0),
                    )
                    or 0
                ),
                "circuit_open": False,
                "cycle_budget_seconds": int(
                    getattr(
                        self,
                        "cycle_budget_seconds",
                        DEFAULT_CYCLE_BUDGET_SECONDS,
                    )
                ),
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
        )
        self._write_budget(state)
        return True

    def _close_browser_session(self) -> None:
        for page in list(getattr(self, "pages", [])):
            try:
                if not page.is_closed():
                    page.close()
            except Exception:
                pass
        context = getattr(self, "context", None)
        if context is not None:
            try:
                context.close()
            except Exception:
                pass
        self.pages = []
        self.page = None
        self._active_page = None
        self._assigned_match_pages = {}
        self.context = None

    def _recover_browser_after_timeouts(self, consecutive: int) -> None:
        cooldown = int(
            getattr(
                self,
                "recovery_cooldown_seconds",
                DEFAULT_CIRCUIT_COOLDOWN_SECONDS,
            )
        )
        self.logger(
            "Flashscore: tres timeouts consecutivos; cerrando sesión y "
            "pestañas para recuperar el navegador. "
            f"acción=reinicio; espera={cooldown}s; pestañas_iniciales=1."
        )
        self._close_browser_session()
        sleeper = getattr(self, "_sleep", time.sleep)
        if cooldown > 0:
            sleeper(cooldown)
        self._consecutive_timeouts = 0
        self._circuit_open = False
        self._circuit_message_emitted = False
        self._effective_max_tabs = 1
        self._successful_recovery_attempts = 0
        self.logger(
            "Flashscore: navegador reiniciado; se continúa con una pestaña "
            "y recuperación gradual hasta el límite configurado."
        )

    def _record_attempt_outcome(
        self,
        *,
        success: bool,
        timed_out: bool,
    ) -> None:
        state = self._read_budget()
        consecutive = int(
            state.get(
                "consecutive_timeouts",
                getattr(self, "_consecutive_timeouts", 0),
            )
            or 0
        )
        if success:
            consecutive = 0
            configured = int(
                getattr(self, "_configured_max_tabs", getattr(self, "max_tabs", 1))
            )
            effective = int(
                getattr(self, "_effective_max_tabs", configured)
            )
            if effective < configured:
                effective += 1
                self._effective_max_tabs = effective
                self._successful_recovery_attempts = int(
                    getattr(self, "_successful_recovery_attempts", 0)
                ) + 1
                self.logger(
                    "Flashscore: recuperación estable; límite temporal de "
                    f"pestañas aumentado a {effective}."
                )
        elif timed_out:
            consecutive += 1
        self._consecutive_timeouts = consecutive
        limit = int(
            getattr(
                self,
                "circuit_timeout_limit",
                DEFAULT_CIRCUIT_TIMEOUTS,
            )
        )
        recovered = False
        if consecutive >= limit:
            self._circuit_open = True
            self._recover_browser_after_timeouts(consecutive)
            consecutive = 0
            recovered = True
        else:
            self._circuit_open = False

        state.update(
            {
                "attempted_matches": int(
                    state.get(
                        "attempted_matches",
                        getattr(self, "_attempted_matches", 0),
                    )
                    or 0
                ),
                "max_matches": int(
                    getattr(
                        self,
                        "max_matches_per_cycle",
                        DEFAULT_MAX_MATCHES_PER_CYCLE,
                    )
                ),
                "consecutive_timeouts": consecutive,
                "circuit_open": False,
                "browser_restarted": recovered,
                "effective_tabs": int(
                    getattr(
                        self,
                        "_effective_max_tabs",
                        getattr(self, "max_tabs", 1),
                    )
                ),
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
        )
        self._write_budget(state)

    def _remaining_timeout_ms(self, cap_ms: int) -> int:
        deadline = getattr(self, "_match_deadline", None)
        if deadline is None:
            return max(500, int(cap_ms))
        remaining = int((deadline - time.monotonic()) * 1000)
        if remaining <= 0:
            self._last_attempt_timed_out = True
            raise PlaywrightTimeoutError(
                "Flashscore agotó el presupuesto de tiempo del partido."
            )
        return max(500, min(int(cap_ms), remaining))

    def _skip_message(self) -> str:
        if bool(getattr(self, "_cycle_budget_exhausted_flag", False)):
            return (
                "Flashscore omitido: se agotó el presupuesto global de "
                "8–10 minutos del ciclo; el progreso quedó guardado."
            )
        if bool(getattr(self, "_circuit_open", False)):
            return (
                "Flashscore omitido: recuperación del navegador en curso."
            )
        return (
            "Flashscore omitido: se alcanzó el máximo de "
            f"{int(getattr(self, 'max_matches_per_cycle', DEFAULT_MAX_MATCHES_PER_CYCLE))} "
            "partidos necesarios por ciclo."
        )

    def cycle_stats(self) -> dict[str, Any]:
        state = self._read_budget()
        return {
            "attempted_matches": int(
                state.get(
                    "attempted_matches",
                    getattr(self, "_attempted_matches", 0),
                )
                or 0
            ),
            "max_matches": int(
                getattr(
                    self,
                    "max_matches_per_cycle",
                    DEFAULT_MAX_MATCHES_PER_CYCLE,
                )
            ),
            "consecutive_timeouts": int(
                state.get(
                    "consecutive_timeouts",
                    getattr(self, "_consecutive_timeouts", 0),
                )
                or 0
            ),
            "circuit_open": bool(
                state.get(
                    "circuit_open",
                    getattr(self, "_circuit_open", False),
                )
            ),
            "effective_tabs": int(
                getattr(
                    self,
                    "_effective_max_tabs",
                    getattr(self, "max_tabs", DEFAULT_BROWSER_TABS),
                )
            ),
            "cycle_budget_exhausted": bool(
                getattr(self, "_cycle_budget_exhausted_flag", False)
            ),
        }

    def _read_cache(self) -> dict[str, Any]:
        try:
            data = json.loads(
                self.cache_path.read_text(encoding="utf-8")
            )
        except (OSError, json.JSONDecodeError):
            return {}
        return data if isinstance(data, dict) else {}

    def _write_cache(self) -> None:
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.cache_path.with_suffix(".tmp")
        temporary.write_text(
            json.dumps(
                self.match_cache,
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        temporary.replace(self.cache_path)

    def _diagnostic(
        self,
        message: str,
        *,
        reason: str,
        action: str,
        match: MatchRef | None = None,
        team: str | None = None,
        url: str | None = None,
        exc: Exception | None = None,
    ) -> None:
        details = [message]
        if match is not None:
            event_id = match.sofascore_event_id or match.match_id or "N/D"
            details.extend(
                [
                    f"event_id={event_id}",
                    f"equipos={match.home_team} vs {match.away_team}",
                ]
            )
        if team:
            details.append(f"equipo={team}")
        if url:
            details.append(f"url={url}")
        details.append(f"motivo={reason}")
        details.append(f"acción={action}")
        if exc is not None:
            details.append(f"error={type(exc).__name__}: {exc}")
        self.logger(" | ".join(details))

    def _safe_write_cache(
        self,
        *,
        match: MatchRef | None,
        url: str | None,
        action: str,
    ) -> bool:
        try:
            self._write_cache()
            return True
        except Exception as exc:
            self._diagnostic(
                "Flashscore: no se pudo escribir la caché en disco.",
                reason=CACHE_WRITE_FAILED,
                action=(
                    f"{action}; conservar el cambio en memoria y continuar "
                    "sin perder las estadísticas recuperadas"
                ),
                match=match,
                url=url,
                exc=exc,
            )
            return False

    def _invalidate_cache_entry(
        self,
        key: str,
        *,
        match: MatchRef,
        url: str,
        reason: str,
    ) -> None:
        event_id = match.sofascore_event_id or match.match_id
        event_key = f"event:{event_id}" if event_id is not None else ""
        changed = False
        for cache_key in (key, event_key):
            if cache_key and cache_key in self.match_cache:
                self.match_cache.pop(cache_key, None)
                changed = True

        trace = getattr(self, "_last_navigation_trace", None)
        if isinstance(trace, dict):
            trace["cache_invalidated"] = bool(changed)
            trace["cache_invalidated_url"] = url
            trace["cache_invalidation_reason"] = reason

        self._diagnostic(
            "Flashscore: URL cacheada inválida.",
            reason=reason,
            action=(
                "entrada retirada de la caché en memoria; intentando "
                "persistir la invalidación antes de probar URL directa y "
                "búsqueda por equipo local"
            ),
            match=match,
            url=url,
        )
        persisted = True
        if changed:
            persisted = self._safe_write_cache(
                match=match,
                url=url,
                action="falló la persistencia de la invalidación selectiva",
            )
        if isinstance(trace, dict):
            trace["cache_invalidation_persisted"] = bool(persisted)

    def _save_match_url(self, match: MatchRef, url: str) -> str:
        normalized = _normalize_flashscore_url(url)
        key = self._match_key(match)
        record = {
            "url": normalized,
            "cached_at": datetime.now(timezone.utc).isoformat(),
            "event_id": match.sofascore_event_id or match.match_id,
            "home_team": match.home_team,
            "away_team": match.away_team,
        }
        self.match_cache[key] = record
        event_id = match.sofascore_event_id or match.match_id
        if event_id is not None:
            self.match_cache[f"event:{event_id}"] = dict(record)
        cache_write_ok = self._safe_write_cache(
            match=match,
            url=normalized,
            action="falló el guardado de la URL validada",
        )
        trace = getattr(self, "_last_navigation_trace", None)
        if isinstance(trace, dict):
            trace["match_url_resolved"] = True
            trace["match_url"] = normalized
            trace["cache_saved"] = bool(cache_write_ok)
            trace["cache_write_ok"] = bool(cache_write_ok)
            trace["cache_saved_url"] = normalized if cache_write_ok else None
            if trace.get("cache_invalidated"):
                trace["stale_cache_recovered"] = bool(cache_write_ok)
        return normalized

    def _current_tab_limit(self) -> int:
        return max(
            1,
            min(
                int(getattr(self, "_effective_max_tabs", getattr(self, "max_tabs", 1))),
                int(getattr(self, "max_tabs", DEFAULT_BROWSER_TABS)),
            ),
        )

    def _match_key(self, match: MatchRef) -> str:
        identity = (
            match.sofascore_event_id
            or match.match_id
            or "none"
        )
        return "|".join(
            (
                str(identity),
                _normalize(match.competition),
                _normalize(match.season),
                _parse_kickoff(match.kickoff).date().isoformat(),
                _normalize(match.home_team),
                _normalize(match.away_team),
            )
        )

    @staticmethod
    def _page_open(page: Page) -> bool:
        try:
            return not page.is_closed()
        except Exception:
            return False

    def _ensure_context(self) -> BrowserContext:
        open_pages = [page for page in self.pages if self._page_open(page)]
        if self.context is not None:
            self.pages = open_pages
            if not self.pages:
                try:
                    self.pages = [self.context.new_page()]
                    self._page_cursor = -1
                    return self.context
                except Exception:
                    try:
                        self.context.close()
                    except Exception:
                        pass
                    self.context = None

        if self.context is None:
            browser_executable = find_browser_executable()
            headless_default = os.name != "nt"
            launch_kwargs: dict[str, Any] = {
                "user_data_dir": str(self.profile_dir),
                "headless": _env_bool(
                    self.project_root,
                    "ODDSHUNTER_BROWSER_HEADLESS",
                    headless_default,
                ),
                "chromium_sandbox": _env_bool(
                    self.project_root,
                    "ODDSHUNTER_CHROMIUM_SANDBOX",
                    os.name == "nt",
                ),
                "locale": "es-ES",
                "viewport": {"width": 1360, "height": 900},
                "args": [
                    "--disable-session-crashed-bubble",
                    "--no-first-run",
                ],
            }
            if browser_executable is not None:
                launch_kwargs["executable_path"] = str(browser_executable)

            self.context = self.playwright.chromium.launch_persistent_context(
                **launch_kwargs
            )
            self.pages = [
                page
                for page in self.context.pages
                if self._page_open(page)
            ]
            if not self.pages:
                self.pages = [self.context.new_page()]

            # Una sesión anterior pudo dejar pestañas restauradas. El grupo
            # adaptativo comienza con una sola y abre otra únicamente cuando
            # un nuevo partido realmente llega al respaldo Flashscore.
            for extra in self.pages[1:]:
                try:
                    extra.close()
                except Exception:
                    pass
            self.pages = self.pages[:1]
            self._page_cursor = -1

        if self.context is None:
            raise RuntimeError("No se pudo iniciar el contexto Chromium/Flashscore.")
        return self.context

    def _next_page(self, match_key: str) -> Page:
        assigned = self._assigned_match_pages.get(match_key)
        if assigned is not None and self._page_open(assigned):
            self.page = assigned
            return assigned

        context = self._ensure_context()
        self.pages = [
            page for page in self.pages if self._page_open(page)
        ]
        self._assigned_match_pages = {
            key: assigned_page
            for key, assigned_page in self._assigned_match_pages.items()
            if self._page_open(assigned_page)
        }
        assigned_pages = set(self._assigned_match_pages.values())
        page = next(
            (candidate for candidate in self.pages if candidate not in assigned_pages),
            None,
        )
        tab_limit = self._current_tab_limit()
        if page is None and len(self.pages) < tab_limit:
            page = context.new_page()
            self.pages.append(page)
        if page is None:
            # La ejecución es secuencial. Esta rama solo se alcanza si una
            # llamada anterior aún conserva todas las páginas asignadas.
            self._page_cursor = (self._page_cursor + 1) % len(self.pages)
            page = self.pages[self._page_cursor]

        self._assigned_match_pages[match_key] = page
        self.page = page
        self.logger(
            f"Flashscore: {len(self.pages)} pestaña(s) abierta(s), "
            f"{len(self._assigned_match_pages)} en uso; máximo {tab_limit}."
        )
        return page

    def _release_page(self, match_key: str, page: Page | None) -> None:
        self._assigned_match_pages.pop(match_key, None)
        if page is None or not self._page_open(page):
            return
        try:
            page.goto(
                "about:blank",
                wait_until="commit",
                timeout=2_000,
            )
        except Exception:
            pass

    def _ensure_page(self) -> Page:
        if self._active_page is not None and self._page_open(
            self._active_page
        ):
            return self._active_page
        raise RuntimeError(
            "No hay una pestaña Flashscore asignada al partido actual."
        )

    def _discard_page(self, match_key: str, page: Page | None) -> None:
        self._assigned_match_pages = {
            key: assigned_page
            for key, assigned_page in self._assigned_match_pages.items()
            if key != match_key and assigned_page is not page
        }
        if page is None:
            return
        try:
            if not page.is_closed():
                page.close()
        except Exception:
            pass
        self.pages = [
            candidate
            for candidate in self.pages
            if candidate is not page and self._page_open(candidate)
        ]

    def _dismiss_consent(self, page: Page) -> None:
        for label in (
            "Aceptar todas",
            "Aceptar",
            "Acepto",
            "Estoy de acuerdo",
            "Consentir",
        ):
            try:
                button = page.get_by_role(
                    "button",
                    name=label,
                    exact=True,
                )
                if button.count() == 1 and button.is_visible():
                    button.click(timeout=2_000)
                    return
            except Exception:
                continue

    def _dismiss_overlays(self, page: Page) -> None:
        self._dismiss_consent(page)
        selectors = (
            'button[aria-label="Cerrar"]',
            'button[aria-label="Close"]',
            '[class*="overlay"] button[class*="close"]',
            '[class*="modal"] button[class*="close"]',
            '[class*="ad"] button[class*="close"]',
            '.adsenvelope__button',
        )
        for selector in selectors:
            try:
                locator = page.locator(selector)
                for index in range(min(locator.count(), 4)):
                    item = locator.nth(index)
                    if item.is_visible():
                        item.click(timeout=1_500, force=True)
            except Exception:
                continue

    def _goto(self, url: str, *, cap_ms: int = 25_000) -> Page:
        page = self._ensure_page()
        try:
            page.goto(
                url,
                wait_until="domcontentloaded",
                timeout=self._remaining_timeout_ms(cap_ms),
            )
        except Exception as exc:
            if type(exc).__name__ == "TimeoutError":
                self._last_attempt_timed_out = True
            raise
        self._dismiss_overlays(page)
        return page

    @staticmethod
    def _visible_search_results(page: Page) -> list[dict[str, Any]]:
        """Lee exclusivamente tarjetas visibles del modal real de búsqueda."""

        value = page.evaluate(
            """
            () => {
                const cardSelector = 'section.dialog--search .searchResults a.searchResult';
                const nameSelector = '.searchResult__participantName';
                const categorySelector = '.searchResult__participantCategory';
                const visible = element => Boolean(
                    element && (
                        element.offsetWidth ||
                        element.offsetHeight ||
                        element.getClientRects().length
                    )
                );
                const result = [];
                const cards = Array.from(document.querySelectorAll(cardSelector));
                cards.forEach((anchor, index) => {
                    if (!visible(anchor)) return;
                    const name = (
                        anchor.querySelector(nameSelector)?.innerText || ''
                    ).trim();
                    const category = (
                        anchor.querySelector(categorySelector)?.innerText || ''
                    ).trim();
                    const rawHref = (anchor.getAttribute('href') || '').trim();
                    if (!name || !rawHref) return;
                    if (!category.toLocaleLowerCase('es').startsWith('fútbol')) {
                        return;
                    }
                    const escaped = rawHref.replace(/\"/g, '\\"');
                    result.push({
                        index,
                        name,
                        category,
                        raw_href: rawHref,
                        href: rawHref,
                        text: `${name}\n${category}`,
                        selector: `${cardSelector}[href="${escaped}"]`
                    });
                });
                return result;
            }
            """
        )
        if not isinstance(value, list):
            return []
        return [item for item in value if isinstance(item, dict)]

    @staticmethod
    def _team_profile_route(url: str) -> bool:
        parsed = urlsplit(str(url or ""))
        path = parsed.path.casefold()
        return bool(
            parsed.netloc.endswith("flashscore.es")
            and (
                "/equipo/" in path
                or "/team/" in path
                or "r=3:" in parsed.query.casefold()
            )
        )

    @staticmethod
    def _team_identity_snapshot(
        page: Page,
        team_name: str,
    ) -> tuple[list[str], float]:
        texts: list[str] = []
        try:
            title = page.title().strip()
            if title:
                texts.append(title)
        except Exception:
            pass

        selectors = (
            "h1",
            ".heading__name",
            "[class*='heading__name']",
            "[class*='teamHeader'] [class*='name']",
            "[class*='teamHeader']",
            "[class*='participant__participantName']",
        )
        for selector in selectors:
            try:
                locator = page.locator(selector)
                for index in range(min(locator.count(), 5)):
                    item = locator.nth(index)
                    if not item.is_visible():
                        continue
                    value = item.inner_text(timeout=1_500).strip()
                    if value and value not in texts:
                        texts.append(value)
            except Exception:
                continue
        score = max(
            (_name_score(team_name, value) for value in texts),
            default=0.0,
        )
        return texts, round(score, 4)

    @classmethod
    def _team_page_matches(cls, page: Page, team_name: str) -> bool:
        if not cls._team_profile_route(getattr(page, "url", "")):
            return False
        _texts, score = cls._team_identity_snapshot(page, team_name)
        return score >= 0.72

    def _wait_for_team_profile(
        self,
        page: Page,
        team_name: str,
        *,
        seconds: float = 15.0,
    ) -> bool:
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            if self._team_page_matches(page, team_name):
                return True
            try:
                page.wait_for_timeout(300)
            except Exception:
                break
        return self._team_page_matches(page, team_name)

    @staticmethod
    def _find_search_result_locator(
        page: Page,
        resolved: dict[str, Any],
    ):
        raw_href = str(
            resolved.get("raw_href")
            or resolved.get("url")
            or ""
        ).strip()
        cards = page.locator(SEARCH_CARD_SELECTOR)
        try:
            count = cards.count()
        except Exception:
            return None

        if not hasattr(cards, "nth"):
            try:
                first = cards.first
                if (first.get_attribute("href") or "").strip() == raw_href:
                    return first
            except Exception:
                return None

        index = int(resolved.get("index") or 0)
        if 0 <= index < count:
            item = cards.nth(index)
            try:
                if (item.get_attribute("href") or "").strip() == raw_href:
                    return item
            except Exception:
                pass
        for position in range(count):
            item = cards.nth(position)
            try:
                if (item.get_attribute("href") or "").strip() == raw_href:
                    return item
            except Exception:
                continue
        return None

    def _save_search_debug(
        self,
        page: Page,
        *,
        team_name: str,
        candidates: list[dict[str, Any]],
        failure_code: str,
        error: str,
        selected: dict[str, Any] | None = None,
    ) -> None:
        match = getattr(self, "_current_match_for_debug", None)
        event_id = (
            getattr(match, "sofascore_event_id", None)
            or getattr(match, "match_id", None)
            or _slugify(team_name)
        )
        project_root = Path(getattr(self, "project_root", Path.cwd()))
        debug_dir = project_root / "data" / "debug" / "flashscore"
        debug_dir.mkdir(parents=True, exist_ok=True)
        base = debug_dir / f"{event_id}_search"
        payload = {
            "event_id": event_id,
            "searched_team": team_name,
            "modal_detected": False,
            "candidates_found": len(candidates),
            "candidates": candidates,
            "selected_candidate": selected,
            "failure_code": failure_code,
            "error": error,
            "url": getattr(page, "url", ""),
            "saved_at": datetime.now(timezone.utc).isoformat(),
        }
        try:
            modal = page.locator(SEARCH_MODAL_SELECTOR)
            payload["modal_detected"] = bool(
                modal.count() and modal.first.is_visible()
            )
        except Exception:
            pass
        try:
            base.with_suffix(".json").write_text(
                json.dumps(payload, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except OSError as exc:
            self.logger(
                "Flashscore: no pudo guardar el JSON de diagnóstico "
                f"({type(exc).__name__}: {exc})."
            )
        try:
            base.with_suffix(".html").write_text(
                page.content(),
                encoding="utf-8",
            )
        except Exception as exc:
            self.logger(
                "Flashscore: no pudo guardar el HTML de diagnóstico "
                f"({type(exc).__name__}: {exc})."
            )
        try:
            page.screenshot(path=str(base.with_suffix(".png")), full_page=True)
        except Exception as exc:
            self.logger(
                "Flashscore: no pudo guardar la captura de diagnóstico "
                f"({type(exc).__name__}: {exc})."
            )

    def _open_search(self, page: Page) -> bool:
        candidates = (
            page.get_by_role("button", name="Búsqueda", exact=True),
            page.get_by_role("button", name="Buscar", exact=True),
            page.get_by_role("button", name="Search", exact=True),
            page.locator('button[aria-label*="Buscar" i]'),
            page.locator('button[aria-label*="Search" i]'),
            page.locator('#searchWindow button'),
            page.locator('#searchWindow'),
            page.locator('[class*="header__block--search"] button'),
            page.locator('[class*="search"] button'),
        )
        for candidate in candidates:
            try:
                count = candidate.count()
                for index in range(min(count, 5)):
                    item = candidate.nth(index)
                    if not item.is_visible():
                        continue
                    self._dismiss_overlays(page)
                    item.scroll_into_view_if_needed(timeout=2_000)
                    for force in (False, True):
                        try:
                            item.click(timeout=5_000, force=force)
                            return True
                        except Exception:
                            continue
                    try:
                        item.evaluate("element => element.click()")
                        return True
                    except Exception:
                        continue
            except Exception:
                continue
        return False

    def _search_input(self, page: Page):
        candidates = (
            page.locator(SEARCH_INPUT_SELECTOR),
            page.get_by_placeholder(
                "Introduzca su búsqueda aquí",
                exact=True,
            ),
            page.get_by_placeholder("Buscar", exact=False),
            page.get_by_placeholder("Search", exact=False),
            page.locator('[role="dialog"] input[type="text"]'),
            page.locator('[role="dialog"] input[type="search"]'),
            page.locator('input[type="search"]'),
        )
        for candidate in candidates:
            try:
                count = candidate.count()
                for index in range(min(count, 5)):
                    item = candidate.nth(index)
                    if item.is_visible():
                        return item
            except Exception:
                continue
        return None

    def _wait_for_search_input(
        self,
        page: Page,
        deadline: float,
    ):
        while time.monotonic() < deadline:
            search = self._search_input(page)
            if search is not None:
                return search
            remaining_ms = int((deadline - time.monotonic()) * 1000)
            if remaining_ms <= 0:
                break
            page.wait_for_timeout(max(50, min(250, remaining_ms)))
        return None

    def _reopen_search_session(self) -> Page:
        self._close_browser_session()
        context = self._ensure_context()
        open_pages = [
            page for page in self.pages if self._page_open(page)
        ]
        page = open_pages[0] if open_pages else context.new_page()
        if page not in self.pages:
            self.pages.append(page)
        self.page = page
        self._active_page = page
        return page

    def _try_search_surface(
        self,
        page: Page,
        *,
        deadline: float,
        stage_seconds: float,
    ):
        search = self._search_input(page)
        if search is not None:
            return search

        opened = self._open_search(page)
        stage_deadline = min(
            deadline,
            time.monotonic() + max(0.25, stage_seconds),
        )
        search = self._wait_for_search_input(page, stage_deadline)
        if search is not None:
            return search

        # Algunas variantes de Flashscore abren el cuadro sin que el clic
        # devuelva una navegación observable. Se vuelve a comprobar el DOM
        # aunque _open_search() haya informado False.
        if not opened:
            return self._search_input(page)
        return None

    def _prepare_search_input(
        self,
        page: Page,
        *,
        team_name: str,
        deadline: float,
    ) -> tuple[Page, Any | None]:
        search = self._try_search_surface(
            page,
            deadline=deadline,
            stage_seconds=3.0,
        )
        if search is not None:
            return page, search

        self._diagnostic(
            "Flashscore: el botón o campo de búsqueda aún no está disponible.",
            reason=SELECTOR_NOT_FOUND,
            action=(
                "recargar la portada, esperar la carga dinámica y volver a "
                "comprobar el campo antes de abandonar"
            ),
            team=team_name,
            url=getattr(page, "url", HOME_URL),
        )
        try:
            remaining = max(500, int((deadline - time.monotonic()) * 1000))
            page.reload(
                wait_until="domcontentloaded",
                timeout=min(
                    self._remaining_timeout_ms(10_000),
                    remaining,
                ),
            )
            self._dismiss_overlays(page)
            search = self._try_search_surface(
                page,
                deadline=deadline,
                stage_seconds=4.0,
            )
            if search is not None:
                return page, search
        except Exception as exc:
            reason = _exception_code(exc, NAVIGATION_FAILED)
            if reason == NAVIGATION_TIMEOUT:
                self._last_attempt_timed_out = True
            self._diagnostic(
                "Flashscore: falló la recarga del buscador.",
                reason=reason,
                action="reabrir la sesión de Flashscore y probar otra vez",
                team=team_name,
                url=getattr(page, "url", HOME_URL),
                exc=exc,
            )

        if time.monotonic() < deadline:
            self._diagnostic(
                "Flashscore: el buscador sigue sin estar disponible.",
                reason=SELECTOR_NOT_FOUND,
                action=(
                    "cerrar la sesión actual, abrir una sesión limpia y "
                    "reintentar la portada"
                ),
                team=team_name,
                url=getattr(page, "url", HOME_URL),
            )
            try:
                page = self._reopen_search_session()
                page.goto(
                    HOME_URL,
                    wait_until="domcontentloaded",
                    timeout=min(
                        self._remaining_timeout_ms(12_000),
                        max(500, int((deadline - time.monotonic()) * 1000)),
                    ),
                )
                self._dismiss_overlays(page)
                search = self._try_search_surface(
                    page,
                    deadline=deadline,
                    stage_seconds=5.0,
                )
                if search is not None:
                    return page, search
            except Exception as exc:
                reason = _exception_code(exc, NAVIGATION_FAILED)
                if reason == NAVIGATION_TIMEOUT:
                    self._last_attempt_timed_out = True
                self._diagnostic(
                    "Flashscore: falló la reapertura de la sesión del buscador.",
                    reason=reason,
                    action="probar la ruta alternativa del buscador",
                    team=team_name,
                    url=HOME_URL,
                    exc=exc,
                )

        if time.monotonic() < deadline:
            alternative_url = urljoin(HOME_URL, "?search=1")
            try:
                page.goto(
                    alternative_url,
                    wait_until="domcontentloaded",
                    timeout=min(
                        self._remaining_timeout_ms(10_000),
                        max(500, int((deadline - time.monotonic()) * 1000)),
                    ),
                )
                self._dismiss_overlays(page)
                search = self._try_search_surface(
                    page,
                    deadline=deadline,
                    stage_seconds=max(
                        0.25,
                        deadline - time.monotonic(),
                    ),
                )
                if search is not None:
                    return page, search
            except Exception as exc:
                reason = _exception_code(exc, NAVIGATION_FAILED)
                if reason == NAVIGATION_TIMEOUT:
                    self._last_attempt_timed_out = True
                self._diagnostic(
                    "Flashscore: falló la ruta alternativa del buscador.",
                    reason=reason,
                    action="terminar la búsqueda solo después de agotar respaldos",
                    team=team_name,
                    url=alternative_url,
                    exc=exc,
                )

        if time.monotonic() >= deadline:
            self._last_attempt_timed_out = True
        self._diagnostic(
            "Flashscore: selector del botón o campo de búsqueda no encontrado.",
            reason=SELECTOR_NOT_FOUND,
            action=(
                "respaldos agotados: campo visible, recarga, sesión limpia y "
                "ruta alternativa; continuar con el siguiente origen"
            ),
            team=team_name,
            url=getattr(page, "url", HOME_URL),
        )
        return page, None

    def _open_team_result(
        self,
        page: Page,
        resolved: dict[str, Any],
        team_name: str,
        match: MatchRef | None = None,
    ) -> bool:
        raw_href = str(
            resolved.get("raw_href")
            or resolved.get("url")
            or ""
        ).strip()
        target_url = urljoin(HOME_URL, raw_href)
        trace = getattr(self, "_last_navigation_trace", None)
        attempt = {
            "captured_href": raw_href,
            "target_url": target_url,
            "click_result": "NOT_ATTEMPTED",
            "card_disappeared": False,
            "direct_navigation_attempted": False,
            "final_team_url": None,
            "team_identity_verified": False,
            "candidate_name": resolved.get("name"),
            "candidate_country": _candidate_country(resolved.get("category")),
        }
        if isinstance(trace, dict):
            trace.setdefault("team_clicks", []).append(attempt)

        locator = self._find_search_result_locator(page, resolved)
        if locator is None:
            attempt["card_disappeared"] = True
            attempt["click_result"] = "CARD_DISAPPEARED"
            self._diagnostic(
                "Flashscore: la tarjeta seleccionada desapareció; se usa el href capturado.",
                reason=CLICK_BLOCKED,
                action="navegar inmediatamente al href capturado",
                team=team_name,
                url=target_url,
            )
        else:
            try:
                self._dismiss_overlays(page)
                locator.click(timeout=self._remaining_timeout_ms(5_000))
                attempt["click_result"] = "NORMAL_CLICK_OK"
                try:
                    page.wait_for_timeout(450)
                    page.wait_for_load_state(
                        "domcontentloaded",
                        timeout=self._remaining_timeout_ms(5_000),
                    )
                except Exception:
                    pass
                health = flashscore_page_health(
                    page,
                    expected_team=team_name,
                )
                if health.get("is_error"):
                    if isinstance(trace, dict):
                        trace["flashscore_error_page_detected"] = True
                elif self._wait_for_team_profile(page, team_name, seconds=5.0):
                    attempt["final_team_url"] = str(getattr(page, "url", "") or "")
                    attempt["team_identity_verified"] = True
                    if isinstance(trace, dict):
                        trace["team_base_page_verified"] = True
                    return True
            except Exception as exc:
                message = str(exc).casefold()
                locator_after = self._find_search_result_locator(page, resolved)
                disappeared = bool(
                    locator_after is None
                    or "desapareci" in message
                    or "detached" in message
                    or "not attached" in message
                )
                attempt["card_disappeared"] = disappeared
                attempt["click_result"] = (
                    "CARD_DISAPPEARED" if disappeared else "NORMAL_CLICK_FAILED"
                )
                self._diagnostic(
                    "Flashscore: falló el clic normal del resultado del equipo.",
                    reason=_exception_code(exc, CLICK_BLOCKED),
                    action=(
                        "la tarjeta desapareció; navegar inmediatamente al href capturado"
                        if disappeared
                        else "usar inmediatamente el href capturado sin repetir clics"
                    ),
                    team=team_name,
                    url=target_url,
                    exc=exc,
                )

        attempt["direct_navigation_attempted"] = True
        last_reason = NAVIGATION_FAILED
        try:
            page.goto(
                target_url,
                wait_until="domcontentloaded",
                timeout=self._remaining_timeout_ms(16_000),
            )
            self._dismiss_overlays(page)
            actual_url = _normalize_flashscore_url(getattr(page, "url", ""))
            attempt["final_team_url"] = actual_url or target_url
            health = flashscore_page_health(
                page,
                expected_team=team_name,
            )
            if health.get("is_error"):
                last_reason = (
                    FLASHSCORE_ERROR_PAGE
                    if health.get("explicit_error") or health.get("generic_error")
                    else TEAM_IDENTITY_MISMATCH
                )
                if isinstance(trace, dict):
                    trace["flashscore_error_page_detected"] = bool(
                        health.get("explicit_error") or health.get("generic_error")
                    )
            elif self._wait_for_team_profile(page, team_name, seconds=7.0):
                attempt["team_identity_verified"] = True
                if isinstance(trace, dict):
                    trace["team_base_page_verified"] = True
                return True
            else:
                last_reason = TEAM_IDENTITY_MISMATCH
            self._last_team_search_failure_code = last_reason
            self._diagnostic(
                "Flashscore: la navegación directa no abrió una ficha de equipo verificable.",
                reason=last_reason,
                action="rechazar la ficha y continuar con el siguiente respaldo",
                team=team_name,
                url=actual_url or target_url,
            )
        except Exception as exc:
            last_reason = _exception_code(exc, NAVIGATION_FAILED)
            if last_reason == NAVIGATION_TIMEOUT:
                self._last_attempt_timed_out = True
            self._last_team_search_failure_code = (
                RETRYABLE if last_reason in {NAVIGATION_TIMEOUT, NAVIGATION_FAILED} else last_reason
            )
            self._diagnostic(
                "Flashscore: falló page.goto() de la ficha del equipo.",
                reason=last_reason,
                action="continuar con el equipo visitante o el siguiente respaldo",
                team=team_name,
                url=target_url,
                exc=exc,
            )
        return False

    def _search_team(
        self,
        team_name: str,
        match: MatchRef | None = None,
    ) -> dict[str, Any] | None:
        if _is_unsafe_generic_team_query(team_name):
            self._last_team_search_failure_code = TEAM_SEARCH_NO_MATCH
            trace = getattr(self, "_last_navigation_trace", None)
            if isinstance(trace, dict):
                trace.setdefault("team_searches", []).append(
                    {
                        "searched_team": team_name,
                        "blocked_before_search": True,
                        "blocked_reason": "UNSAFE_GENERIC_TEAM_QUERY",
                        "expected_rival": (
                            match.away_team
                            if match is not None
                            and _name_score(team_name, match.home_team) >= 0.72
                            else match.home_team if match is not None else None
                        ),
                        "expected_kickoff": (
                            match.kickoff if match is not None else None
                        ),
                    }
                )
            self._diagnostic(
                "Flashscore: búsqueda genérica bloqueada antes de abrir candidatos.",
                reason=TEAM_SEARCH_NO_MATCH,
                action=(
                    "usar nombre completo, rival, fecha y contexto de competición"
                ),
                match=match,
                team=team_name,
                url=HOME_URL,
            )
            return None

        competition_key = _normalize(match.competition) if match is not None else ""
        key = f"{_normalize(team_name)}|{competition_key}"

        registry_team = self.identity_registry.flashscore_profile(team_name)
        if registry_team is not None:
            cached_team = dict(registry_team)
            if match is None:
                self.team_cache[key] = cached_team
                return cached_team
            cached_urls = self._candidate_urls_from_team(match, cached_team)
            if cached_urls:
                cached_team["_match_urls"] = cached_urls
                cached_team["context_verified"] = True
                self.team_cache[key] = cached_team
                trace = getattr(self, "_last_navigation_trace", None)
                if isinstance(trace, dict):
                    trace.setdefault("team_searches", []).append(
                        {
                            "searched_team": team_name,
                            "source": "persistent_team_identity_registry",
                            "profile_opened": True,
                            "context_verified": True,
                            "matching_result_urls": cached_urls,
                        }
                    )
                    trace["team_profile_opened"] = True
                    trace["team_profile_verified"] = True
                self.logger(
                    "Flashscore: ficha de equipo reutilizada desde el "
                    "registro central y validada con rival y fecha."
                )
                return cached_team
            self.logger(
                "Flashscore: la ficha guardada en el registro central no "
                "contenía este partido; se ejecuta búsqueda contextual."
            )

        if key in self.team_cache:
            cached_team = dict(self.team_cache[key])
            if match is None:
                return cached_team
            # La caché de equipo conserva la ficha, no las URLs de un partido
            # anterior. Para cada nuevo encuentro se vuelve a abrir Resultados y
            # se valida rival + fecha antes de reutilizar la ficha.
            cached_team.pop("_match_urls", None)
            cached_urls = self._candidate_urls_from_team(match, cached_team)
            if cached_urls:
                cached_team["_match_urls"] = cached_urls
                cached_team["context_verified"] = True
                trace = getattr(self, "_last_navigation_trace", None)
                if isinstance(trace, dict):
                    trace.setdefault("team_searches", []).append(
                        {
                            "searched_team": team_name,
                            "source": "validated_team_cache",
                            "profile_opened": True,
                            "context_verified": True,
                            "matching_result_urls": cached_urls,
                        }
                    )
                    trace["team_profile_opened"] = True
                    trace["team_profile_verified"] = True
                return cached_team
            # Si la ficha cacheada no contiene el partido esperado, se elimina
            # solo esa ficha en memoria y se ejecuta una búsqueda contextual.
            self.team_cache.pop(key, None)

        self._last_team_search_failure_code = None
        self.logger(f"Flashscore: buscando equipo {team_name}...")
        search_timeout = float(
            getattr(
                self,
                "search_timeout_seconds",
                DEFAULT_SEARCH_TIMEOUT_SECONDS,
            )
        )
        search_deadline = time.monotonic() + search_timeout
        match_deadline = getattr(self, "_match_deadline", None)
        if match_deadline is not None:
            search_deadline = min(search_deadline, match_deadline)

        page = None
        results: list[dict[str, Any]] = []
        try:
            page = self._goto(HOME_URL)
            page, search = self._prepare_search_input(
                page,
                team_name=team_name,
                deadline=search_deadline,
            )
            if search is None:
                self._last_team_search_failure_code = SEARCH_RESULTS_NOT_DETECTED
                self._save_search_debug(
                    page,
                    team_name=team_name,
                    candidates=[],
                    failure_code=SEARCH_RESULTS_NOT_DETECTED,
                    error="No apareció el campo del modal de búsqueda.",
                )
                return None

            remaining_ms = max(
                500,
                int((search_deadline - time.monotonic()) * 1000),
            )
            search.fill("", timeout=min(5_000, remaining_ms))
            search.fill(team_name, timeout=min(5_000, remaining_ms))

            stable_signature: tuple[tuple[str, str, str], ...] | None = None
            stable_hits = 0
            while time.monotonic() < search_deadline:
                page.wait_for_timeout(250)
                current = self._visible_search_results(page)
                if not current:
                    continue
                signature = tuple(
                    (
                        str(item.get("name") or ""),
                        str(item.get("category") or ""),
                        str(item.get("raw_href") or item.get("href") or ""),
                    )
                    for item in current
                )
                if signature == stable_signature:
                    stable_hits += 1
                else:
                    stable_signature = signature
                    stable_hits = 0
                results = current
                if stable_hits >= 1:
                    break
        except Exception as exc:
            reason = _exception_code(exc, SEARCH_RESULTS_NOT_DETECTED)
            if reason == NAVIGATION_TIMEOUT:
                self._last_attempt_timed_out = True
            self._last_team_search_failure_code = SEARCH_RESULTS_NOT_DETECTED
            self._diagnostic(
                "Flashscore: no pudo leer los resultados del buscador.",
                reason=SEARCH_RESULTS_NOT_DETECTED,
                action="guardar HTML, captura y candidatos para diagnóstico",
                team=team_name,
                url=getattr(page, "url", HOME_URL),
                exc=exc,
            )
            if page is not None:
                self._save_search_debug(
                    page,
                    team_name=team_name,
                    candidates=results,
                    failure_code=SEARCH_RESULTS_NOT_DETECTED,
                    error=f"{type(exc).__name__}: {exc}",
                )
            return None

        country_hints = _contextual_team_country_hints(
            team_name,
            match,
        )
        normalized_candidates: list[
            tuple[float, float, int, dict[str, Any]]
        ] = []
        debug_candidates: list[dict[str, Any]] = []
        for result in results:
            normalized = _team_result_from_search_item(result)
            if normalized is None:
                continue
            name_score = round(_name_score(team_name, normalized["name"]), 4)
            sport_match = _category_is_association_football(
                normalized.get("category")
            )
            country_match = _category_country_matches(
                normalized.get("category"), country_hints
            )
            category_adjustment = _category_context_score(
                normalized.get("category"), country_hints
            )
            country_score = 1.0 if country_match else 0.0
            context_score = round(
                max(0.0, min(1.0, name_score * 0.85 + country_score * 0.15)),
                4,
            )
            variant_mismatch = _candidate_variant_mismatch(
                team_name, normalized["name"]
            )
            name_context_valid = _candidate_name_context_valid(
                team_name, normalized["name"], name_score
            )
            rejection_reason = None
            if not sport_match:
                rejection_reason = "SPORT_CATEGORY_MISMATCH"
            elif not country_match:
                rejection_reason = "COUNTRY_CATEGORY_MISMATCH"
            elif variant_mismatch:
                rejection_reason = variant_mismatch
            elif not name_context_valid:
                rejection_reason = "NAME_CONTEXT_TOO_WEAK"
            normalized["score"] = name_score
            normalized["context_score"] = context_score
            normalized["category_adjustment"] = category_adjustment
            normalized["sport_match"] = sport_match
            normalized["country_match"] = country_match
            normalized["country_score"] = country_score
            normalized["candidate_country"] = _candidate_country(
                normalized.get("category")
            )
            normalized["candidate_rejected_before_navigation"] = bool(
                rejection_reason
            )
            normalized["rejection_reason"] = rejection_reason
            debug_candidates.append(
                {
                    "index": normalized.get("index"),
                    "candidate_name": normalized.get("name"),
                    "candidate_country": normalized.get("candidate_country"),
                    "name": normalized.get("name"),
                    "category": normalized.get("category"),
                    "href": normalized.get("raw_href"),
                    "selector": normalized.get("selector"),
                    "name_score": name_score,
                    "country_score": country_score,
                    "score": name_score,
                    "context_score": context_score,
                    "sport_match": sport_match,
                    "country_match": country_match,
                    "candidate_rejected_before_navigation": bool(rejection_reason),
                    "rejection_reason": rejection_reason,
                    "discarded_reason": rejection_reason,
                }
            )
            if rejection_reason:
                self.logger(
                    "Flashscore: candidato descartado antes de navegar. "
                    f"candidate_name={normalized.get('name')}; "
                    f"candidate_country={normalized.get('candidate_country')}; "
                    f"name_score={name_score}; country_score={country_score}; "
                    f"sport_match={sport_match}; context_score={context_score}; "
                    f"candidate_rejected_before_navigation=true; "
                    f"rejection_reason={rejection_reason}."
                )
                continue
            normalized_candidates.append(
                (
                    context_score,
                    name_score,
                    int(normalized.get("index") or 0),
                    normalized,
                )
            )

        if not results or not debug_candidates:
            self._last_team_search_failure_code = SEARCH_RESULTS_NOT_DETECTED
            error = "El modal apareció, pero no se detectaron tarjetas de fútbol."
            self._diagnostic(
                "Flashscore: no se detectaron tarjetas del modal de búsqueda.",
                reason=SEARCH_RESULTS_NOT_DETECTED,
                action="guardar diagnóstico y probar el equipo visitante",
                team=team_name,
                url=getattr(page, "url", HOME_URL),
            )
            self._save_search_debug(
                page,
                team_name=team_name,
                candidates=debug_candidates,
                failure_code=SEARCH_RESULTS_NOT_DETECTED,
                error=error,
            )
            return None

        if not normalized_candidates:
            self._last_team_search_failure_code = TEAM_IDENTITY_MISMATCH
            error = (
                "Se leyeron candidatos, pero todos fueron descartados antes "
                "de navegar por deporte, nombre, país o variante incompatible."
            )
            self._diagnostic(
                "Flashscore: las tarjetas fueron leídas, pero ninguna coincide con el equipo.",
                reason=TEAM_IDENTITY_MISMATCH,
                action="guardar candidatos descartados y probar el equipo visitante",
                team=team_name,
                url=getattr(page, "url", HOME_URL),
            )
            self._save_search_debug(
                page,
                team_name=team_name,
                candidates=debug_candidates,
                failure_code=TEAM_IDENTITY_MISMATCH,
                error=error,
            )
            return None

        normalized_candidates.sort(
            key=lambda item: (-item[0], -item[1], item[2])
        )
        trace = getattr(self, "_last_navigation_trace", None)
        candidate_attempts: list[dict[str, Any]] = []

        # En casos homónimos se prueban hasta cinco candidatos ya capturados.
        # No se vuelve a abrir el buscador para recuperar el mismo href.
        for _context_score, _name_score_value, _index, resolved in normalized_candidates[:5]:
            self.logger(
                "Flashscore: probando candidato. "
                f"equipo={team_name}; candidato={resolved['name']}; "
                f"categoría={resolved.get('category')}; "
                f"href={resolved.get('raw_href')}; "
                f"score={resolved.get('score')}; "
                f"context_score={resolved.get('context_score')}."
            )
            opened = self._open_team_result(page, resolved, team_name, match)
            attempt = {
                "searched_team": team_name,
                "candidate": resolved.get("name"),
                "category": resolved.get("category"),
                "raw_href": resolved.get("raw_href"),
                "candidate_name": resolved.get("name"),
                "candidate_country": resolved.get("candidate_country"),
                "name_score": resolved.get("score"),
                "country_score": resolved.get("country_score"),
                "score": resolved.get("score"),
                "context_score": resolved.get("context_score"),
                "candidate_rejected_before_navigation": False,
                "rejection_reason": None,
                "profile_opened": opened,
                "expected_rival": (
                    match.away_team
                    if match is not None and _name_score(team_name, match.home_team) >= 0.72
                    else match.home_team if match is not None else None
                ),
                "expected_kickoff": match.kickoff if match is not None else None,
            }
            candidate_attempts.append(attempt)
            if not opened:
                continue

            resolved["url"] = page.url.split("?", 1)[0].rstrip("/") + "/"
            if match is not None:
                candidate_match_urls = self._candidate_urls_from_team(
                    match,
                    resolved,
                )
                attempt["matching_result_urls"] = candidate_match_urls
                if not candidate_match_urls:
                    failure_code = str(
                        resolved.get("_results_failure_code")
                        or EXPECTED_MATCH_NOT_FOUND
                    )
                    self._last_team_search_failure_code = failure_code
                    if failure_code == TEAM_RESULTS_ROUTE_INVALID:
                        message = (
                            "Flashscore: la ficha del equipo es correcta, pero "
                            "la sección real de Resultados no pudo validarse."
                        )
                        action = "probar el equipo visitante sin guardar la ruta inválida"
                    else:
                        message = (
                            "Flashscore: la ficha y Resultados son válidos, "
                            "pero no contienen el partido esperado."
                        )
                        action = (
                            "probar el siguiente respaldo usando rival, fecha "
                            "y competición como contexto"
                        )
                        failure_code = TEAM_SEARCH_NO_MATCH
                        self._last_team_search_failure_code = failure_code
                    self._diagnostic(
                        message,
                        reason=failure_code,
                        action=action,
                        match=match,
                        team=team_name,
                        url=resolved["url"],
                    )
                    continue
                resolved["_match_urls"] = candidate_match_urls
                resolved["context_verified"] = True

            try:
                identity_saved = self.identity_registry.remember_flashscore_identity(
                    team_name,
                    display_name=resolved.get("name"),
                    team_id=resolved.get("id"),
                    team_url=resolved.get("url"),
                    category=resolved.get("category"),
                )
                if identity_saved:
                    self.logger(
                        "Flashscore: identificador y URL de la ficha guardados "
                        "en el registro central de equipos."
                    )
            except Exception as exc:
                self.logger(
                    "Flashscore: no se pudo actualizar el registro central; "
                    f"se continúa sin perder el partido. {type(exc).__name__}: {exc}"
                )

            self.team_cache[key] = resolved
            if isinstance(trace, dict):
                trace.setdefault("team_searches", []).append(
                    {
                        "searched_team": team_name,
                        "candidates_found": len(debug_candidates),
                        "candidate_attempts": candidate_attempts,
                        "similar_candidates": [
                            item for item in debug_candidates
                            if float(item.get("score") or 0.0) >= 0.72
                        ][:10],
                        "selected_candidate": {
                            "name": resolved.get("name"),
                            "category": resolved.get("category"),
                            "raw_href": resolved.get("raw_href"),
                            "score": resolved.get("score"),
                            "context_score": resolved.get("context_score"),
                        },
                        "profile_opened": True,
                        "context_verified": bool(
                            resolved.get("context_verified")
                        ),
                        "final_url": resolved["url"],
                    }
                )
                trace["team_profile_opened"] = True
                trace["team_profile_verified"] = True
            self.logger(
                f"Flashscore: equipo abierto y verificado: {resolved['name']}."
            )
            return resolved

        final_search_failure = (
            self._last_team_search_failure_code
            or TEAM_IDENTITY_MISMATCH
        )
        self._last_team_search_failure_code = final_search_failure
        self._save_search_debug(
            page,
            team_name=team_name,
            candidates=debug_candidates,
            selected=(candidate_attempts[-1] if candidate_attempts else None),
            failure_code=final_search_failure,
            error=(
                "Se agotaron los candidatos compatibles sin resolver una ficha, "
                "una ruta válida de Resultados y el partido esperado."
            ),
        )
        if isinstance(trace, dict):
            trace.setdefault("team_searches", []).append(
                {
                    "searched_team": team_name,
                    "candidates_found": len(debug_candidates),
                    "candidate_attempts": candidate_attempts,
                    "profile_opened": any(
                        item.get("profile_opened") for item in candidate_attempts
                    ),
                    "context_verified": False,
                }
            )
        return None

    @staticmethod
    def _match_links(page: Page) -> list[dict[str, str]]:
        """Lee partidos desde las filas actuales de Flashscore.

        Flashscore puede representar cada encuentro como un enlace que ES la
        propia fila, o como una fila que contiene un enlace invisible. La
        versión anterior solo cubría parcialmente el segundo caso y por eso
        podía mostrar Resultados correctamente sin recuperar la URL del partido.
        """
        value = page.evaluate(
            """
            () => {
                const result = [];
                const seen = new Set();
                const rowSelector = [
                    '[class*="event__match"]',
                    '[class*="eventRow"]',
                    '[data-testid*="event"]'
                ].join(',');
                const routeLooksLikeMatch = href => {
                    const value = (href || '').toLocaleLowerCase('es');
                    return value.includes('/partido/') || value.includes('/match/');
                };
                const add = (row, anchor) => {
                    if (!row || !anchor) return;
                    const href = (anchor.href || anchor.getAttribute('href') || '').trim();
                    if (!href || !routeLooksLikeMatch(href)) return;
                    const text = (row.innerText || row.textContent || '').trim();
                    if (!text) return;
                    const key = `${href}\n${text.slice(0, 180)}`;
                    if (seen.has(key)) return;
                    seen.add(key);
                    result.push({href, text: text.slice(0, 900)});
                };

                // Caso 1: el enlace es la propia fila.
                const directSelectors = [
                    'a[href*="/partido/"]',
                    'a[href*="/match/"]',
                    'a[class*="eventRowLink"][href]',
                    'a[class*="event__match"][href]',
                    'a[class*="eventRow"][href]'
                ];
                for (const anchor of document.querySelectorAll(directSelectors.join(','))) {
                    const row = anchor.matches(rowSelector) ? anchor : anchor.closest(rowSelector);
                    add(row, anchor);
                }

                // Caso 2: la fila contiene un enlace de navegación.
                for (const row of document.querySelectorAll(rowSelector)) {
                    const anchors = Array.from(row.querySelectorAll('a[href]'));
                    const matchAnchor = anchors.find(anchor =>
                        routeLooksLikeMatch(anchor.href || anchor.getAttribute('href'))
                        || String(anchor.className || '').includes('eventRowLink')
                    );
                    add(row, matchAnchor);
                }
                return result.slice(0, 500);
            }
            """
        )
        return [
            {
                "href": str(item.get("href") or ""),
                "text": str(item.get("text") or ""),
            }
            for item in value
            if isinstance(item, dict)
        ] if isinstance(value, list) else []

    def _candidate_urls_from_competition(
        self,
        match: MatchRef,
    ) -> list[str]:
        pages = _competition_results_pages(match)
        if not pages:
            return []

        scored: list[
            tuple[float, int, str, dict[str, Any]]
        ] = []
        trace = getattr(
            self,
            "_last_navigation_trace",
            None,
        )
        for results_url in pages:
            try:
                page = self._goto(
                    results_url,
                    cap_ms=10_000,
                )
                self._dismiss_overlays(page)
            except Exception as exc:
                self._diagnostic(
                    "Flashscore: no pudo abrir Resultados "
                    "de la competición.",
                    reason=_exception_code(
                        exc,
                        NAVIGATION_FAILED,
                    ),
                    action=(
                        "probar la siguiente página de resultados"
                    ),
                    match=match,
                    url=results_url,
                    exc=exc,
                )
                continue

            for load_round in range(5):
                rows: list[dict[str, str]] = []
                for _attempt in range(8):
                    rows = self._match_links(page)
                    if rows:
                        break
                    page.wait_for_timeout(250)

                for row_index, row in enumerate(rows):
                    score, details = _match_row_score(
                        match,
                        row["text"],
                    )
                    if score <= 0.0:
                        continue
                    scored.append(
                        (
                            score,
                            row_index,
                            row["href"],
                            {
                                **details,
                                "results_url": results_url,
                                "row_text": row["text"][:300],
                            },
                        )
                    )

                if scored:
                    break
                if load_round >= 4:
                    break

                clicked = False
                for label in (
                    "Mostrar más partidos",
                    "Mostrar más",
                    "Más partidos",
                ):
                    try:
                        more = page.get_by_text(
                            label,
                            exact=True,
                        )
                        if (
                            more.count() >= 1
                            and more.first.is_visible()
                        ):
                            more.first.click(
                                timeout=self._remaining_timeout_ms(
                                    3_000
                                ),
                                force=True,
                            )
                            page.wait_for_timeout(650)
                            clicked = True
                            break
                    except Exception:
                        continue
                if not clicked:
                    break

            if scored:
                break

        scored.sort(
            key=lambda item: (-item[0], item[1])
        )
        urls = list(
            dict.fromkeys(
                item[2]
                for item in scored
            )
        )
        if isinstance(trace, dict):
            trace.setdefault(
                "match_candidates",
                [],
            ).extend(
                {
                    "source": "competition_results",
                    "url": url,
                    "score": score,
                    **details,
                }
                for score, _index, url, details
                in scored[:12]
            )
            trace["competition_results_fallback_used"] = (
                bool(urls)
            )
        if urls:
            self.logger(
                "Flashscore: partido localizado desde "
                "Resultados de la competición."
            )
        return urls


    def _discover_team_results_link(
        self,
        page: Page,
        team_name: str,
    ) -> str | None:
        health = flashscore_page_health(
            page,
            expected_team=team_name,
        )
        if health.get("is_error"):
            return None
        current = str(health.get("url") or getattr(page, "url", "") or "")
        current_parsed = urlsplit(current)
        current_base = current_parsed.path.rstrip("/")
        candidates: list[str] = []
        for row in health.get("results_links", []):
            if not isinstance(row, dict):
                continue
            href = _normalize_flashscore_url(row.get("href"))
            if not href:
                continue
            parsed = urlsplit(href)
            if not parsed.netloc.endswith("flashscore.es"):
                continue
            if current_base and not parsed.path.startswith(current_base):
                continue
            # En flashscore.es la ruta inglesa /results/ puede devolver la
            # página de error aunque /resultados/ funcione correctamente.
            if "/results/" in parsed.path.casefold():
                continue
            candidates.append(href)
        candidates = list(dict.fromkeys(candidates))
        candidates.sort(
            key=lambda value: (
                0 if "/resultados/" in urlsplit(value).path.casefold() else 1,
                value,
            )
        )
        return candidates[0] if candidates else None

    def _candidate_urls_from_team(
        self,
        match: MatchRef,
        team: dict[str, Any],
    ) -> list[str]:
        base_url = str(team.get("url") or "").strip()
        if not base_url:
            base_url = (
                "https://www.flashscore.es/equipo/"
                f"{team['slug']}/{team['id']}/"
            )
        base_url = _normalize_flashscore_url(base_url)
        team_name = str(team.get("name") or "").strip()
        trace = getattr(self, "_last_navigation_trace", None)

        try:
            page = self._goto(base_url, cap_ms=10_000)
            self._dismiss_overlays(page)
        except Exception as exc:
            team["_results_failure_code"] = RETRYABLE
            self._diagnostic(
                "Flashscore: no pudo reabrir la ficha base verificada del equipo.",
                reason=_exception_code(exc, NAVIGATION_FAILED),
                action="probar la ficha del equipo visitante",
                match=match,
                team=team_name,
                url=base_url,
                exc=exc,
            )
            return []

        base_health = flashscore_page_health(
            page,
            expected_team=team_name,
        )
        explicit_base_error = bool(
            base_health.get("explicit_error")
            or base_health.get("generic_error")
            or base_health.get("redirected_home")
        )
        base_verified = bool(
            not explicit_base_error
            and self._wait_for_team_profile(
                page,
                team_name,
                seconds=5.0,
            )
        )
        if isinstance(trace, dict):
            trace["team_base_page_verified"] = bool(base_verified)
        if not base_verified:
            reason = (
                FLASHSCORE_ERROR_PAGE
                if base_health.get("explicit_error") or base_health.get("generic_error")
                else TEAM_IDENTITY_MISMATCH
            )
            team["_results_failure_code"] = reason
            if isinstance(trace, dict):
                trace["flashscore_error_page_detected"] = bool(
                    base_health.get("explicit_error") or base_health.get("generic_error")
                )
            self._diagnostic(
                "Flashscore: la ficha base del equipo no superó la verificación.",
                reason=reason,
                action="rechazar la ficha y probar el siguiente respaldo",
                match=match,
                team=team_name,
                url=str(getattr(page, "url", base_url) or base_url),
            )
            return []

        discovered = self._discover_team_results_link(page, team_name)
        if isinstance(trace, dict):
            trace["real_results_link_discovered"] = bool(discovered)
            trace["real_results_href"] = discovered

        parsed = urlsplit(base_url)
        # flashscore.es usa /resultados/. La ruta /results/ fue
        # comprobada en navegador real y puede abrir una página de error, por
        # lo que no debe consumir el presupuesto del partido.
        fallback_paths = (
            parsed.path.rstrip("/") + "/resultados/",
        )
        route_candidates: list[tuple[str, str]] = []
        if discovered:
            route_candidates.append(("DOM", discovered))
        for path in fallback_paths:
            route_candidates.append(
                (
                    "FALLBACK_RESULTADOS",
                    urlunsplit(
                        (
                            parsed.scheme or "https",
                            parsed.netloc or "www.flashscore.es",
                            path,
                            "",
                            "",
                        )
                    ),
                )
            )

        scored_urls: list[tuple[float, int, str, dict[str, Any]]] = []
        valid_results_route = False
        any_error_page = False

        for route_source, results_url in list(dict.fromkeys(route_candidates)):
            try:
                page = self._goto(results_url, cap_ms=9_000)
                self._dismiss_overlays(page)
            except Exception as exc:
                self._diagnostic(
                    "Flashscore: no pudo abrir una ruta candidata de Resultados.",
                    reason=_exception_code(exc, NAVIGATION_FAILED),
                    action="probar la siguiente ruta controlada",
                    match=match,
                    team=team_name,
                    url=results_url,
                    exc=exc,
                )
                continue

            rows: list[dict[str, str]] = []
            for _attempt in range(12):
                rows = self._match_links(page)
                if rows:
                    break
                try:
                    page.wait_for_timeout(250)
                except Exception:
                    break

            health = flashscore_page_health(
                page,
                expected_team=team_name,
                require_results=True,
            )
            if health.get("is_error"):
                explicit = bool(
                    health.get("explicit_error")
                    or health.get("generic_error")
                )
                any_error_page = any_error_page or explicit
                if isinstance(trace, dict):
                    trace["flashscore_error_page_detected"] = bool(
                        trace.get("flashscore_error_page_detected") or explicit
                    )
                    trace["team_results_route_valid"] = False
                    trace["invalid_results_route_saved"] = False
                    trace.setdefault("invalid_results_routes", []).append(
                        {
                            "source": route_source,
                            "requested_url": results_url,
                            "final_url": health.get("url"),
                            "explicit_error": explicit,
                            "heading_missing": health.get("heading_missing"),
                            "results_missing": health.get("results_missing"),
                            "redirected_home": health.get("redirected_home"),
                        }
                    )
                self._diagnostic(
                    "Flashscore: la ruta de Resultados abrió una página inválida.",
                    reason=(
                        FLASHSCORE_ERROR_PAGE if explicit else TEAM_RESULTS_ROUTE_INVALID
                    ),
                    action="no guardar la URL y probar la siguiente ruta controlada",
                    match=match,
                    team=team_name,
                    url=str(health.get("url") or results_url),
                )
                continue

            valid_results_route = True
            if isinstance(trace, dict):
                trace["results_opened"] = True
                trace["results_url"] = str(health.get("url") or results_url)
                trace["results_route_source"] = route_source
                trace["team_results_route_valid"] = True
                trace["invalid_results_route_saved"] = False

            # ODDSHUNTER FLASHSCORE HISTORICAL RESULTS V1
            #
            # Flashscore carga solamente una parte del historial del equipo.
            # Para partidos antiguos hay que expandir Resultados repetidamente.
            # Se aceptan los textos español e inglés porque el idioma visible
            # puede variar entre flashscore.es / flashscore.com / sesión.
            # ODDSHUNTER_HISTORY_DYNAMIC_LIMIT_V61
            max_load_rounds = _oh_v61_history_limit(match.kickoff)

            for load_round in range(max_load_rounds + 1):
                if load_round > 0:
                    rows = self._match_links(page)

                for row_index, row in enumerate(rows):
                    score, details = _match_row_score(
                        match,
                        row["text"],
                    )

                    if score <= 0.0:
                        continue

                    scored_urls.append(
                        (
                            score,
                            row_index,
                            row["href"],
                            details,
                        )
                    )

                if scored_urls:
                    break
                
                # ODDSHUNTER_RESULTS_DATE_STOP_V61
                _oh_v61_window = _oh_v61_date_window(rows, match.kickoff)
                if _oh_v61_window.get("past_target"):
                    self.logger(
                        "Flashscore: STOP por fecha en Resultados; "
                        f"target={_oh_v61_window.get('target')}; "
                        f"oldest={_oh_v61_window.get('oldest')}; "
                        f"newest={_oh_v61_window.get('newest')}; "
                        f"load_round={load_round}; limit={max_load_rounds}."
                    )
                    if isinstance(trace, dict):
                        trace["results_date_stop"] = True
                        trace["results_date_stop_window"] = dict(_oh_v61_window)
                    break
                

                if load_round >= max_load_rounds:
                    self.logger(
                        "Flashscore: límite seguro de expansiones "
                        f"alcanzado ({max_load_rounds})."
                    )
                    break

                clicked_more = False

                labels = (
                    "Mostrar más partidos",
                    "Mostrar más",
                    "Más partidos",
                    "Show more matches",
                    "Show more",
                )

                for label in labels:

                    if clicked_more:
                        break

                    try:
                        locator = page.get_by_text(
                            label,
                            exact=True,
                        )

                        count_more = locator.count()

                    except Exception:
                        continue

                    if count_more < 1:
                        continue

                    for locator_index in range(
                        min(count_more, 4)
                    ):
                        try:
                            more = locator.nth(locator_index)

                            if not more.is_visible():
                                continue

                            self._dismiss_overlays(page)

                            try:
                                more.scroll_into_view_if_needed(
                                    timeout=self._remaining_timeout_ms(
                                        2_000
                                    )
                                )
                            except Exception:
                                pass

                            rows_before = len(
                                self._match_links(page)
                            )

                            for force in (False, True):
                                try:
                                    more.click(
                                        timeout=self._remaining_timeout_ms(
                                            2_500
                                        ),
                                        force=force,
                                    )
                                    clicked_more = True
                                    break
                                except Exception:
                                    continue

                            if not clicked_more:
                                try:
                                    more.evaluate(
                                        "(element) => element.click()"
                                    )
                                    clicked_more = True
                                except Exception:
                                    pass

                            if not clicked_more:
                                continue

                            self.logger(
                                "Flashscore: expandiendo historial de "
                                "Resultados "
                                f"({load_round + 1}/"
                                f"{max_load_rounds}) "
                                f"con botón '{label}'."
                            )

                            # No confiar en una espera fija:
                            # comprobar que aparezcan nuevas filas.
                            for _wait in range(12):
                                page.wait_for_timeout(250)

                                refreshed_rows = (
                                    self._match_links(page)
                                )

                                if (
                                    len(refreshed_rows)
                                    > rows_before
                                ):
                                    rows = refreshed_rows
                                    break
                            else:
                                rows = self._match_links(page)

                            break

                        except Exception:
                            continue

                if clicked_more:
                    continue

                # Último respaldo: algunos builds de Flashscore cambian el
                # nodo del botón pero conservan el texto visible.
                try:
                    clicked_js = page.evaluate(
                        """
                        () => {
                            const wanted = new Set([
                                'mostrar más partidos',
                                'mostrar más',
                                'más partidos',
                                'show more matches',
                                'show more'
                            ]);

                            const elements = Array.from(
                                document.querySelectorAll(
                                    'button, a, div, span'
                                )
                            );

                            for (const element of elements) {
                                const text = (
                                    element.innerText || ''
                                )
                                    .trim()
                                    .toLocaleLowerCase();

                                if (!wanted.has(text)) {
                                    continue;
                                }

                                const style = window.getComputedStyle(
                                    element
                                );

                                const rect = (
                                    element.getBoundingClientRect()
                                );

                                if (
                                    style.display === 'none'
                                    || style.visibility === 'hidden'
                                    || rect.width <= 0
                                    || rect.height <= 0
                                ) {
                                    continue;
                                }

                                element.scrollIntoView({
                                    block: 'center'
                                });

                                element.click();

                                return text;
                            }

                            return null;
                        }
                        """
                    )

                    if clicked_js:
                        clicked_more = True

                        self.logger(
                            "Flashscore: expandiendo historial mediante "
                            f"fallback DOM/JS: '{clicked_js}'."
                        )

                        page.wait_for_timeout(750)

                except Exception:
                    clicked_more = False

                if not clicked_more:
                    self.logger(
                        "Flashscore: no quedan botones visibles para "
                        "expandir Resultados."
                    )
                    break
            if scored_urls:
                break

        scored_urls.sort(key=lambda item: (-item[0], item[1]))
        urls = list(dict.fromkeys(item[2] for item in scored_urls))
        if isinstance(trace, dict):
            trace.setdefault("match_candidates", []).extend(
                {
                    "team_profile": team.get("name"),
                    "url": url,
                    "score": score,
                    **details,
                }
                for score, _index, url, details in scored_urls[:10]
            )
        if urls:
            team["_results_failure_code"] = None
            self.logger(
                f"Flashscore: partido localizado desde {team['name']} "
                "usando local, visitante y fecha."
            )
            return urls

        team["_results_failure_code"] = (
            EXPECTED_MATCH_NOT_FOUND
            if valid_results_route
            else TEAM_RESULTS_ROUTE_INVALID
        )
        if any_error_page and isinstance(trace, dict):
            trace["flashscore_error_page_detected"] = True
        return []

    def _match_page_identity_snapshot(
        self,
        page: Page,
        match: MatchRef,
    ) -> dict[str, Any]:
        texts: list[str] = []
        title = ""
        try:
            title = page.title().strip()
            if title:
                texts.append(title)
        except Exception:
            pass

        found_home = ""
        found_away = ""
        participant_source = ""
        participant_pairs = (
            (
                "[class*='duelParticipant__home'] [class*='participantName']",
                "[class*='duelParticipant__away'] [class*='participantName']",
            ),
            (
                ".duelParticipant__home .participant__participantName",
                ".duelParticipant__away .participant__participantName",
            ),
            (
                "[class*='duelParticipant__home']",
                "[class*='duelParticipant__away']",
            ),
        )
        for home_selector, away_selector in participant_pairs:
            try:
                home_locator = page.locator(home_selector)
                away_locator = page.locator(away_selector)
                if home_locator.count() < 1 or away_locator.count() < 1:
                    continue
                home_item = home_locator.nth(0)
                away_item = away_locator.nth(0)
                if not home_item.is_visible() or not away_item.is_visible():
                    continue
                candidate_home = home_item.inner_text(timeout=1_500).strip()
                candidate_away = away_item.inner_text(timeout=1_500).strip()
                if candidate_home and candidate_away:
                    found_home = candidate_home.splitlines()[0].strip()
                    found_away = candidate_away.splitlines()[0].strip()
                    participant_source = f"DOM:{home_selector}|{away_selector}"
                    break
            except Exception:
                continue

        if not found_home or not found_away:
            for selector in (
                "[class*='duelParticipant__participant'] [class*='participantName']",
                "[class*='participant__participantName']",
                "[data-testid*='participant']",
            ):
                try:
                    locator = page.locator(selector)
                    values: list[str] = []
                    for index in range(min(locator.count(), 6)):
                        item = locator.nth(index)
                        if not item.is_visible():
                            continue
                        value = item.inner_text(timeout=1_500).strip()
                        if value and value not in values:
                            values.append(value.splitlines()[0].strip())
                    if len(values) >= 2:
                        found_home, found_away = values[0], values[1]
                        participant_source = f"DOM_LIST:{selector}"
                        break
                except Exception:
                    continue

        if (not found_home or not found_away) and title:
            clean_title = re.sub(
                r"\s*[|,-]\s*(estadísticas|statistics|partido|match).*$",
                "",
                title,
                flags=re.IGNORECASE,
            )
            title_match = re.search(
                r"^\s*(.+?)\s+(?:vs\.?|v\.?|-)\s+(.+?)(?:\s+\d{1,2}[./]\d{1,2}[./]\d{2,4})?\s*$",
                clean_title,
                flags=re.IGNORECASE,
            )
            if title_match:
                found_home = title_match.group(1).strip()
                found_away = title_match.group(2).strip()
                participant_source = "TITLE"

        selectors = (
            "h1",
            "[class*='duelParticipant__startTime']",
            "[class*='startTime']",
            "[class*='eventTime']",
            "time",
            "[class*='tournamentHeader']",
            "[class*='breadcrumb']",
        )
        for selector in selectors:
            try:
                locator = page.locator(selector)
                for index in range(min(locator.count(), 8)):
                    item = locator.nth(index)
                    if not item.is_visible():
                        continue
                    value = item.inner_text(timeout=1_500).strip()
                    if value and value not in texts:
                        texts.append(value)
            except Exception:
                continue

        try:
            body = page.locator("body").inner_text(timeout=3_000).strip()
            if body:
                texts.append(body[:30_000])
        except Exception:
            pass

        identity_text = "\n".join(texts)
        home_score = _name_score(match.home_team, found_home) if found_home else 0.0
        away_score = _name_score(match.away_team, found_away) if found_away else 0.0
        date_match, _date_bonus = _row_date_state(identity_text, match.kickoff)
        competition_tokens = _competition_identity_tokens(match.competition)
        page_tokens = set(_normalize(identity_text).split())
        competition_overlap = sorted(competition_tokens & page_tokens)
        return {
            "expected_home": match.home_team,
            "expected_away": match.away_team,
            "expected_date": _parse_kickoff(match.kickoff).date().isoformat(),
            "found_home": found_home or None,
            "found_away": found_away or None,
            "found_date": date_match,
            "participant_source": participant_source or None,
            "home_score": round(home_score, 4),
            "away_score": round(away_score, 4),
            "date_match": date_match,
            "competition_tokens": sorted(competition_tokens),
            "competition_overlap": competition_overlap,
            "texts_preview": texts[:12],
        }


    def _match_page_is_correct(
        self,
        page: Page,
        match: MatchRef,
    ) -> bool:
        try:
            details = self._match_page_identity_snapshot(page, match)
        except Exception:
            return False

        trace = getattr(self, "_last_navigation_trace", None)
        if isinstance(trace, dict):
            trace["match_identity_snapshot"] = details
            trace["found_home"] = details.get("found_home")
            trace["found_away"] = details.get("found_away")
            trace["found_date"] = details.get("found_date")

        # Se exigen participantes explícitos del encabezado/título. El cuerpo
        # completo ya no puede hacer coincidir una ciudad, pie de página o rival
        # perteneciente a otro encuentro.
        if not details.get("found_home") or not details.get("found_away"):
            return False
        if float(details.get("home_score") or 0.0) < 0.72:
            return False
        if float(details.get("away_score") or 0.0) < 0.72:
            return False
        if details.get("date_match") is not True:
            return False
        return True


    def _replace_active_page_with_clean(self, match: MatchRef) -> Page:
        key = self._match_key(match)
        old_page = getattr(self, "_active_page", None)
        context = self._ensure_context()
        if old_page is not None:
            self._discard_page(key, old_page)
        clean = context.new_page()
        self.pages.append(clean)
        self._active_page = clean
        self._assigned_match_pages[key] = clean
        self.page = clean
        return clean

    def _try_match_url(
        self,
        match: MatchRef,
        url: str,
        *,
        source_label: str,
        clean_page: bool = False,
    ) -> tuple[str | None, str]:
        normalized = _normalize_flashscore_url(url)
        trace = getattr(self, "_last_navigation_trace", None)
        if isinstance(trace, dict):
            trace["candidate_url"] = normalized or None
            trace["candidate_source"] = source_label
        if not normalized:
            if isinstance(trace, dict):
                trace["verification_result"] = MATCH_IDENTITY_MISMATCH
            return None, MATCH_IDENTITY_MISMATCH
        if clean_page:
            self._replace_active_page_with_clean(match)
        try:
            page = self._goto(normalized, cap_ms=12_000)
            try:
                page.wait_for_load_state(
                    "domcontentloaded",
                    timeout=self._remaining_timeout_ms(4_000),
                )
            except Exception:
                pass
        except Exception as exc:
            reason = _exception_code(exc, NAVIGATION_FAILED)
            if isinstance(trace, dict):
                trace["verification_result"] = reason
            self._diagnostic(
                f"Flashscore: falló {source_label}.",
                reason=reason,
                action=(
                    "reintentar en una pestaña limpia"
                    if not clean_page
                    else "buscar el partido por equipo local"
                ),
                match=match,
                url=normalized,
                exc=exc,
            )
            return None, reason

        actual = _normalize_flashscore_url(page.url)
        page_health = flashscore_page_health(page)
        if page_health.get("is_error"):
            if isinstance(trace, dict):
                trace["flashscore_error_page_detected"] = True
                trace["verification_result"] = FLASHSCORE_ERROR_PAGE
                trace["rejected_url"] = actual or normalized
            self._diagnostic(
                f"Flashscore: {source_label} abrió una página de error.",
                reason=FLASHSCORE_ERROR_PAGE,
                action="invalidar solo esta URL y continuar con el siguiente respaldo",
                match=match,
                url=actual or normalized,
            )
            return None, FLASHSCORE_ERROR_PAGE
        if self._match_page_is_correct(page, match):
            if isinstance(trace, dict):
                trace["match_identity_verified"] = True
                trace["verified_match_url"] = actual or normalized
                trace["verification_result"] = "OK"
            return actual or normalized, "OK"

        redirected = bool(actual and actual != normalized)
        reason = REDIRECTED_TO_WRONG_MATCH if redirected else MATCH_IDENTITY_MISMATCH
        if isinstance(trace, dict):
            trace["match_identity_verified"] = False
            trace["verification_result"] = reason
            trace["rejected_url"] = actual or normalized
        self._diagnostic(
            f"Flashscore: {source_label} no corresponde al partido solicitado.",
            reason=reason,
            action="descartar esta dirección y continuar con el siguiente respaldo",
            match=match,
            url=actual or normalized,
        )
        return None, reason


    def _resolve_match_url(self, match: MatchRef) -> str | None:
        self._current_match_for_debug = match
        key = self._match_key(match)
        event_id = self._event_id(match)
        trace = getattr(self, "_last_navigation_trace", None)

        cached = self.match_cache.get(key)
        cache_lookup_key = key
        if not isinstance(cached, dict) and event_id is not None:
            cache_lookup_key = f"event:{event_id}"
            cached = self.match_cache.get(cache_lookup_key)

        if isinstance(cached, dict) and cached.get("url"):
            cached_url = _normalize_flashscore_url(cached["url"])
            cached_event_id = cached.get("event_id")
            try:
                cached_event_id = int(cached_event_id) if cached_event_id is not None else None
            except (TypeError, ValueError):
                cached_event_id = None
            if isinstance(trace, dict):
                trace["cache_status"] = "FOUND"
                trace["cached_match_url"] = cached_url
                trace["cached_event_id"] = cached_event_id

            if event_id is not None and cached_event_id not in {None, event_id}:
                if isinstance(trace, dict):
                    trace["cache_status"] = CACHE_URL_MISMATCH
                    trace["cache_verification_failure"] = "EVENT_ID_MISMATCH"
                self._invalidate_cache_entry(
                    key,
                    match=match,
                    url=cached_url,
                    reason=CACHE_URL_MISMATCH,
                )
            else:
                resolved, reason = self._try_match_url(
                    match,
                    cached_url,
                    source_label="la URL cacheada del partido",
                )
                if resolved:
                    if isinstance(trace, dict):
                        trace["cache_reused"] = True
                        trace["cache_status"] = "VALIDATED_CACHE"
                        trace["cache_source"] = cache_lookup_key
                    self.logger(
                        "Flashscore: URL del partido recuperada y validada desde caché."
                    )
                    return self._save_match_url(match, resolved)
                if isinstance(trace, dict):
                    trace["cache_status"] = CACHE_URL_MISMATCH
                    trace["cache_verification_failure"] = reason
                self._invalidate_cache_entry(
                    key,
                    match=match,
                    url=cached_url,
                    reason=(STALE_CACHE_URL if reason == NAVIGATION_TIMEOUT else CACHE_URL_MISMATCH),
                )
                # La pestaña incorrecta no puede quedar asignada al evento actual.
                current_page = getattr(self, "_active_page", None)
                if current_page is not None:
                    self._discard_page(key, current_page)
                    self._active_page = self._next_page(key)

        if match.flashscore_url:
            direct_url = _normalize_flashscore_url(match.flashscore_url)
            for clean_page in (False, True):
                resolved, _reason = self._try_match_url(
                    match,
                    direct_url,
                    source_label="la URL directa proporcionada",
                    clean_page=clean_page,
                )
                if resolved:
                    return self._save_match_url(match, resolved)

            statistics_candidate = self._statistics_url(direct_url)
            resolved, _reason = self._try_match_url(
                match,
                statistics_candidate,
                source_label="la ruta de Estadísticas derivada de la URL directa",
            )
            if resolved:
                return self._save_match_url(match, direct_url)

        competition_candidates = (
            self._candidate_urls_from_competition(match)
        )
        for candidate in list(
            dict.fromkeys(competition_candidates)
        )[:8]:
            resolved, _reason = self._try_match_url(
                match,
                candidate,
                source_label=(
                    "la URL encontrada desde Resultados "
                    "de la competición"
                ),
            )
            if not resolved:
                continue
            return self._save_match_url(
                match,
                resolved,
            )

        for team_role, team_name in (
            ("local", match.home_team),
            ("visitante", match.away_team),
        ):
            role_candidates: list[str] = []
            for search_name in _contextual_team_search_variants(
                team_name,
                match,
            ):
                try:
                    team = self._search_team(
                        search_name,
                        match,
                    )
                except TypeError as exc:
                    message = str(exc).casefold()
                    if (
                        "positional" not in message
                        and "argument" not in message
                    ):
                        raise
                    team = self._search_team(search_name)

                if team is None:
                    # ODDSHUNTER CONFERENCE BLOCK 11-15 V1: switch to opponent
                    if self._last_team_search_failure_code in {
                        EXPECTED_MATCH_NOT_FOUND,
                        TEAM_RESULTS_ROUTE_INVALID,
                    }:
                        self.logger(
                            "Flashscore: la ficha correcta ya fue validada "
                            "pero no contiene el encuentro; se cambia al rival "
                            "sin repetir alias del mismo equipo."
                        )
                        break
                    continue
                candidates = list(
                    team.get("_match_urls") or []
                )
                if not candidates:
                    candidates = (
                        self._candidate_urls_from_team(
                            match,
                            team,
                        )
                    )
                role_candidates.extend(candidates)
                if candidates:
                    break

            for candidate in list(
                dict.fromkeys(role_candidates)
            )[:8]:
                resolved, _reason = self._try_match_url(
                    match,
                    candidate,
                    source_label=(
                        "la URL encontrada desde Resultados "
                        f"del equipo {team_role}"
                    ),
                )
                if not resolved:
                    continue
                saved = self._save_match_url(
                    match,
                    resolved,
                )
                self.logger(
                    "Flashscore: partido abierto, verificado "
                    "y URL actualizada en caché."
                )
                return saved

            if team_role == "local":
                self.logger(
                    "Flashscore: el local no resolvió un "
                    "partido válido; se intenta con el visitante."
                )

        final_reason = (
            getattr(self, "_last_team_search_failure_code", None)
            or MATCH_IDENTITY_MISMATCH
        )
        if isinstance(trace, dict):
            trace["verification_result"] = final_reason
            trace["cache_status"] = trace.get("cache_status") or "NO_VALID_CACHE"
        self._diagnostic(
            "Flashscore: no fue posible resolver la URL del partido.",
            reason=final_reason,
            action="dejar el partido pendiente para el siguiente intento",
            match=match,
        )
        return None


    @staticmethod
    def _statistics_url(match_url: str) -> str:
        parsed = urlsplit(match_url)
        path = parsed.path.rstrip("/")
        marker = "/resumen/estadisticas"
        if marker in path:
            path = path.split(marker, 1)[0]
        path += "/resumen/estadisticas/general/"
        return urlunsplit(
            (
                parsed.scheme or "https",
                parsed.netloc or "www.flashscore.es",
                path,
                parsed.query,
                "",
            )
        )

    def _open_statistics_page(
        self,
        match: MatchRef,
        match_url: str,
    ) -> Page | None:
        statistics_url = self._statistics_url(match_url)
        try:
            page = self._goto(statistics_url, cap_ms=15_000)
            if is_flashscore_error_page(page):
                trace = getattr(self, "_last_navigation_trace", None)
                if isinstance(trace, dict):
                    trace["flashscore_error_page_detected"] = True
                self._diagnostic(
                    "Flashscore: la ruta de Estadísticas abrió una página de error.",
                    reason=FLASHSCORE_ERROR_PAGE,
                    action="no aceptar la navegación y continuar con el siguiente respaldo",
                    match=match,
                    url=str(getattr(page, "url", statistics_url) or statistics_url),
                )
                return None
            if self._match_page_is_correct(page, match):
                trace = getattr(self, "_last_navigation_trace", None)
                if isinstance(trace, dict):
                    trace["statistics_opened"] = True
                    trace["statistics_url"] = getattr(page, "url", statistics_url)
                return page
        except Exception as exc:
            self._diagnostic(
                "Flashscore: falló la apertura directa de Estadísticas.",
                reason=_exception_code(exc, STATISTICS_TAB_NOT_FOUND),
                action="abrir el resumen y localizar la pestaña Estadísticas",
                match=match,
                url=statistics_url,
                exc=exc,
            )

        try:
            page = self._goto(match_url, cap_ms=12_000)
            self._dismiss_overlays(page)
            candidates = (
                page.get_by_text("Estadísticas", exact=True),
                page.get_by_text("Statistics", exact=True),
                page.locator('a[href*="/resumen/estadisticas"]'),
            )
            for candidate in candidates:
                try:
                    if candidate.count() == 0:
                        continue
                    item = candidate.first
                    if not item.is_visible():
                        continue
                    href = item.get_attribute("href")
                    try:
                        item.click(
                            timeout=self._remaining_timeout_ms(5_000)
                        )
                    except Exception:
                        item.click(
                            timeout=self._remaining_timeout_ms(5_000),
                            force=True,
                        )
                    try:
                        page.wait_for_load_state(
                            "domcontentloaded",
                            timeout=self._remaining_timeout_ms(6_000),
                        )
                    except Exception:
                        pass
                    current_url = _normalize_flashscore_url(page.url)
                    if href and "/resumen/estadisticas" not in current_url:
                        page = self._goto(
                            _normalize_flashscore_url(href), cap_ms=10_000
                        )
                        current_url = _normalize_flashscore_url(page.url)
                    if (
                        "/resumen/estadisticas" in current_url
                        and self._match_page_is_correct(page, match)
                    ):
                        trace = getattr(self, "_last_navigation_trace", None)
                        if isinstance(trace, dict):
                            trace["statistics_opened"] = True
                            trace["statistics_url"] = current_url
                        return page
                except Exception as exc:
                    self._diagnostic(
                        "Flashscore: falló un método para abrir la pestaña Estadísticas.",
                        reason=_exception_code(exc, STATISTICS_TAB_NOT_FOUND),
                        action="probar el siguiente selector o enlace disponible",
                        match=match,
                        url=match_url,
                        exc=exc,
                    )
                    continue
        except Exception as exc:
            self._diagnostic(
                "Flashscore: falló la navegación desde el resumen a Estadísticas.",
                reason=_exception_code(exc, STATISTICS_TAB_NOT_FOUND),
                action="dejar el partido pendiente sin descartar datos previos",
                match=match,
                url=match_url,
                exc=exc,
            )

        self._diagnostic(
            "Flashscore: no se encontró la pestaña Estadísticas.",
            reason=STATISTICS_TAB_NOT_FOUND,
            action="guardar el intento y reintentar según la urgencia",
            match=match,
            url=match_url,
        )
        return None

    def _collect_statistics_snapshot(
        self,
        page: Page,
        *,
        wait_seconds: float = 8.0,
    ) -> tuple[str, list[dict[str, Any]]]:
        """Recoge texto y filas DOM con etiquetas exactas.

        La fila se identifica por el elemento cuyo texto coincide exactamente
        con una etiqueta aprobada. Luego se elige el ancestro más pequeño con
        un valor numérico antes y otro después de la etiqueta.
        """

        deadline = time.monotonic() + max(0.5, wait_seconds)
        match_deadline = getattr(self, "_match_deadline", None)
        if match_deadline is not None:
            deadline = min(deadline, match_deadline)

        last_body = ""
        last_rows: list[dict[str, Any]] = []
        labels = tuple(
            label
            for group in (DIRECT_XG_EXACT_LABELS, *STAT_EXACT_LABELS.values())
            for label in group
        )
        normalized_labels = sorted({_normalize(label) for label in labels})
        while time.monotonic() < deadline:
            body_text = page.locator("body").inner_text(
                timeout=min(
                    self._remaining_timeout_ms(4_000),
                    max(500, int((deadline - time.monotonic()) * 1000)),
                )
            )
            rows = page.evaluate(
                r"""
                (approvedLabels) => {
                    const normalize = value => (value || '')
                        .toLocaleLowerCase('es')
                        .normalize('NFD')
                        .replace(/[\u0300-\u036f]/g, '')
                        .replace(/[^a-z0-9]+/g, ' ')
                        .trim()
                        .replace(/\s+/g, ' ');
                    const approved = new Set(approvedLabels);
                    const numberPattern = /^\s*\d+(?:[.,]\d+)?%?\s*$/;
                    const results = [];
                    const seen = new Set();

                    for (const labelElement of document.querySelectorAll('body *')) {
                        const labelText = (labelElement.innerText || '').trim();
                        const normalizedLabel = normalize(labelText);
                        if (!approved.has(normalizedLabel)) continue;
                        if (labelText.split(/\r?\n/).filter(Boolean).length !== 1) continue;

                        let best = null;
                        let ancestor = labelElement;
                        for (let depth = 0; depth < 7 && ancestor; depth += 1) {
                            const lines = (ancestor.innerText || '')
                                .split(/\r?\n/)
                                .map(line => line.trim())
                                .filter(Boolean);
                            const labelIndex = lines.findIndex(
                                line => normalize(line) === normalizedLabel
                            );
                            if (labelIndex >= 0) {
                                let home = null;
                                let away = null;
                                for (let i = labelIndex - 1; i >= Math.max(0, labelIndex - 4); i -= 1) {
                                    if (numberPattern.test(lines[i])) {
                                        home = lines[i];
                                        break;
                                    }
                                }
                                for (let i = labelIndex + 1; i <= Math.min(lines.length - 1, labelIndex + 4); i += 1) {
                                    if (numberPattern.test(lines[i])) {
                                        away = lines[i];
                                        break;
                                    }
                                }
                                if (home !== null && away !== null) {
                                    const candidate = {
                                        label: labelText,
                                        normalized_label: normalizedLabel,
                                        home,
                                        away,
                                        text: lines.join('\n'),
                                        line_count: lines.length,
                                        depth,
                                    };
                                    if (!best || candidate.line_count < best.line_count) {
                                        best = candidate;
                                    }
                                }
                            }
                            ancestor = ancestor.parentElement;
                        }
                        if (!best) continue;
                        const key = `${best.normalized_label}|${best.home}|${best.away}`;
                        if (seen.has(key)) continue;
                        seen.add(key);
                        results.push(best);
                    }
                    return results;
                }
                """,
                normalized_labels,
            )
            last_body = str(body_text)
            last_rows = rows if isinstance(rows, list) else []
            if last_rows or any(
                _normalize(line) in set(normalized_labels)
                for line in last_body.splitlines()
            ):
                break
            remaining_ms = int((deadline - time.monotonic()) * 1000)
            if remaining_ms <= 0:
                break
            page.wait_for_timeout(max(50, min(300, remaining_ms)))
        return last_body, last_rows

    def _parse_statistics_snapshot(
        self,
        *,
        match_url: str,
        page: Page,
        body_text: str,
        candidates: list[dict[str, Any]],
    ) -> tuple[
        DirectXG | None,
        MatchAggregateStats | None,
        dict[str, MetricPair],
        list[str],
    ]:
        body_lines = [
            line.strip()
            for line in str(body_text).splitlines()
            if line.strip()
        ]
        candidate_rows = candidates if isinstance(candidates, list) else []

        direct_pair = _extract_exact_pair(
            candidate_rows,
            body_lines,
            DIRECT_XG_EXACT_LABELS,
            integer=False,
        )
        direct: DirectXG | None = None
        if direct_pair is not None:
            direct = DirectXG(
                home=float(direct_pair[0]),
                away=float(direct_pair[1]),
                details={
                    "url": match_url,
                    "statistics_url": page.url,
                    "label": "Goles esperados (xG) publicado por Flashscore",
                    "row_matching": "exact_label",
                },
            )

        values: dict[
            str,
            tuple[float | int, float | int] | None,
        ] = {}
        for key, aliases in STAT_EXACT_LABELS.items():
            values[key] = _extract_exact_pair(
                candidate_rows,
                body_lines,
                aliases,
                integer=True,
            )


        # ODDSHUNTER VERIFIED ZERO YELLOW CARDS V1: SAFE INFERENCE
        yellow_cards_zero_verified = False
        if values.get("yellow_cards") is None:
            yellow_label_present = _exact_stat_label_present(
                candidate_rows,
                body_lines,
                STAT_EXACT_LABELS["yellow_cards"],
            )
            mandatory_complete = all(
                values.get(metric) is not None
                for metric in (
                    "total_shots",
                    "shots_on_target",
                    "corners",
                )
            )
            supporting_complete = sum(
                values.get(metric) is not None
                for metric in (
                    "shots_off_target",
                    "blocked_shots",
                )
            )
            snapshot_has_structure = bool(
                len(candidate_rows) >= 3
                or len(body_lines) >= 8
            )

            if (
                mandatory_complete
                and supporting_complete >= 1
                and snapshot_has_structure
                and not yellow_label_present
            ):
                # Flashscore omite normalmente la fila cuando ambos equipos
                # terminaron con cero amarillas. Solo se aplica después de
                # validar el partido y de recibir una pantalla estadística
                # suficientemente completa.
                values["yellow_cards"] = (0, 0)
                yellow_cards_zero_verified = True

        total = values["total_shots"]
        target = values["shots_on_target"]
        aggregate: MatchAggregateStats | None = None
        if total is not None and target is not None:
            off = values["shots_off_target"]
            blocked = values["blocked_shots"]
            aggregate = MatchAggregateStats(
                home=AggregateStats(
                    total_shots=total[0],
                    shots_on_target=target[0],
                    shots_off_target=off[0] if off else None,
                    blocked_shots=blocked[0] if blocked else None,
                ),
                away=AggregateStats(
                    total_shots=total[1],
                    shots_on_target=target[1],
                    shots_off_target=off[1] if off else None,
                    blocked_shots=blocked[1] if blocked else None,
                ),
                details={
                    "url": match_url,
                    "statistics_url": page.url,
                },
            )

        real_mapping = {
            "shots": "total_shots",
            "shots_on_target": "shots_on_target",
            "shots_off_target": "shots_off_target",
            "blocked_shots": "blocked_shots",
            "corners": "corners",
            "yellow_cards": "yellow_cards",
            "red_cards": "red_cards",
            "possession": "possession",
            "fouls": "fouls",
            "offsides": "offsides",
            "big_chances": "big_chances",
        }
        real_stats: dict[str, MetricPair] = {}
        for metric, source_key in real_mapping.items():
            pair = values.get(source_key)
            real_stats[metric] = (
                MetricPair(pair[0], pair[1])
                if pair is not None
                else MetricPair(None, None)
            )

        available = [
            key for key, pair in real_stats.items() if pair.available
        ]

        # ODDSHUNTER VERIFIED ZERO YELLOW CARDS V1: TRACE MARKER
        if yellow_cards_zero_verified:
            available.append("yellow_cards_zero_verified")
        if direct is not None:
            available.append("xg_direct")
        elif aggregate is not None:
            available.append("xg_aggregate")
        return direct, aggregate, real_stats, available

    def _reload_statistics_page(
        self,
        page: Page,
        *,
        match: MatchRef,
        match_url: str,
    ) -> Page | None:
        try:
            page.reload(
                wait_until="domcontentloaded",
                timeout=self._remaining_timeout_ms(12_000),
            )
            self._dismiss_overlays(page)
            page.wait_for_timeout(500)
        except Exception as exc:
            reason = _exception_code(exc, NAVIGATION_FAILED)
            if reason == NAVIGATION_TIMEOUT:
                self._last_attempt_timed_out = True
            self._diagnostic(
                "Flashscore: falló la recarga de la pantalla de estadísticas.",
                reason=reason,
                action=(
                    "reabrir la ruta de Estadísticas una vez antes de "
                    "finalizar el intento"
                ),
                match=match,
                url=getattr(page, "url", self._statistics_url(match_url)),
                exc=exc,
            )

        reopened = self._open_statistics_page(match, match_url)
        return reopened or page

    def _read_statistics(
        self,
        match: MatchRef,
    ) -> tuple[
        DirectXG | None,
        MatchAggregateStats | None,
        dict[str, MetricPair],
    ]:
        match_url = self._resolve_match_url(match)
        if not match_url:
            return None, None, {}

        page = self._open_statistics_page(match, match_url)
        if page is None:
            return None, None, {}

        if not self._match_page_is_correct(page, match):
            trace = getattr(self, "_last_navigation_trace", None)
            if isinstance(trace, dict):
                trace["wrong_match_metrics_blocked"] = True
                trace["verification_result"] = MATCH_IDENTITY_MISMATCH
            self._diagnostic(
                "Flashscore: la página de estadísticas cambió a otro partido.",
                reason=MATCH_IDENTITY_MISMATCH,
                action=(
                    "bloquear todas las métricas, cerrar la pestaña incorrecta "
                    "y dejar el evento pendiente"
                ),
                match=match,
                url=getattr(page, "url", match_url),
            )
            self._discard_page(self._match_key(match), page)
            return None, None, {}

        for extraction_attempt in range(2):
            page.wait_for_timeout(500)
            for position in (350, 650, 950, 1250, 1600, 0):
                page.evaluate(
                    "(position) => window.scrollTo(0, position)",
                    position,
                )
                page.wait_for_timeout(250)

            try:
                body_text, candidates = self._collect_statistics_snapshot(
                    page,
                    wait_seconds=8.0,
                )
                direct, aggregate, real_stats, available = (
                    self._parse_statistics_snapshot(
                        match_url=match_url,
                        page=page,
                        body_text=body_text,
                        candidates=candidates,
                    )
                )
            except Exception as exc:
                reason = _exception_code(exc, NAVIGATION_FAILED)
                if reason == NAVIGATION_TIMEOUT:
                    self._last_attempt_timed_out = True
                self._diagnostic(
                    "Flashscore: no pudo extraer el contenido estadístico.",
                    reason=reason,
                    action=(
                        "recargar y repetir una vez"
                        if extraction_attempt == 0
                        else "finalizar el intento conservando campos NULL"
                    ),
                    match=match,
                    url=getattr(page, "url", self._statistics_url(match_url)),
                    exc=exc,
                )
                available = []
                direct = None
                aggregate = None
                real_stats = {}

            if available:
                received = sorted(set(available))
                trace = getattr(self, "_last_navigation_trace", None)
                if isinstance(trace, dict):
                    trace["metrics_received"] = received
                    trace["metrics_received_any"] = True
                    trace["metric_values"] = {
                        metric: {
                            "home": pair.home,
                            "away": pair.away,
                            "available": pair.available,
                        }
                        for metric, pair in real_stats.items()
                    }
                    if direct is not None:
                        trace["xg"] = {
                            "home": direct.home,
                            "away": direct.away,
                            "is_estimated": False,
                            "source": "flashscore_direct_xg",
                            "method_version": "direct_v1",
                        }
                    elif aggregate is not None:
                        trace["xg"] = {
                            "home": None,
                            "away": None,
                            "is_estimated": True,
                            "source": "shot_aggregate",
                            "method_version": "aggregate_v1",
                        }
                self.logger(
                    "Flashscore: estadísticas recibidas: "
                    + ", ".join(received)
                    + "."
                )
                return direct, aggregate, real_stats

            if extraction_attempt == 0:
                self._diagnostic(
                    "Flashscore: la pantalla abrió pero todavía no entregó estadísticas.",
                    reason=NO_STATISTICS_RECEIVED,
                    action=(
                        "recargar, reabrir Estadísticas, esperar el contenido "
                        "dinámico y repetir la extracción una vez"
                    ),
                    match=match,
                    url=getattr(page, "url", self._statistics_url(match_url)),
                )
                page = self._reload_statistics_page(
                    page,
                    match=match,
                    match_url=match_url,
                )
                if page is None:
                    break
                continue

            self._diagnostic(
                "Flashscore: no entregó estadísticas después de la recuperación.",
                reason=NO_STATISTICS_RECEIVED,
                action=(
                    "recarga y segunda extracción agotadas; guardar el intento "
                    "y mantener los campos como NULL"
                ),
                match=match,
                url=getattr(page, "url", self._statistics_url(match_url)),
            )
            return direct, aggregate, real_stats

        return None, None, {}

    def _prepare(
        self,
        match: MatchRef,
    ) -> tuple[
        DirectXG | None,
        MatchAggregateStats | None,
        dict[str, MetricPair],
    ]:
        key = self._match_key(match)
        if key in self._prepared:
            stored_trace = self._navigation_traces_by_key.get(key)
            if isinstance(stored_trace, dict):
                self._last_navigation_trace = dict(stored_trace)
            self._current_match_for_debug = match
            return self._prepared[key]

        if not self._reserve_cycle_attempt():
            if not bool(getattr(self, "_circuit_message_emitted", False)):
                self.logger(self._skip_message())
                self._circuit_message_emitted = True
            self._reset_event_state(match)
            self._last_navigation_trace["verification_result"] = "SKIPPED_BY_BUDGET"
            self._prepared[key] = (None, None, {})
            self._remember_navigation_trace(match)
            return self._prepared[key]

        self._last_attempt_timed_out = False
        self._reset_event_state(match)
        self._match_deadline = time.monotonic() + float(
            getattr(
                self,
                "match_timeout_seconds",
                DEFAULT_MATCH_TIMEOUT_SECONDS,
            )
        )
        self._active_page = self._next_page(key)
        try:
            # La página reutilizada queda en blanco antes de asociarla al event_id.
            try:
                self._active_page.goto(
                    "about:blank",
                    wait_until="commit",
                    timeout=2_000,
                )
            except Exception:
                pass
            result = self._read_statistics(match)
            direct, aggregate, stats = result
            success = bool(
                direct is not None
                or aggregate is not None
                or any(pair.available for pair in stats.values())
            )
            self._record_attempt_outcome(
                success=success,
                timed_out=bool(self._last_attempt_timed_out),
            )
            self._prepared[key] = result
            self._release_page(key, self._active_page)
            return result
        except Exception as exc:
            timed_out = (
                bool(self._last_attempt_timed_out)
                or type(exc).__name__ == "TimeoutError"
            )
            self._record_attempt_outcome(
                success=False,
                timed_out=timed_out,
            )
            self._discard_page(key, self._active_page)
            self.logger(
                "Flashscore: pestaña dañada cerrada; el partido queda "
                "pendiente para reintento sin detener los demás."
            )
            raise
        finally:
            self._remember_navigation_trace(match)
            self._active_page = None
            self._match_deadline = None
            self._current_match_for_debug = None
            self._event_temporary_state = {}


    def get_direct_xg(self, match: MatchRef) -> DirectXG | None:
        return self._prepare(match)[0]

    def get_aggregate_stats(
        self,
        match: MatchRef,
    ) -> MatchAggregateStats | None:
        return self._prepare(match)[1]

    def get_match_stats(
        self,
        match: MatchRef,
    ) -> dict[str, MetricPair]:
        return self._prepare(match)[2]

    def close(self) -> None:
        self._close_browser_session()


# ==============================================================================
# ODDSHUNTER_JAPAN_FLASHSCORE_APPEND_ONLY_V27
# Compatibilidad J1/J2 añadida al final del módulo.
# No reduce umbrales ni reescribe el código original.
# ==============================================================================

_OH_JAPAN_ORIGINAL_SAFE_EQUIVALENT = _is_safe_team_name_equivalent
_OH_JAPAN_ORIGINAL_SEARCH_VARIANTS = _contextual_team_search_variants

_OH_JAPAN_EXACT_EQUIVALENTS = frozenset(
    {
        frozenset({"avispa fukuoka", "fukuoka"}),
        frozenset({"fagiano okayama", "okayama"}),
        frozenset({"fc tokyo", "tokyo"}),
        frozenset({"jef united chiba", "chiba"}),
        frozenset({"kashima antlers", "kashima"}),
        frozenset({"kashiwa reysol", "kashiwa"}),
        frozenset({"kawasaki frontale", "kawasaki"}),
        frozenset({"kyoto sanga fc", "kyoto"}),
        frozenset({"kyoto sanga", "kyoto"}),
        frozenset({"machida zelvia", "machida"}),
        frozenset({"fc machida zelvia", "machida"}),
        frozenset({"machida z", "machida"}),
        frozenset({"mito hollyhock", "mito"}),
        frozenset({"nagoya grampus", "nagoya"}),
        frozenset({"sanfrecce hiroshima", "sanfrecce"}),
        frozenset({"shimizu s pulse", "shimizu"}),
        frozenset({"tokyo verdy", "verdy"}),
        frozenset({"urawa red diamonds", "urawa"}),
        frozenset({"urawa reds", "urawa"}),
        frozenset({"urawa red diamonds", "urawa reds"}),
        frozenset({"v varen nagasaki", "nagasaki"}),
        frozenset({"yokohama f marinos", "yokohama fm"}),
    }
)

_OH_JAPAN_SEARCH_VARIANTS = {
    "avispa fukuoka": ("Fukuoka",),
    "fukuoka": ("Avispa Fukuoka",),
    "fagiano okayama": ("Okayama",),
    "okayama": ("Fagiano Okayama",),
    "fc tokyo": ("Tokyo",),
    "tokyo": ("FC Tokyo",),
    "jef united chiba": ("Chiba",),
    "chiba": ("JEF United Chiba",),
    "kashima antlers": ("Kashima",),
    "kashima": ("Kashima Antlers",),
    "kashiwa reysol": ("Kashiwa",),
    "kashiwa": ("Kashiwa Reysol",),
    "kawasaki frontale": ("Kawasaki",),
    "kawasaki": ("Kawasaki Frontale",),
    "kyoto sanga fc": ("Kyoto", "Kyoto Sanga"),
    "kyoto sanga": ("Kyoto", "Kyoto Sanga FC"),
    "kyoto": ("Kyoto Sanga FC", "Kyoto Sanga"),
    "machida zelvia": ("Machida", "FC Machida Zelvia"),
    "fc machida zelvia": ("Machida", "Machida Zelvia"),
    "machida z": ("Machida", "Machida Zelvia"),
    "machida": ("Machida Zelvia", "FC Machida Zelvia"),
    "mito hollyhock": ("Mito",),
    "mito": ("Mito Hollyhock",),
    "nagoya grampus": ("Nagoya",),
    "nagoya": ("Nagoya Grampus",),
    "sanfrecce hiroshima": ("Sanfrecce",),
    "sanfrecce": ("Sanfrecce Hiroshima",),
    "shimizu s pulse": ("Shimizu",),
    "shimizu": ("Shimizu S-Pulse",),
    "tokyo verdy": ("Verdy",),
    "verdy": ("Tokyo Verdy",),
    "urawa red diamonds": ("Urawa", "Urawa Reds"),
    "urawa reds": ("Urawa", "Urawa Red Diamonds"),
    "urawa": ("Urawa Red Diamonds", "Urawa Reds"),
    "v varen nagasaki": ("Nagasaki",),
    "nagasaki": ("V-Varen Nagasaki",),
    "yokohama f marinos": ("Yokohama FM",),
    "yokohama fm": ("Yokohama F. Marinos",),
}


def _oh_japan_identity_key(value):
    return _normalize(value)


def _is_safe_team_name_equivalent(expected, candidate):
    if _OH_JAPAN_ORIGINAL_SAFE_EQUIVALENT(expected, candidate):
        return True

    pair = frozenset(
        {
            _oh_japan_identity_key(expected),
            _oh_japan_identity_key(candidate),
        }
    )
    return bool(pair) and pair in _OH_JAPAN_EXACT_EQUIVALENTS


def _contextual_team_search_variants(team_name, match):
    original_variants = list(
        _OH_JAPAN_ORIGINAL_SEARCH_VARIANTS(team_name, match)
    )

    raw = str(team_name or "").strip()
    japan_variants = _OH_JAPAN_SEARCH_VARIANTS.get(
        _oh_japan_identity_key(raw),
        (),
    )

    result = []
    seen = set()

    for value in (raw, *japan_variants, *original_variants):
        text = str(value or "").strip()
        key = _normalize(text)
        if not text or not key or key in seen:
            continue
        seen.add(key)
        result.append(text)

    return result


# ==============================================================================
# ODDSHUNTER_JAPAN_FLASHSCORE_V28_THREE_FIXES
# 1. Gamba/Cerezo aliases exactos
# 2. lotes 4/4 se controlan desde el instalador
# 3. recuperación box-over-content / página cerrada
# ==============================================================================

_OH_V28_ORIGINAL_SAFE_EQUIVALENT = _is_safe_team_name_equivalent
_OH_V28_ORIGINAL_SEARCH_VARIANTS = _contextual_team_search_variants
_OH_V28_ORIGINAL_GOTO = FlashscoreXGClient._goto

_OH_V28_OSAKA_EQUIVALENTS = frozenset(
    {
        frozenset({"gamba osaka", "g osaka"}),
        frozenset({"cerezo osaka", "c osaka"}),
    }
)

_OH_V28_OSAKA_VARIANTS = {
    "gamba osaka": ("G-Osaka",),
    "g osaka": ("Gamba Osaka",),
    "cerezo osaka": ("C-Osaka",),
    "c osaka": ("Cerezo Osaka",),
}


def _is_safe_team_name_equivalent(expected, candidate):
    if _OH_V28_ORIGINAL_SAFE_EQUIVALENT(expected, candidate):
        return True
    pair = frozenset({_normalize(expected), _normalize(candidate)})
    return bool(pair) and pair in _OH_V28_OSAKA_EQUIVALENTS


def _contextual_team_search_variants(team_name, match):
    raw = str(team_name or "").strip()
    exact = _OH_V28_OSAKA_VARIANTS.get(_normalize(raw), ())
    original = list(_OH_V28_ORIGINAL_SEARCH_VARIANTS(team_name, match))

    result = []
    seen = set()
    for value in (raw, *exact, *original):
        text = str(value or "").strip()
        key = _normalize(text)
        if not text or not key or key in seen:
            continue
        seen.add(key)
        result.append(text)
    return result


def _oh_v28_overlay_exception(exc):
    message = str(exc or "").casefold()
    markers = (
        "box-over-content",
        "interrupted by another navigation",
        "targetclosederror",
        "target page, context or browser has been closed",
        "target page has been closed",
        "browser has been closed",
        "context has been closed",
        "page has been closed",
        "page closed",
    )
    return any(marker in message for marker in markers)


def _oh_v28_summary_url(url):
    value = str(url or "")
    marker = "/resumen/estadisticas/general/"
    if marker in value:
        return value.replace(marker, "/", 1)
    return value


def _oh_v28_install_overlay_block(client, page):
    if page is None:
        return

    routed = getattr(client, "_oh_v28_routed_pages", None)
    if not isinstance(routed, set):
        routed = set()
        client._oh_v28_routed_pages = routed

    identity = id(page)
    if identity in routed:
        return

    try:
        page.route(
            "**/box-over-content/**",
            lambda route: route.abort(),
        )
        routed.add(identity)
    except Exception:
        pass


def _oh_v28_fresh_active_page(client):
    old_page = getattr(client, "_active_page", None)

    assigned = getattr(client, "_assigned_match_pages", {})
    if isinstance(assigned, dict):
        client._assigned_match_pages = {
            key: page
            for key, page in assigned.items()
            if page is not old_page and client._page_open(page)
        }

    if old_page is not None:
        try:
            if client._page_open(old_page):
                old_page.close()
        except Exception:
            pass

    client.pages = [
        page
        for page in list(getattr(client, "pages", []))
        if page is not old_page and client._page_open(page)
    ]
    client._active_page = None
    client.page = None

    context = client._ensure_context()
    open_pages = [
        page
        for page in list(getattr(client, "pages", []))
        if client._page_open(page)
    ]
    page = open_pages[0] if open_pages else context.new_page()

    if page not in client.pages:
        client.pages.append(page)

    client._active_page = page
    client.page = page

    match = getattr(client, "_current_match_for_debug", None)
    if match is not None:
        try:
            key = client._match_key(match)
            client._assigned_match_pages[key] = page
        except Exception:
            pass

    _oh_v28_install_overlay_block(client, page)
    return page


def _oh_v28_goto(self, url, *, cap_ms=25_000):
    try:
        page = self._ensure_page()
        _oh_v28_install_overlay_block(self, page)
    except Exception:
        pass

    try:
        return _OH_V28_ORIGINAL_GOTO(self, url, cap_ms=cap_ms)
    except Exception as exc:
        if not _oh_v28_overlay_exception(exc):
            raise

        try:
            self.logger(
                "Flashscore: box-over-content/pestaña cerrada detectado; "
                "se conserva la URL verificada y se recrea solo la pestaña."
            )
        except Exception:
            pass

        page = _oh_v28_fresh_active_page(self)
        summary_url = _oh_v28_summary_url(url)

        # No se vuelve a buscar equipo ni partido. Se reutiliza la URL
        # previamente verificada por el cliente.
        if summary_url != str(url):
            page.goto(
                summary_url,
                wait_until="domcontentloaded",
                timeout=self._remaining_timeout_ms(min(int(cap_ms), 20_000)),
            )
            self._dismiss_overlays(page)
            try:
                page.wait_for_timeout(350)
            except Exception:
                pass

        page.goto(
            str(url),
            wait_until="domcontentloaded",
            timeout=self._remaining_timeout_ms(int(cap_ms)),
        )
        self._dismiss_overlays(page)

        try:
            self.logger(
                "Flashscore: navegación a Estadísticas recuperada sin "
                "repetir búsqueda de equipo/partido."
            )
        except Exception:
            pass
        return page


FlashscoreXGClient._goto = _oh_v28_goto

# ============================================================================== 
# ODDSHUNTER_JAPAN_YOKOHAMA_M_V283
# Yokohama F. Marinos = Yokohama FM = Yokohama M.
# ============================================================================== 

_OH_V283_ORIGINAL_SAFE_EQUIVALENT = _is_safe_team_name_equivalent
_OH_V283_ORIGINAL_SEARCH_VARIANTS = _contextual_team_search_variants

_OH_V283_YOKOHAMA_NAMES = frozenset({
    "yokohama f marinos",
    "yokohama fm",
    "yokohama m",
})

def _is_safe_team_name_equivalent(expected, candidate):
    if _OH_V283_ORIGINAL_SAFE_EQUIVALENT(expected, candidate):
        return True
    left = _normalize(expected)
    right = _normalize(candidate)
    return left in _OH_V283_YOKOHAMA_NAMES and right in _OH_V283_YOKOHAMA_NAMES

def _contextual_team_search_variants(team_name, match):
    raw = str(team_name or "").strip()
    key = _normalize(raw)
    original = list(_OH_V283_ORIGINAL_SEARCH_VARIANTS(team_name, match))
    exact = ()
    if key in _OH_V283_YOKOHAMA_NAMES:
        exact = ("Yokohama M.", "Yokohama FM", "Yokohama F. Marinos")
    result = []
    seen = set()
    for value in (raw, *exact, *original):
        text = str(value or "").strip()
        normalized = _normalize(text)
        if not text or not normalized or normalized in seen:
            continue
        seen.add(normalized)
        result.append(text)
    return result

# ============================================================================== 
# ODDSHUNTER_JAPAN_FINAL_ALIAS_GUARD_V284
# - reservas/amateur/femenino nunca pueden convertirse en alias válido
# - Sanfrecce Hiroshima = Sanfrecce = Hiroshima
# ============================================================================== 

_OH_V284_ORIGINAL_SAFE_EQUIVALENT = _is_safe_team_name_equivalent
_OH_V284_ORIGINAL_SEARCH_VARIANTS = _contextual_team_search_variants

_OH_V284_SANFRECCE_NAMES = frozenset({
    "sanfrecce hiroshima",
    "sanfrecce",
    "hiroshima",
})

def _oh_v284_forbidden_team_variant(value):
    raw = str(value or '').strip().casefold()
    norm = _normalize(value)

    if not raw and not norm:
        return False

    # Amateur / women.
    if re.search(r'\(\s*am\s*\)', raw):
        return True
    if re.search(r'(^|\s)(f|fem|femenino|women|womens|ladies)(\s|$)', norm):
        return True

    # Youth / reserves: Sub-18, U18, U-18, Under 18, II, B team, reserves.
    if re.search(r'(^|\s)(sub|u|under)\s*[- ]?\s*\d{2}(\s|$)', norm):
        return True
    if re.search(r'(^|\s)(ii|iii|res|reserve|reserves|b team|b-team)(\s|$)', norm):
        return True

    return False

def _is_safe_team_name_equivalent(expected, candidate):
    # Este guard tiene prioridad sobre TODOS los wrappers anteriores.
    # Un candidato reserva/amateur/femenino no puede llegar a score=1.0.
    if _oh_v284_forbidden_team_variant(candidate):
        return False

    if _OH_V284_ORIGINAL_SAFE_EQUIVALENT(expected, candidate):
        return True

    left = _normalize(expected)
    right = _normalize(candidate)
    return left in _OH_V284_SANFRECCE_NAMES and right in _OH_V284_SANFRECCE_NAMES

def _contextual_team_search_variants(team_name, match):
    raw = str(team_name or '').strip()
    key = _normalize(raw)
    original = list(_OH_V284_ORIGINAL_SEARCH_VARIANTS(team_name, match))

    exact = ()
    if key in _OH_V284_SANFRECCE_NAMES:
        exact = ("Hiroshima", "Sanfrecce", "Sanfrecce Hiroshima")

    result = []
    seen = set()
    for value in (raw, *exact, *original):
        text = str(value or '').strip()
        normalized = _normalize(text)
        if not text or not normalized or normalized in seen:
            continue
        if _oh_v284_forbidden_team_variant(text):
            continue
        seen.add(normalized)
        result.append(text)
    return result


# ============================================================================== 
# ODDSHUNTER_JAPAN_FIX_FC_GUARD_V286
# Fix: 'Kyoto Sanga F.C.' must NOT be classified as female.
# ============================================================================== 

def _oh_v284_forbidden_team_variant(value):
    raw = str(value or '').strip().casefold()
    norm = _normalize(value)

    if not raw and not norm:
        return False

    # Amateur.
    if re.search(r'\(\s*am\s*\)', raw):
        return True

    # Youth.
    if re.search(r'(^|\s)(sub|u|under)\s*[- ]?\s*\d{2}(\s|$)', norm):
        return True

    # Reserve / second team.
    if re.search(r'(^|\s)(ii|iii|res|reserve|reserves)(\s|$)', norm):
        return True
    if re.search(r'(^|\s)b[ -]?team(\s|$)', norm):
        return True

    # Explicit female labels.
    if re.search(r'\(\s*f\s*\)', raw):
        return True
    if re.search(r'(^|\s)(women|womens|woman|ladies|fem|femenino|femenina)(\s|$)', norm):
        return True

    # Flashscore female variants seen in logs use terminal ' F'.
    # This blocks 'Urawa F', 'Hiroshima F', 'C-Osaka F', etc.
    # It deliberately does NOT block 'F.C.' because normalized F.C. = 'f c'.
    if re.search(r'(^|\s)f$', norm):
        return True

    return False

# ==============================================================================
# ODDSHUNTER_JAPAN_MATRIX_20_CLUBS_V285
# Closed identity matrix for J1 2026/27.
# Sources represented in this matrix:
# - official J.League naming supplied by user
# - visible Flashscore/SofaScore aliases supplied by user
# - variants already observed in real OddsHunter logs
# ==============================================================================

_OH_V285_ORIGINAL_SAFE_EQUIVALENT = _is_safe_team_name_equivalent
_OH_V285_ORIGINAL_SEARCH_VARIANTS = _contextual_team_search_variants

_OH_V285_MATRIX_RAW = {'Avispa Fukuoka': ['Avispa Fukuoka', 'Fukuoka'], 'Cerezo Osaka': ['Cerezo Osaka', 'C-Osaka'], 'Fagiano Okayama': ['Fagiano Okayama', 'Okayama'], 'FC Tokyo': ['FC Tokyo', 'Tokyo'], 'Gamba Osaka': ['Gamba Osaka', 'G-Osaka'], 'JEF United Chiba': ['JEF United Chiba', 'JEF United Ichihara Chiba', 'Chiba'], 'Kashima Antlers': ['Kashima Antlers', 'Kashima'], 'Kashiwa Reysol': ['Kashiwa Reysol', 'Kashiwa'], 'Kawasaki Frontale': ['Kawasaki Frontale', 'Kawasaki'], 'Kyoto Sanga F.C.': ['Kyoto Sanga F.C.', 'Kyoto Sanga FC', 'Kyoto Sanga', 'Kyoto'], 'FC Machida Zelvia': ['FC Machida Zelvia', 'Machida Zelvia', 'Machida', 'Machida Z'], 'Mito Hollyhock': ['Mito Hollyhock', 'Mito'], 'Nagoya Grampus': ['Nagoya Grampus', 'Nagoya'], 'Sanfrecce Hiroshima': ['Sanfrecce Hiroshima', 'Sanfrecce', 'Hiroshima'], 'Shimizu S-Pulse': ['Shimizu S-Pulse', 'Shimizu'], 'Tokyo Verdy': ['Tokyo Verdy', 'Verdy'], 'Urawa Reds': ['Urawa Reds', 'Urawa Red Diamonds', 'Urawa'], 'V-Varen Nagasaki': ['V-Varen Nagasaki', 'Nagasaki'], 'Vissel Kobe': ['Vissel Kobe'], 'Yokohama F. Marinos': ['Yokohama F. Marinos', 'Yokohama FM', 'Yokohama M.']}

_OH_V285_GROUPS = {}
_OH_V285_ALIAS_TO_CANONICAL = {}

for _canonical, _aliases in _OH_V285_MATRIX_RAW.items():
    _group = frozenset(_normalize(_name) for _name in _aliases)
    _OH_V285_GROUPS[_canonical] = _group
    for _alias in _group:
        _OH_V285_ALIAS_TO_CANONICAL[_alias] = _canonical


def _oh_v285_canonical(value):
    return _OH_V285_ALIAS_TO_CANONICAL.get(_normalize(value))


def _is_safe_team_name_equivalent(expected, candidate):
    # Safety guard from V2.8.4 remains absolute priority.
    if "_oh_v284_forbidden_team_variant" in globals():
        if _oh_v284_forbidden_team_variant(candidate):
            return False

    left = _oh_v285_canonical(expected)
    right = _oh_v285_canonical(candidate)

    if left is not None and right is not None:
        return left == right

    return _OH_V285_ORIGINAL_SAFE_EQUIVALENT(expected, candidate)


def _contextual_team_search_variants(team_name, match):
    raw = str(team_name or "").strip()
    canonical = _oh_v285_canonical(raw)
    original = list(_OH_V285_ORIGINAL_SEARCH_VARIANTS(team_name, match))

    exact = ()
    if canonical is not None:
        exact = tuple(_OH_V285_MATRIX_RAW[canonical])

    result = []
    seen = set()

    for value in (raw, *exact, *original):
        text = str(value or "").strip()
        norm = _normalize(text)
        if not text or not norm or norm in seen:
            continue

        if "_oh_v284_forbidden_team_variant" in globals():
            if _oh_v284_forbidden_team_variant(text):
                continue

        # If a known J1 alias belongs to a different club, do not leak it
        # into this team's variants.
        if canonical is not None:
            candidate_canonical = _oh_v285_canonical(text)
            if candidate_canonical is not None and candidate_canonical != canonical:
                continue

        seen.add(norm)
        result.append(text)

    return result


# ==============================================================================
# ODDSHUNTER_FLASHSCORE_RECOVERY_GENERAL_V61
# ==============================================================================

_OH_V61_ORIGINAL_NAME_SCORE = _name_score

_OH_V61_ORIGINAL_NAME_CONTEXT = (
    _candidate_name_context_valid
)

# Base real ANTERIOR al wrapper V28.
_OH_V61_BASE_GOTO = (
    _OH_V28_ORIGINAL_GOTO
)


_OH_V61_GENERIC = frozenset(
    {
        "fc",
        "cf",
        "sc",
        "ac",
        "afc",
        "club",
        "real",
        "city",
        "united",
        "sporting",
        "athletic",
        "atletico",
        "deportivo",
        "racing",
        "inter",
    }
)


def _oh_v61_short_equivalent(
    expected,
    candidate,
):

    left = _team_core(expected)
    right = _team_core(candidate)

    if (
        not left
        or
        not right
        or
        left == right
    ):

        return False

    left_tokens = set(
        left.split()
    )

    right_tokens = set(
        right.split()
    )

    if left_tokens.issubset(
        right_tokens
    ):

        short = left_tokens
        long = right_tokens

    elif right_tokens.issubset(
        left_tokens
    ):

        short = right_tokens
        long = left_tokens

    else:

        return False

    if len(long) <= len(short):

        return False

    if len(short) > 2:

        return False

    meaningful = [

        token

        for token in short

        if (
            len(token) >= 3
            and
            token not in _OH_V61_GENERIC
        )
    ]

    return bool(meaningful)


def _name_score(
    expected,
    candidate,
):

    base = float(
        _OH_V61_ORIGINAL_NAME_SCORE(
            expected,
            candidate,
        )
    )

    if _oh_v61_short_equivalent(
        expected,
        candidate,
    ):

        return max(
            base,
            0.82,
        )

    return base


def _candidate_name_context_valid(
    expected,
    candidate,
    score,
):

    if _oh_v61_short_equivalent(
        expected,
        candidate,
    ):

        return True

    return (
        _OH_V61_ORIGINAL_NAME_CONTEXT(
            expected,
            candidate,
            score,
        )
    )


def _oh_v61_target_date(
    value,
):

    try:

        if isinstance(
            value,
            datetime,
        ):

            return value.date()

        if isinstance(
            value,
            (int, float),
        ):

            return datetime.fromtimestamp(
                int(value)
            ).date()

        text = str(
            value
            or ""
        ).strip()

        if not text:

            return None

        if text.isdigit():

            return datetime.fromtimestamp(
                int(text)
            ).date()

        if text.endswith("Z"):

            text = (
                text[:-1]
                +
                "+00:00"
            )

        return datetime.fromisoformat(
            text
        ).date()

    except Exception:

        return None


def _oh_v61_result_dates(
    rows,
    target,
):

    if target is None:

        return []

    pattern = re.compile(
        r"(?<!\d)"
        r"(\d{1,2})"
        r"[./]"
        r"(\d{1,2})"
        r"(?:[./](\d{2,4}))?"
        r"(?!\d)"
    )

    values = []

    for row in (
        rows
        or []
    ):

        if isinstance(
            row,
            dict,
        ):

            text = str(
                row.get("text")
                or ""
            )

        else:

            text = str(
                row
                or ""
            )

        for found in pattern.finditer(
            text
        ):

            try:

                day = int(
                    found.group(1)
                )

                month = int(
                    found.group(2)
                )

                year_text = (
                    found.group(3)
                )

                if year_text:

                    year = int(
                        year_text
                    )

                    if year < 100:

                        year += 2000

                    value = datetime(
                        year,
                        month,
                        day,
                    ).date()

                else:

                    possibilities = []

                    for year in (
                        target.year - 1,
                        target.year,
                        target.year + 1,
                    ):

                        try:

                            possibilities.append(
                                datetime(
                                    year,
                                    month,
                                    day,
                                ).date()
                            )

                        except ValueError:

                            pass

                    if not possibilities:

                        continue

                    value = min(
                        possibilities,
                        key=lambda item:
                            abs(
                                (
                                    item
                                    -
                                    target
                                ).days
                            ),
                    )

                values.append(
                    value
                )

            except Exception:

                pass

    return sorted(
        set(values)
    )


def _oh_v61_date_window(
    rows,
    kickoff,
):

    target = _oh_v61_target_date(
        kickoff
    )

    dates = _oh_v61_result_dates(
        rows,
        target,
    )

    if (
        target is None
        or
        not dates
    ):

        return {

            "target":
                (
                    target.isoformat()
                    if target
                    else None
                ),

            "oldest":
                None,

            "newest":
                None,

            "past_target":
                False,
        }

    oldest = min(dates)
    newest = max(dates)

    # Un día de tolerancia.
    # Dos o más días por detrás = ya cruzamos target.
    past_target = (
        (
            target
            -
            oldest
        ).days
        >=
        2
    )

    return {

        "target":
            target.isoformat(),

        "oldest":
            oldest.isoformat(),

        "newest":
            newest.isoformat(),

        "past_target":
            bool(past_target),
    }


def _oh_v61_history_limit(
    kickoff,
):

    target = _oh_v61_target_date(
        kickoff
    )

    if target is None:

        return 30

    age_days = max(
        0,
        (
            datetime.now().date()
            -
            target
        ).days,
    )

    if age_days <= 400:

        return 6

    if age_days <= 800:

        return 18

    return 30


def _oh_v61_drop_dead_page(
    client,
    page,
):

    if page is None:

        return

    client._assigned_match_pages = {

        key:
            assigned

        for (
            key,
            assigned,
        ) in getattr(
            client,
            "_assigned_match_pages",
            {},
        ).items()

        if (
            assigned is not page
            and
            client._page_open(
                assigned
            )
        )
    }

    client.pages = [

        candidate

        for candidate in list(
            getattr(
                client,
                "pages",
                [],
            )
        )

        if (
            candidate is not page
            and
            client._page_open(
                candidate
            )
        )
    ]

    if getattr(
        client,
        "_active_page",
        None,
    ) is page:

        client._active_page = None

    if getattr(
        client,
        "page",
        None,
    ) is page:

        client.page = None


def _oh_v61_goto(
    self,
    url,
    *,
    cap_ms=25_000,
):

    try:

        active = self._ensure_page()

        _oh_v28_install_overlay_block(
            self,
            active,
        )

    except Exception:

        active = getattr(
            self,
            "_active_page",
            None,
        )

    try:

        return _OH_V61_BASE_GOTO(
            self,
            url,
            cap_ms=cap_ms,
        )

    except Exception as exc:

        if not _oh_v28_overlay_exception(
            exc
        ):

            raise

        page = getattr(
            self,
            "_active_page",
            None,
        )

        # Página realmente muerta:
        # NO close/new_page bloqueante.
        if (
            page is None
            or
            not self._page_open(
                page
            )
        ):

            _oh_v61_drop_dead_page(
                self,
                page,
            )

            self.logger(
                "Flashscore: pestaña realmente cerrada; "
                "recuperación V6.1 aborta este intento "
                "sin recreación bloqueante."
            )

            raise RuntimeError(
                "FLASHSCORE_PAGE_CLOSED_RETRYABLE"
            ) from exc

        # Overlay pero pestaña viva:
        # reutilizar exactamente la misma.
        _oh_v28_install_overlay_block(
            self,
            page,
        )

        self.logger(
            "Flashscore: box-over-content detectado; "
            "recuperación V6.1 reutiliza la misma pestaña "
            "y evita close/new_page."
        )

        summary_url = _oh_v28_summary_url(
            url
        )

        targets = []

        if (
            summary_url
            !=
            str(url)
        ):

            targets.append(
                summary_url
            )

        targets.append(
            str(url)
        )

        navigation_timeout = max(
            1_000,
            min(
                int(cap_ms),
                8_000,
            ),
        )

        last_error = None

        for target in targets:

            try:

                page.goto(
                    target,
                    wait_until=
                        "domcontentloaded",
                    timeout=
                        navigation_timeout,
                )

                self._dismiss_overlays(
                    page
                )

                try:

                    page.wait_for_timeout(
                        250
                    )

                except Exception:

                    pass

                last_error = None

            except Exception as retry_exc:

                last_error = (
                    retry_exc
                )

                if not self._page_open(
                    page
                ):

                    _oh_v61_drop_dead_page(
                        self,
                        page,
                    )

                    raise RuntimeError(
                        "FLASHSCORE_PAGE_CLOSED_RETRYABLE"
                    ) from retry_exc

                continue

        if last_error is not None:

            raise last_error

        self.logger(
            "Flashscore: navegación recuperada "
            "en la misma pestaña; sin recreación."
        )

        return page


# Wrapper final activo.
FlashscoreXGClient._goto = (
    _oh_v61_goto
)

