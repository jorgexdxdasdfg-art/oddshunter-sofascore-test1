from __future__ import annotations

import argparse
import json
import os
import re
import time
import unicodedata
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from playwright.sync_api import (
    BrowserContext,
    Page,
    Response,
    TimeoutError as PlaywrightTimeoutError,
    sync_playwright,
)

from database import (
    get_connection,
    transaction,
    upsert_league,
    upsert_match,
    upsert_team,
    upsert_team_competition_membership,
    upsert_team_match_stats,
)
from futbol24_client import Futbol24Client
from flashscore_xg_client import FlashscoreXGClient
from xg_estimator import (
    AggregateStats,
    classify_match_data_quality,
)
from xg_pipeline import (
    DirectXG,
    MatchAggregateStats,
    MatchRef,
    StaticXGSource,
    XGResult,
    recover_xg,
)
from match_stats_pipeline import (
    MatchStatsResult,
    MetricPair,
    recover_match_stats,
)


# ==============================================================================
# 1. RUTAS Y CONFIGURACIÓN
# ==============================================================================

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
REGISTRY_PATH = DATA_DIR / "competitions.json"
COMPETITIONS_DIR = DATA_DIR / "competitions"
RAW_ROOT_DIR = DATA_DIR / "raw_competitions"
BRAVE_PROFILE_DIR = DATA_DIR / "brave_oddshunter_profile"
VERIFIED_MATCH_OVERRIDES_PATH = DATA_DIR / "verified_match_overrides.json"

PAGE_TIMEOUT_MS = 90_000
NETWORK_WAIT_SECONDS = 25
MAX_RELOADS = 1
DEFAULT_DELAY_SECONDS = 4.0

DATA_DIR.mkdir(parents=True, exist_ok=True)
COMPETITIONS_DIR.mkdir(parents=True, exist_ok=True)
RAW_ROOT_DIR.mkdir(parents=True, exist_ok=True)
BRAVE_PROFILE_DIR.mkdir(parents=True, exist_ok=True)


# ==============================================================================
# 2. CONTADORES
# ==============================================================================

@dataclass
class Counters:
    encontrados: int = 0
    seleccionados: int = 0
    full_omitidos: int = 0
    partial_omitidos: int = 0
    guardados_full: int = 0
    guardados_partial: int = 0
    errores: int = 0


# ==============================================================================
# 3. UTILIDADES
# ==============================================================================



def close_playwright_target(target: Any, label: str) -> None:
    """Cierra una página/contexto sin fallar si Brave ya lo cerró."""
    if target is None:
        return

    try:
        is_closed = getattr(target, "is_closed", None)
        if callable(is_closed) and bool(is_closed()):
            return
    except Exception:
        # Algunos objetos de Playwright no exponen is_closed o pueden quedar
        # desconectados mientras se consulta. El cierre protegido sigue abajo.
        pass

    try:
        target.close()
    except Exception as exc:
        # El trabajo principal ya fue guardado. Un TargetClosedError durante
        # la limpieza no debe devolver código 1 ni detener la cola automática.
        print(
            f"⚠️ Cierre de {label} omitido: "
            f"{type(exc).__name__}: {exc}"
        )


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def slugify(text: str) -> str:
    value = text.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-")


def read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"No existe:\n{path}")

    with path.open("r", encoding="utf-8") as file:
        data = json.load(file)

    if not isinstance(data, dict):
        raise ValueError(f"{path.name} no contiene un objeto JSON válido.")

    return data


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def encontrar_brave() -> Path:
    candidatos = [
        (
            Path(os.environ.get("PROGRAMFILES", ""))
            / "BraveSoftware"
            / "Brave-Browser"
            / "Application"
            / "brave.exe"
        ),
        (
            Path(os.environ.get("PROGRAMFILES(X86)", ""))
            / "BraveSoftware"
            / "Brave-Browser"
            / "Application"
            / "brave.exe"
        ),
        (
            Path(os.environ.get("LOCALAPPDATA", ""))
            / "BraveSoftware"
            / "Brave-Browser"
            / "Application"
            / "brave.exe"
        ),
    ]

    for path in candidatos:
        if path.exists():
            return path

    raise FileNotFoundError("No se encontró brave.exe automáticamente.")


# ==============================================================================
# 4. REGISTRO Y PARTIDOS DE LA COMPETICIÓN
# ==============================================================================

def load_registry() -> dict[str, Any]:
    registry = read_json(REGISTRY_PATH)

    if not isinstance(registry.get("competitions"), list):
        raise ValueError(
            "competitions.json no contiene una lista 'competitions'."
        )

    return registry


def find_competition(
    registry: dict[str, Any],
    key: str,
) -> dict[str, Any]:
    normalized = slugify(key)

    for competition in registry["competitions"]:
        current = slugify(str(competition.get("key", "")))

        if current == normalized:
            return competition

    raise ValueError(f"No existe la competición '{key}'.")


def competition_family(name: str, key: str = "") -> tuple[str, str]:
    """Clasifica el contexto sin mezclar copas UEFA y ligas domésticas."""

    value = slugify(f"{key} {name}")
    if any(token in value for token in ("champions", "conference", "europa-league")):
        return "UEFA", "UEFA_PRIMARY"
    if any(token in value for token in ("sudamericana", "libertadores")):
        return "CONMEBOL", "INTERNATIONAL_PRIMARY"
    return "DOMESTIC", "PRIMARY_COMPETITION"


def validar_evento_competicion(
    event_json: dict[str, Any] | None,
    competition: dict[str, Any],
    match: dict[str, Any] | None = None,
) -> None:
    """Valida torneo y temporada sin bloquear los respaldos por un fallo temporal.

    La fuente preferida sigue siendo el JSON real del evento de SofaScore. Si
    ese endpoint no responde, se permite continuar únicamente cuando el
    inventario ``matches_finished.json`` ya contiene ``competition_id`` y
    ``season_id`` y ambos coinciden exactamente con el registro activo.
    """

    require_competition = bool(competition.get("same_competition_only"))
    require_season = bool(competition.get("current_season_only"))
    if not (require_competition or require_season):
        return

    expected_tournament = competition.get("source_competition_id")
    expected_season = competition.get("season_id")

    if require_competition and expected_tournament is None:
        raise ValueError(
            "source_competition_id no está resuelto para esta competición."
        )
    if require_season and expected_season is None:
        raise ValueError(
            "season_id actual aún no fue resuelto para esta competición."
        )

    if isinstance(event_json, dict):
        event = event_json.get("event", event_json)
        if not isinstance(event, dict):
            raise ValueError("El JSON no contiene un evento validable.")

        tournament = event.get("tournament", {})
        if not isinstance(tournament, dict):
            tournament = {}
        unique = tournament.get("uniqueTournament", {})
        if not isinstance(unique, dict):
            unique = {}

        actual_tournament = unique.get("id") or tournament.get("id")
        actual_season = (
            event.get("season", {}).get("id")
            if isinstance(event.get("season"), dict)
            else None
        )
        validation_source = "SofaScore event JSON"
    else:
        if not isinstance(match, dict):
            raise ValueError(
                "No hay JSON de evento ni inventario del partido para validar "
                "competición y temporada."
            )

        actual_tournament = (
            match.get("competition_id")
            or match.get("source_competition_id")
        )
        actual_season = match.get("season_id")
        validation_source = "matches_finished.json"

        if require_competition and actual_tournament is None:
            raise ValueError(
                "SofaScore no devolvió el evento y el inventario no contiene "
                "competition_id; no se continúa por seguridad."
            )
        if require_season and actual_season is None:
            raise ValueError(
                "SofaScore no devolvió el evento y el inventario no contiene "
                "season_id; no se continúa por seguridad."
            )

    if require_competition and int(actual_tournament or 0) != int(
        expected_tournament or 0
    ):
        raise ValueError(
            "Evento rechazado por tournament_id: "
            f"esperado={expected_tournament}, actual={actual_tournament}, "
            f"fuente={validation_source}."
        )

    if require_season and int(actual_season or 0) != int(expected_season):
        raise ValueError(
            "Evento rechazado por season_id: "
            f"esperado={expected_season}, actual={actual_season}, "
            f"fuente={validation_source}."
        )

    if not isinstance(event_json, dict):
        event_id = match.get("event_id") if isinstance(match, dict) else "N/D"
        print(
            "   ℹ️ SofaScore no devolvió el JSON del evento; "
            "tournament_id y season_id fueron validados de forma estricta "
            f"con matches_finished.json. event_id={event_id}"
        )


def cargar_partidos_competicion(
    competition: dict[str, Any],
) -> tuple[list[dict[str, Any]], Path]:
    key = slugify(str(competition["key"]))
    path = COMPETITIONS_DIR / key / "matches_finished.json"
    data = read_json(path)
    matches = data.get("matches")

    if not isinstance(matches, list):
        raise ValueError(
            f"{path.name} no contiene una lista 'matches'."
        )

    unique: dict[int, dict[str, Any]] = {}

    for match in matches:
        if not isinstance(match, dict):
            continue

        try:
            event_id = int(match["event_id"])
        except (KeyError, TypeError, ValueError):
            continue

        if bool(competition.get("same_competition_only")):
            try:
                match_competition_id = int(match.get("competition_id"))
            except (TypeError, ValueError):
                continue
            if match_competition_id != int(
                competition["source_competition_id"]
            ):
                continue

        if bool(competition.get("current_season_only")):
            try:
                match_season_id = int(match.get("season_id"))
            except (TypeError, ValueError):
                continue
            if match_season_id != int(competition["season_id"]):
                continue

        normalized = dict(match)
        normalized["event_id"] = event_id
        normalized["_competition_key"] = key
        normalized["_competition_country"] = str(
            competition.get("country") or ""
        )
        normalized["_registry_name"] = str(
            competition.get("name") or ""
        )
        normalized["_registry_season"] = str(
            competition.get("season_name") or ""
        )
        normalized["_registry_tournament_id"] = int(
            competition.get("source_competition_id") or 0
        )
        normalized["_registry_season_id"] = int(
            competition.get("season_id") or match.get("season_id") or 0
        )

        unique[event_id] = normalized

    ordered = sorted(
        unique.values(),
        key=lambda item: (
            int(item.get("start_timestamp") or 0),
            int(item["event_id"]),
        ),
    )

    return ordered, path


# ==============================================================================
# 5. ESTADO EN SQLITE
# ==============================================================================



# ==============================================================================
# ODDSHUNTER_J1_FULL_REQUIRES_GOALS_V2866
# ==============================================================================
_OH_J1_KEYS_V2866 = {
    "j1-league",
    "domestic-context-196-87931",
    "domestic-context-196-69871",
    "domestic-context-402-70418",
}


def _oh_j1_quality_with_goals_v2866(
    quality: str,
    event: dict[str, Any],
) -> str:
    key = slugify(str(event.get("competition_key") or ""))
    if key not in _OH_J1_KEYS_V2866:
        return quality
    if event.get("home_goals") is None or event.get("away_goals") is None:
        return "PARTIAL"
    return quality


# ODDSHUNTER_J1_FULL_STRICT_V2867
def partido_estado_sqlite(
    event_id: int,
    competition_key: str | None = None,
) -> str:
    """
    NONE: no existe o no tiene exactamente dos filas.
    PARTIAL: dos filas, pero J1 aún no está completo.
    FULL: dos filas completas.

    J1 V2.8.6.7 replica el criterio core-complete del flujo J1:
    goals_for, goals_against, xg_for, xg_against, shots,
    corners_for, corners_against, yellow_cards y data_quality=FULL.

    Las demás competiciones conservan el criterio anterior.
    """
    j1_keys = {
        "j1-league",
        "domestic-context-196-87931",
        "domestic-context-196-69871",
        "domestic-context-402-70418",
    }
    strict_j1 = slugify(str(competition_key or "")) in j1_keys

    conn = get_connection()
    try:
        row = conn.execute(
            """
            SELECT
                COUNT(s.stat_id) AS total_rows,
                SUM(
                    CASE
                        WHEN s.data_quality = 'FULL'
                         AND s.xg_for IS NOT NULL
                         AND s.shots IS NOT NULL
                         AND s.corners_for IS NOT NULL
                         AND s.yellow_cards IS NOT NULL
                         AND (
                             ? = 0
                             OR (
                                 s.goals_for IS NOT NULL
                                 AND s.goals_against IS NOT NULL
                                 AND s.xg_against IS NOT NULL
                                 AND s.corners_against IS NOT NULL
                             )
                         )
                        THEN 1
                        ELSE 0
                    END
                ) AS full_rows
            FROM matches AS m
            LEFT JOIN team_match_stats AS s
              ON s.match_id = m.match_id
            WHERE m.sofascore_id = ?;
            """,
            (1 if strict_j1 else 0, event_id),
        ).fetchone()

        total_rows = int(row["total_rows"] or 0) if row else 0
        full_rows = int(row["full_rows"] or 0) if row else 0

        if total_rows == 2 and full_rows == 2:
            return "FULL"
        if total_rows == 2:
            return "PARTIAL"
        return "NONE"
    finally:
        conn.close()


# ==============================================================================
# 6. PARSEO DE ESTADÍSTICAS
# ==============================================================================

def convertir_numero(value: Any) -> int | float | None:
    if value is None:
        return None

    if isinstance(value, bool):
        return int(value)

    if isinstance(value, (int, float)):
        return value

    text = str(value).strip().replace(",", ".")
    match = re.search(r"-?\d+(?:\.\d+)?", text)

    if not match:
        return None

    number = float(match.group())
    return int(number) if number.is_integer() else number


def match_score(score: dict[str, Any] | None) -> Any:
    """Usa el marcador visible del partido y excluye la tanda de penaltis."""

    values = score if isinstance(score, dict) else {}
    for key in ("display", "normaltime", "current"):
        value = values.get(key)
        if value is not None:
            return value
    return None


def normalizar_estado(event: dict[str, Any] | None) -> str:
    if not event:
        return "FT"

    kind = str(
        event.get("status", {}).get("type", "finished")
    ).lower()

    mapping = {
        "notstarted": "NS",
        "inprogress": "LIVE",
        "paused": "LIVE",
        "finished": "FT",
        "postponed": "POSTPONED",
        "canceled": "CANCELED",
        "cancelled": "CANCELED",
    }

    return mapping.get(kind, kind.upper())


def extraer_items(
    stats_json: dict[str, Any],
) -> dict[str, tuple[Any, Any]]:
    periods = stats_json.get("statistics", [])

    if not isinstance(periods, list):
        return {}

    full_period: dict[str, Any] | None = None

    for period in periods:
        if (
            isinstance(period, dict)
            and str(period.get("period", "")).upper() == "ALL"
        ):
            full_period = period
            break

    if full_period is None:
        for period in periods:
            if isinstance(period, dict):
                full_period = period
                break

    if full_period is None:
        return {}

    result: dict[str, tuple[Any, Any]] = {}

    for group in full_period.get("groups", []):
        if not isinstance(group, dict):
            continue

        for item in group.get("statisticsItems", []):
            if not isinstance(item, dict):
                continue

            name = str(item.get("name", "")).strip().lower()

            if not name:
                continue

            home = item.get("home")
            if home is None:
                home = item.get("homeValue")

            away = item.get("away")
            if away is None:
                away = item.get("awayValue")

            result[name] = (home, away)

    return result



def normalizar_nombre_estadistica(value: Any) -> str:
    text = unicodedata.normalize(
        "NFKD",
        str(value or "").casefold(),
    )
    text = "".join(
        character
        for character in text
        if not unicodedata.combining(character)
    )
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return " ".join(text.split())


def buscar_estadistica(
    items: dict[str, tuple[Any, Any]],
    names: tuple[str, ...],
) -> tuple[int | float | None, int | float | None]:
    normalized_items = {
        normalizar_nombre_estadistica(key): value
        for key, value in items.items()
    }

    normalized_names = [
        normalizar_nombre_estadistica(name)
        for name in names
    ]

    for name in normalized_names:
        value = normalized_items.get(name)

        if value is not None:
            home, away = value
            return convertir_numero(home), convertir_numero(away)

    # SofaScore cambia ocasionalmente el texto visible de una métrica.
    # Esta comparación permite variantes como "Expected goals (xG)".
    for expected_name in normalized_names:
        # Un alias genérico de una palabra (por ejemplo "Shots") nunca
        # puede capturar otra fila distinta como "Shots on target".
        if len(expected_name.split()) < 2:
            continue
        for current_name, value in normalized_items.items():
            if len(current_name.split()) < 2:
                continue
            if (
                expected_name
                and (
                    expected_name in current_name
                    or current_name in expected_name
                )
            ):
                home, away = value
                return convertir_numero(home), convertir_numero(away)

    return None, None


def extraer_xg_desde_shotmap(
    shotmap_json: dict[str, Any] | None,
    home_team_id: int | None,
    away_team_id: int | None,
) -> tuple[float | None, float | None]:
    if not isinstance(shotmap_json, dict):
        return None, None

    shots = (
        shotmap_json.get("shotmap")
        or shotmap_json.get("shots")
        or shotmap_json.get("events")
    )

    if not isinstance(shots, list):
        return None, None

    home_total = 0.0
    away_total = 0.0
    home_seen = False
    away_seen = False

    for shot in shots:
        if not isinstance(shot, dict):
            continue

        xg_value = convertir_numero(
            shot.get("xg")
            if shot.get("xg") is not None
            else shot.get("expectedGoals")
        )

        if xg_value is None:
            xg_value = convertir_numero(
                shot.get("expected_goals")
            )

        if xg_value is None:
            continue

        is_home = shot.get("isHome")
        team_id_value = (
            shot.get("teamId")
            or (
                shot.get("team", {}).get("id")
                if isinstance(shot.get("team"), dict)
                else None
            )
        )

        try:
            team_id = (
                int(team_id_value)
                if team_id_value is not None
                else None
            )
        except (TypeError, ValueError):
            team_id = None

        if isinstance(is_home, bool):
            if is_home:
                home_total += float(xg_value)
                home_seen = True
            else:
                away_total += float(xg_value)
                away_seen = True
            continue

        if (
            team_id is not None
            and home_team_id is not None
            and team_id == int(home_team_id)
        ):
            home_total += float(xg_value)
            home_seen = True
        elif (
            team_id is not None
            and away_team_id is not None
            and team_id == int(away_team_id)
        ):
            away_total += float(xg_value)
            away_seen = True

    if not home_seen and not away_seen:
        return None, None

    # Si un equipo no aparece en el mapa, significa que no tuvo remates
    # con valor xG publicado.
    return (
        round(home_total, 3) if home_seen else 0.0,
        round(away_total, 3) if away_seen else 0.0,
    )


def _periodo_total_estadisticas(
    stats_json: dict[str, Any],
) -> dict[str, Any]:
    periods = stats_json.setdefault("statistics", [])

    if not isinstance(periods, list):
        periods = []
        stats_json["statistics"] = periods

    for period in periods:
        if (
            isinstance(period, dict)
            and str(period.get("period") or "").upper() == "ALL"
        ):
            period.setdefault("groups", [])
            return period

    period = {
        "period": "ALL",
        "groups": [],
    }
    periods.insert(0, period)
    return period


def _agregar_estadistica(
    stats_json: dict[str, Any],
    name: str,
    home: Any,
    away: Any,
) -> None:
    period = _periodo_total_estadisticas(stats_json)
    groups = period.setdefault("groups", [])

    if not isinstance(groups, list):
        groups = []
        period["groups"] = groups

    target_group: dict[str, Any] | None = None

    for group in groups:
        if (
            isinstance(group, dict)
            and isinstance(group.get("statisticsItems"), list)
        ):
            target_group = group
            break

    if target_group is None:
        target_group = {
            "groupName": "Datos derivados de SofaScore",
            "statisticsItems": [],
        }
        groups.append(target_group)

    target_group["statisticsItems"].append(
        {
            "name": name,
            "home": home,
            "away": away,
            "homeValue": home,
            "awayValue": away,
        }
    )


def completar_xg_desde_shotmap(
    stats_json: dict[str, Any],
    shotmap_json: dict[str, Any] | None,
    home_team_id: int | None,
    away_team_id: int | None,
) -> tuple[dict[str, Any], bool]:
    items = extraer_items(stats_json)
    current_home, current_away = buscar_estadistica(
        items,
        (
            "Expected goals",
            "Expected goals (xG)",
            "xG",
            "Goles esperados",
            "Golos esperados",
        ),
    )

    if current_home is not None and current_away is not None:
        return stats_json, False

    shotmap_home, shotmap_away = extraer_xg_desde_shotmap(
        shotmap_json,
        home_team_id,
        away_team_id,
    )

    if shotmap_home is None or shotmap_away is None:
        return stats_json, False

    _agregar_estadistica(
        stats_json,
        "Expected goals",
        shotmap_home,
        shotmap_away,
    )
    return stats_json, True


def _optional_int(value: Any) -> int | None:
    try:
        return int(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _sofascore_xg_source(
    stats_json: dict[str, Any],
) -> StaticXGSource:
    items = extraer_items(stats_json)
    xg_home, xg_away = buscar_estadistica(
        items,
        (
            "Expected goals",
            "Expected goals (xG)",
            "xG",
            "Goles esperados",
            "Golos esperados",
        ),
    )
    direct = (
        DirectXG(
            home=float(xg_home),
            away=float(xg_away),
            details={
                "origin": (
                    "SofaScore statistics or shotmap"
                )
            },
        )
        if xg_home is not None and xg_away is not None
        else None
    )

    total_home, total_away = buscar_estadistica(
        items,
        (
            "Total shots",
            "Shots",
            "Remates",
            "Remates totales",
            "Chutes totais",
            "Finalizações",
        ),
    )
    target_home, target_away = buscar_estadistica(
        items,
        (
            "Shots on target",
            "Shots on goal",
            "Remates a puerta",
            "Remates al arco",
            "Chutes no gol",
        ),
    )
    off_home, off_away = buscar_estadistica(
        items,
        (
            "Shots off target",
            "Shots off goal",
            "Remates fuera",
            "Remates desviados",
            "Chutes para fora",
        ),
    )
    blocked_home, blocked_away = buscar_estadistica(
        items,
        (
            "Blocked shots",
            "Remates bloqueados",
            "Tiros bloqueados",
            "Chutes bloqueados",
        ),
    )
    aggregate = None
    if (
        total_home is not None
        and total_away is not None
        and target_home is not None
        and target_away is not None
    ):
        aggregate = MatchAggregateStats(
            home=AggregateStats(
                total_shots=total_home,
                shots_on_target=target_home,
                shots_off_target=off_home,
                blocked_shots=blocked_home,
            ),
            away=AggregateStats(
                total_shots=total_away,
                shots_on_target=target_away,
                shots_off_target=off_away,
                blocked_shots=blocked_away,
            ),
            details={"origin": "SofaScore aggregate statistics"},
        )
    # ODDSHUNTER_FALSE_ZERO_XG_USE_AGGREGATE_V1_V55
    # Misma regla que MLS: si el supuesto xG directo es 0-0 pero hubo
    # remates y existe aggregate, no aceptar ese 0-0 como xG real.
    # recover_xg() seguirá con ESTE MISMO source y ejecutará aggregate_v1.
    if (
        direct is not None
        and float(direct.home) == 0.0
        and float(direct.away) == 0.0
        and aggregate is not None
        and (
            float(total_home or 0.0)
            + float(total_away or 0.0)
        ) > 0.0
    ):
        direct = None

    # ODDSHUNTER_XG_REAL_FALSE_ZERO_R2
    # Rechaza solo el xG directo 0-0 cuando hay evidencia real de remates.
    # El pipeline existente continúa con aggregate/Futbol24/Flashscore.
    if (
        direct is not None
        and float(direct.home) == 0.0
        and float(direct.away) == 0.0
        and aggregate is not None
    ):
        _oh_evidence = (
            aggregate.home.total_shots,
            aggregate.away.total_shots,
            aggregate.home.shots_on_target,
            aggregate.away.shots_on_target,
        )
        if any(
            value is not None and float(value) > 0.0
            for value in _oh_evidence
        ):
            direct = None

    return StaticXGSource(
        "sofascore",
        direct=direct,
        aggregate=aggregate,
    )


def _match_reference(
    match: dict[str, Any],
    event_json: dict[str, Any] | None,
) -> MatchRef:
    event = obtener_datos_evento(match, event_json)
    return MatchRef(
        match_id=None,
        kickoff=str(event["kickoff"]),
        home_team=str(event["home_name"]),
        away_team=str(event["away_name"]),
        competition=str(event["league_name"]),
        season=str(event["season"]),
        sofascore_event_id=int(event["event_id"]),
        competition_id=_optional_int(
            match.get("source_competition_id")
            or match.get("_registry_tournament_id")
        ),
        season_id=_optional_int(
            match.get("season_id")
            or match.get("_registry_season_id")
        ),
        home_goals=event.get("home_goals"),
        away_goals=event.get("away_goals"),
        flashscore_url=(
            str(match.get("flashscore_url"))
            if match.get("flashscore_url")
            else None
        ),
    )


def recuperar_xg_partido(
    match: dict[str, Any],
    event_json: dict[str, Any] | None,
    stats_json: dict[str, Any],
    futbol24_client: Futbol24Client | None,
    flashscore_client: FlashscoreXGClient | None,
    raw_dir: Path | None = None,
) -> XGResult:
    event = obtener_datos_evento(match, event_json)
    reference = _match_reference(match, event_json)
    sources: list[Any] = [_sofascore_xg_source(stats_json)]
    if futbol24_client is not None:
        sources.append(futbol24_client)
    if flashscore_client is not None:
        sources.append(flashscore_client)

    result = recover_xg(reference, sources)
    if raw_dir is not None:
        write_json(
            raw_dir / f"xg_{event['event_id']}.json",
            {
                "match": {
                    "event_id": event["event_id"],
                    "competition": event["league_name"],
                    "season": event["season"],
                    "kickoff": event["kickoff"],
                    "home_team": event["home_name"],
                    "away_team": event["away_name"],
                },
                "result": result.to_dict(),
            },
        )
    return result


def recuperar_metricas_partido(
    match: dict[str, Any],
    event_json: dict[str, Any] | None,
    stats_json: dict[str, Any],
    futbol24_client: Futbol24Client | None,
    flashscore_client: FlashscoreXGClient | None,
    raw_dir: Path | None = None,
) -> MatchStatsResult:
    """Completa todas las métricas guardadas campo por campo."""

    event = obtener_datos_evento(match, event_json)
    items = extraer_items(stats_json)
    primary = {
        "shots": MetricPair(
            *buscar_estadistica(
                items,
                (
                    "Total shots",
                    "Shots",
                    "Remates",
                    "Remates totales",
                    "Chutes totais",
                    "Finalizações",
                ),
            )
        ),
        "shots_on_target": MetricPair(
            *buscar_estadistica(
                items,
                (
                    "Shots on target",
                    "Shots on goal",
                    "Remates a puerta",
                    "Remates al arco",
                    "Chutes no gol",
                ),
            )
        ),
        "corners": MetricPair(
            *buscar_estadistica(
                items,
                (
                    "Corner kicks",
                    "Corners",
                    "Córners",
                    "Tiros de esquina",
                    "Escanteios",
                ),
            )
        ),
        "yellow_cards": MetricPair(
            *buscar_estadistica(
                items,
                (
                    "Yellow cards",
                    "Tarjetas amarillas",
                    "Cartões amarelos",
                    "Cartoes amarelos",
                ),
            )
        ),
        "red_cards": MetricPair(
            *buscar_estadistica(
                items,
                ("Red cards", "Tarjetas rojas", "Cartões vermelhos"),
            )
        ),
    }
    primary["possession"] = MetricPair(
        *buscar_estadistica(
            items,
            ("Ball possession", "Possession", "Posesión del balón"),
        )
    )
    primary["fouls"] = MetricPair(
        *buscar_estadistica(
            items,
            ("Fouls", "Fouls committed", "Faltas"),
        )
    )
    primary["offsides"] = MetricPair(
        *buscar_estadistica(
            items,
            ("Offsides", "Fueras de juego"),
        )
    )
    primary["big_chances"] = MetricPair(
        *buscar_estadistica(
            items,
            ("Big chances", "Grandes ocasiones", "Grandes oportunidades"),
        )
    )
    sources: list[Any] = []
    if futbol24_client is not None:
        sources.append(futbol24_client)
    if flashscore_client is not None:
        sources.append(flashscore_client)
    result = recover_match_stats(
        _match_reference(match, event_json),
        primary,
        sources,
    )
    if raw_dir is not None:
        write_json(
            raw_dir / f"real_stats_{event['event_id']}.json",
            {
                "match": {
                    "event_id": event["event_id"],
                    "competition": event["league_name"],
                    "season": event["season"],
                    "kickoff": event["kickoff"],
                    "home_team": event["home_name"],
                    "away_team": event["away_name"],
                },
                "result": result.to_dict(),
            },
        )
    return result




# ODDSHUNTER_YELLOW_ZERO_FIX_V23_HELPER

def _oh_yellow_zero_token(value):
    return "".join(
        ch
        for ch in str(value or "").strip().lower()
        if ch.isalnum()
    )


def _oh_yellow_zero_finished(event_json, normalized_event):

    for candidate in (event_json, normalized_event):

        if not isinstance(candidate, dict):
            continue

        event = candidate.get("event", candidate)

        if not isinstance(event, dict):
            continue

        status = event.get("status")

        if isinstance(status, str):
            if status.strip().upper() in {
                "FT",
                "AET",
                "PEN",
                "FINISHED",
                "ENDED",
            }:
                return True

        if isinstance(status, dict):

            token = _oh_yellow_zero_token(
                status.get("type")
            )

            if token in {
                "finished",
                "ended",
                "afterextratime",
                "afterpenalties",
            }:
                return True

            try:
                if int(status.get("code")) == 100:
                    return True
            except Exception:
                pass

    return False


def _oh_yellow_zero_full_period(stats_json):

    if not isinstance(stats_json, dict):
        return None

    periods = stats_json.get("statistics")

    if not isinstance(periods, list):
        return None

    for period in periods:

        if (
            isinstance(period, dict)
            and
            str(period.get("period", "")).strip().upper() == "ALL"
        ):
            return period

    return None


def _oh_yellow_zero_resolve(
    event_json,
    normalized_event,
    stats_json,
    current_home,
    current_away,
):

    # Ya tenemos ambos valores.
    # Incluye 0-0, 0-2, 2-0, etc.
    if (
        current_home is not None
        and
        current_away is not None
    ):
        return (
            current_home,
            current_away,
            False,
            "already_available",
        )

    full = _oh_yellow_zero_full_period(
        stats_json
    )

    if full is None:
        return (
            current_home,
            current_away,
            False,
            "no_all_period",
        )

    groups = full.get("groups", [])

    if not isinstance(groups, list):
        return (
            current_home,
            current_away,
            False,
            "invalid_groups",
        )

    yellow_found = False
    explicit_home = None
    explicit_away = None

    anchors = set()

    for group in groups:

        if not isinstance(group, dict):
            continue

        items = group.get(
            "statisticsItems",
            []
        )

        if not isinstance(items, list):
            continue

        for item in items:

            if not isinstance(item, dict):
                continue

            name_token = _oh_yellow_zero_token(
                item.get("name")
            )

            key_token = _oh_yellow_zero_token(
                item.get("key")
            )

            tokens = {
                name_token,
                key_token,
            }

            # --------------------------------------------------------------
            # Amarillas: name o key canónica.
            # --------------------------------------------------------------

            if (
                "yellowcards" in tokens
                or
                "yellowcard" in tokens
            ):

                yellow_found = True

                h = item.get("home")
                if h is None:
                    h = item.get("homeValue")

                a = item.get("away")
                if a is None:
                    a = item.get("awayValue")

                explicit_home = convertir_numero(h)
                explicit_away = convertir_numero(a)

            # --------------------------------------------------------------
            # Anclas para saber si ALL realmente está completo.
            # --------------------------------------------------------------

            for token in tokens:

                if not token:
                    continue

                if token in {
                    "expectedgoals",
                    "expectedgoalsxg",
                    "xg",
                }:
                    anchors.add("xg")

                if token in {
                    "totalshots",
                    "totalshotsongoal",
                    "shots",
                    "remates",
                    "rematestotales",
                }:
                    anchors.add("shots")

                if token in {
                    "shotsontarget",
                    "shotsongoal",
                    "rematesapuerta",
                    "rematesalarco",
                }:
                    anchors.add("sot")

                if token in {
                    "cornerkicks",
                    "corners",
                    "tirosdeesquina",
                    "escanteios",
                }:
                    anchors.add("corners")

                if token in {
                    "ballpossession",
                    "possession",
                    "posesion",
                }:
                    anchors.add("possession")

                if token in {
                    "fouls",
                    "foulscommitted",
                    "faltas",
                }:
                    anchors.add("fouls")

                if token in {
                    "offsides",
                    "fuerasdejuego",
                }:
                    anchors.add("offsides")

                if token in {
                    "bigchances",
                    "grandesoportunidades",
                }:
                    anchors.add("big_chances")

    # La fila existe.
    # 0 sigue siendo 0.
    # NULL explícito sigue NULL.
    if yellow_found:

        return (
            current_home
            if current_home is not None
            else explicit_home,

            current_away
            if current_away is not None
            else explicit_away,

            False,
            "explicit_yellow_row",
        )

    # No inferir en vivo.
    if not _oh_yellow_zero_finished(
        event_json,
        normalized_event,
    ):
        return (
            current_home,
            current_away,
            False,
            "not_finished",
        )

    base_three = {
        "shots",
        "sot",
        "corners",
    }.issubset(anchors)

    strong = (
        base_three
        and
        "xg" in anchors
    )

    rich = (
        base_three
        and
        len(anchors) >= 5
    )

    if not (strong or rich):

        return (
            current_home,
            current_away,
            False,
            "insufficient_stats",
        )

    # Fila Yellow completamente ausente,
    # partido terminado,
    # bloque ALL suficientemente completo.
    return (
        0 if current_home is None else current_home,
        0 if current_away is None else current_away,
        True,
        "zero_by_omission",
    )


def obtener_datos_evento(
    match: dict[str, Any],
    event_json: dict[str, Any] | None,
) -> dict[str, Any]:
    event: dict[str, Any] | None = None

    if isinstance(event_json, dict):
        possible = event_json.get("event", event_json)

        if isinstance(possible, dict):
            event = possible

    timestamp = int(match.get("start_timestamp") or 0)

    if timestamp <= 0:
        raise ValueError(
            f"El evento {match['event_id']} no tiene start_timestamp válido."
        )

    fallback_season = str(
        match.get("season_name")
        or match.get("_registry_season")
        or datetime.fromtimestamp(
            timestamp,
            tz=timezone.utc,
        ).year
    )

    fallback = {
        "event_id": int(match["event_id"]),
        "league_name": str(
            match.get("competition_name")
            or match.get("_registry_name")
            or "Competition"
        ),
        "country": str(
            match.get("_competition_country")
            or ""
        ),
        "season": fallback_season,
        "kickoff": datetime.fromtimestamp(
            timestamp,
            tz=timezone.utc,
        ).isoformat(),
        "home_sofascore_id": int(match["home_team_id"]),
        "home_name": str(match["home_team"]),
        "away_sofascore_id": int(match["away_team_id"]),
        "away_name": str(match["away_team"]),
        "home_goals": convertir_numero(match.get("home_goals")),
        "away_goals": convertir_numero(match.get("away_goals")),
        "status": "FT",
        "competition_key": str(match.get("_competition_key") or ""),
        "tournament_id": _optional_int(
            match.get("competition_id")
            or match.get("source_competition_id")
            or match.get("_registry_tournament_id")
        ),
        "season_id": _optional_int(
            match.get("season_id")
            or match.get("_registry_season_id")
        ),
        "round": str(match.get("round") or match.get("phase") or "") or None,
    }

    if event is None:
        return fallback

    tournament = event.get("tournament", {})
    unique_tournament = tournament.get("uniqueTournament", {})
    if not isinstance(unique_tournament, dict):
        unique_tournament = {}
    category = tournament.get("category", {})
    season = event.get("season", {})
    home_team = event.get("homeTeam", {})
    away_team = event.get("awayTeam", {})

    event_timestamp = event.get("startTimestamp")
    if not isinstance(event_timestamp, int):
        event_timestamp = timestamp

    home_goals = convertir_numero(match_score(event.get("homeScore")))
    away_goals = convertir_numero(match_score(event.get("awayScore")))

    return {
        "event_id": int(event.get("id") or fallback["event_id"]),
        "league_name": str(
            tournament.get("uniqueTournament", {}).get("name")
            or tournament.get("name")
            or fallback["league_name"]
        ),
        "country": str(
            category.get("name")
            or fallback["country"]
        ),
        "season": str(
            season.get("name")
            or fallback["season"]
        ),
        "kickoff": datetime.fromtimestamp(
            event_timestamp,
            tz=timezone.utc,
        ).isoformat(),
        "home_sofascore_id": int(
            home_team.get("id")
            or fallback["home_sofascore_id"]
        ),
        "home_name": str(
            home_team.get("name")
            or fallback["home_name"]
        ),
        "away_sofascore_id": int(
            away_team.get("id")
            or fallback["away_sofascore_id"]
        ),
        "away_name": str(
            away_team.get("name")
            or fallback["away_name"]
        ),
        "home_goals": (
            home_goals
            if home_goals is not None
            else fallback["home_goals"]
        ),
        "away_goals": (
            away_goals
            if away_goals is not None
            else fallback["away_goals"]
        ),
        "status": normalizar_estado(event),
        "competition_key": fallback["competition_key"],
        "tournament_id": _optional_int(
            unique_tournament.get("id")
            or tournament.get("id")
            or fallback["tournament_id"]
        ),
        "season_id": _optional_int(
            season.get("id") or fallback["season_id"]
        ),
        "round": str(
            event.get("roundInfo", {}).get("name")
            or event.get("roundInfo", {}).get("round")
            or fallback["round"]
            or ""
        ) or None,
    }


# ==============================================================================
# 7. NAVEGACIÓN Y CAPTURA
# ==============================================================================

def detectar_bloqueo(page: Page) -> None:
    try:
        text = page.locator("body").inner_text(timeout=8_000).lower()
    except Exception:
        return

    markers = (
        "verify you are human",
        "verification required",
        "just a moment",
        "captcha",
        "comprobando si la conexión del sitio es segura",
    )

    if any(marker in text for marker in markers):
        raise RuntimeError(
            "SofaScore mostró una verificación. "
            "El proceso se detuvo; no se intenta superarla."
        )


def abrir_pestana_estadisticas(page: Page) -> bool:
    """Intenta abrir Statistics sin convertir su ausencia en fallo.

    SofaScore no publica esta pestaña para todos los encuentros. Encontrar el
    evento no implica que existan estadísticas visuales. El llamador debe
    continuar con Futbol24 y Flashscore cuando esta función devuelve
    ``False``.
    """
    patterns = (
        re.compile(r"^Statistics$", re.IGNORECASE),
        re.compile(r"^Estadísticas$", re.IGNORECASE),
        re.compile(r"^Estadisticas$", re.IGNORECASE),
    )

    for pattern in patterns:
        locators = [
            page.get_by_role("tab", name=pattern),
            page.get_by_role("button", name=pattern),
            page.get_by_role("link", name=pattern),
            page.get_by_text(pattern, exact=True),
        ]

        for locator in locators:
            try:
                count = locator.count()
            except Exception:
                continue

            for index in range(count):
                element = locator.nth(index)

                try:
                    if not element.is_visible():
                        continue

                    element.scroll_into_view_if_needed(timeout=8_000)
                    element.click(timeout=12_000)
                    page.wait_for_timeout(3_000)
                    return True
                except Exception:
                    continue

    return False





# ==============================================================================
# ODDSHUNTER_SOFASCORE_VISUAL_EXACT_V2864
# ÚNICO objetivo: detectar el error frontend de SofaScore inmediatamente
# después de page.goto/page.reload de capturar_json_partido().
# ==============================================================================
_OH_SS_CLIENT_ERROR_TEXT_V2864 = (
    "application error: a client-side exception has occurred"
)


def _oh_ss_has_client_error_v2864(page):
    try:
        url = str(getattr(page, "url", "") or "")
        if "sofascore.com" not in url.casefold():
            return False

        text = page.locator("body").inner_text(timeout=1800)
        return _OH_SS_CLIENT_ERROR_TEXT_V2864 in str(text or "").casefold()
    except Exception:
        return False


def _oh_ss_clear_only_visual_page_v2864(page):
    try:
        page.goto(
            "about:blank",
            wait_until="commit",
            timeout=1500,
        )
    except Exception:
        pass


def _oh_ss_visual_navigation_v2864(page, action):
    """
    Ejecuta la navegación original sin cambiar su resultado.

    Si la navegación termina en el error visual conocido de SofaScore,
    limpia SOLO esa pestaña y lanza RuntimeError. El except que YA existe
    en capturar_json_partido lo captura y continúa con Futbol24 /
    Flashscore exactamente como antes.
    """
    result = action()

    if _oh_ss_has_client_error_v2864(page):
        _oh_ss_clear_only_visual_page_v2864(page)
        raise RuntimeError(
            "SOFASCORE_CLIENT_SIDE_APPLICATION_ERROR: "
            "frontend visual detectado; continuar con respaldos."
        )

    return result


def capturar_json_partido(
    page: Page,
    match: dict[str, Any],
    raw_dir: Path,
) -> tuple[dict[str, Any] | None, dict[str, Any]]:
    event_id = int(match["event_id"])
    url = str(match.get("url") or "").strip()

    captured: dict[str, dict[str, Any] | None] = {
        "event": None,
        "statistics": None,
        "shotmap": None,
    }

    def process_response(response: Response) -> None:
        if response.status != 200:
            return

        response_url = response.url.split("?")[0].rstrip("/")

        try:
            data = response.json()
        except Exception:
            return

        if not isinstance(data, dict):
            return

        if response_url.endswith(
            f"/api/v1/event/{event_id}/statistics"
        ):
            captured["statistics"] = data
        elif response_url.endswith(
            f"/api/v1/event/{event_id}/shotmap"
        ):
            captured["shotmap"] = data
        elif response_url.endswith(f"/api/v1/event/{event_id}"):
            captured["event"] = data

    def direct_json(endpoint: str) -> dict[str, Any] | None:
        direct_status = None
        try:
            response = page.context.request.get(
                endpoint,
                timeout=30_000,
                headers={
                    "Accept": "application/json, text/plain, */*",
                    "Referer": "https://www.sofascore.com/",
                },
            )
            try:
                direct_status = int(getattr(response, "status", 0) or 0)
                if response.ok:
                    data = response.json()
                    if isinstance(data, dict):
                        return data
            finally:
                try:
                    response.dispose()
                except Exception:
                    pass
        except Exception:
            pass

        # Recuperación: mismo transporte API por sesión Brave que ya usa OddsHunter.
        try:
            import sync_upcoming_matches as _syncer
            marker = "https://www.sofascore.com"
            path = endpoint
            if path.startswith(marker):
                path = path[len(marker):]
            if not path.startswith("/"):
                path = "/" + path
            status, data = _syncer._browser_fetch_json(page, path)
            if status == 200 and isinstance(data, dict):
                print(
                    "   ✅ SofaScore API recuperada desde sesión Brave "
                    f"(directo={direct_status}, browser=200): {path}"
                )
                return data
            print(
                "   ℹ️ SofaScore API sin datos tras request directo + sesión Brave: "
                f"directo={direct_status}, browser={status}, path={path}"
            )
        except Exception as exc:
            print(
                "   ℹ️ Recuperación SofaScore por sesión Brave falló: "
                f"{type(exc).__name__}: {exc}"
            )
        return None

    # Primero se usan los endpoints directos. Esto evita depender de que
    # la pestaña Statistics se renderice correctamente.
    captured["event"] = direct_json(
        f"https://www.sofascore.com/api/v1/event/{event_id}"
    )
    captured["statistics"] = direct_json(
        f"https://www.sofascore.com/api/v1/event/{event_id}/statistics"
    )
    captured["shotmap"] = direct_json(
        f"https://www.sofascore.com/api/v1/event/{event_id}/shotmap"
    )

    page.on("response", process_response)

    try:
        if captured["statistics"] is None:
            if not url:
                print(
                    f"   ℹ️ El evento {event_id} no tiene URL visual; "
                    "se continúa con Futbol24 y Flashscore."
                )
            else:
                for attempt in range(MAX_RELOADS + 1):
                    try:
                        if attempt == 0:
                            _oh_ss_visual_navigation_v2864(page, lambda: page.goto(
                                url,
                                wait_until="domcontentloaded",
                                timeout=PAGE_TIMEOUT_MS,
                            ))
                        else:
                            _oh_ss_visual_navigation_v2864(page, lambda: page.reload(
                                wait_until="domcontentloaded",
                                timeout=PAGE_TIMEOUT_MS,
                            ))

                        page.wait_for_timeout(4_000)
                        detectar_bloqueo(page)

                        if captured["statistics"] is None:
                            opened = abrir_pestana_estadisticas(page)
                            if not opened:
                                print(
                                    "   ℹ️ SofaScore no publicó la pestaña "
                                    "Statistics; se continúa con las otras "
                                    "fuentes."
                                )
                                break

                        for _ in range(NETWORK_WAIT_SECONDS):
                            if captured["statistics"] is not None:
                                break
                            page.wait_for_timeout(1_000)

                        if captured["statistics"] is not None:
                            break
                    except Exception as exc:
                        # Una pestaña visual ausente, cerrada, bloqueada o con
                        # error de JavaScript no debe abortar el evento ni los
                        # demás partidos. No se intenta superar verificaciones:
                        # se abandona esta fuente y se sigue con las siguientes.
                        print(
                            "   ⚠️ Respaldo visual de SofaScore omitido: "
                            f"{type(exc).__name__}: {exc}"
                        )
                        break

    finally:
        page.remove_listener("response", process_response)

    stats_json = captured["statistics"]

    if not isinstance(stats_json, dict):
        # La ausencia de estadísticas en SofaScore es un resultado válido de
        # la primera fuente, no un error del partido. Un diccionario vacío
        # permite que los pipelines estrictos continúen con Futbol24 y
        # Flashscore campo por campo.
        stats_json = {}

    event_json = captured["event"]
    shotmap_json = captured["shotmap"]

    if event_json is not None and not isinstance(event_json, dict):
        event_json = None

    stats_json, _xg_from_shotmap = completar_xg_desde_shotmap(
        stats_json,
        shotmap_json,
        int(match.get("home_team_id") or 0) or None,
        int(match.get("away_team_id") or 0) or None,
    )

    write_json(
        raw_dir / f"event_{event_id}.json",
        event_json or {},
    )
    write_json(
        raw_dir / f"statistics_{event_id}.json",
        stats_json,
    )
    write_json(
        raw_dir / f"shotmap_{event_id}.json",
        shotmap_json or {},
    )

    return event_json, stats_json




# ==============================================================================
# 7.1 OVERRIDES VERIFICADOS MANUALMENTE
# ==============================================================================

def cargar_overrides_verificados() -> dict[str, Any]:
    """Lee correcciones puntuales verificadas sin inventar valores.

    Solo se aplican cuando el dato real sigue siendo NULL. Un valor obtenido
    de SofaScore, Futbol24 o Flashscore siempre tiene prioridad.
    """

    if not VERIFIED_MATCH_OVERRIDES_PATH.exists():
        return {}

    try:
        data = read_json(VERIFIED_MATCH_OVERRIDES_PATH)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(
            "⚠️ No se pudo leer verified_match_overrides.json: "
            f"{type(exc).__name__}: {exc}"
        )
        return {}

    matches = data.get("matches")
    return matches if isinstance(matches, dict) else {}


def aplicar_overrides_verificados(
    event_id: int,
    *,
    yellow_home: Any,
    yellow_away: Any,
) -> tuple[Any, Any]:
    """Aplica valores confirmados solo sobre campos faltantes."""

    record = cargar_overrides_verificados().get(str(int(event_id)))
    if not isinstance(record, dict):
        return yellow_home, yellow_away

    yellow = record.get("yellow_cards")
    if not isinstance(yellow, dict):
        return yellow_home, yellow_away

    applied = False
    if yellow_home is None and yellow.get("home") is not None:
        yellow_home = convertir_numero(yellow.get("home"))
        applied = True
    if yellow_away is None and yellow.get("away") is not None:
        yellow_away = convertir_numero(yellow.get("away"))
        applied = True

    if applied:
        verification = record.get("verification")
        source = (
            str(verification.get("source") or "manual_verified")
            if isinstance(verification, dict)
            else "manual_verified"
        )
        print(
            "✅ Tarjetas amarillas verificadas aplicadas: "
            f"{yellow_home} - {yellow_away} | event_id={event_id} "
            f"| fuente={source}"
        )

    return yellow_home, yellow_away


# ==============================================================================
# 8. GUARDAR EN SQLITE
# ==============================================================================

def clasificar_calidad_metricas(
    *,
    xg_home: Any,
    xg_away: Any,
    shots_home: Any,
    shots_away: Any,
    corners_home: Any,
    corners_away: Any,
    yellow_home: Any,
    yellow_away: Any,
) -> str:
    """FULL exige xG directo o estimado para ambos equipos."""

    return classify_match_data_quality(
        xg_home=xg_home,
        xg_away=xg_away,
        shots_home=shots_home,
        shots_away=shots_away,
        corners_home=corners_home,
        corners_away=corners_away,
        yellow_home=yellow_home,
        yellow_away=yellow_away,
    )


def guardar_partido(
    match: dict[str, Any],
    event_json: dict[str, Any] | None,
    stats_json: dict[str, Any],
    xg_result: XGResult | None = None,
    real_stats_result: MatchStatsResult | None = None,
) -> tuple[int, str]:
    event = obtener_datos_evento(match, event_json)
    items = extraer_items(stats_json)

    xg_home, xg_away = buscar_estadistica(
        items,
        (
            "Expected goals",
            "Expected goals (xG)",
            "xG",
            "Goles esperados",
            "Golos esperados",
        ),
    )
    if xg_result is not None and xg_result.available:
        xg_home = xg_result.home
        xg_away = xg_result.away
    if xg_result is None:
        xg_source = (
            "sofascore_direct_xg"
            if xg_home is not None and xg_away is not None
            else "unavailable"
        )
        xg_is_estimated = False
        xg_method_version = (
            "direct_v1"
            if xg_source == "sofascore_direct_xg"
            else None
        )
        xg_updated_at = utc_now()
    else:
        xg_source = xg_result.source
        xg_is_estimated = xg_result.is_estimated
        xg_method_version = xg_result.method_version
        xg_updated_at = xg_result.updated_at
    shots_home, shots_away = buscar_estadistica(
        items,
        (
            "Total shots",
            "Shots",
            "Remates",
            "Remates totales",
            "Chutes totais",
            "Finalizações",
        ),
    )
    target_home, target_away = buscar_estadistica(
        items,
        (
            "Shots on target",
            "Shots on goal",
            "Remates a puerta",
            "Remates al arco",
            "Chutes no gol",
        ),
    )
    corners_home, corners_away = buscar_estadistica(
        items,
        (
            "Corner kicks",
            "Corners",
            "Córners",
            "Tiros de esquina",
            "Escanteios",
        ),
    )
    yellow_home, yellow_away = buscar_estadistica(
        items,
        (
            "Yellow cards",
            "Tarjetas amarillas",
            "Cartões amarelos",
            "Cartoes amarelos",
        ),
    )
    red_home, red_away = buscar_estadistica(
        items,
        ("Red cards",),
    )
    possession_home, possession_away = buscar_estadistica(
        items,
        ("Ball possession", "Possession"),
    )
    fouls_home, fouls_away = buscar_estadistica(
        items,
        ("Fouls", "Fouls committed"),
    )
    offsides_home, offsides_away = buscar_estadistica(
        items,
        ("Offsides",),
    )
    big_home, big_away = buscar_estadistica(
        items,
        ("Big chances",),
    )

    if real_stats_result is not None:
        shots_pair = real_stats_result.pair("shots")
        target_pair = real_stats_result.pair("shots_on_target")
        corners_pair = real_stats_result.pair("corners")
        yellow_pair = real_stats_result.pair("yellow_cards")
        red_pair = real_stats_result.pair("red_cards")
        possession_pair = real_stats_result.pair("possession")
        fouls_pair = real_stats_result.pair("fouls")
        offsides_pair = real_stats_result.pair("offsides")
        big_pair = real_stats_result.pair("big_chances")
        if shots_pair.available:
            shots_home, shots_away = shots_pair.home, shots_pair.away
        if target_pair.available:
            target_home, target_away = target_pair.home, target_pair.away
        if corners_pair.available:
            corners_home, corners_away = corners_pair.home, corners_pair.away
        if yellow_pair.available:
            yellow_home, yellow_away = yellow_pair.home, yellow_pair.away
        if red_pair.available:
            red_home, red_away = red_pair.home, red_pair.away
        if possession_pair.available:
            possession_home, possession_away = (
                possession_pair.home,
                possession_pair.away,
            )
        if fouls_pair.available:
            fouls_home, fouls_away = fouls_pair.home, fouls_pair.away
        if offsides_pair.available:
            offsides_home, offsides_away = (
                offsides_pair.home,
                offsides_pair.away,
            )
        if big_pair.available:
            big_home, big_away = big_pair.home, big_pair.away

    yellow_home, yellow_away = aplicar_overrides_verificados(
        int(event["event_id"]),
        yellow_home=yellow_home,
        yellow_away=yellow_away,
    )


    # ODDSHUNTER_YELLOW_ZERO_FIX_V23_RUNTIME
    (
        yellow_home,
        yellow_away,
        yellow_zero_inferred,
        yellow_zero_reason,
    ) = _oh_yellow_zero_resolve(
        event_json,
        event,
        stats_json,
        yellow_home,
        yellow_away,
    )

    if yellow_zero_inferred:
        print(
            "🟨 yellow_cards: "
            f"{yellow_home}-{yellow_away} "
            "[zero_by_omission]"
        )

    quality = _oh_j1_quality_with_goals_v2866(
        clasificar_calidad_metricas(
                xg_home=xg_home,
                xg_away=xg_away,
                shots_home=shots_home,
                shots_away=shots_away,
                corners_home=corners_home,
                corners_away=corners_away,
                yellow_home=yellow_home,
                yellow_away=yellow_away,
            ),
        event,
    )

    family, context_role = competition_family(
        event["league_name"],
        event.get("competition_key", ""),
    )
    active = True
    visible_in_ui = True
    membership_role = "PARTICIPANT"
    competition_key = str(event.get("competition_key") or "").strip()
    if competition_key:
        try:
            specification = find_competition(load_registry(), competition_key)
        except (OSError, ValueError, json.JSONDecodeError):
            specification = None
        if isinstance(specification, dict):
            family = str(
                specification.get("competition_family") or family
            ).upper()
            context_role = str(
                specification.get("context_role") or context_role
            ).upper()
            active = bool(specification.get("active", True))
            visible_in_ui = bool(specification.get("visible_in_ui", True))
            membership_role = (
                "DOMESTIC_CONTEXT_PREVIOUS"
                if str(
                    specification.get("context_season_role") or "CURRENT"
                ).upper() == "PREVIOUS"
                else "DOMESTIC_CONTEXT"
                if bool(specification.get("context_only"))
                else "PARTICIPANT"
            )

    with transaction() as conn:
        league_id = upsert_league(
            conn,
            name=event["league_name"],
            country=event["country"],
            season=event["season"],
            active=active,
            source_tournament_id=event.get("tournament_id"),
            source_season_id=event.get("season_id"),
            competition_family=family,
            context_role=context_role,
            visible_in_ui=visible_in_ui,
        )

        home_team_id = upsert_team(
            conn,
            sofascore_id=event["home_sofascore_id"],
            name=event["home_name"],
            league_id=league_id,
        )

        away_team_id = upsert_team(
            conn,
            sofascore_id=event["away_sofascore_id"],
            name=event["away_name"],
            league_id=league_id,
        )

        tournament_id = event.get("tournament_id")
        source_season_id = event.get("season_id")
        if tournament_id is not None and source_season_id is not None:
            for team_id in (home_team_id, away_team_id):
                upsert_team_competition_membership(
                    conn,
                    team_id=team_id,
                    league_id=league_id,
                    sofascore_tournament_id=int(tournament_id),
                    sofascore_season_id=int(source_season_id),
                    membership_role=membership_role,
                    membership_status="ACTIVE",
                    current_round=event.get("round"),
                )

        match_id = upsert_match(
            conn,
            sofascore_id=event["event_id"],
            league_id=league_id,
            season=event["season"],
            kickoff=event["kickoff"],
            home_team_id=home_team_id,
            away_team_id=away_team_id,
            status=event["status"],
            home_goals=event["home_goals"],
            away_goals=event["away_goals"],
        )

        upsert_team_match_stats(
            conn,
            match_id=match_id,
            team_id=home_team_id,
            venue="HOME",
            goals_for=event["home_goals"],
            goals_against=event["away_goals"],
            xg_for=xg_home,
            xg_against=xg_away,
            xg_source=xg_source,
            xg_is_estimated=xg_is_estimated,
            xg_method_version=xg_method_version,
            xg_updated_at=xg_updated_at,
            shots=shots_home,
            shots_on_target=target_home,
            corners_for=corners_home,
            corners_against=corners_away,
            yellow_cards=yellow_home,
            red_cards=red_home,
            possession=possession_home,
            fouls=fouls_home,
            offsides=offsides_home,
            big_chances=big_home,
            data_quality=quality,
        )

        upsert_team_match_stats(
            conn,
            match_id=match_id,
            team_id=away_team_id,
            venue="AWAY",
            goals_for=event["away_goals"],
            goals_against=event["home_goals"],
            xg_for=xg_away,
            xg_against=xg_home,
            xg_source=xg_source,
            xg_is_estimated=xg_is_estimated,
            xg_method_version=xg_method_version,
            xg_updated_at=xg_updated_at,
            shots=shots_away,
            shots_on_target=target_away,
            corners_for=corners_away,
            corners_against=corners_home,
            yellow_cards=yellow_away,
            red_cards=red_away,
            possession=possession_away,
            fouls=fouls_away,
            offsides=offsides_away,
            big_chances=big_away,
            data_quality=quality,
        )

    return match_id, quality


# ==============================================================================
# 9. PROGRESO Y ORQUESTACIÓN
# ==============================================================================

def guardar_progreso(
    path: Path,
    competition: dict[str, Any],
    counters: Counters,
    last_event_id: int | None,
) -> None:
    write_json(
        path,
        {
            "competition_key": competition["key"],
            "competition_name": competition["name"],
            "updated_at": utc_now(),
            "last_event_id": last_event_id,
            "counts": counters.__dict__,
        },
    )


def importar_competicion(
    competition: dict[str, Any],
    limit: int | None,
    delay_seconds: float,
    retry_partial: bool,
    event_ids: set[int] | None = None,
) -> None:
    matches, source_path = cargar_partidos_competicion(
        competition
    )

    counters = Counters(
        encontrados=len(matches),
    )

    selected = list(matches)

    # ODDSHUNTER CONFERENCE AUTO V3: explicit event selection
    if event_ids:
        requested_event_ids = {
            int(event_id)
            for event_id in event_ids
        }
        selected = [
            match
            for match in selected
            if int(match["event_id"]) in requested_event_ids
        ]

    if limit is not None:
        selected = selected[:limit]

    counters.seleccionados = len(selected)

    key = slugify(str(competition["key"]))
    competition_dir = COMPETITIONS_DIR / key
    raw_dir = RAW_ROOT_DIR / key
    progress_path = competition_dir / "import_stats_progress.json"

    raw_dir.mkdir(parents=True, exist_ok=True)

    brave_path = encontrar_brave()

    print("=" * 80)
    print("ODDSHUNTER — IMPORTADOR DE ESTADÍSTICAS POR COMPETICIÓN")
    print("=" * 80)
    print(f"Competición:              {competition['name']}")
    print(f"Archivo fuente:           {source_path}")
    print(f"Partidos encontrados:     {counters.encontrados}")
    print(f"Partidos seleccionados:   {counters.seleccionados}")
    print(f"Reintentar PARTIAL:       {'sí' if retry_partial else 'no'}")
    print(f"Brave:                    {brave_path}")
    print()

    with sync_playwright() as playwright:
        context: BrowserContext = (
            playwright.chromium.launch_persistent_context(
                user_data_dir=str(BRAVE_PROFILE_DIR),
                executable_path=str(brave_path),
                headless=False,
                chromium_sandbox=True,
                locale="es-ES",
                viewport={"width": 1365, "height": 900},
                args=[
                    "--start-maximized",
                    "--disable-cache",
                ],
            )
        )
        futbol24_client = Futbol24Client(
            project_root=BASE_DIR,
            logger=lambda message: print(f"   ℹ️ {message}"),
        )
        flashscore_client = FlashscoreXGClient(
            playwright,
            project_root=BASE_DIR,
            logger=lambda message: print(f"   ℹ️ {message}"),
        )

        try:
            page = (
                context.pages[0]
                if context.pages
                else context.new_page()
            )

            for index, match in enumerate(selected, start=1):
                event_id = int(match["event_id"])
                home = match.get("home_team", "Local")
                away = match.get("away_team", "Visitante")

                print("-" * 80)
                print(
                    f"[{index:03d}/{counters.seleccionados:03d}] "
                    f"{home} vs {away} | event_id={event_id}"
                )

                try:
                    state = partido_estado_sqlite(event_id, key)

                    if state == "FULL":
                        counters.full_omitidos += 1
                        print("⏭️ Ya tiene dos filas FULL. Se omite.")
                        guardar_progreso(
                            progress_path,
                            competition,
                            counters,
                            event_id,
                        )
                        continue

                    if state == "PARTIAL" and not retry_partial:
                        counters.partial_omitidos += 1
                        print(
                            "⏭️ Ya tiene dos filas PARTIAL. "
                            "Se omite; usa --retry-partial para reintentarlo."
                        )
                        guardar_progreso(
                            progress_path,
                            competition,
                            counters,
                            event_id,
                        )
                        continue

                    event_json, stats_json = capturar_json_partido(
                        page,
                        match,
                        raw_dir,
                    )

                    validar_evento_competicion(
                        event_json,
                        competition,
                        match,
                    )

                    xg_result = recuperar_xg_partido(
                        match,
                        event_json,
                        stats_json,
                        futbol24_client,
                        flashscore_client,
                        raw_dir,
                    )
                    real_stats_result = recuperar_metricas_partido(
                        match,
                        event_json,
                        stats_json,
                        futbol24_client,
                        flashscore_client,
                        raw_dir,
                    )
                    match_id, quality = guardar_partido(
                        match,
                        event_json,
                        stats_json,
                        xg_result,
                        real_stats_result,
                    )
                    if xg_result.available:
                        label = (
                            "estimado"
                            if xg_result.is_estimated
                            else "real"
                        )
                        print(
                            f"   ✅ xG {label}: "
                            f"{xg_result.home:.2f} - "
                            f"{xg_result.away:.2f} "
                            f"({xg_result.source})"
                        )
                    else:
                        print("   ℹ️ xG no disponible en las tres fuentes.")

                    if quality == "FULL":
                        counters.guardados_full += 1
                        print(
                            f"✅ Guardado {quality} | match_id interno={match_id}"
                        )
                    else:
                        counters.guardados_partial += 1
                        print(
                            f"⚠️ Guardado PARTIAL | match_id interno={match_id}"
                        )

                except PlaywrightTimeoutError as exc:
                    counters.errores += 1
                    print(f"❌ Timeout de Playwright: {exc}")

                except Exception as exc:
                    counters.errores += 1
                    print(f"❌ {type(exc).__name__}: {exc}")

                    if "verificación" in str(exc).lower():
                        guardar_progreso(
                            progress_path,
                            competition,
                            counters,
                            event_id,
                        )
                        raise

                guardar_progreso(
                    progress_path,
                    competition,
                    counters,
                    event_id,
                )

                if delay_seconds > 0:
                    print(
                        f"⏳ Esperando {delay_seconds:.1f} segundos..."
                    )
                    time.sleep(delay_seconds)

        finally:
            flashscore_client.close()
            futbol24_client.close()
            close_playwright_target(context, "contexto de Brave")

    print()
    print("=" * 80)
    print("RESUMEN FINAL")
    print("=" * 80)
    print(f"Partidos encontrados:       {counters.encontrados}")
    print(f"Partidos seleccionados:     {counters.seleccionados}")
    print(f"FULL omitidos:              {counters.full_omitidos}")
    print(f"PARTIAL omitidos:           {counters.partial_omitidos}")
    print(f"Guardados FULL:             {counters.guardados_full}")
    print(f"Guardados PARTIAL:          {counters.guardados_partial}")
    print(f"Errores:                    {counters.errores}")
    print(f"Progreso:                   {progress_path}")
    print("=" * 80)


# ==============================================================================
# 10. CLI
# ==============================================================================

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Importa las estadísticas de los partidos finalizados "
            "de una o varias competiciones registradas."
        )
    )

    group = parser.add_mutually_exclusive_group(required=True)

    group.add_argument(
        "--key",
        help="Clave de competición, por ejemplo: mls",
    )

    group.add_argument(
        "--all",
        action="store_true",
        help="Procesa todas las competiciones activas.",
    )

    parser.add_argument(
        "--limit",
        type=int,
        help=(
            "Procesa solo los primeros N partidos del archivo. "
            "Útil para probar."
        ),
    )

    parser.add_argument(
        "--delay",
        type=float,
        default=DEFAULT_DELAY_SECONDS,
        help="Segundos de espera entre partidos.",
    )

    parser.add_argument(
        "--retry-partial",
        action="store_true",
        help="Reintenta partidos que ya tienen dos filas PARTIAL.",
    )

    # ODDSHUNTER CONFERENCE AUTO V3: event ids CLI
    parser.add_argument(
        "--event-ids",
        type=int,
        nargs="+",
        help=(
            "Procesa únicamente los event_id indicados. "
            "El automático V3 usa lotes de cuatro."
        ),
    )

    return parser


def main() -> None:
    args = build_parser().parse_args()

    try:
        registry = load_registry()

        if args.all:
            competitions = [
                item
                for item in registry["competitions"]
                if item.get("active")
            ]
        else:
            competitions = [
                find_competition(registry, args.key)
            ]

        for competition in competitions:
            importar_competicion(
                competition=competition,
                limit=args.limit,
                delay_seconds=max(0.0, float(args.delay)),
                retry_partial=bool(args.retry_partial),
                event_ids=set(args.event_ids or []) or None,
            )

    except KeyboardInterrupt:
        print(
            "\n⚠️ Proceso interrumpido. "
            "Lo ya guardado permanece en SQLite."
        )

    except Exception as exc:
        print(
            f"\n❌ Error inicial: {type(exc).__name__}: {exc}"
        )


if __name__ == "__main__":
    main()
