from __future__ import annotations

from pathlib import Path


# ==============================================================================
# 1. RUTAS DEL PROYECTO
# ==============================================================================

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "oddshunter.db"

# Crear automáticamente la carpeta data si no existe.
DATA_DIR.mkdir(parents=True, exist_ok=True)


# ==============================================================================
# 2. CONFIGURACIÓN DEL MODELO
# ==============================================================================

MODEL_VERSION = "ODDSHUNTER_V6_MLS_1.0"

# Cantidad máxima de partidos utilizados por equipo.
MATCHES_WINDOW = 15

# Los últimos cinco partidos tendrán mayor importancia.
RECENT_MATCHES = 5

# Partidos 1–10.
OLD_MATCH_WEIGHT = 1.0

# Partidos 11–15.
RECENT_MATCH_WEIGHT = 2.0

# Parámetro inicial de Dixon-Coles.
DIXON_COLES_RHO = -0.03

# Elo inicial de un equipo sin historial.
DEFAULT_ELO = 1500.0

# Velocidad de actualización del Elo.
ELO_K_FACTOR = 25.0

# Ventaja inicial por jugar como local.
HOME_ADVANTAGE = 1.08

# Media inicial por equipo cuando todavía no existe suficiente información.
DEFAULT_GOALS_AVERAGE = 1.35
DEFAULT_CORNERS_AVERAGE = 5.0
DEFAULT_CARDS_AVERAGE = 2.0


# ==============================================================================
# 3. MERCADOS DE GOLES
# ==============================================================================

GOAL_LINES = (
    0.5,
    1.5,
    2.0,
    2.5,
    3.5,
)


# ==============================================================================
# 4. MERCADOS DE CÓRNERS
# ==============================================================================

# El scraper aceptará todas las líneas de Betano desde 5.5 en adelante.
MIN_CORNERS_LINE = 5.5

# Líneas principales que aparecerán inicialmente en la aplicación.
# No representa un límite máximo obligatorio.
DEFAULT_CORNER_LINES = (
    5.5,
    6.5,
    7.5,
    8.5,
    9.5,
    10.5,
    11.5,
)


# ==============================================================================
# 5. MERCADOS DE TARJETAS
# ==============================================================================

CARD_LINES = (
    0.5,
    1.5,
    2.5,
    3.5,
)


# ==============================================================================
# 6. FILTROS DE PROBABILIDAD Y VALOR
# ==============================================================================

# Probabilidad mínima para destacar una selección.
MIN_MODEL_PROBABILITY = 0.60

# EV mínimo expresado en decimal.
# 0.02 equivale a +2%.
MIN_EXPECTED_VALUE = 0.02

# Límite de Kelly para no recomendar exposiciones excesivas.
MAX_KELLY_FRACTION = 0.02

# Fracción conservadora de Kelly.
KELLY_MULTIPLIER = 0.25


# ==============================================================================
# 7. SOFASCORE
# ==============================================================================

SOFASCORE_API_BASE = "https://api.sofascore.com/api/v1"

# Dominios alternativos para probar en orden.
SOFASCORE_BASE_URLS = (
    "https://www.sofascore.com/api/v1",
    "https://api.sofascore.com/api/v1",
)

REQUEST_TIMEOUT = 20

# Pausa entre solicitudes para no hacer demasiadas peticiones seguidas.
REQUEST_DELAY = 0.6

# Brave usa una identificación compatible con Chromium/Chrome.
REQUEST_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/150.0.0.0 Safari/537.36"
    ),
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
    "Origin": "https://www.sofascore.com",
    "Referer": "https://www.sofascore.com/",
    "Connection": "keep-alive",
}


# ==============================================================================
# 8. BETANO
# ==============================================================================

BETANO_BOOKMAKER_NAME = "BETANO"

BETANO_HEADERS = {
    "User-Agent": REQUEST_HEADERS["User-Agent"],
    "Accept": (
        "text/html,application/xhtml+xml,application/xml;q=0.9,"
        "image/avif,image/webp,*/*;q=0.8"
    ),
    "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
    "Referer": "https://ec.betano.com/",
    "Connection": "keep-alive",
}


# ==============================================================================
# 9. ESTADOS DE PARTIDOS
# ==============================================================================

FINISHED_STATUSES = {
    "FT",
    "AET",
    "PEN",
}

LIVE_STATUSES = {
    "LIVE",
    "1H",
    "HT",
    "2H",
    "ET",
    "P",
}

NOT_STARTED_STATUS = "NS"


# ==============================================================================
# 10. CALIDAD DE DATOS
# ==============================================================================

DATA_QUALITY_FULL = "FULL"
DATA_QUALITY_PARTIAL = "PARTIAL"
DATA_QUALITY_ESTIMATED = "ESTIMATED"