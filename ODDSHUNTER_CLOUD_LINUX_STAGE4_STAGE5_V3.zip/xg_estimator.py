from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from typing import Any


METHOD_VERSION = "aggregate_v1"


def classify_match_data_quality(
    *,
    xg_home: Any,
    xg_away: Any,
    shots_home: Any,
    shots_away: Any,
    corners_home: Any,
    corners_away: Any,
    yellow_home: Any,
    yellow_away: Any,
) -> str:
    """FULL exige xG directo o estimado y métricas para ambos equipos."""

    required = (
        xg_home,
        xg_away,
        shots_home,
        shots_away,
        corners_home,
        corners_away,
        yellow_home,
        yellow_away,
    )
    return (
        "FULL"
        if all(value is not None for value in required)
        else "PARTIAL"
    )


@dataclass(frozen=True)
class AggregateStats:
    total_shots: float | int | None
    shots_on_target: float | int | None
    shots_off_target: float | int | None = None
    blocked_shots: float | int | None = None


@dataclass(frozen=True)
class EstimatedXG:
    value: float | None
    method_version: str
    components: dict[str, Any]
    reason: str | None = None

    @property
    def available(self) -> bool:
        return self.value is not None


def _finite_nonnegative(
    value: float | int | None,
    field: str,
) -> tuple[float | None, str | None]:
    if value is None or isinstance(value, bool):
        return None, None

    try:
        number = float(value)
    except (TypeError, ValueError):
        return None, f"{field} no es numérico."

    if not math.isfinite(number):
        return None, f"{field} no es finito."
    if number < 0:
        return None, f"{field} no puede ser negativo."
    return number, None


def estimate_team_xg(stats: AggregateStats) -> EstimatedXG:
    values: dict[str, float | None] = {}
    for field in (
        "total_shots",
        "shots_on_target",
        "shots_off_target",
        "blocked_shots",
    ):
        value, error = _finite_nonnegative(getattr(stats, field), field)
        if error:
            return EstimatedXG(
                value=None,
                method_version=METHOD_VERSION,
                components={"raw": asdict(stats)},
                reason=error,
            )
        values[field] = value

    total = values["total_shots"]
    on_target = values["shots_on_target"]
    off_target = values["shots_off_target"]
    blocked = values["blocked_shots"]

    if total is None or on_target is None:
        return EstimatedXG(
            value=None,
            method_version=METHOD_VERSION,
            components={"raw": asdict(stats)},
            reason=(
                "Se requieren remates totales y remates a puerta."
            ),
        )

    if on_target > total:
        return EstimatedXG(
            value=None,
            method_version=METHOD_VERSION,
            components={"raw": asdict(stats)},
            reason=(
                "Los remates a puerta superan los remates totales."
            ),
        )

    remaining = total - on_target
    inferred = {
        "shots_off_target": False,
        "blocked_shots": False,
    }

    if off_target is None and blocked is None:
        off_target = round(remaining * 0.60, 3)
        blocked = round(remaining - off_target, 3)
        inferred["shots_off_target"] = True
        inferred["blocked_shots"] = True
    elif off_target is None:
        if blocked is not None and blocked > remaining:
            return EstimatedXG(
                value=None,
                method_version=METHOD_VERSION,
                components={"raw": asdict(stats)},
                reason="Los remates bloqueados son inconsistentes.",
            )
        blocked = blocked or 0.0
        off_target = remaining - blocked
        inferred["shots_off_target"] = True
    elif blocked is None:
        if off_target > remaining:
            return EstimatedXG(
                value=None,
                method_version=METHOD_VERSION,
                components={"raw": asdict(stats)},
                reason="Los remates fuera son inconsistentes.",
            )
        blocked = remaining - off_target
        inferred["blocked_shots"] = True
    elif off_target + blocked > remaining + 0.5:
        return EstimatedXG(
            value=None,
            method_version=METHOD_VERSION,
            components={"raw": asdict(stats)},
            reason=(
                "La suma de remates a puerta, fuera y bloqueados "
                "supera los remates totales."
            ),
        )

    off_target = float(off_target or 0.0)
    blocked = float(blocked or 0.0)
    contributions = {
        "shots_on_target": round(on_target * 0.22, 4),
        "shots_off_target": round(off_target * 0.06, 4),
        "blocked_shots": round(blocked * 0.05, 4),
    }
    value = round(sum(contributions.values()), 2)

    return EstimatedXG(
        value=value,
        method_version=METHOD_VERSION,
        components={
            "total_shots": total,
            "shots_on_target": on_target,
            "shots_off_target": off_target,
            "blocked_shots": blocked,
            "inferred": inferred,
            "contributions": contributions,
        },
    )


def estimate_match_xg(
    home: AggregateStats,
    away: AggregateStats,
) -> tuple[EstimatedXG, EstimatedXG]:
    return estimate_team_xg(home), estimate_team_xg(away)
