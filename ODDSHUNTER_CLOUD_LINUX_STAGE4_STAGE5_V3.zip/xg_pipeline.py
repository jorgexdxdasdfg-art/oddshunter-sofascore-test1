from __future__ import annotations

import math
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Protocol, Sequence

from xg_estimator import (
    AggregateStats,
    METHOD_VERSION,
    estimate_match_xg,
)


DIRECT_METHOD_VERSION = "direct_v1"


@dataclass(frozen=True)
class MatchRef:
    match_id: int | None
    kickoff: str
    home_team: str
    away_team: str
    competition: str
    season: str
    sofascore_event_id: int | None = None
    competition_id: int | None = None
    season_id: int | None = None
    home_goals: int | float | None = None
    away_goals: int | float | None = None
    flashscore_url: str | None = None


@dataclass(frozen=True)
class DirectXG:
    home: float
    away: float
    details: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class MatchAggregateStats:
    home: AggregateStats
    away: AggregateStats
    details: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class XGResult:
    home: float | None
    away: float | None
    source: str
    is_estimated: bool
    method_version: str | None
    updated_at: str
    details: dict[str, Any] = field(default_factory=dict)

    @property
    def available(self) -> bool:
        return self.home is not None and self.away is not None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class XGSource(Protocol):
    name: str

    def get_direct_xg(self, match: MatchRef) -> DirectXG | None:
        ...

    def get_aggregate_stats(
        self,
        match: MatchRef,
    ) -> MatchAggregateStats | None:
        ...


class StaticXGSource:
    def __init__(
        self,
        name: str,
        *,
        direct: DirectXG | None = None,
        aggregate: MatchAggregateStats | None = None,
    ) -> None:
        self.name = name
        self.direct = direct
        self.aggregate = aggregate

    def get_direct_xg(self, match: MatchRef) -> DirectXG | None:
        return self.direct

    def get_aggregate_stats(
        self,
        match: MatchRef,
    ) -> MatchAggregateStats | None:
        return self.aggregate


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _valid_xg_pair(home: Any, away: Any) -> bool:
    try:
        values = (float(home), float(away))
    except (TypeError, ValueError):
        return False
    return all(
        math.isfinite(value) and 0.0 <= value <= 15.0
        for value in values
    )


def recover_xg(
    match: MatchRef,
    sources: Sequence[XGSource],
) -> XGResult:
    """Recupera xG priorizando valores directos sobre estimaciones.

    Primero consulta xG directo en SofaScore, Futbol24 y Flashscore.
    Solo si ninguna de las tres fuentes publica un xG directo valido,
    recorre las mismas fuentes en el mismo orden para calcular un
    aproximado desde estadisticas agregadas.

    De este modo un xG aproximado nunca bloquea un xG real publicado por
    una fuente posterior.

    El orden de cada fase sigue siendo SofaScore, Futbol24 y Flashscore.

    """

    attempts: list[dict[str, Any]] = []

    ordered_sources: list[tuple[str, XGSource]] = [
        (str(source.name).strip().lower(), source)
        for source in sources
    ]

    # ------------------------------------------------------------------
    # FASE 1 ? XG DIRECTO REAL
    # ------------------------------------------------------------------
    for source_name, source in ordered_sources:
        try:
            direct = source.get_direct_xg(match)
        except Exception as exc:
            attempts.append(
                {
                    "source": source_name,
                    "stage": "direct",
                    "error": f"{type(exc).__name__}: {exc}",
                }
            )
            direct = None

        if (
            direct is not None
            and _valid_xg_pair(direct.home, direct.away)
        ):
            return XGResult(
                home=round(float(direct.home), 2),
                away=round(float(direct.away), 2),
                source=f"{source_name}_direct_xg",
                is_estimated=False,
                method_version=DIRECT_METHOD_VERSION,
                updated_at=_now(),
                details={
                    "attempts": attempts,
                    "source_details": direct.details,
                },
            )

        attempts.append(
            {
                "source": source_name,
                "stage": "direct",
                "result": "unavailable_or_incomplete",
            }
        )

    # ------------------------------------------------------------------
    # FASE 2 ? ESTIMACIONES / AGGREGATES
    # Solo se entra aqu? si NINGUNA fuente tuvo xG directo v?lido.
    # ------------------------------------------------------------------
    for source_name, source in ordered_sources:
        try:
            aggregate = source.get_aggregate_stats(match)
        except Exception as exc:
            attempts.append(
                {
                    "source": source_name,
                    "stage": "aggregate",
                    "error": f"{type(exc).__name__}: {exc}",
                }
            )
            aggregate = None

        if aggregate is None:
            attempts.append(
                {
                    "source": source_name,
                    "stage": "aggregate",
                    "result": "unavailable",
                }
            )
            continue

        home_estimate, away_estimate = estimate_match_xg(
            aggregate.home,
            aggregate.away,
        )

        if (
            home_estimate.available
            and away_estimate.available
            and _valid_xg_pair(
                home_estimate.value,
                away_estimate.value,
            )
        ):
            aggregate_source = (
                "shot_aggregate"
                if source_name == "sofascore"
                else f"{source_name}_aggregate_estimate"
            )

            return XGResult(
                home=home_estimate.value,
                away=away_estimate.value,
                source=aggregate_source,
                is_estimated=True,
                method_version=METHOD_VERSION,
                updated_at=_now(),
                details={
                    "attempts": attempts,
                    "source_details": aggregate.details,
                    "home_calculation": asdict(home_estimate),
                    "away_calculation": asdict(away_estimate),
                },
            )

        attempts.append(
            {
                "source": source_name,
                "stage": "aggregate",
                "result": "insufficient_or_inconsistent",
                "home_reason": home_estimate.reason,
                "away_reason": away_estimate.reason,
            }
        )

    return XGResult(
        home=None,
        away=None,
        source="unavailable",
        is_estimated=False,
        method_version=None,
        updated_at=_now(),
        details={"attempts": attempts},
    )
