#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv .venv-cloud
source .venv-cloud/bin/activate
python -m pip install --upgrade pip
pip install -r requirements-cloud.txt
python -m playwright install --with-deps chromium
echo "INSTALL_CLOUD_LINUX=PASS"
