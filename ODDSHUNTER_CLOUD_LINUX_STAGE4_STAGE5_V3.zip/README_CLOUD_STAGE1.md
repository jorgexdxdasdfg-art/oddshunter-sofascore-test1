# OddsHunter Cloud Linux — Stage 1

Este paquete deriva del runtime real entregado por el usuario. No contiene `oddshunter.db`.

## Política cloud fijada

- SofaScore: **OFF** en cloud.
- Estado / marcador: **Futbol24**.
- xG y métricas de equipo: **Futbol24 → Flashscore**.
- Ausencia real: `NULL/N/D`, nunca convertir automáticamente a `0`.
- Flashscore usa Chromium administrado por Playwright en Linux; ya no exige `brave.exe`.

## Qué está listo en Stage 1

- Código núcleo compila en Linux.
- `futbol24_client.py` incluye `get_match_snapshot()` para estado/marcador.
- `flashscore_xg_client.py` es portable Windows/Linux.
- `cloud_incremental_result_sync.py` procesa **partidos que ya poseen identidad local**.
- El modo de escritura exige dos gates:
  - `ODDSHUNTER_RUNTIME_MODE=cloud`
  - `ODDSHUNTER_ALLOW_WORK_DB_WRITE=1`
- `cloud_preflight.py` es READ ONLY respecto de SQLite.

## Limitación intencional de Stage 1

`sync_upcoming_matches.py` se conserva únicamente como legado Desktop/SofaScore.
Todavía NO se usa para descubrir nuevos partidos en cloud porque ese módulo depende
de calendarios SofaScore. Stage 2 debe certificar descubrimiento de próximos partidos
con Futbol24/Flashscore antes de reemplazarlo.

Turso tampoco se escribe desde este paquete: el esquema/publicador móvil no venía
incluido en el source V2. No se inventó un mapeo.

## Linux

```bash
chmod +x install_cloud_linux.sh run_cloud_preflight.sh
./install_cloud_linux.sh
./run_cloud_preflight.sh
```

El preflight de red usa Bologna–Lazio del 24-Ago-2026, el mismo caso ya utilizado
para certificar Futbol24/Flashscore.

## Procesar un evento existente, primero sin escribir

```bash
source .venv-cloud/bin/activate
python cloud_incremental_result_sync.py --key serie-a --event-id 16283049 --dry-run
```

Para escribir sobre la **copia de trabajo cloud**:

```bash
export ODDSHUNTER_RUNTIME_MODE=cloud
export ODDSHUNTER_ALLOW_WORK_DB_WRITE=1
python cloud_incremental_result_sync.py --key <key> --event-id <id>
```

Nunca apuntar este Stage 1 a la DB oficial del Desktop.


## V1.1 score gate
- Corrige marcador Futbol24 cuando el resultado completo llega en `score1`, por ejemplo `0-1`.
- El preflight de red ahora falla si Bologna-Lazio no resulta exactamente 0-1 o si faltan xG/métricas núcleo.
