from __future__ import annotations

import argparse
import json
import math
import re
import sqlite3
import unicodedata
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

from bot10_context_model import build_match_context, build_model_profiles

from trained_model_loader import (
    component_parameters,
    infer_competition_key,
    load_latest_model,
    model_metadata,
    numeric_parameter,
)


# ==============================================================================
# 1. RUTAS Y CONFIGURACIÓN
# ==============================================================================

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "oddshunter.db"
HISTORY_DIR = DATA_DIR / "historiales"
RATINGS_DIR = DATA_DIR / "ratings"
REGISTRY_PATH = DATA_DIR / "competitions.json"

MATCHES_WINDOW = 15
MAX_HISTORY_CANDIDATES = 250
RECENT_MATCHES = 5
OLD_WEIGHT = 1.0
RECENT_WEIGHT = 2.4444444444444446

# V4.4.6: pesos validados por mercado. El escalar histórico RECENT_WEIGHT
# se conserva en 55% para forma/general y compatibilidad; los promedios
# estadísticos usan RECENT_WEIGHT_BY_MARKET.
RECENT_WEIGHT_GOALS_XG = 1.1746031746031746
RECENT_WEIGHT_SHOTS = 1.6363636363636365
RECENT_WEIGHT_CORNERS = 1.0769230769230769
RECENT_WEIGHT_CARDS = 1.0
RECENT_WEIGHT_GENERAL = 2.4444444444444446

RECENT_WEIGHT_BY_MARKET = {
    "goals": RECENT_WEIGHT_GOALS_XG,
    "xg": RECENT_WEIGHT_GOALS_XG,
    "shots": RECENT_WEIGHT_SHOTS,
    "corners": RECENT_WEIGHT_CORNERS,
    "cards": RECENT_WEIGHT_CARDS,
    "general": RECENT_WEIGHT_GENERAL,
}
ACTIVE_MODEL_METADATA: dict[str, Any] = {
    "available": False,
    "component": "goals",
}

CONTEXT_COMPETITION_KEYS = {
    "uefa-conference-league",
    "uefa-champions-league",
    "uefa-europa-league",
    "conmebol-sudamericana",
    "copa-colombia",
}

RATINGS_DIR.mkdir(parents=True, exist_ok=True)

METRICS = (
    "goals_for",
    "goals_against",
    "xg_for",
    "xg_against",
    "shots",
    "shots_on_target",
    "corners_for",
    "corners_against",
    "yellow_cards",
    "red_cards",
    "possession",
    "fouls",
    "offsides",
    "big_chances",
)

MARKET_METRICS: dict[str, tuple[str, ...]] = {
    "goals": ("goals_for", "goals_against"),
    "xg": ("xg_for", "xg_against"),
    "shots": ("shots", "shots_on_target"),
    "corners": ("corners_for", "corners_against"),
    "cards": ("yellow_cards", "red_cards"),
    "general": ("possession", "fouls", "offsides", "big_chances"),
}

METRIC_MARKET = {
    metric: market
    for market, metrics in MARKET_METRICS.items()
    for metric in metrics
}

METRIC_LABELS = {
    "goals_for": "Goles a favor",
    "goals_against": "Goles en contra",
    "xg_for": "xG a favor",
    "xg_against": "xG en contra",
    "shots": "Remates",
    "shots_on_target": "Remates al arco",
    "corners_for": "Córners a favor",
    "corners_against": "Córners en contra",
    "yellow_cards": "Tarjetas amarillas",
    "red_cards": "Tarjetas rojas",
    "possession": "Posesión",
    "fouls": "Faltas",
    "offsides": "Offsides",
    "big_chances": "Grandes ocasiones",
}


# ==============================================================================
# 2. SQLITE
# ==============================================================================

def get_connection() -> sqlite3.Connection:
    """
    Abre la base SQLite en modo lectura y devuelve filas tipo diccionario.
    """

    if not DB_PATH.exists():
        raise FileNotFoundError(
            f"No se encontró la base de datos:\n{DB_PATH}"
        )

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def validar_esquema(conn: sqlite3.Connection) -> None:
    """
    Comprueba que existan las tablas y columnas necesarias.
    """

    tablas_requeridas = {
        "teams",
        "matches",
        "team_match_stats",
    }

    tablas_existentes = {
        fila["name"]
        for fila in conn.execute(
            """
            SELECT name
            FROM sqlite_master
            WHERE type = 'table';
            """
        ).fetchall()
    }

    faltantes = tablas_requeridas - tablas_existentes

    if faltantes:
        raise RuntimeError(
            "Faltan tablas en oddshunter.db: "
            + ", ".join(sorted(faltantes))
        )

    columnas_stats = {
        fila["name"]
        for fila in conn.execute(
            "PRAGMA table_info(team_match_stats);"
        ).fetchall()
    }

    columnas_requeridas = {
        "match_id",
        "team_id",
        "venue",
        *METRICS,
        "data_quality",
    }

    columnas_faltantes = columnas_requeridas - columnas_stats

    if columnas_faltantes:
        raise RuntimeError(
            "Faltan columnas en team_match_stats: "
            + ", ".join(sorted(columnas_faltantes))
        )


def competition_history_scope(
    conn: sqlite3.Connection,
    competition_key: str | None,
) -> list[int] | None:
    """Resuelve el scope histórico configurado para una competición.

    - Legacy/no BOT9: None.
    - BOT9 sin history_source_pairs: temporada primaria.
    - BOT9 con history_source_pairs: unión de la temporada primaria y todos
      los tournament_id/season_id declarados.
    """

    if not competition_key or not REGISTRY_PATH.exists():
        return None

    try:
        registry = json.loads(
            REGISTRY_PATH.read_text(encoding="utf-8-sig")
        )
    except (OSError, json.JSONDecodeError):
        return None

    rows = registry.get("competitions")
    if not isinstance(rows, list):
        return None

    specification = next(
        (
            row
            for row in rows
            if isinstance(row, dict)
            and str(row.get("key") or "").strip() == competition_key
        ),
        None,
    )

    if not specification or not bool(specification.get("bot9_managed")):
        return None

    league_columns = {
        str(row["name"])
        for row in conn.execute("PRAGMA table_info(leagues);").fetchall()
    }

    can_resolve_source = {
        "source_tournament_id",
        "source_season_id",
    } <= league_columns

    league_ids: set[int] = set()

    def add_pair(tournament_id: Any, season_id: Any) -> None:
        if not can_resolve_source:
            return
        try:
            tid = int(tournament_id)
            sid = int(season_id)
        except (TypeError, ValueError):
            return

        rows_by_source = conn.execute(
            """
            SELECT league_id
            FROM leagues
            WHERE source_tournament_id = ?
              AND source_season_id = ?
            ORDER BY league_id;
            """,
            (tid, sid),
        ).fetchall()

        for source_row in rows_by_source:
            if source_row["league_id"] is not None:
                league_ids.add(int(source_row["league_id"]))

    add_pair(
        specification.get("source_competition_id"),
        specification.get("season_id"),
    )

    history_pairs = specification.get("history_source_pairs") or []
    if isinstance(history_pairs, list):
        for item in history_pairs:
            if isinstance(item, dict):
                add_pair(
                    item.get("tournament_id"),
                    item.get("season_id"),
                )
            elif isinstance(item, (list, tuple)) and len(item) >= 2:
                add_pair(item[0], item[1])

    if league_ids:
        return sorted(league_ids)

    names = {
        str(value).strip().casefold()
        for value in (
            specification.get("name"),
            specification.get("source_name"),
            *(specification.get("aliases") or []),
        )
        if str(value or "").strip()
    }
    season = str(
        specification.get("season_name") or ""
    ).strip().casefold()

    fallback_ids: list[int] = []

    for row in conn.execute(
        "SELECT league_id, name, season FROM leagues ORDER BY league_id"
    ).fetchall():
        row_name = str(row["name"] or "").strip().casefold()
        row_season = str(row["season"] or "").strip().casefold()

        if row_name not in names:
            continue
        if season and row_season != season:
            continue

        fallback_ids.append(int(row["league_id"]))

    return sorted(set(fallback_ids))


def archivo_proximo_partido(argumento: str | None = None) -> Path:
    """
    Usa el archivo indicado por terminal o detecta el más reciente.
    """

    if argumento:
        ruta = Path(argumento)

        if not ruta.is_absolute():
            ruta = BASE_DIR / ruta

        if not ruta.exists():
            raise FileNotFoundError(
                f"No existe el archivo indicado:\n{ruta}"
            )

        return ruta

    candidatos = sorted(
        HISTORY_DIR.glob("proximo_partido_*.json"),
        key=lambda ruta: ruta.stat().st_mtime,
        reverse=True,
    )

    if not candidatos:
        raise FileNotFoundError(
            "No se encontró ningún proximo_partido_*.json "
            f"dentro de:\n{HISTORY_DIR}"
        )

    return candidatos[0]


def cargar_proximo_partido(ruta: Path) -> dict[str, Any]:
    """
    Lee el JSON del próximo encuentro.
    """

    with ruta.open("r", encoding="utf-8") as archivo:
        contenido = json.load(archivo)

    evento = contenido.get("evento")

    if not isinstance(evento, dict):
        raise ValueError(
            f"{ruta.name} no contiene un objeto 'evento' válido."
        )

    campos = (
        "event_id",
        "home_team_id",
        "home_team",
        "away_team_id",
        "away_team",
    )

    faltantes = [
        campo
        for campo in campos
        if evento.get(campo) is None
    ]

    if faltantes:
        raise ValueError(
            "Faltan campos en el próximo partido: "
            + ", ".join(faltantes)
        )

    return evento


# ==============================================================================
# 4. CONSULTAR EQUIPOS Y PARTIDOS
# ==============================================================================

def normalize_team_identity(value: Any) -> str:
    text = unicodedata.normalize(
        "NFKD",
        str(value or "").casefold(),
    )
    text = "".join(
        character
        for character in text
        if not unicodedata.combining(character)
    )
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def team_identity_score(
    expected_name: str,
    candidate_name: str,
) -> float:
    expected = normalize_team_identity(expected_name)
    candidate = normalize_team_identity(candidate_name)
    if not expected or not candidate:
        return 0.0
    if expected == candidate:
        return 1.0

    expected_tokens = set(expected.split())
    candidate_tokens = set(candidate.split())
    overlap = expected_tokens & candidate_tokens
    if not overlap:
        return 0.0

    score = len(overlap) / max(
        len(expected_tokens),
        len(candidate_tokens),
    )
    if (
        len(overlap) >= 2
        and (
            overlap == expected_tokens
            or overlap == candidate_tokens
        )
    ):
        score = max(score, 0.86)
    return round(score, 6)


def resolver_equipo(
    conn: sqlite3.Connection,
    sofascore_id: int,
    league_ids: list[int] | None = None,
    expected_name: str | None = None,
    allow_virtual: bool = False,
) -> dict[str, Any]:
    """Resuelve una identidad sin escribir ni corregir SQLite.

    Orden:
    1. sofascore_id exacto;
    2. nombre/alias seguro ya existente en ``teams``;
    3. identidad virtual del evento cuando no existe historial.

    La identidad virtual solo permite utilizar priors y contexto legítimo.
    Nunca crea filas, muestras ni partidos artificiales.
    """

    exact = conn.execute(
        """
        SELECT
            team_id,
            sofascore_id,
            name,
            league_id
        FROM teams
        WHERE sofascore_id = ?
        ORDER BY team_id DESC
        LIMIT 1;
        """,
        (sofascore_id,),
    ).fetchone()

    if exact is not None:
        result = dict(exact)
        result["identity_resolution"] = "SOFASCORE_ID_EXACT"
        result["requested_sofascore_id"] = sofascore_id
        result["virtual_identity"] = False
        return result

    expected_name = str(expected_name or "").strip()
    candidates = conn.execute(
        """
        SELECT
            team.team_id,
            team.sofascore_id,
            team.name,
            team.league_id,
            COUNT(stats.match_id) AS history_rows
        FROM teams AS team
        LEFT JOIN team_match_stats AS stats
          ON stats.team_id = team.team_id
        GROUP BY
            team.team_id,
            team.sofascore_id,
            team.name,
            team.league_id
        ORDER BY history_rows DESC, team.team_id DESC;
        """
    ).fetchall()

    ranked: list[tuple[float, int, dict[str, Any]]] = []
    for row in candidates:
        candidate = dict(row)
        score = team_identity_score(
            expected_name,
            str(candidate.get("name") or ""),
        )
        if score >= 0.86:
            ranked.append(
                (
                    score,
                    int(candidate.get("history_rows") or 0),
                    candidate,
                )
            )

    if ranked:
        ranked.sort(
            key=lambda item: (item[0], item[1]),
            reverse=True,
        )
        best_score, _history, best = ranked[0]
        best["identity_resolution"] = (
            "SAFE_NAME_ALIAS_MATCH"
        )
        best["identity_name_score"] = best_score
        best["requested_sofascore_id"] = sofascore_id
        best["requested_name"] = expected_name
        best["virtual_identity"] = False
        return best

    if allow_virtual and expected_name:
        return {
            "team_id": None,
            "sofascore_id": sofascore_id,
            "name": expected_name,
            "league_id": (
                int(league_ids[0])
                if league_ids
                else None
            ),
            "identity_resolution": (
                "EVENT_IDENTITY_VIRTUAL_PRIOR_ONLY"
            ),
            "identity_name_score": None,
            "requested_sofascore_id": sofascore_id,
            "requested_name": expected_name,
            "virtual_identity": True,
        }

    raise RuntimeError(
        "No se encontró una identidad segura en teams para "
        f"sofascore_id={sofascore_id}, nombre={expected_name!r}."
    )


def obtener_ultimos_partidos(
    conn: sqlite3.Connection,
    sofascore_id: int,
    limite: int = MAX_HISTORY_CANDIDATES,
    league_ids: list[int] | None = None,
    kickoff_from: str | None = None,
    kickoff_before: str | None = None,
) -> list[dict[str, Any]]:
    """
    Devuelve los últimos partidos finalizados del equipo.

    La identidad se resuelve por ``teams.sofascore_id`` y no por el
    ``team_id`` interno. Esto permite unir el historial de un mismo club
    cuando SQLite creó filas distintas para Apertura y Clausura.
    """

    filters = [
        "analysed_team.sofascore_id = ?",
        "UPPER(COALESCE(m.status, '')) IN ('FT', 'FINISHED')",
    ]
    parameters: list[Any] = [sofascore_id]
    if league_ids is not None:
        if not league_ids:
            return []
        placeholders = ",".join("?" for _ in league_ids)
        filters.append(f"m.league_id IN ({placeholders})")
        parameters.extend(league_ids)
    if kickoff_from:
        filters.append("m.kickoff >= ?")
        parameters.append(kickoff_from)
    if kickoff_before:
        # Corte estricto del evento: un partido que comenzó en el mismo
        # instante o después del encuentro analizado nunca puede entrar en
        # su historial. Esto también protege reanálisis y backtesting.
        filters.append("m.kickoff < ?")
        parameters.append(kickoff_before)
    parameters.append(limite)

    filas = conn.execute(
        f"""
        SELECT
            s.stat_id,
            s.match_id,
            s.team_id,
            s.venue,
            s.goals_for,
            s.goals_against,
            s.xg_for,
            s.xg_against,
            s.shots,
            s.shots_on_target,
            s.corners_for,
            s.corners_against,
            s.yellow_cards,
            s.red_cards,
            s.possession,
            s.fouls,
            s.offsides,
            s.big_chances,
            s.data_quality,
            m.sofascore_id AS event_id,
            m.kickoff,
            m.status,
            m.home_team_id,
            m.away_team_id,
            home.name AS home_team,
            away.name AS away_team,
            m.league_id AS source_league_id
        FROM team_match_stats AS s
        INNER JOIN teams AS analysed_team
            ON analysed_team.team_id = s.team_id
        INNER JOIN matches AS m
            ON m.match_id = s.match_id
        INNER JOIN teams AS home
            ON home.team_id = m.home_team_id
        INNER JOIN teams AS away
            ON away.team_id = m.away_team_id
        WHERE {" AND ".join(filters)}
        ORDER BY
            m.kickoff DESC,
            m.match_id DESC
        LIMIT ?;
        """,
        tuple(parameters),
    ).fetchall()

    partidos = [dict(fila) for fila in filas]

    for indice, partido in enumerate(partidos):
        partido["orden_recencia"] = indice + 1
        partido["weight"] = (
            RECENT_WEIGHT
            if indice < RECENT_MATCHES
            else OLD_WEIGHT
        )

        gf = partido.get("goals_for")
        ga = partido.get("goals_against")

        if gf is None or ga is None:
            partido["result"] = None
            partido["points"] = None
        elif gf > ga:
            partido["result"] = "W"
            partido["points"] = 3
        elif gf == ga:
            partido["result"] = "D"
            partido["points"] = 1
        else:
            partido["result"] = "L"
            partido["points"] = 0

    return partidos


def domestic_history_scope(
    conn: sqlite3.Connection,
    sofascore_id: int,
) -> list[int]:
    """Obtiene el torneo doméstico del club en las temporadas almacenadas.

    La membresía suele apuntar solamente a la temporada doméstica actual.
    BOT 10.1 amplía ese alcance a filas de ``leagues`` con el mismo
    ``source_tournament_id`` (normalmente la temporada anterior). El corte
    de 12 meses se aplica después al consultar partidos, por lo que nunca se
    mezclan torneos ni se admiten encuentros fuera de la ventana aprobada.
    """

    tables = {
        str(row["name"])
        for row in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table';"
        ).fetchall()
    }
    if "team_competition_memberships" in tables:
        rows = conn.execute(
            """
            SELECT DISTINCT
                membership.league_id,
                league.source_tournament_id
            FROM team_competition_memberships AS membership
            JOIN teams AS team ON team.team_id = membership.team_id
            JOIN leagues AS league ON league.league_id = membership.league_id
            WHERE team.sofascore_id = ?
              AND league.competition_family = 'DOMESTIC'
            ORDER BY membership.league_id;
            """,
            (sofascore_id,),
        ).fetchall()
        if rows:
            league_ids = {
                int(row["league_id"])
                for row in rows
                if row["league_id"] is not None
            }
            tournament_ids = {
                int(row["source_tournament_id"])
                for row in rows
                if row["source_tournament_id"] is not None
            }
            if tournament_ids:
                placeholders = ",".join("?" for _ in tournament_ids)
                related = conn.execute(
                    f"""
                    SELECT league_id
                    FROM leagues
                    WHERE competition_family = 'DOMESTIC'
                      AND source_tournament_id IN ({placeholders})
                    ORDER BY league_id;
                    """,
                    tuple(sorted(tournament_ids)),
                ).fetchall()
                league_ids.update(
                    int(row["league_id"])
                    for row in related
                    if row["league_id"] is not None
                )
            return sorted(league_ids)

    row = conn.execute(
        """
        SELECT team.league_id
        FROM teams AS team
        LEFT JOIN leagues AS league ON league.league_id = team.league_id
        WHERE team.sofascore_id = ?
          AND (league.competition_family = 'DOMESTIC'
               OR league.competition_family IS NULL)
        LIMIT 1;
        """,
        (sofascore_id,),
    ).fetchone()
    return [int(row[0])] if row is not None and row[0] is not None else []


def uefa_history_scope(
    conn: sqlite3.Connection,
    sofascore_id: int,
) -> list[int]:
    """Devuelve todas las competiciones UEFA reales del club.

    Se usa solo para construir el perfil UEFA de 24 meses. Cada partido
    conserva su league_id/tournament_id original en SQLite.
    """

    rows = conn.execute(
        """
        SELECT DISTINCT m.league_id
        FROM team_match_stats AS stats
        JOIN teams AS team ON team.team_id = stats.team_id
        JOIN matches AS m ON m.match_id = stats.match_id
        JOIN leagues AS league ON league.league_id = m.league_id
        WHERE team.sofascore_id = ?
          AND league.competition_family = 'UEFA'
        ORDER BY m.league_id;
        """,
        (sofascore_id,),
    ).fetchall()
    return [int(row[0]) for row in rows if row[0] is not None]


def competition_metric_priors(
    conn: sqlite3.Connection,
    league_ids: list[int] | None,
    kickoff_from: str | None = None,
    kickoff_before: str | None = None,
) -> dict[str, float | None]:
    """Medias observadas dentro de una ventana cerrada; NULL nunca es cero."""

    where = ["UPPER(COALESCE(m.status, '')) IN ('FT', 'FINISHED')"]
    parameters: list[Any] = []
    if league_ids:
        placeholders = ",".join("?" for _ in league_ids)
        where.append(f"m.league_id IN ({placeholders})")
        parameters.extend(league_ids)
    else:
        where.append("league.competition_family = 'UEFA'")
    if kickoff_from:
        where.append("m.kickoff >= ?")
        parameters.append(kickoff_from)
    if kickoff_before:
        where.append("m.kickoff < ?")
        parameters.append(kickoff_before)
    columns = ",\n".join(
        f"AVG(stats.{metric}) AS {metric}" for metric in METRICS
    )
    row = conn.execute(
        f"""
        SELECT {columns}
        FROM team_match_stats AS stats
        JOIN matches AS m ON m.match_id = stats.match_id
        JOIN leagues AS league ON league.league_id = m.league_id
        WHERE {' AND '.join(where)};
        """,
        tuple(parameters),
    ).fetchone()
    return {
        metric: (
            float(row[metric])
            if row is not None and row[metric] is not None
            else None
        )
        for metric in METRICS
    }


def global_elo_ratings(
    conn: sqlite3.Connection,
    kickoff_before: str | None = None,
) -> dict[int, float]:
    """Calcula un ELO único y comparable para todas las competiciones.

    Todos los clubes parten de 1500 y los partidos domésticos y UEFA se
    procesan juntos cronológicamente. Los cruces internacionales conectan
    las escalas nacionales; no se mezclan ratings aislados de cada liga.
    """

    where = [
        "UPPER(COALESCE(m.status, '')) IN ('FT', 'FINISHED')",
        "m.home_goals IS NOT NULL",
        "m.away_goals IS NOT NULL",
    ]
    parameters: list[Any] = []
    if kickoff_before:
        where.append("m.kickoff < ?")
        parameters.append(kickoff_before)
    rows = conn.execute(
        f"""
        SELECT
            COALESCE(home.sofascore_id, home.team_id) AS home_identity,
            COALESCE(away.sofascore_id, away.team_id) AS away_identity,
            m.home_goals,
            m.away_goals
        FROM matches AS m
        JOIN teams AS home ON home.team_id = m.home_team_id
        JOIN teams AS away ON away.team_id = m.away_team_id
        WHERE {' AND '.join(where)}
        ORDER BY m.kickoff, m.match_id;
        """,
        tuple(parameters),
    ).fetchall()
    ratings: dict[int, float] = {}
    for row in rows:
        home_id = int(row["home_identity"])
        away_id = int(row["away_identity"])
        home_rating = ratings.get(home_id, 1500.0)
        away_rating = ratings.get(away_id, 1500.0)
        expected_home = 1.0 / (
            1.0 + 10.0 ** ((away_rating - (home_rating + 55.0)) / 400.0)
        )
        home_goals = int(row["home_goals"])
        away_goals = int(row["away_goals"])
        actual_home = 1.0 if home_goals > away_goals else 0.5 if home_goals == away_goals else 0.0
        margin_factor = 1.0 + 0.35 * math.log1p(abs(home_goals - away_goals))
        change = 20.0 * margin_factor * (actual_home - expected_home)
        ratings[home_id] = home_rating + change
        ratings[away_id] = away_rating - change
    return ratings


def latest_team_elo(
    conn: sqlite3.Connection,
    sofascore_id: int,
    kickoff_before: str | None = None,
) -> float | None:
    value = global_elo_ratings(conn, kickoff_before).get(int(sofascore_id))
    return None if value is None else round(value, 4)


def _market_row_is_valid(row: dict[str, Any], market: str) -> bool:
    required: dict[str, tuple[str, ...]] = {
        "goals": ("goals_for", "goals_against"),
        "xg": ("xg_for", "xg_against"),
        "shots": ("shots",),
        "corners": ("corners_for", "corners_against"),
        "cards": ("yellow_cards",),
        "general": (),
    }
    fields = required[market]
    if fields:
        return all(row.get(field) is not None for field in fields)
    return any(row.get(field) is not None for field in MARKET_METRICS[market])


def seleccionar_ventanas_por_mercado(
    partidos: list[dict[str, Any]],
) -> dict[str, list[dict[str, Any]]]:
    """Selecciona hasta 15 filas válidas por mercado, nunca NULL como cero."""

    windows: dict[str, list[dict[str, Any]]] = {}
    for market in MARKET_METRICS:
        selected: list[dict[str, Any]] = []
        for row in partidos:
            if not _market_row_is_valid(row, market):
                continue
            current = dict(row)
            current["weight"] = (
                RECENT_WEIGHT_BY_MARKET.get(market, RECENT_WEIGHT) if len(selected) < RECENT_MATCHES else OLD_WEIGHT
            )
            selected.append(current)
            if len(selected) >= MATCHES_WINDOW:
                break
        windows[market] = selected
    return windows


# ==============================================================================
# 5. CÁLCULOS
# ==============================================================================

def promedio_ponderado(
    partidos: Iterable[dict[str, Any]],
    campo: str,
) -> float | None:
    """
    Calcula un promedio ponderado ignorando NULL.
    Un NULL no se convierte en cero.
    """

    numerador = 0.0
    denominador = 0.0

    for partido in partidos:
        valor = partido.get(campo)

        if valor is None:
            continue

        peso = float(partido["weight"])
        numerador += float(valor) * peso
        denominador += peso

    if denominador == 0:
        return None

    return round(numerador / denominador, 4)


def contar_calidad(
    partidos: Iterable[dict[str, Any]],
) -> dict[str, int]:
    resultado: dict[str, int] = {}

    for partido in partidos:
        calidad = str(
            partido.get("data_quality") or "UNKNOWN"
        ).upper()

        resultado[calidad] = resultado.get(calidad, 0) + 1

    return resultado


def resumen_forma(
    partidos: list[dict[str, Any]],
) -> dict[str, Any]:
    """
    Resume victorias, empates, derrotas y puntos ponderados.
    """

    victorias = 0
    empates = 0
    derrotas = 0
    puntos_ponderados = 0.0
    peso_con_resultado = 0.0
    secuencia: list[str] = []

    for partido in partidos:
        resultado = partido.get("result")
        puntos = partido.get("points")

        if resultado is None or puntos is None:
            continue

        secuencia.append(resultado)

        if resultado == "W":
            victorias += 1
        elif resultado == "D":
            empates += 1
        elif resultado == "L":
            derrotas += 1

        peso = float(partido["weight"])
        puntos_ponderados += float(puntos) * peso
        peso_con_resultado += peso

    promedio_puntos = (
        round(puntos_ponderados / peso_con_resultado, 4)
        if peso_con_resultado
        else None
    )

    return {
        "wins": victorias,
        "draws": empates,
        "losses": derrotas,
        "sequence_recent_to_old": secuencia,
        "weighted_points_per_match": promedio_puntos,
    }


def crear_perfil(
    partidos: list[dict[str, Any]],
    venue: str | None = None,
) -> dict[str, Any]:
    """
    Crea un perfil general, local o visitante.
    Los pesos conservan la recencia de la ventana general de 15.
    """

    if venue is None:
        seleccionados = list(partidos)
        nombre = "ALL"
    else:
        nombre = venue.upper()
        seleccionados = [
            partido
            for partido in partidos
            if str(partido.get("venue", "")).upper() == nombre
        ]

    base_forma = [dict(row) for row in seleccionados[:MATCHES_WINDOW]]
    for index, row in enumerate(base_forma):
        row["weight"] = RECENT_WEIGHT if index < RECENT_MATCHES else OLD_WEIGHT

    windows = seleccionar_ventanas_por_mercado(seleccionados)
    promedios = {
        metrica: promedio_ponderado(
            windows[METRIC_MARKET[metrica]],
            metrica,
        )
        for metrica in METRICS
    }

    disponibles = {
        metrica: sum(
            1
            for partido in windows[METRIC_MARKET[metrica]]
            if partido.get(metrica) is not None
        )
        for metrica in METRICS
    }

    return {
        "venue": nombre,
        "matches": len(base_forma),
        "total_weight": round(
            sum(float(p["weight"]) for p in base_forma),
            2,
        ),
        "form": resumen_forma(base_forma),
        "averages": promedios,
        "available_values": disponibles,
        "data_quality": contar_calidad(base_forma),
        "matches_by_market": {
            market: len(rows)
            for market, rows in windows.items()
        },
        "event_ids_by_market": {
            market: [row.get("event_id") for row in rows]
            for market, rows in windows.items()
        },
    }


def resumir_partido_para_json(
    partido: dict[str, Any],
) -> dict[str, Any]:
    """
    Reduce cada fila para guardar un historial legible.
    """

    return {
        "event_id": partido.get("event_id"),
        "kickoff": partido.get("kickoff"),
        "home_team": partido.get("home_team"),
        "away_team": partido.get("away_team"),
        "venue": partido.get("venue"),
        "result": partido.get("result"),
        "goals_for": partido.get("goals_for"),
        "goals_against": partido.get("goals_against"),
        "weight": partido.get("weight"),
        "data_quality": partido.get("data_quality"),
    }



# ODDSHUNTER_FUTURE_WINDOW_ANCHOR_V4_1
def _oddshunter_effective_history_kickoff_from_v4_1(
    kickoff_from: str | None,
    kickoff_before: str | None,
) -> str | None:
    if not kickoff_from or not kickoff_before:
        return kickoff_from

    from datetime import datetime as _dt, timezone as _tz

    try:
        _from = _dt.fromisoformat(str(kickoff_from).replace("Z", "+00:00"))
        _before = _dt.fromisoformat(str(kickoff_before).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return kickoff_from

    if _from.tzinfo is None:
        _from = _from.replace(tzinfo=_tz.utc)
    if _before.tzinfo is None:
        _before = _before.replace(tzinfo=_tz.utc)

    _from = _from.astimezone(_tz.utc)
    _before = _before.astimezone(_tz.utc)
    _now = _dt.now(_tz.utc)

    _span = _before - _from
    if _span.total_seconds() <= 0 or _before <= _now:
        return kickoff_from

    return (_now - _span).isoformat()


def calcular_equipo(
    conn: sqlite3.Connection,
    sofascore_id: int,
    relevant_venue: str,
    league_ids: list[int] | None = None,
    kickoff_from: str | None = None,
    kickoff_before: str | None = None,
    context_name: str = "PRIMARY",
    allow_empty: bool = False,
    expected_name: str | None = None,
) -> dict[str, Any]:
    """
    Calcula perfiles independientes sin mezclar métricas
    mediante porcentajes arbitrarios.
    """

    equipo = resolver_equipo(
        conn,
        sofascore_id,
        league_ids,
        expected_name=expected_name,
        allow_virtual=allow_empty,
    )

    resolved_sofascore_id = int(
        equipo.get("sofascore_id")
        or sofascore_id
    )
    partidos = (
        []
        if equipo.get("virtual_identity")
        else obtener_ultimos_partidos(
        conn,
        sofascore_id=sofascore_id,
        limite=MAX_HISTORY_CANDIDATES,
        league_ids=league_ids,
        kickoff_from=_oddshunter_effective_history_kickoff_from_v4_1(kickoff_from, kickoff_before),
        kickoff_before=kickoff_before,
    )
    )

    if not partidos and not allow_empty:
        raise RuntimeError(
            f"No hay partidos guardados para {equipo['name']}."
        )

    return {
        "team": equipo,
        "configuration": {
            "matches_window": MATCHES_WINDOW,
            "storage_policy": "full_history; analytical_limit_per_market",
            "candidate_rows": len(partidos),
            "recent_matches": RECENT_MATCHES,
            "recent_weight": RECENT_WEIGHT,
            "recent_weights_by_market": dict(RECENT_WEIGHT_BY_MARKET),
            "old_weight": OLD_WEIGHT,
            "competition_current_season_only": league_ids is not None,
            "league_ids": list(league_ids or []),
            "context_name": context_name,
            "kickoff_from": kickoff_from,
            "kickoff_before": kickoff_before,
        },
        "profiles": {
            "overall": crear_perfil(partidos),
            "home": crear_perfil(partidos, "HOME"),
            "away": crear_perfil(partidos, "AWAY"),
            "relevant": crear_perfil(
                partidos,
                relevant_venue,
            ),
        },
        "matches_used": [
            resumir_partido_para_json(partido)
            for partido in partidos[:MATCHES_WINDOW]
        ],
    }


def league_scope_is_uefa(
    conn: sqlite3.Connection,
    league_ids: list[int] | None,
) -> bool:
    # LEAGUES_CUP_SEPARATE_CONTEXT_AST_V2
    # La función conserva su nombre histórico, pero este bloque
    # habilita el contexto doméstico separado para Leagues Cup.
    _lc_scope_ids: list[int] = []
    for _lc_value in (league_ids or []):
        try:
            _lc_scope_ids.append(int(_lc_value))
        except (TypeError, ValueError):
            continue
    if _lc_scope_ids:
        _lc_placeholders = ",".join("?" for _ in _lc_scope_ids)
        _lc_row = conn.execute(
            f"""
            SELECT 1
            FROM leagues
            WHERE league_id IN ({_lc_placeholders})
              AND source_tournament_id = ?
            LIMIT 1;
            """,
            (*_lc_scope_ids, 13783),
        ).fetchone()
        if _lc_row is not None:
            return True

    if not league_ids:
        return False
    columns = {
        str(row["name"])
        for row in conn.execute("PRAGMA table_info(leagues);").fetchall()
    }
    if "competition_family" not in columns:
        return False
    placeholders = ",".join("?" for _ in league_ids)
    row = conn.execute(
        f"""
        SELECT 1
        FROM leagues
        WHERE league_id IN ({placeholders})
          AND competition_family = 'UEFA'
        LIMIT 1;
        """,
        tuple(league_ids),
    ).fetchone()
    return row is not None



def context_scope_enabled(
    competition_key: str | None,
) -> bool:
    return str(competition_key or "").strip() in CONTEXT_COMPETITION_KEYS


def competition_family_for_league_ids(
    conn: sqlite3.Connection,
    league_ids: list[int] | None,
) -> str:
    if not league_ids:
        return ""
    columns = {
        str(row["name"])
        for row in conn.execute(
            "PRAGMA table_info(leagues);"
        ).fetchall()
    }
    if "competition_family" not in columns:
        return ""
    placeholders = ",".join("?" for _ in league_ids)
    row = conn.execute(
        f"""
        SELECT competition_family
        FROM leagues
        WHERE league_id IN ({placeholders})
          AND competition_family IS NOT NULL
        ORDER BY league_id
        LIMIT 1;
        """,
        tuple(league_ids),
    ).fetchone()
    return (
        str(row["competition_family"] or "").strip().upper()
        if row is not None
        else ""
    )


def family_history_scope(
    conn: sqlite3.Connection,
    sofascore_id: int,
    family: str,
) -> list[int]:
    family = str(family or "").strip().upper()
    if not family:
        return []
    rows = conn.execute(
        """
        SELECT DISTINCT m.league_id
        FROM team_match_stats AS stats
        JOIN teams AS team
          ON team.team_id = stats.team_id
        JOIN matches AS m
          ON m.match_id = stats.match_id
        JOIN leagues AS league
          ON league.league_id = m.league_id
        WHERE team.sofascore_id = ?
          AND upper(coalesce(league.competition_family, '')) = ?
        ORDER BY m.league_id;
        """,
        (sofascore_id, family),
    ).fetchall()
    return [
        int(row["league_id"])
        for row in rows
        if row["league_id"] is not None
    ]


def add_domestic_context(
    conn: sqlite3.Connection,
    analysis: dict[str, Any],
    sofascore_id: int,
    relevant_venue: str,
    cutoff: str,
) -> None:
    """Adjunta el perfil doméstico separado; no altera el perfil UEFA."""

    domestic_ids = domestic_history_scope(conn, sofascore_id)
    analysis["context_profiles"] = {
        "primary_competition": analysis["profiles"],
        "domestic": None,
    }
    analysis["context_policy"] = {
        "separated_until_model_calculation": True,
        "arbitrary_percentage_blending": False,
        "domestic_lookback_months": 12,
        "domestic_league_ids": domestic_ids,
    }
    if not domestic_ids:
        return
    try:
        domestic = calcular_equipo(
            conn,
            sofascore_id=sofascore_id,
            relevant_venue=relevant_venue,
            league_ids=domestic_ids,
            kickoff_from=cutoff,
            context_name="DOMESTIC",
        )
    except RuntimeError:
        return
    analysis["context_profiles"]["domestic"] = domestic["profiles"]
    analysis["domestic_context_matches_used"] = domestic["matches_used"]



def add_bot10_context(
    conn: sqlite3.Connection,
    analysis: dict[str, Any],
    sofascore_id: int,
    relevant_venue: str,
    reference: datetime,
    competition_key: str,
    primary_league_ids: list[int] | None,
) -> None:
    """Construye perfil internacional/copa y doméstico por separado.

    UEFA conserva su ventana agregada de 24 meses. Sudamericana agrega el
    historial CONMEBOL disponible. Copa Colombia conserva su perfil de copa
    como contexto principal y utiliza la liga doméstica normalizada como
    respaldo. NULL nunca se convierte en cero.
    """

    target_ids = [
        int(value)
        for value in (primary_league_ids or [])
    ]
    family = competition_family_for_league_ids(
        conn,
        target_ids,
    )

    if competition_key in {
        "uefa-conference-league",
        "uefa-champions-league",
        "uefa-europa-league",
    }:
        international_ids = uefa_history_scope(
            conn,
            sofascore_id,
        )
        context_family = "UEFA"
        international_months = 24
    elif competition_key == "conmebol-sudamericana":
        international_ids = family_history_scope(
            conn,
            sofascore_id,
            family or "CONMEBOL",
        )
        if not international_ids:
            international_ids = list(target_ids)
        context_family = family or "CONMEBOL"
        international_months = 24
    else:
        international_ids = list(target_ids)
        context_family = family or "DOMESTIC_CUP"
        international_months = 24

    domestic_ids = [
        league_id
        for league_id in domestic_history_scope(
            conn,
            sofascore_id,
        )
        if league_id not in set(target_ids)
        and league_id not in set(international_ids)
    ]

    reference_cutoff = (
        reference.astimezone(timezone.utc).isoformat()
    )
    international_cutoff = (
        reference - timedelta(days=730)
    ).isoformat()
    domestic_cutoff = (
        reference - timedelta(days=365)
    ).isoformat()

    expected_name = str(
        (analysis.get("team") or {}).get("name")
        or ""
    )
    international = calcular_equipo(
        conn,
        sofascore_id,
        relevant_venue,
        league_ids=international_ids,
        kickoff_from=international_cutoff,
        kickoff_before=reference_cutoff,
        context_name=f"{context_family}_AGGREGATED",
        allow_empty=True,
        expected_name=expected_name,
    )
    domestic = calcular_equipo(
        conn,
        sofascore_id,
        relevant_venue,
        league_ids=domestic_ids,
        kickoff_from=domestic_cutoff,
        kickoff_before=reference_cutoff,
        context_name="DOMESTIC",
        allow_empty=True,
        expected_name=expected_name,
    )

    priors = competition_metric_priors(
        conn,
        target_ids,
        kickoff_from=international_cutoff,
        kickoff_before=reference_cutoff,
    )
    if not any(
        value is not None
        for value in priors.values()
    ):
        priors = competition_metric_priors(
            conn,
            international_ids,
            kickoff_from=international_cutoff,
            kickoff_before=reference_cutoff,
        )

    domestic_priors = (
        competition_metric_priors(
            conn,
            domestic_ids,
            kickoff_from=domestic_cutoff,
            kickoff_before=reference_cutoff,
        )
        if domestic_ids
        else {
            metric: None
            for metric in METRICS
        }
    )

    analysis["context_profiles"] = {
        "primary_competition": analysis.get("profiles"),
        "international": international["profiles"],
        "uefa": (
            international["profiles"]
            if context_family == "UEFA"
            else None
        ),
        "domestic": domestic["profiles"],
    }
    analysis["context_policy"] = {
        "version": "BOT10.4_REAL_FINAL_1.4",
        "competition_key": competition_key,
        "context_family": context_family,
        "separated_until_model_calculation": True,
        "fixed_percentage_blend": False,
        "dynamic_evidence_weight": True,
        "international_lookback_months": international_months,
        "domestic_lookback_months": 12,
        "analytical_limit_per_market": MATCHES_WINDOW,
        "strict_event_cutoff": reference_cutoff,
        "domestic_league_normalization": True,
        "global_comparable_elo": True,
        "primary_league_ids": target_ids,
        "international_league_ids": international_ids,
        "domestic_league_ids": domestic_ids,
    }
    analysis["model_profiles"] = build_model_profiles(
        international["profiles"],
        domestic["profiles"],
        priors,
        domestic_priors,
    )
    analysis["international_context_matches_used"] = (
        international["matches_used"]
    )
    analysis["uefa_context_matches_used"] = (
        international["matches_used"]
        if context_family == "UEFA"
        else []
    )
    analysis["domestic_context_matches_used"] = (
        domestic["matches_used"]
    )
    resolved_elo = latest_team_elo(
        conn,
        sofascore_id,
        kickoff_before=reference_cutoff,
    )
    if resolved_elo is None:
        analysis["elo"] = 1500.0
        analysis["elo_method"] = (
            "neutral_elo_baseline_no_history"
        )
        analysis["elo_is_fallback"] = True
    else:
        analysis["elo"] = resolved_elo
        analysis["elo_method"] = (
            "global_cross_competition_elo_v1"
        )
        analysis["elo_is_fallback"] = False


def build_event_match_context(
    home_analysis: dict[str, Any],
    away_analysis: dict[str, Any],
    competition_key: str,
) -> dict[str, Any] | None:
    if (
        not home_analysis.get("model_profiles")
        or not away_analysis.get("model_profiles")
    ):
        return None

    context = build_match_context(
        home_analysis,
        away_analysis,
        home_analysis.get("elo"),
        away_analysis.get("elo"),
    )
    context["competition_key"] = competition_key

    if competition_key in {
        "uefa-conference-league",
        "uefa-champions-league",
        "uefa-europa-league",
    }:
        source = "separate_uefa_domestic_profiles_elo"
    elif competition_key == "conmebol-sudamericana":
        source = (
            "separate_conmebol_domestic_profiles_elo"
        )
    else:
        source = (
            "separate_cup_domestic_profiles_elo"
        )

    markets = context.get("markets")
    if isinstance(markets, dict):
        for projection in markets.values():
            if isinstance(projection, dict):
                projection["source"] = source
                projection[
                    "competition_key"
                ] = competition_key
    context["source"] = source
    return context


# ==============================================================================
# 6. MOSTRAR EN TERMINAL
# ==============================================================================

def formato_numero(valor: Any) -> str:
    if valor is None:
        return "NULL"

    return f"{float(valor):.2f}"


def imprimir_perfil(
    titulo: str,
    perfil: dict[str, Any],
) -> None:
    print()
    print(titulo)
    print("-" * 72)
    print(
        f"Partidos: {perfil['matches']} | "
        f"Peso total: {perfil['total_weight']}"
    )

    forma = perfil["form"]

    print(
        "Forma: "
        f"{forma['wins']}G "
        f"{forma['draws']}E "
        f"{forma['losses']}P | "
        "Puntos ponderados/partido: "
        f"{formato_numero(forma['weighted_points_per_match'])}"
    )

    promedios = perfil["averages"]

    claves_principales = (
        "goals_for",
        "goals_against",
        "xg_for",
        "xg_against",
        "shots",
        "shots_on_target",
        "corners_for",
        "corners_against",
        "yellow_cards",
        "possession",
        "fouls",
        "offsides",
        "big_chances",
    )

    for clave in claves_principales:
        etiqueta = METRIC_LABELS[clave]
        valor = formato_numero(promedios[clave])
        disponibles = perfil["available_values"][clave]

        print(
            f"{etiqueta:<24}: {valor:<8} "
            f"(datos: {disponibles}/{perfil['matches']})"
        )


def imprimir_equipo(
    calculo: dict[str, Any],
    relevant_label: str,
) -> None:
    nombre = calculo["team"]["name"]

    print()
    print("=" * 72)
    print(nombre)
    print("=" * 72)

    imprimir_perfil(
        "PERFIL GENERAL — últimos 15",
        calculo["profiles"]["overall"],
    )

    imprimir_perfil(
        relevant_label,
        calculo["profiles"]["relevant"],
    )


# ==============================================================================
# 7. GUARDAR RESULTADO
# ==============================================================================

def guardar_resultado(
    evento: dict[str, Any],
    archivo_fuente: Path,
    local: dict[str, Any],
    visitante: dict[str, Any],
    bot10_context: dict[str, Any] | None = None,
) -> Path:
    event_id = int(evento["event_id"])

    resultado = {
        "generated_at": datetime.now(
            timezone.utc
        ).isoformat(),
        "source_file": str(archivo_fuente),
        "upcoming_match": evento,
        "weighting": {
            "matches_window": MATCHES_WINDOW,
            "recent_matches": RECENT_MATCHES,
            "recent_weight": RECENT_WEIGHT,
            "recent_weights_by_market": dict(RECENT_WEIGHT_BY_MARKET),
            "old_weight": OLD_WEIGHT,
            "null_policy": (
                "Los valores NULL se excluyen del promedio; "
                "nunca se convierten en cero."
            ),
        },
        "trained_model": ACTIVE_MODEL_METADATA,
        "home_team_analysis": local,
        "away_team_analysis": visitante,
        "bot10_context": bot10_context,
    }

    ruta = RATINGS_DIR / f"ratings_{event_id}.json"

    ruta.write_text(
        json.dumps(
            resultado,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    ultima = RATINGS_DIR / "ultimo_ratings.json"

    ultima.write_text(
        json.dumps(
            resultado,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    return ruta


# ==============================================================================
# 8. EJECUCIÓN
# ==============================================================================

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Calcula ratings ponderados y usa el peso reciente "
            "aprendido para la competición cuando está disponible."
        )
    )

    parser.add_argument(
        "match_json",
        nargs="?",
        help="JSON del próximo partido.",
    )

    parser.add_argument(
        "--key",
        help="Clave de competición, por ejemplo: mls.",
    )

    return parser



# ==============================================================================
# ODDSHUNTER_REGISTRY_HISTORY_SCOPE_V2_J1
# Continuidad doméstica exacta y dirigida por competitions.json.
# Solo actúa cuando una competición declara history_source_pairs.
# ==============================================================================
_OH_ORIGINAL_COMPETITION_HISTORY_SCOPE = competition_history_scope


def _oh_history_spec(competition_key: str | None) -> dict[str, Any] | None:
    if not competition_key or not REGISTRY_PATH.exists():
        return None
    try:
        document = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    rows = document.get("competitions")
    if not isinstance(rows, list):
        return None
    for row in rows:
        if (
            isinstance(row, dict)
            and str(row.get("key") or "").strip() == str(competition_key).strip()
        ):
            return row
    return None


def competition_history_scope(
    conn: sqlite3.Connection,
    competition_key: str | None,
) -> list[int] | None:
    specification = _oh_history_spec(competition_key)
    pairs = (
        list(specification.get("history_source_pairs") or [])
        if isinstance(specification, dict)
        else None
    )
    if isinstance(pairs, list) and pairs:
        # El historial complementa la temporada activa; no la reemplaza.
        # Excluirla congelaba los ratings en la campaña anterior y dejaba sin
        # datos a clubes que sí acumulan partidos en la campaña actual.
        pairs.append(
            {
                "tournament_id": specification.get(
                    "source_competition_id"
                ),
                "season_id": specification.get("season_id"),
            }
        )
        resolved: set[int] = set()
        for item in pairs:
            if isinstance(item, dict):
                tournament_id = item.get("tournament_id")
                season_id = item.get("season_id")
            elif isinstance(item, (list, tuple)) and len(item) >= 2:
                tournament_id, season_id = item[0], item[1]
            else:
                continue
            try:
                tournament_id = int(tournament_id)
                season_id = int(season_id)
            except (TypeError, ValueError):
                continue
            rows = conn.execute(
                """
                SELECT league_id
                FROM leagues
                WHERE source_tournament_id = ?
                  AND source_season_id = ?
                ORDER BY league_id
                """,
                (tournament_id, season_id),
            ).fetchall()
            resolved.update(
                int(row["league_id"])
                for row in rows
                if row["league_id"] is not None
            )
        if resolved:
            return sorted(resolved)
    return _OH_ORIGINAL_COMPETITION_HISTORY_SCOPE(conn, competition_key)


def competition_history_cutoff(
    competition_key: str | None,
    reference: datetime,
) -> str | None:
    specification = _oh_history_spec(competition_key)
    if not isinstance(specification, dict):
        return None
    try:
        days = int(specification.get("history_lookback_days") or 0)
    except (TypeError, ValueError):
        return None
    if days <= 0:
        return None
    return (reference - timedelta(days=days)).astimezone(timezone.utc).isoformat()


def main() -> None:
    # LEAGUES_CUP_CONTEXT_SEMANTIC_V4
    global RECENT_WEIGHT
    global ACTIVE_MODEL_METADATA

    args = build_parser().parse_args()

    try:
        fuente = archivo_proximo_partido(args.match_json)
        evento = cargar_proximo_partido(fuente)

        input_document = {
            "upcoming_match": evento,
        }

        competition_key = infer_competition_key(
            input_document,
            args.key,
        )

        trained_model = None
        trained_path = DATA_DIR / "trained_models" / "UNKNOWN" / "latest_model.json"
        goals_component = None
        goal_recent_weight = RECENT_WEIGHT_GOALS_XG

        if competition_key:
            trained_model, trained_path = load_latest_model(
                competition_key
            )
            goals_component = component_parameters(
                trained_model,
                "goals",
            )

        if goals_component:
            goal_recent_weight = numeric_parameter(
                goals_component.get("parameters"),
                "recent_weight",
                RECENT_WEIGHT_GOALS_XG,
                minimum=1.1746031746031746,
                maximum=1.1746031746031746,
            )

        ACTIVE_MODEL_METADATA = model_metadata(
            trained_model,
            trained_path,
            "goals",
        )
        ACTIVE_MODEL_METADATA["competition_key"] = competition_key
        ACTIVE_MODEL_METADATA["recent_weight_used"] = goal_recent_weight
        ACTIVE_MODEL_METADATA["recent_weights_by_market"] = dict(RECENT_WEIGHT_BY_MARKET)

        print("=" * 72)
        print("ODDSHUNTER — RATINGS Y PERFILES PONDERADOS")
        print("=" * 72)
        print(f"Base: {DB_PATH}")
        print(f"Próximo partido: {fuente.name}")
        print(
            f"{evento['home_team']} vs "
            f"{evento['away_team']}"
        )
        print()
        print("Pesos V4.4.6 por mercado | diez anteriores = 1.0")
        print(
            f"  goles/xG={goal_recent_weight:.2f} | "
            f"remates/SOT={RECENT_WEIGHT_SHOTS:.2f} | "
            f"córners={RECENT_WEIGHT_CORNERS:.2f} | "
            f"tarjetas={RECENT_WEIGHT_CARDS:.2f}"
        )
        print(
            "Origen del peso reciente: "
            + (
                f"modelo entrenado v{ACTIVE_MODEL_METADATA.get('version')}"
                if ACTIVE_MODEL_METADATA.get("available")
                else "configuración predeterminada"
            )
        )
        print(
            "Las métricas permanecen separadas; "
            "no se mezclan con porcentajes arbitrarios."
        )

        conn = get_connection()

        try:
            validar_esquema(conn)
            scoped_league_ids = competition_history_scope(
                conn,
                competition_key,
            )

            reference = datetime.now(timezone.utc)
            kickoff_text = str(evento.get("kickoff") or "").strip()
            if kickoff_text:
                try:
                    reference = datetime.fromisoformat(
                        kickoff_text.replace("Z", "+00:00")
                    )
                    if reference.tzinfo is None:
                        reference = reference.replace(tzinfo=timezone.utc)
                except ValueError:
                    pass
            event_cutoff = reference.astimezone(timezone.utc).isoformat()

            contextual_fallback_enabled = (
                context_scope_enabled(
                    competition_key
                )
            )

            local = calcular_equipo(
                conn,
                sofascore_id=int(
                    evento["home_team_id"]
                ),
                relevant_venue="HOME",
                league_ids=scoped_league_ids,
                kickoff_from=competition_history_cutoff(competition_key, reference),
                kickoff_before=event_cutoff,
                allow_empty=(contextual_fallback_enabled or competition_key == 'leagues-cup'),
                expected_name=str(
                    evento["home_team"]
                ),
            )

            visitante = calcular_equipo(
                conn,
                sofascore_id=int(
                    evento["away_team_id"]
                ),
                relevant_venue="AWAY",
                league_ids=scoped_league_ids,
                kickoff_from=competition_history_cutoff(competition_key, reference),
                kickoff_before=event_cutoff,
                allow_empty=(contextual_fallback_enabled or competition_key == 'leagues-cup'),
                expected_name=str(
                    evento["away_team"]
                ),
            )

            if (contextual_fallback_enabled or competition_key == 'leagues-cup'):
                add_bot10_context(
                    conn,
                    local,
                    int(
                        (local.get("team") or {}).get(
                            "sofascore_id"
                        )
                        or evento["home_team_id"]
                    ),
                    "HOME",
                    reference,
                    competition_key,
                    scoped_league_ids,
                )
                add_bot10_context(
                    conn,
                    visitante,
                    int(
                        (visitante.get("team") or {}).get(
                            "sofascore_id"
                        )
                        or evento["away_team_id"]
                    ),
                    "AWAY",
                    reference,
                    competition_key,
                    scoped_league_ids,
                )

        finally:
            conn.close()

        imprimir_equipo(
            local,
            "PERFIL COMO LOCAL — dentro de los últimos 15",
        )

        imprimir_equipo(
            visitante,
            "PERFIL COMO VISITANTE — dentro de los últimos 15",
        )

        ruta_salida = guardar_resultado(
            evento=evento,
            archivo_fuente=fuente,
            local=local,
            visitante=visitante,
            bot10_context=build_event_match_context(
                local,
                visitante,
                competition_key,
            ),
        )

        print()
        print("=" * 72)
        print("✅ CÁLCULO TERMINADO")
        print("=" * 72)
        print(f"Resultado guardado en:\n{ruta_salida}")
        print(
            "\nCopia actualizada también en:\n"
            f"{RATINGS_DIR / 'ultimo_ratings.json'}"
        )

    except KeyboardInterrupt:
        print("\n⚠️ Proceso interrumpido.")

    except Exception as exc:
        print()
        print(
            f"❌ Error: "
            f"{type(exc).__name__}: {exc}"
        )
        raise SystemExit(1)



# ============================================================================
# ODDSHUNTER_FRANCIA_PROFILE_ONLY_V10_4_3
# ============================================================================
import functools as _oh_functools_v1043
import inspect as _oh_inspect_v1043

_OH_ORIGINAL_CALCULAR_EQUIPO_PROFILE_V1042 = calcular_equipo
_OH_PROFILE_ONLY_LAST_V1042 = None

def _oh_registry_comp_v1043(_key):
    try:
        _doc = json.loads(REGISTRY_PATH.read_text(encoding="utf-8-sig"))
    except Exception:
        return None
    _rows = _doc.get("competitions") if isinstance(_doc, dict) else None
    if not isinstance(_rows, list):
        return None
    return next((_r for _r in _rows if isinstance(_r, dict) and str(_r.get("key") or "").strip() == _key), None)

def _oh_pair_league_ids_v1043(_conn, _pairs):
    if not isinstance(_pairs, list):
        return []
    _sql = "SELECT league_id FROM leagues WHERE source_tournament_id=? AND source_season_id=? ORDER BY league_id"
    _ids = set()
    for _item in _pairs:
        if not isinstance(_item, dict):
            continue
        try:
            _tid = int(_item.get("tournament_id"))
            _sid = int(_item.get("season_id"))
        except Exception:
            continue
        for _row in _conn.execute(_sql, (_tid, _sid)).fetchall():
            try:
                _value = _row["league_id"]
            except Exception:
                _value = _row[0]
            if _value is not None:
                _ids.add(int(_value))
    return sorted(_ids)

def _oh_profile_scope_for_team_v1043(
    _conn,
    _sofascore_id,
    _competition_key="ligue-1",
):
    _spec = _oh_registry_comp_v1043(_competition_key)
    if not isinstance(_spec, dict):
        return None
    _primary = _oh_pair_league_ids_v1043(_conn, _spec.get("history_source_pairs"))
    _profile = set()
    _allowed = False
    _pairs = _spec.get("profile_history_source_pairs")
    if isinstance(_pairs, list):
        for _item in _pairs:
            if not isinstance(_item, dict):
                continue
            _teams = _item.get("team_sofascore_ids")
            if not isinstance(_teams, list):
                continue
            try:
                _teams = {int(_x) for _x in _teams}
            except Exception:
                continue
            if int(_sofascore_id) not in _teams:
                continue
            _allowed = True
            _profile.update(_oh_pair_league_ids_v1043(_conn, [_item]))
    if not _allowed or not _profile:
        return None
    return {"primary": sorted(_primary), "profile": sorted(_profile)}

def _oh_cli_competition_key_v1043():
    import sys as _sys
    _argv = list(_sys.argv)
    for _index, _value in enumerate(_argv):
        if _value == "--key" and _index + 1 < len(_argv):
            return str(_argv[_index + 1]).strip().lower()
        if str(_value).startswith("--key="):
            return str(_value).split("=", 1)[1].strip().lower()
    return None

@_oh_functools_v1043.wraps(_OH_ORIGINAL_CALCULAR_EQUIPO_PROFILE_V1042)
def calcular_equipo(*args, **kwargs):
    global _OH_PROFILE_ONLY_LAST_V1042
    _sig = _oh_inspect_v1043.signature(_OH_ORIGINAL_CALCULAR_EQUIPO_PROFILE_V1042)
    _bound = _sig.bind_partial(*args, **kwargs)
    _conn = _bound.arguments.get("conn")
    _sid = _bound.arguments.get("sofascore_id")
    _league_ids = _bound.arguments.get("league_ids")
    if _conn is not None and _sid is not None and _league_ids is not None:
        try:
            _sid_int = int(_sid)
            _competition_key = _oh_cli_competition_key_v1043()
            # Se conserva intacta la ruta histórica de Ligue 1. Bundesliga
            # activa la misma continuidad doméstica solo porque su registro
            # declara explícitamente profile_history_source_pairs por equipo.
            _profile_key = (
                "bundesliga"
                if _competition_key == "bundesliga"
                else "ligue-1"
            )
            _scope = _oh_profile_scope_for_team_v1043(
                _conn,
                _sid_int,
                _profile_key,
            )
            _current = sorted({int(_x) for _x in _league_ids})
        except Exception:
            _scope = None
            _current = None
        if isinstance(_scope, dict) and _current == _scope.get("primary") and _scope.get("profile"):
            _bound.arguments["league_ids"] = list(_scope["profile"])
            _OH_PROFILE_ONLY_LAST_V1042 = {
                "sofascore_id": _sid_int,
                "from_scope": list(_current),
                "to_scope": list(_scope["profile"]),
            }
            return _OH_ORIGINAL_CALCULAR_EQUIPO_PROFILE_V1042(*_bound.args, **_bound.kwargs)
    return _OH_ORIGINAL_CALCULAR_EQUIPO_PROFILE_V1042(*args, **kwargs)


# ============================================================================
# ODDSHUNTER_PREMIER_PROMOTED_PROFILE_RUNTIME_V1
# Si el scope primario Premier no tiene filas para Coventry/Hull/Ipswich,
# reintenta exclusivamente con el profile_history_source_pairs real
# Championship 2025/26. NO altera entrenamiento ni SQLite.
# ============================================================================

_oh_calcular_equipo_before_premier_profile_v1 = calcular_equipo

def _oh_premier_profile_scope_v1(
    _conn,
    _sofascore_id,
    _incoming_league_ids,
):
    try:
        _sid = int(_sofascore_id)
    except Exception:
        return []

    if _sid not in {11, 96, 32}:
        return []

    try:
        _incoming = {
            int(_x)
            for _x in (
                _incoming_league_ids
                or []
            )
        }
    except Exception:
        return []

    if not _incoming:
        return []

    try:
        _doc = json.loads(
            REGISTRY_PATH.read_text(
                encoding="utf-8-sig"
            )
        )
    except Exception:
        return []

    _spec = None

    for _item in (
        _doc.get("competitions")
        or []
    ):
        if (
            isinstance(_item, dict)
            and str(
                _item.get("key")
                or ""
            ).strip().lower()
            == "premier-league"
        ):
            _spec = _item
            break

    if not isinstance(
        _spec,
        dict,
    ):
        return []

    def _resolve_pairs(_pairs):
        _ids = set()

        for _pair in (
            _pairs
            or []
        ):
            if not isinstance(
                _pair,
                dict,
            ):
                continue

            try:
                _tid = int(
                    _pair.get(
                        "tournament_id"
                    )
                )

                _season = int(
                    _pair.get(
                        "season_id"
                    )
                )

            except Exception:
                continue

            _rows = _conn.execute(
                """
                SELECT league_id
                FROM leagues
                WHERE source_tournament_id = ?
                  AND source_season_id = ?
                ORDER BY league_id
                """,
                (
                    _tid,
                    _season,
                ),
            ).fetchall()

            for _row in _rows:

                try:
                    _value = int(
                        _row["league_id"]
                    )
                except Exception:
                    _value = int(
                        _row[0]
                    )

                _ids.add(
                    _value
                )

        return sorted(
            _ids
        )

    _primary_pairs = list(
        _spec.get(
            "history_source_pairs"
        )
        or []
    )

    # También incluye la temporada actual
    # para confirmar que la llamada realmente
    # pertenece al scope Premier.
    try:
        _current_tid = int(
            _spec.get(
                "tournament_id"
            )
        )

        _current_season = int(
            _spec.get(
                "season_id"
            )
        )

        _primary_pairs.append(
            {
                "tournament_id": _current_tid,
                "season_id": _current_season,
            }
        )

    except Exception:
        pass

    _primary_ids = set(
        _resolve_pairs(
            _primary_pairs
        )
    )

    if not (
        _incoming
        & _primary_ids
    ):
        return []

    _profile_pairs = []

    for _pair in (
        _spec.get(
            "profile_history_source_pairs"
        )
        or []
    ):

        if not isinstance(
            _pair,
            dict,
        ):
            continue

        try:
            _teams = {
                int(_x)
                for _x in (
                    _pair.get(
                        "team_sofascore_ids"
                    )
                    or []
                )
            }
        except Exception:
            continue

        if _sid in _teams:
            _profile_pairs.append(
                _pair
            )

    return _resolve_pairs(
        _profile_pairs
    )


def calcular_equipo(
    *args,
    **kwargs,
):
    try:
        return (
            _oh_calcular_equipo_before_premier_profile_v1(
                *args,
                **kwargs,
            )
        )

    except RuntimeError as _original_error:

        _message = str(
            _original_error
        )

        if (
            "No hay partidos guardados"
            not in _message
        ):
            raise

        _conn = (
            kwargs.get("conn")
            if "conn" in kwargs
            else (
                args[0]
                if len(args) >= 1
                else None
            )
        )

        _sid = (
            kwargs.get(
                "sofascore_id"
            )
            if "sofascore_id" in kwargs
            else (
                args[1]
                if len(args) >= 2
                else None
            )
        )

        _incoming = kwargs.get(
            "league_ids"
        )

        if (
            _incoming is None
            and len(args) >= 4
        ):
            _incoming = args[3]

        if (
            _conn is None
            or _sid is None
        ):
            raise

        _profile_ids = (
            _oh_premier_profile_scope_v1(
                _conn,
                _sid,
                _incoming,
            )
        )

        if not _profile_ids:
            raise

        print(
            "[PROFILE_HISTORY_SCOPE] "
            f"key=premier-league "
            f"sid={int(_sid)} "
            f"league_ids={_profile_ids}"
        )

        _new_args = list(
            args
        )

        _new_kwargs = dict(
            kwargs
        )

        if "league_ids" in _new_kwargs:

            _new_kwargs[
                "league_ids"
            ] = _profile_ids

        elif len(_new_args) >= 4:

            _new_args[3] = (
                _profile_ids
            )

        else:

            _new_kwargs[
                "league_ids"
            ] = _profile_ids

        if (
            "context_name"
            in _new_kwargs
        ):
            _new_kwargs[
                "context_name"
            ] = (
                "PROMOTED_TEAM_PROFILE_ONLY"
            )

        return (
            _oh_calcular_equipo_before_premier_profile_v1(
                *_new_args,
                **_new_kwargs,
            )
        )

# ============================================================================
# FIN ODDSHUNTER_PREMIER_PROMOTED_PROFILE_RUNTIME_V1
# ============================================================================

# ============================================================================
# FIN ODDSHUNTER_FRANCIA_PROFILE_ONLY_V10_4_3
# ============================================================================



# ==============================================================================
# ODDSHUNTER_LALIGA_PROMOTED_CURRENT_PLUS_PROFILE_V1
# ==============================================================================

_OH_LALIGA_PROMOTED_ORIGINAL_CALCULAR_V1 = calcular_equipo

_OH_LALIGA_PROMOTED_SIDS_V1 = {
    2830,
    2832,
    2835,
}

_OH_LALIGA_PROMOTED_SCOPE_V1 = [
    15251,
    17540,
]


def _oh_laliga_competition_key_v1():
    import json as _json
    import sys as _sys
    from pathlib import Path as _Path

    _argv = list(_sys.argv)

    for _index, _value in enumerate(_argv):

        if str(_value).strip() != "--key":
            continue

        if _index + 1 >= len(_argv):
            continue

        _key = str(
            _argv[
                _index + 1
            ]
        ).strip()

        if _key:
            return _key.lower()

    for _value in _argv[1:]:

        try:
            _path = _Path(
                str(_value)
            )
        except Exception:
            continue

        if not _path.exists():
            continue

        if _path.suffix.lower() != ".json":
            continue

        try:
            _doc = _json.loads(
                _path.read_text(
                    encoding="utf-8-sig"
                )
            )
        except Exception:
            continue

        if not isinstance(
            _doc,
            dict,
        ):
            continue

        _key = str(
            _doc.get(
                "competition_key"
            )
            or ""
        ).strip().lower()

        if _key:
            return _key

    return ""


def _oh_laliga_sid_v1(
    _args,
    _kwargs,
):
    _value = _kwargs.get(
        "sofascore_id"
    )

    if _value is None and len(
        _args
    ) >= 2:
        _value = _args[1]

    try:
        return int(_value)
    except Exception:
        return None


def calcular_equipo(
    *_args,
    **_kwargs,
):
    _key = (
        _oh_laliga_competition_key_v1()
    )

    _sid = (
        _oh_laliga_sid_v1(
            _args,
            _kwargs,
        )
    )

    if (
        _key == "laliga"
        and _sid
        in _OH_LALIGA_PROMOTED_SIDS_V1
    ):
        _kwargs = dict(
            _kwargs
        )

        _kwargs[
            "league_ids"
        ] = list(
            _OH_LALIGA_PROMOTED_SCOPE_V1
        )

        print(
            "[LALIGA_PROMOTED_SCOPE] "
            f"sid={_sid} "
            f"league_ids="
            f"{_OH_LALIGA_PROMOTED_SCOPE_V1}"
        )

    return (
        _OH_LALIGA_PROMOTED_ORIGINAL_CALCULAR_V1(
            *_args,
            **_kwargs
        )
    )


# ==============================================================================
# FIN ODDSHUNTER_LALIGA_PROMOTED_CURRENT_PLUS_PROFILE_V1
# ==============================================================================

# ============================================================================
# ODDSHUNTER_ACTIVE_PROFILE_SCOPE_V2_2_7
# REAL CLI FIX: executes BEFORE ratings.py main().
# ============================================================================
import json as _oh_v227_json
import sys as _oh_v227_sys
from pathlib import Path as _oh_v227_Path

_OH_V227_TARGET_KEYS = (
    "greece-stoiximan-super-league",
    "championship",
    "turkey-super-lig",
    "saudi-pro-league",
    "serie-a",
)
_OH_V227_ORIG_CALCULAR_EQUIPO = calcular_equipo

def _oh_v227_cli_key():
    _argv = list(_oh_v227_sys.argv)
    for _i, _x in enumerate(_argv):
        if str(_x) == "--key" and _i + 1 < len(_argv):
            return str(_argv[_i + 1]).strip()
    return None

def _oh_v227_registry_spec(_key):
    if _key not in _OH_V227_TARGET_KEYS:
        return None
    _p = _oh_v227_Path(__file__).resolve().parent / "data" / "competitions.json"
    try:
        _doc = _oh_v227_json.loads(_p.read_text(encoding="utf-8-sig"))
        _rows = _doc.get("competitions") if isinstance(_doc, dict) else _doc
        if not isinstance(_rows, list):
            return None
        return next(
            (_x for _x in _rows
             if isinstance(_x, dict) and str(_x.get("key")) == _key),
            None,
        )
    except Exception:
        return None

def _oh_v227_profile_ids(_conn, _key, _sid):
    _spec = _oh_v227_registry_spec(_key)
    if not isinstance(_spec, dict):
        return None
    try:
        _sid = int(_sid)
    except Exception:
        return None

    _pairs = []
    for _item in _spec.get("profile_history_source_pairs") or []:
        if not isinstance(_item, dict):
            continue
        _teams = set()
        for _x in _item.get("team_sofascore_ids") or []:
            try:
                _teams.add(int(_x))
            except Exception:
                pass
        if _sid in _teams:
            _pairs.append(_item)

    if not _pairs:
        return None

    _ids = set()
    for _item in _pairs:
        try:
            _tid = int(_item.get("tournament_id"))
            _season = int(_item.get("season_id"))
        except Exception:
            continue
        for _row in _conn.execute(
            "SELECT league_id FROM leagues "
            "WHERE source_tournament_id=? AND source_season_id=? "
            "ORDER BY league_id",
            (_tid, _season),
        ).fetchall():
            try:
                _ids.add(int(_row[0]))
            except Exception:
                pass
    return sorted(_ids) or None

def calcular_equipo(*_args, **_kwargs):
    _key = _oh_v227_cli_key()
    if _key not in _OH_V227_TARGET_KEYS:
        return _OH_V227_ORIG_CALCULAR_EQUIPO(*_args, **_kwargs)

    _conn = _kwargs.get("conn") or _kwargs.get("connection")
    if _conn is None and len(_args) >= 1:
        _conn = _args[0]

    _sid = _kwargs.get("sofascore_id")
    if _sid is None and len(_args) >= 2:
        _sid = _args[1]

    if _conn is None or _sid is None:
        return _OH_V227_ORIG_CALCULAR_EQUIPO(*_args, **_kwargs)

    _profile = _oh_v227_profile_ids(_conn, _key, _sid)
    if not _profile:
        return _OH_V227_ORIG_CALCULAR_EQUIPO(*_args, **_kwargs)

    _new_args = list(_args)
    _new_kwargs = dict(_kwargs)

    if len(_new_args) >= 4:
        _new_args[3] = list(_profile)
        _new_kwargs.pop("league_ids", None)
    else:
        _new_kwargs["league_ids"] = list(_profile)

    if len(_new_args) >= 5:
        _new_args[4] = None
        _new_kwargs.pop("kickoff_from", None)
    elif "kickoff_from" in _new_kwargs:
        _new_kwargs["kickoff_from"] = None

    print(
        "[PROFILE_HISTORY_SCOPE_ACTIVE_V2_2_7] "
        f"key={_key} sid={int(_sid)} league_ids={list(_profile)}"
    )
    return _OH_V227_ORIG_CALCULAR_EQUIPO(*_new_args, **_new_kwargs)
# ============================================================================
# FIN ODDSHUNTER_ACTIVE_PROFILE_SCOPE_V2_2_7
# ============================================================================

if __name__ == "__main__":
    main()
