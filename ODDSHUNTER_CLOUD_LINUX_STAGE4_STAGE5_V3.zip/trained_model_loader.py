from __future__ import annotations

import json
import math
import re
from pathlib import Path
from typing import Any


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
REGISTRY_PATH = DATA_DIR / "competitions.json"
TRAINED_MODELS_DIR = DATA_DIR / "trained_models"


def slugify(text: str) -> str:
    value = text.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-")


def read_json_optional(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None

    return data if isinstance(data, dict) else None


def load_latest_model(
    competition_key: str,
) -> tuple[dict[str, Any] | None, Path]:
    key = slugify(competition_key)
    path = TRAINED_MODELS_DIR / key / "latest_model.json"
    return read_json_optional(path), path


def infer_competition_key(
    document: dict[str, Any],
    explicit_key: str | None = None,
) -> str | None:
    if explicit_key:
        return slugify(explicit_key)

    event = document.get("upcoming_match")

    if not isinstance(event, dict):
        event = document.get("evento")

    candidates: list[str] = []

    if isinstance(event, dict):
        for field in (
            "competition_key",
            "key",
            "competicion",
            "competition_name",
            "competition",
        ):
            value = event.get(field)

            if isinstance(value, str) and value.strip():
                candidates.append(value)

    competition = document.get("competition")

    if isinstance(competition, dict):
        for field in ("key", "name"):
            value = competition.get(field)

            if isinstance(value, str) and value.strip():
                candidates.append(value)

    registry = read_json_optional(REGISTRY_PATH) or {}
    competitions = registry.get("competitions", [])

    if isinstance(competitions, list):
        for candidate in candidates:
            normalized = slugify(candidate)

            for item in competitions:
                if not isinstance(item, dict):
                    continue

                item_key = slugify(str(item.get("key") or ""))
                item_name = slugify(str(item.get("name") or ""))

                if normalized in {item_key, item_name}:
                    return item_key

    trained = sorted(
        path.parent.name
        for path in TRAINED_MODELS_DIR.glob("*/latest_model.json")
        if path.is_file()
    )

    if len(trained) == 1:
        return trained[0]

    return None


def component_parameters(
    model: dict[str, Any] | None,
    component: str,
) -> dict[str, Any] | None:
    if not isinstance(model, dict):
        return None

    section = model.get(component)

    if not isinstance(section, dict):
        return None

    if component == "goals":
        parameters = section.get("parameters")

        if not isinstance(parameters, dict):
            return None

        return {
            "family": "poisson_dixon_coles",
            "parameters": dict(parameters),
            "validation_metrics": section.get("validation_metrics"),
        }

    family = str(section.get("selected_family") or "poisson")
    family_section = section.get(family)

    if not isinstance(family_section, dict):
        return None

    parameters = family_section.get("parameters")

    if not isinstance(parameters, dict):
        return None

    result = {
        "family": family,
        "parameters": dict(parameters),
        "validation_metrics": family_section.get("validation_metrics"),
    }

    if family == "negative_binomial":
        result["size"] = family_section.get("size")

    return result


def numeric_parameter(
    parameters: dict[str, Any] | None,
    name: str,
    default: float,
    minimum: float | None = None,
    maximum: float | None = None,
) -> float:
    value: Any = default

    if isinstance(parameters, dict):
        value = parameters.get(name, default)

    try:
        number = float(value)
    except (TypeError, ValueError):
        number = float(default)

    if not math.isfinite(number):
        number = float(default)

    if minimum is not None:
        number = max(minimum, number)

    if maximum is not None:
        number = min(maximum, number)

    return number


def model_metadata(
    model: dict[str, Any] | None,
    path: Path,
    component: str,
) -> dict[str, Any]:
    if not isinstance(model, dict):
        return {
            "available": False,
            "path": str(path),
            "component": component,
            "reason": "No existe un modelo entrenado vigente.",
        }

    resolved_component = component_parameters(model, component)
    if not isinstance(resolved_component, dict):
        return {
            "available": False,
            "path": str(path),
            "component": component,
            "version": model.get("version"),
            "reason": f"El modelo vigente no contiene el componente '{component}'.",
        }

    competition = model.get("competition")
    data = model.get("data")
    return {
        "available": True,
        "path": str(path),
        "component": component,
        "version": model.get("version"),
        "generated_at": model.get("generated_at"),
        "model_type": model.get("model_type"),
        "competition": dict(competition) if isinstance(competition, dict) else None,
        "parameters": dict(resolved_component.get("parameters") or {}),
        "validation_metrics": resolved_component.get("validation_metrics"),
        "training_data": dict(data) if isinstance(data, dict) else None,
        "source": "latest_model.json promovido mediante validación temporal walk-forward",
        "promotion": model.get("promotion"),
    }