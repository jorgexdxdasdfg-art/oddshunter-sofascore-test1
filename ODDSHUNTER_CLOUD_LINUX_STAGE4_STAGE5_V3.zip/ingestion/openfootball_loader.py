from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Optional

import pandas as pd


ROOT = Path(
    r"data\raw\openfootball"
)

COVERAGE_JSON = Path(
    r"data\manifests\openfootball_coverage_2023_2026.json"
)

AUDIT_OUTPUT = Path(
    r"data\manifests\OPENFOOTBALL_LOADER_AUDIT.txt"
)


MONTHS = {
    "Jan": 1,
    "Feb": 2,
    "Mar": 3,
    "Apr": 4,
    "May": 5,
    "Jun": 6,
    "Jul": 7,
    "Aug": 8,
    "Sep": 9,
    "Oct": 10,
    "Nov": 11,
    "Dec": 12,
}


DATE_RE = re.compile(
    r"""
    ^\s*
    (?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)
    \s+
    (?P<month>
        Jan|Feb|Mar|Apr|May|Jun|
        Jul|Aug|Sep|Oct|Nov|Dec
    )
    \s+
    (?P<day>\d{1,2})
    (?:\s+(?P<year>\d{4}))?
    \s*$
    """,
    re.VERBOSE,
)


MATCH_RE = re.compile(
    r"""
    ^\s*
    (?:
        (?P<time>\d{1,2}:\d{2})
        \s+
    )?
    (?P<home>.+?)
    \s+v\s+
    (?P<away>.+?)
    \s+
    (?P<result>
        \d+\s*-\s*\d+
        .*
    )
    \s*$
    """,
    re.VERBOSE,
)


LEADING_SCORE_RE = re.compile(
    r"""
    ^\s*
    (?P<home>\d+)
    \s*-\s*
    (?P<away>\d+)
    """,
    re.VERBOSE,
)


SCORE_PAIR_RE = re.compile(
    r"""
    (?P<home>\d+)
    \s*-\s*
    (?P<away>\d+)
    """,
    re.VERBOSE,
)


TITLE_SEASON_RE = re.compile(
    r"""
    (?P<season>
        20\d{2}
        (?:
            /
            \d{2,4}
        )?
    )
    \s*$
    """,
    re.VERBOSE,
)


HEADER_MATCHES_RE = re.compile(
    r"""
    ^\s*
    \#\s*Matches
    \s+
    (?P<count>\d+)
    """,
    re.VERBOSE,
)


HEADER_TEAMS_RE = re.compile(
    r"""
    ^\s*
    \#\s*Teams
    \s+
    (?P<count>\d+)
    """,
    re.VERBOSE,
)


@dataclass
class FileParseResult:

    path: Path
    dataframe: pd.DataFrame

    competition_title: str
    season_label: str

    header_matches: Optional[int]
    header_teams: Optional[int]

    score_like_unparsed: list[
        tuple[int, str]
    ]

    rows_without_date: int


def normalize_space(
    value: str,
) -> str:

    return re.sub(
        r"\s+",
        " ",
        str(value),
    ).strip()


def get_title(
    lines: list[str],
) -> str:

    for line in lines:

        stripped = line.strip()

        if stripped.startswith("="):

            title = stripped.lstrip(
                "="
            ).strip()

            if title:
                return title

    return ""


def get_season_label(
    title: str,
    path: Path,
) -> str:

    match = TITLE_SEASON_RE.search(
        title
    )

    if match:
        return match.group(
            "season"
        )

    filename = path.stem

    match = re.search(
        r"""
        (?P<season>
            20\d{2}
            (?:-\d{2})?
        )
        """,
        filename,
        re.VERBOSE,
    )

    if match:
        return match.group(
            "season"
        )

    return ""


def start_year_from_season(
    season_label: str,
) -> Optional[int]:

    match = re.search(
        r"20\d{2}",
        season_label,
    )

    if not match:
        return None

    return int(
        match.group(0)
    )


def parse_stage(
    value: str,
) -> tuple[
    Optional[str],
    Optional[str],
]:

    text = normalize_space(
        value
    )

    if not text:
        return None, None

    if "," in text:

        left, right = text.split(
            ",",
            1,
        )

        stage_name = normalize_space(
            left
        )

        round_label = normalize_space(
            right
        )

        return (
            stage_name or None,
            round_label or None,
        )

    return (
        None,
        text,
    )


def parse_date_line(
    line: str,
    *,
    current_year: Optional[int],
    previous_date: Optional[date],
    fallback_year: Optional[int],
) -> tuple[
    Optional[date],
    Optional[int],
]:
    match = DATE_RE.match(
        line
    )

    if not match:
        return None, current_year

    month = MONTHS[
        match.group(
            "month"
        )
    ]

    day = int(
        match.group(
            "day"
        )
    )

    explicit_year = match.group(
        "year"
    )

    weekday_token = (
        str(line)
        .strip()
        .split()[0][:3]
        .title()
    )

    if explicit_year:
        year = int(
            explicit_year
        )

        parsed = date(
            year,
            month,
            day,
        )

        return parsed, year

    candidate_years: set[int] = set()

    if fallback_year is not None:
        candidate_years.update(
            {
                fallback_year - 1,
                fallback_year,
                fallback_year + 1,
                fallback_year + 2,
            }
        )

    if current_year is not None:
        candidate_years.update(
            {
                current_year - 1,
                current_year,
                current_year + 1,
            }
        )

    candidates: list[date] = []

    for year in sorted(
        candidate_years
    ):
        try:
            candidate = date(
                year,
                month,
                day,
            )
        except ValueError:
            continue

        if (
            candidate.strftime("%a")
            ==
            weekday_token
        ):
            candidates.append(
                candidate
            )

    if len(candidates) == 1:
        parsed = candidates[0]
        return parsed, parsed.year

    if (
        len(candidates) > 1
        and previous_date is not None
    ):
        candidates.sort(
            key=lambda item: abs(
                (
                    item
                    -
                    previous_date
                ).days
            )
        )

        best = candidates[0]

        if (
            abs((
                candidates[0]
                - previous_date
            ).days)
            <
            abs((
                candidates[1]
                - previous_date
            ).days)
        ):
            return best, best.year

    raise ValueError(
        "No pude resolver ano de fecha OpenFootball: "
        f"line={line!r} "
        f"fallback_year={fallback_year} "
        f"current_year={current_year} "
        f"previous_date={previous_date} "
        f"candidates={candidates}"
    )


def parse_result(
    result_raw: str,
) -> dict:

    raw = normalize_space(
        result_raw
    )

    lower = raw.casefold()

    leading = LEADING_SCORE_RE.match(
        raw
    )

    if not leading:

        raise ValueError(
            f"Resultado inválido: {raw}"
        )

    home_goals = int(
        leading.group(
            "home"
        )
    )

    away_goals = int(
        leading.group(
            "away"
        )
    )

    is_awarded = (
        "[awarded]" in lower
        or "awarded" in lower
    )

    is_penalty = (
        "pen." in lower
        or "penalties" in lower
        or "penalty" in lower
    )

    is_extra_time = (
        "a.e.t." in lower
        or "extra time" in lower
    )

    special_result = (
        is_awarded
        or is_penalty
        or is_extra_time
    )

    home_goals_1h = None
    away_goals_1h = None

    halftime_ambiguous = False

    parenthetical = re.findall(
        r"\(([^()]*)\)",
        raw,
    )

    if parenthetical:

        content = parenthetical[-1]

        pairs = list(
            SCORE_PAIR_RE.finditer(
                content
            )
        )

        # Sólo aceptamos como descanso una pareja única.
        #
        # Ejemplo seguro:
        # (1-0)
        #
        # Ejemplo ambiguo:
        # (1-1, 0-0)
        if (
            len(pairs) == 1
            and "," not in content
            and not is_penalty
            and not is_extra_time
        ):

            home_goals_1h = int(
                pairs[0].group(
                    "home"
                )
            )

            away_goals_1h = int(
                pairs[0].group(
                    "away"
                )
            )

        elif pairs:
            halftime_ambiguous = True

    home_goals_2h = None
    away_goals_2h = None

    invalid_period_math = False

    if (
        home_goals_1h is not None
        and away_goals_1h is not None
        and not special_result
    ):

        calculated_home_2h = (
            home_goals
            -
            home_goals_1h
        )

        calculated_away_2h = (
            away_goals
            -
            away_goals_1h
        )

        if (
            calculated_home_2h < 0
            or calculated_away_2h < 0
        ):

            invalid_period_math = True

        else:

            home_goals_2h = (
                calculated_home_2h
            )

            away_goals_2h = (
                calculated_away_2h
            )

    review_required = (
        special_result
        or halftime_ambiguous
        or invalid_period_math
    )

    # Para rendimiento histórico:
    #
    # AWARDED:
    # no fue un partido disputado normalmente.
    #
    # PEN / AET:
    # no asumimos que el primer score represente
    # exactamente los 90 minutos.
    usable_for_performance = (
        not special_result
        and not invalid_period_math
    )

    ft_score_trusted = (
        not is_penalty
        and not is_extra_time
    )

    return {
        "home_goals":
            home_goals,

        "away_goals":
            away_goals,

        "home_goals_1h":
            home_goals_1h,

        "away_goals_1h":
            away_goals_1h,

        "home_goals_2h":
            home_goals_2h,

        "away_goals_2h":
            away_goals_2h,

        "has_halftime":
            (
                home_goals_1h
                is not None
                and
                away_goals_1h
                is not None
            ),

        "is_awarded":
            is_awarded,

        "is_penalty":
            is_penalty,

        "is_extra_time":
            is_extra_time,

        "halftime_ambiguous":
            halftime_ambiguous,

        "invalid_period_math":
            invalid_period_math,

        "review_required":
            review_required,

        "usable_for_performance":
            usable_for_performance,

        "ft_score_trusted":
            ft_score_trusted,

        "result_raw":
            raw,
    }


def repository_info(
    path: Path,
) -> tuple[
    str,
    str,
    str,
]:

    try:

        relative = path.resolve().relative_to(
            ROOT.resolve()
        )

    except ValueError:

        return (
            "",
            "",
            str(path),
        )

    parts = relative.parts

    repository = (
        parts[0]
        if len(parts) >= 1
        else ""
    )

    top_group = (
        parts[1]
        if len(parts) >= 2
        else ""
    )

    relative_inside_repo = (
        Path(*parts[1:]).as_posix()
        if len(parts) >= 2
        else relative.as_posix()
    )

    return (
        repository,
        top_group,
        relative_inside_repo,
    )


def load_file(
    path: str | Path,
) -> FileParseResult:

    path = Path(
        path
    )

    if not path.exists():
        raise FileNotFoundError(
            path
        )

    lines = path.read_text(
        encoding="utf-8-sig",
        errors="replace",
    ).splitlines()

    title = get_title(
        lines
    )

    season_label = get_season_label(
        title,
        path,
    )

    fallback_year = start_year_from_season(
        season_label
    )

    header_matches = None
    header_teams = None

    for line in lines[:40]:

        match = HEADER_MATCHES_RE.match(
            line
        )

        if match:
            header_matches = int(
                match.group(
                    "count"
                )
            )

        match = HEADER_TEAMS_RE.match(
            line
        )

        if match:
            header_teams = int(
                match.group(
                    "count"
                )
            )

    (
        repository,
        top_group,
        relative_path,
    ) = repository_info(
        path
    )

    current_stage_label = None
    current_stage_name = None
    current_round_label = None

    current_date = None
    current_year = fallback_year

    previous_date = None

    rows = []

    score_like_unparsed = []

    rows_without_date = 0

    for line_number, line in enumerate(
        lines,
        start=1,
    ):

        stripped = line.strip()

        if not stripped:
            continue

        # ----------------------------------------
        # STAGE / ROUND
        # ----------------------------------------

        if stripped.startswith(
            ("▪", "•")
        ):

            current_stage_label = (
                stripped[1:].strip()
            )

            (
                current_stage_name,
                current_round_label,
            ) = parse_stage(
                current_stage_label
            )

            continue

        # ----------------------------------------
        # DATE
        # ----------------------------------------

        parsed_date, parsed_year = (
            parse_date_line(
                stripped,
                current_year=current_year,
                previous_date=previous_date,
                fallback_year=fallback_year,
            )
        )

        if parsed_date is not None:

            current_date = parsed_date
            previous_date = parsed_date
            current_year = parsed_year

            continue

        # ----------------------------------------
        # MATCH
        # ----------------------------------------

        match = MATCH_RE.match(
            line
        )

        if not match:

            if (
                " v " in line
                and re.search(
                    r"\d+\s*-\s*\d+",
                    line,
                )
            ):

                score_like_unparsed.append(
                    (
                        line_number,
                        line.rstrip(),
                    )
                )

            continue

        if current_date is None:

            rows_without_date += 1

        home_team = normalize_space(
            match.group(
                "home"
            )
        )

        away_team = normalize_space(
            match.group(
                "away"
            )
        )

        kickoff_time = match.group(
            "time"
        )

        if kickoff_time:
            kickoff_time = kickoff_time.strip()

        result = parse_result(
            match.group(
                "result"
            )
        )

        row = {
            "source":
                "openfootball",

            "repository":
                repository,

            "top_group":
                top_group,

            "source_file":
                relative_path,

            "source_line":
                line_number,

            "competition_title":
                title,

            "season_label":
                season_label,

            "stage_label":
                current_stage_label,

            "stage_name":
                current_stage_name,

            "round_label":
                current_round_label,

            # IMPORTANTE:
            # fecha y hora local separadas.
            #
            # NO inventar UTC.
            "match_date":
                (
                    current_date.isoformat()
                    if current_date
                    else None
                ),

            "kickoff_time_local":
                kickoff_time,

            "home_team":
                home_team,

            "away_team":
                away_team,
        }

        row.update(
            result
        )

        rows.append(
            row
        )

    df = pd.DataFrame(
        rows
    )

    expected_columns = [
        "source",
        "repository",
        "top_group",
        "source_file",
        "source_line",
        "competition_title",
        "season_label",
        "stage_label",
        "stage_name",
        "round_label",
        "match_date",
        "kickoff_time_local",
        "home_team",
        "away_team",
        "home_goals",
        "away_goals",
        "home_goals_1h",
        "away_goals_1h",
        "home_goals_2h",
        "away_goals_2h",
        "has_halftime",
        "is_awarded",
        "is_penalty",
        "is_extra_time",
        "halftime_ambiguous",
        "invalid_period_math",
        "review_required",
        "usable_for_performance",
        "ft_score_trusted",
        "result_raw",
    ]

    if df.empty:

        df = pd.DataFrame(
            columns=expected_columns
        )

    else:

        df = df.reindex(
            columns=expected_columns
        )

    return FileParseResult(
        path=path,
        dataframe=df,
        competition_title=title,
        season_label=season_label,
        header_matches=header_matches,
        header_teams=header_teams,
        score_like_unparsed=(
            score_like_unparsed
        ),
        rows_without_date=(
            rows_without_date
        ),
    )


def load_target_files() -> list[
    FileParseResult
]:
    if not COVERAGE_JSON.exists():
        raise FileNotFoundError(
            COVERAGE_JSON
        )

    payload = json.loads(
        COVERAGE_JSON.read_text(
            encoding="utf-8-sig"
        )
    )

    allowed = {
        ("south-america", "argentina"),
        ("south-america", "brazil"),
        ("south-america", "colombia"),
        ("south-america", "ecuador"),
        ("south-america", "paraguay"),
        ("south-america", "copa-libertadores"),
        ("world", "central-america"),
        ("world", "north-america"),
    }

    results = []

    for item in payload["files"]:
        if not item.get("target_2023_2026"):
            continue

        repository = item["repository"]
        top_group = item["top_group"]

        if (repository, top_group) not in allowed:
            continue

        relative_path = Path(item["relative_path"])

        full_path = (
            ROOT
            / repository
            / relative_path
        )

        if not full_path.exists():
            continue

        results.append(
            load_file(full_path)
        )

    return results


def load_targets_dataframe() -> pd.DataFrame:

    parsed_files = load_target_files()

    frames = [
        result.dataframe
        for result in parsed_files
        if not result.dataframe.empty
    ]

    if not frames:

        return pd.DataFrame()

    return pd.concat(
        frames,
        ignore_index=True,
    )


def self_test() -> None:

    print(
        "OPENFOOTBALL LOADER SELF TEST"
    )

    print(
        "=" * 70
    )

    test_files = [
        ROOT
        / "south-america"
        / "argentina"
        / "2023_ar1.txt",

        ROOT
        / "south-america"
        / "brazil"
        / "2025_brcup.txt",

        ROOT
        / "south-america"
        / "colombia"
        / "2024_co1.txt",

        ROOT
        / "south-america"
        / "ecuador"
        / "2025_ec1.txt",

        ROOT
        / "south-america"
        / "paraguay"
        / "2025_py1.txt",

        ROOT
        / "world"
        / "central-america"
        / "costa-rica"
        / "2024-25_cr1.txt",

        ROOT
        / "world"
        / "north-america"
        / "mexico"
        / "2024-25_mx2expansion.txt",
    ]

    tested = 0

    parsed_total = 0

    for path in test_files:

        if not path.exists():

            print(
                "SKIP missing:",
                path,
            )

            continue

        result = load_file(
            path
        )

        df = result.dataframe

        if df.empty:

            raise RuntimeError(
                f"0 partidos parseados: {path}"
            )

        if (
            result.rows_without_date
            != 0
        ):

            raise RuntimeError(
                f"Partidos sin fecha: {path}"
            )

        if (
            result.score_like_unparsed
        ):

            raise RuntimeError(
                "Líneas de resultado no parseadas "
                f"en {path}: "
                f"{result.score_like_unparsed[:3]}"
            )

        tested += 1
        parsed_total += len(
            df
        )

        print("")
        print(
            path.as_posix()
        )

        print(
            "  title       =",
            result.competition_title,
        )

        print(
            "  rows        =",
            len(df),
        )

        print(
            "  with HT     =",
            int(
                df[
                    "has_halftime"
                ].sum()
            ),
        )

        print(
            "  review      =",
            int(
                df[
                    "review_required"
                ].sum()
            ),
        )

        print(
            "  awarded     =",
            int(
                df[
                    "is_awarded"
                ].sum()
            ),
        )

        print(
            "  penalties   =",
            int(
                df[
                    "is_penalty"
                ].sum()
            ),
        )

        print(
            "  extra time  =",
            int(
                df[
                    "is_extra_time"
                ].sum()
            ),
        )

    if tested < 5:

        raise RuntimeError(
            "Muy pocos archivos disponibles "
            "para self test."
        )

    # ------------------------------------------
    # TEST ESPECÍFICO ECUADOR
    # ------------------------------------------

    ecuador_path = (
        ROOT
        / "south-america"
        / "ecuador"
        / "2025_ec1.txt"
    )

    if ecuador_path.exists():

        ecuador = load_file(
            ecuador_path
        ).dataframe

        sample = ecuador[
            (
                ecuador["home_team"]
                ==
                "Manta"
            )
            &
            (
                ecuador["away_team"]
                ==
                "Barcelona"
            )
        ]

        if sample.empty:

            raise RuntimeError(
                "No encontré Manta-Barcelona "
                "en Ecuador 2025."
            )

        row = sample.iloc[0]

        assert int(
            row["home_goals"]
        ) == 2

        assert int(
            row["away_goals"]
        ) == 3

        assert int(
            row["home_goals_1h"]
        ) == 1

        assert int(
            row["away_goals_1h"]
        ) == 1

        assert int(
            row["home_goals_2h"]
        ) == 1

        assert int(
            row["away_goals_2h"]
        ) == 2

    # ------------------------------------------
    # TEST COPA / PENALTIES
    # ------------------------------------------

    cup_path = (
        ROOT
        / "south-america"
        / "brazil"
        / "2025_brcup.txt"
    )

    if cup_path.exists():

        cup = load_file(
            cup_path
        ).dataframe

        if int(
            cup[
                "is_penalty"
            ].sum()
        ) == 0:

            raise RuntimeError(
                "No detecté penaltis "
                "en Copa do Brasil."
            )

    # ------------------------------------------
    # TEST AWARDED
    # ------------------------------------------

    costa_rica_path = (
        ROOT
        / "world"
        / "central-america"
        / "costa-rica"
        / "2024-25_cr1.txt"
    )

    if costa_rica_path.exists():

        costa_rica = load_file(
            costa_rica_path
        ).dataframe

        if int(
            costa_rica[
                "is_awarded"
            ].sum()
        ) == 0:

            raise RuntimeError(
                "No detecté partido awarded "
                "en Costa Rica."
            )

    print("")
    print(
        "=" * 70
    )

    print(
        "SELF TEST = PASS"
    )

    print(
        "files tested =",
        tested,
    )

    print(
        "rows parsed =",
        parsed_total,
    )


def audit_targets() -> None:

    results = load_target_files()

    lines = []

    lines.append(
        "ODDSHUNTER - OPENFOOTBALL LOADER AUDIT"
    )

    lines.append(
        "=" * 100
    )

    lines.append("")

    total_rows = 0
    total_unparsed = 0
    total_without_date = 0

    total_review = 0
    total_awarded = 0
    total_penalty = 0
    total_extra_time = 0

    total_ht = 0
    total_no_ht = 0

    for result in results:

        df = result.dataframe

        rows = len(
            df
        )

        total_rows += rows

        total_unparsed += len(
            result.score_like_unparsed
        )

        total_without_date += (
            result.rows_without_date
        )

        if not df.empty:

            review = int(
                df[
                    "review_required"
                ].sum()
            )

            awarded = int(
                df[
                    "is_awarded"
                ].sum()
            )

            penalty = int(
                df[
                    "is_penalty"
                ].sum()
            )

            extra_time = int(
                df[
                    "is_extra_time"
                ].sum()
            )

            with_ht = int(
                df[
                    "has_halftime"
                ].sum()
            )

        else:

            review = 0
            awarded = 0
            penalty = 0
            extra_time = 0
            with_ht = 0

        no_ht = (
            rows
            -
            with_ht
        )

        total_review += review
        total_awarded += awarded
        total_penalty += penalty
        total_extra_time += extra_time

        total_ht += with_ht
        total_no_ht += no_ht

        lines.append(
            result.path.as_posix()
        )

        lines.append(
            f"  TITLE        : "
            f"{result.competition_title}"
        )

        lines.append(
            f"  HEADER MATCH : "
            f"{result.header_matches}"
        )

        lines.append(
            f"  PARSED       : "
            f"{rows}"
        )

        lines.append(
            f"  WITH HT      : "
            f"{with_ht}"
        )

        lines.append(
            f"  WITHOUT HT   : "
            f"{no_ht}"
        )

        lines.append(
            f"  REVIEW       : "
            f"{review}"
        )

        lines.append(
            f"  AWARDED      : "
            f"{awarded}"
        )

        lines.append(
            f"  PENALTIES    : "
            f"{penalty}"
        )

        lines.append(
            f"  EXTRA TIME   : "
            f"{extra_time}"
        )

        lines.append(
            f"  UNPARSED     : "
            f"{len(result.score_like_unparsed)}"
        )

        lines.append(
            f"  NO DATE      : "
            f"{result.rows_without_date}"
        )

        lines.append("")

    lines.append(
        "=" * 100
    )

    lines.append(
        "TOTAL"
    )

    lines.append(
        "=" * 100
    )

    lines.append(
        f"FILES           : {len(results)}"
    )

    lines.append(
        f"ROWS            : {total_rows}"
    )

    lines.append(
        f"WITH HT         : {total_ht}"
    )

    lines.append(
        f"WITHOUT HT      : {total_no_ht}"
    )

    lines.append(
        f"REVIEW          : {total_review}"
    )

    lines.append(
        f"AWARDED         : {total_awarded}"
    )

    lines.append(
        f"PENALTIES       : {total_penalty}"
    )

    lines.append(
        f"EXTRA TIME      : {total_extra_time}"
    )

    lines.append(
        f"UNPARSED RESULT : {total_unparsed}"
    )

    lines.append(
        f"ROWS NO DATE    : {total_without_date}"
    )

    AUDIT_OUTPUT.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    AUDIT_OUTPUT.write_text(
        "\n".join(lines) + "\n",
        encoding="utf-8",
    )

    print(
        "OPENFOOTBALL TARGET AUDIT = OK"
    )

    print(
        "files =",
        len(results),
    )

    print(
        "rows =",
        total_rows,
    )

    print(
        "with halftime =",
        total_ht,
    )

    print(
        "without halftime =",
        total_no_ht,
    )

    print(
        "review =",
        total_review,
    )

    print(
        "awarded =",
        total_awarded,
    )

    print(
        "penalties =",
        total_penalty,
    )

    print(
        "extra time =",
        total_extra_time,
    )

    print(
        "unparsed result lines =",
        total_unparsed,
    )

    print(
        "rows without date =",
        total_without_date,
    )

    print(
        "saved =",
        AUDIT_OUTPUT,
    )

    if total_unparsed:
        raise RuntimeError(
            "Existen líneas de resultado "
            "que el parser no entendió."
        )

    if total_without_date:
        raise RuntimeError(
            "Existen partidos sin fecha."
        )


def main() -> None:

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--file",
        type=str,
    )

    parser.add_argument(
        "--self-test",
        action="store_true",
    )

    parser.add_argument(
        "--audit-targets",
        action="store_true",
    )

    args = parser.parse_args()

    if args.self_test:

        self_test()
        return

    if args.audit_targets:

        audit_targets()
        return

    if args.file:

        result = load_file(
            args.file
        )

        print(
            result.dataframe.to_string(
                index=False,
            )
        )

        return

    parser.print_help()


if __name__ == "__main__":
    main()