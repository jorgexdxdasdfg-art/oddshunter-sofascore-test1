from __future__ import annotations

import re
import sqlite3
from collections import Counter
from pathlib import Path

import pandas as pd

from ingestion.openfootball_loader import (
    load_targets_dataframe,
)

from ingestion.team_mapper import (
    TeamMapper,
)

from ingestion.league_mapper import (
    LeagueMapper,
)

from ingestion.match_mapper import (
    MatchMapper,
)


OUT_DIR = Path(
    r"data\bulk\openfootball"
)

STAGING_CSV = (
    OUT_DIR
    / "openfootball_staging_audit.csv"
)

TEAM_REVIEW_CSV = (
    OUT_DIR
    / "openfootball_team_review.csv"
)

LEAGUE_REVIEW_CSV = (
    OUT_DIR
    / "openfootball_league_review.csv"
)

SUMMARY_TXT = (
    OUT_DIR
    / "OPENFOOTBALL_STAGING_SUMMARY.txt"
)


SEASON_SUFFIX_RE = re.compile(
    r"""
    \s+
    20\d{2}
    (?:
        /
        \d{2,4}
    )?
    \s*$
    """,
    re.VERBOSE,
)


COUNTRY_HINTS = {
    "argentina": "Argentina",
    "brazil": "Brazil",
    "colombia": "Colombia",
    "ecuador": "Ecuador",
    "paraguay": "Paraguay",
}


def clean_competition_name(
    title: str,
) -> str:

    value = str(
        title or ""
    ).strip()

    value = SEASON_SUFFIX_RE.sub(
        "",
        value,
    )

    return value.strip()


def competition_country_hint(
    row: pd.Series,
) -> str | None:

    top_group = str(
        row.get(
            "top_group",
            ""
        )
        or ""
    ).strip().lower()

    source_file = str(
        row.get(
            "source_file",
            ""
        )
        or ""
    ).replace(
        "\\",
        "/",
    ).lower()

    competition_title = str(
        row.get(
            "competition_title",
            ""
        )
        or ""
    ).casefold()

    # ------------------------------------------
    # Ligas nacionales South America
    # ------------------------------------------

    if top_group in COUNTRY_HINTS:
        return COUNTRY_HINTS[
            top_group
        ]

    # ------------------------------------------
    # Costa Rica
    #
    # source_file real:
    # central-america/costa-rica/...
    # ------------------------------------------

    if "costa-rica/" in source_file:
        return "Costa Rica"

    # ------------------------------------------
    # M?xico
    #
    # source_file real:
    # north-america/mexico/...
    # ------------------------------------------

    if "mexico/" in source_file:
        return "Mexico"

    # ------------------------------------------
    # MLS
    # ------------------------------------------

    if "major-league-soccer/" in source_file:
        return "USA"

    # ------------------------------------------
    # CONMEBOL
    # ------------------------------------------

    if (
        "libertadores" in competition_title
        or
        "sudamericana" in competition_title
    ):
        return "South America"

    # CONCACAF queda sin country fijo por ahora.
    # Se resolver? por identidad de competici?n.
    return None


def safe_int(
    value,
):

    if value is None:
        return None

    if pd.isna(
        value
    ):
        return None

    return int(
        value
    )




# ==========================================================================
# ODDSHUNTER_OPENFOOTBALL_ROUTE_EXACT_V1
# OpenFootball:
# competition + season + stage
# -> tournament_id + season_id
# -> league_id exacto SQLite.
#
# NO fuzzy.
# LeagueMapper queda solamente como fallback.
# ==========================================================================

_OPENFOOTBALL_ROUTE_INDEX_CACHE = None


def _openfootball_route_norm(
    value,
):
    import re
    import unicodedata

    text = str(
        value or ""
    ).strip().casefold()

    text = unicodedata.normalize(
        "NFKD",
        text,
    )

    text = "".join(
        char
        for char in text
        if not unicodedata.combining(
            char
        )
    )

    text = (
        text
        .replace("?", "")
        .replace("?", "")
    )

    text = re.sub(
        r"[^a-z0-9]+",
        " ",
        text,
    )

    return re.sub(
        r"\s+",
        " ",
        text,
    ).strip()


def _load_openfootball_route_index():

    global _OPENFOOTBALL_ROUTE_INDEX_CACHE

    if (
        _OPENFOOTBALL_ROUTE_INDEX_CACHE
        is not None
    ):

        return (
            _OPENFOOTBALL_ROUTE_INDEX_CACHE
        )

    import json
    import sqlite3
    from pathlib import Path

    root = (
        Path(__file__)
        .resolve()
        .parents[1]
    )

    manifest_path = (
        root
        / "data"
        / "bulk"
        / "openfootball"
        / "openfootball_league_route_manifest.json"
    )

    db_path = (
        root
        / "data"
        / "oddshunter.db"
    )

    payload = json.loads(
        manifest_path.read_text(
            encoding="utf-8-sig"
        )
    )

    routes = payload.get(
        "route_definitions"
    )

    if not isinstance(
        routes,
        list,
    ):

        raise RuntimeError(
            "route_definitions no existe "
            "en route manifest."
        )

    uri = (
        db_path.resolve().as_uri()
        + "?mode=ro"
    )

    conn = sqlite3.connect(
        uri,
        uri=True,
    )

    conn.row_factory = sqlite3.Row

    index = {}

    try:

        for route in routes:

            tournament_id = int(
                route[
                    "tournament_id"
                ]
            )

            season_id = int(
                route[
                    "season_id"
                ]
            )

            rows = conn.execute(
                """
                SELECT
                    league_id,
                    name,
                    country,
                    season,
                    source_tournament_id,
                    source_season_id
                FROM leagues
                WHERE source_tournament_id=?
                  AND source_season_id=?
                ORDER BY league_id
                """,
                (
                    tournament_id,
                    season_id,
                ),
            ).fetchall()

            if len(rows) != 1:

                raise RuntimeError(
                    "OpenFootball route identity "
                    "no resuelve a una sola league: "
                    f"{tournament_id}/"
                    f"{season_id} -> "
                    f"{len(rows)} filas"
                )

            league = rows[0]

            competition_key = (
                route.get(
                    "competition_key"
                )
                or
                _openfootball_route_norm(
                    route.get(
                        "competition_label"
                    )
                )
            )

            season_label = str(
                route.get(
                    "season_label"
                )
                or ""
            ).strip()

            stage_contains = (
                route.get(
                    "stage_contains"
                )
            )

            stage_contains = (
                _openfootball_route_norm(
                    stage_contains
                )
                if stage_contains
                else None
            )

            key = (
                _openfootball_route_norm(
                    competition_key
                ),
                season_label,
            )

            index.setdefault(
                key,
                [],
            ).append(
                {
                    "stage_contains":
                        stage_contains,

                    "league_id":
                        int(
                            league[
                                "league_id"
                            ]
                        ),

                    "canonical_name":
                        str(
                            league[
                                "name"
                            ]
                        ),

                    "tournament_id":
                        tournament_id,

                    "season_id":
                        season_id,
                }
            )

    finally:

        conn.close()

    _OPENFOOTBALL_ROUTE_INDEX_CACHE = (
        index
    )

    return index


def _resolve_openfootball_route_exact(
    competition_name,
    season_label,
    stage_label,
):

    from types import SimpleNamespace

    index = (
        _load_openfootball_route_index()
    )

    key = (
        _openfootball_route_norm(
            competition_name
        ),
        str(
            season_label
            or ""
        ).strip(),
    )

    stage_norm = (
        _openfootball_route_norm(
            stage_label
        )
    )

    candidates = []

    for item in index.get(
        key,
        [],
    ):

        wanted = item[
            "stage_contains"
        ]

        if (
            wanted
            and wanted not in stage_norm
        ):

            continue

        candidates.append(
            item
        )

    if len(candidates) == 0:

        return None

    if len(candidates) != 1:

        raise RuntimeError(
            "OpenFootball route ambiguo: "
            f"{competition_name} | "
            f"{season_label} | "
            f"{stage_label} -> "
            f"{len(candidates)} candidatos"
        )

    item = candidates[0]

    return SimpleNamespace(
        league_id=int(
            item[
                "league_id"
            ]
        ),
        review_required=False,
        method=(
            "OPENFOOTBALL_ROUTE_EXACT"
        ),
        score=100.0,
        canonical_name=str(
            item[
                "canonical_name"
            ]
        ),
        source_tournament_id=int(
            item[
                "tournament_id"
            ]
        ),
        source_season_id=int(
            item[
                "season_id"
            ]
        ),
    )


def main() -> None:

    OUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    print(
        "OPENFOOTBALL STAGING"
    )

    print(
        "=" * 70
    )

    print(
        "Loading OpenFootball dataframe..."
    )

    df = load_targets_dataframe()

    if df.empty:

        raise RuntimeError(
            "OpenFootball DataFrame vacío."
        )

    print(
        "source rows =",
        len(df),
    )

    team_mapper = TeamMapper()
    league_mapper = LeagueMapper()
    match_mapper = MatchMapper()

    print(
        "TeamMapper teams =",
        len(
            team_mapper.teams
        ),
    )

    print(
        "LeagueMapper leagues =",
        len(
            league_mapper.leagues
        ),
    )

    # --------------------------------------------------
    # CACHÉS
    #
    # Muy importante:
    # no repetimos resolución del mismo nombre miles
    # de veces.
    # --------------------------------------------------

    team_cache = {}

    league_cache = {}

    match_cache = {}

    staging_rows = []

    team_review_rows = []

    league_review_rows = []

    # --------------------------------------------------
    # CONTADORES
    # --------------------------------------------------

    status_counter = Counter()

    league_method_counter = Counter()
    home_method_counter = Counter()
    away_method_counter = Counter()
    match_method_counter = Counter()

    source_special = 0

    total = len(
        df
    )

    for index, row in df.iterrows():

        # ==============================================
        # LEAGUE
        # ==============================================

        competition_title = str(
            row[
                "competition_title"
            ]
            or ""
        )

        season_label = str(
            row[
                "season_label"
            ]
            or ""
        )

        competition_name = (
            clean_competition_name(
                competition_title
            )
        )

        country_hint = (
            competition_country_hint(
                row
            )
        )

        # ODDSHUNTER_OPENFOOTBALL_ROUTE_STAGE_KEY_V1
        #
        # stage_label DEBE formar parte del cache.
        # Apertura / Clausura / Campeon pueden compartir
        # competition_name + season_label.
        stage_label = str(
            row[
                "stage_label"
            ]
            or ""
        )

        league_key = (
            competition_name,
            season_label,
            country_hint,
            stage_label,
        )

        if league_key not in league_cache:

            strong_result = (
                _resolve_openfootball_route_exact(
                    competition_name,
                    season_label,
                    stage_label,
                )
            )

            if strong_result is not None:

                league_cache[
                    league_key
                ] = strong_result

            else:

                league_cache[
                    league_key
                ] = league_mapper.resolve(
                    "openfootball",
                    competition_name,
                    season=season_label,
                    country=country_hint,
                )

        league_result = (
            league_cache[
                league_key
            ]
        )

        league_method_counter[
            league_result.method
        ] += 1

        # ==============================================
        # HOME TEAM
        # ==============================================

        home_name = str(
            row[
                "home_team"
            ]
        ).strip()

        home_key = (
            home_name,
        )

        if home_key not in team_cache:

            team_cache[
                home_key
            ] = team_mapper.resolve(
                "openfootball",
                home_name,
            )

        home_result = (
            team_cache[
                home_key
            ]
        )

        home_method_counter[
            home_result.method
        ] += 1

        # ==============================================
        # AWAY TEAM
        # ==============================================

        away_name = str(
            row[
                "away_team"
            ]
        ).strip()

        away_key = (
            away_name,
        )

        if away_key not in team_cache:

            team_cache[
                away_key
            ] = team_mapper.resolve(
                "openfootball",
                away_name,
            )

        away_result = (
            team_cache[
                away_key
            ]
        )

        away_method_counter[
            away_result.method
        ] += 1

        # ==============================================
        # SOURCE SPECIAL RESULT
        # ==============================================

        source_review = bool(
            row[
                "review_required"
            ]
        )

        usable_for_performance = bool(
            row[
                "usable_for_performance"
            ]
        )

        if source_review:
            source_special += 1

        # ==============================================
        # MATCH MAPPER
        # ==============================================

        match_id = None
        match_method = None
        match_review = None
        match_new = None

        identities_ok = (
            league_result.league_id
            is not None
            and not league_result.review_required

            and home_result.team_id
            is not None
            and not home_result.review_required

            and away_result.team_id
            is not None
            and not away_result.review_required
        )

        if (
            identities_ok
            and not source_review
        ):

            match_key = (
                int(
                    league_result.league_id
                ),
                int(
                    home_result.team_id
                ),
                int(
                    away_result.team_id
                ),
                str(
                    row[
                        "match_date"
                    ]
                ),
                safe_int(
                    row[
                        "home_goals"
                    ]
                ),
                safe_int(
                    row[
                        "away_goals"
                    ]
                ),
            )

            if match_key not in match_cache:

                match_cache[
                    match_key
                ] = match_mapper.resolve(
                    league_id=(
                        league_result.league_id
                    ),
                    home_team_id=(
                        home_result.team_id
                    ),
                    away_team_id=(
                        away_result.team_id
                    ),
                    kickoff=(
                        row[
                            "match_date"
                        ]
                    ),
                    home_goals=safe_int(
                        row[
                            "home_goals"
                        ]
                    ),
                    away_goals=safe_int(
                        row[
                            "away_goals"
                        ]
                    ),
                )

            match_result = (
                match_cache[
                    match_key
                ]
            )

            match_id = (
                match_result.match_id
            )

            match_method = (
                match_result.method
            )

            match_review = (
                match_result.review_required
            )

            match_new = (
                match_result.new_match
            )

            match_method_counter[
                match_result.method
            ] += 1

        # ==============================================
        # STATUS GENERAL
        # ==============================================

        if source_review:

            staging_status = (
                "SOURCE_SPECIAL_REVIEW"
            )

        elif (
            league_result.league_id
            is None
            or league_result.review_required
        ):

            staging_status = (
                "LEAGUE_REVIEW"
            )

        elif (
            (
                home_result.team_id
                is None
                or home_result.review_required
            )
            and
            (
                away_result.team_id
                is None
                or away_result.review_required
            )
        ):

            staging_status = (
                "BOTH_TEAMS_REVIEW"
            )

        elif (
            home_result.team_id
            is None
            or home_result.review_required
        ):

            staging_status = (
                "HOME_TEAM_REVIEW"
            )

        elif (
            away_result.team_id
            is None
            or away_result.review_required
        ):

            staging_status = (
                "AWAY_TEAM_REVIEW"
            )

        elif match_id is not None:

            staging_status = (
                "MATCH_RESOLVED"
            )

        elif match_new is True:

            staging_status = (
                "NEW_MATCH"
            )

        else:

            staging_status = (
                "MATCH_REVIEW"
            )

        status_counter[
            staging_status
        ] += 1

        # ==============================================
        # STAGING ROW
        # ==============================================

        staging_rows.append(
            {
                "source_file":
                    row[
                        "source_file"
                    ],

                "source_line":
                    row[
                        "source_line"
                    ],

                "competition_title":
                    competition_title,

                "competition_name":
                    competition_name,

                "season_label":
                    season_label,

                "country_hint":
                    country_hint,

                "stage_label":
                    row[
                        "stage_label"
                    ],

                "match_date":
                    row[
                        "match_date"
                    ],

                "kickoff_time_local":
                    row[
                        "kickoff_time_local"
                    ],

                "home_team_source":
                    home_name,

                "away_team_source":
                    away_name,

                "home_goals":
                    row[
                        "home_goals"
                    ],

                "away_goals":
                    row[
                        "away_goals"
                    ],

                "home_goals_1h":
                    row[
                        "home_goals_1h"
                    ],

                "away_goals_1h":
                    row[
                        "away_goals_1h"
                    ],

                "home_goals_2h":
                    row[
                        "home_goals_2h"
                    ],

                "away_goals_2h":
                    row[
                        "away_goals_2h"
                    ],

                "source_review":
                    source_review,

                "usable_for_performance":
                    usable_for_performance,

                "league_id":
                    league_result.league_id,

                "league_method":
                    league_result.method,

                "league_score":
                    league_result.score,

                "league_suggestion":
                    league_result.canonical_name,

                "home_team_id":
                    home_result.team_id,

                "home_team_method":
                    home_result.method,

                "home_team_score":
                    home_result.score,

                "home_team_canonical":
                    home_result.canonical_name,

                "away_team_id":
                    away_result.team_id,

                "away_team_method":
                    away_result.method,

                "away_team_score":
                    away_result.score,

                "away_team_canonical":
                    away_result.canonical_name,

                "match_id":
                    match_id,

                "match_method":
                    match_method,

                "match_review":
                    match_review,

                "match_new":
                    match_new,

                "staging_status":
                    staging_status,
            }
        )

        # ==============================================
        # TEAM REVIEW UNIQUE LATER
        # ==============================================

        if (
            home_result.team_id is None
            or home_result.review_required
        ):

            team_review_rows.append(
                {
                    "source_name":
                        home_name,

                    "side":
                        "HOME",

                    "method":
                        home_result.method,

                    "score":
                        home_result.score,

                    "suggestion":
                        home_result.canonical_name,
                }
            )

        if (
            away_result.team_id is None
            or away_result.review_required
        ):

            team_review_rows.append(
                {
                    "source_name":
                        away_name,

                    "side":
                        "AWAY",

                    "method":
                        away_result.method,

                    "score":
                        away_result.score,

                    "suggestion":
                        away_result.canonical_name,
                }
            )

        # ==============================================
        # LEAGUE REVIEW
        # ==============================================

        if (
            league_result.league_id is None
            or league_result.review_required
        ):

            league_review_rows.append(
                {
                    "competition_title":
                        competition_title,

                    "competition_name":
                        competition_name,

                    "season_label":
                        season_label,

                    "country_hint":
                        country_hint,

                    "method":
                        league_result.method,

                    "score":
                        league_result.score,

                    "suggestion":
                        league_result.canonical_name,

                    "suggestion_season":
                        league_result.canonical_season,
                }
            )

        if (
            (index + 1) % 1000
            == 0
        ):

            print(
                f"processed "
                f"{index + 1}"
                f"/{total}"
            )

    # ==================================================
    # DATAFRAMES
    # ==================================================

    staging_df = pd.DataFrame(
        staging_rows
    )

    team_review_df = pd.DataFrame(
        team_review_rows
    )

    league_review_df = pd.DataFrame(
        league_review_rows
    )

    if not team_review_df.empty:

        team_review_df = (
            team_review_df
            .drop_duplicates(
                subset=[
                    "source_name",
                ]
            )
            .sort_values(
                [
                    "method",
                    "source_name",
                ]
            )
        )

    if not league_review_df.empty:

        league_review_df = (
            league_review_df
            .drop_duplicates(
                subset=[
                    "competition_title",
                    "season_label",
                ]
            )
            .sort_values(
                [
                    "competition_title",
                    "season_label",
                ]
            )
        )

    # ==================================================
    # GUARDAR
    # ==================================================

    staging_df.to_csv(
        STAGING_CSV,
        index=False,
        encoding="utf-8-sig",
    )

    team_review_df.to_csv(
        TEAM_REVIEW_CSV,
        index=False,
        encoding="utf-8-sig",
    )

    league_review_df.to_csv(
        LEAGUE_REVIEW_CSV,
        index=False,
        encoding="utf-8-sig",
    )

    # ==================================================
    # RESUMEN
    # ==================================================

    lines = []

    lines.append(
        "ODDSHUNTER - OPENFOOTBALL STAGING"
    )

    lines.append(
        "=" * 80
    )

    lines.append("")

    lines.append(
        f"SOURCE ROWS = {len(df)}"
    )

    lines.append(
        f"SOURCE SPECIAL REVIEW = "
        f"{source_special}"
    )

    lines.append("")

    lines.append(
        "STAGING STATUS"
    )

    lines.append(
        "-" * 80
    )

    for key, value in (
        status_counter
        .most_common()
    ):

        lines.append(
            f"{key:28} {value}"
        )

    lines.append("")

    lines.append(
        "UNIQUE TEAM REVIEW = "
        f"{len(team_review_df)}"
    )

    lines.append(
        "UNIQUE LEAGUE REVIEW = "
        f"{len(league_review_df)}"
    )

    lines.append("")

    lines.append(
        "LEAGUE METHODS"
    )

    lines.append(
        "-" * 80
    )

    for key, value in (
        league_method_counter
        .most_common()
    ):

        lines.append(
            f"{key:28} {value}"
        )

    lines.append("")

    lines.append(
        "MATCH METHODS"
    )

    lines.append(
        "-" * 80
    )

    for key, value in (
        match_method_counter
        .most_common()
    ):

        lines.append(
            f"{key:28} {value}"
        )

    SUMMARY_TXT.write_text(
        "\n".join(
            lines
        ) + "\n",
        encoding="utf-8",
    )

    # ==================================================
    # TERMINAL
    # ==================================================

    print("")
    print(
        "=" * 70
    )

    print(
        "OPENFOOTBALL STAGING = OK"
    )

    print(
        "=" * 70
    )

    print(
        "source rows =",
        len(df),
    )

    print(
        "source special review =",
        source_special,
    )

    print("")

    for key, value in (
        status_counter
        .most_common()
    ):

        print(
            f"{key:28} = {value}"
        )

    print("")

    print(
        "unique team review =",
        len(
            team_review_df
        ),
    )

    print(
        "unique league review =",
        len(
            league_review_df
        ),
    )

    print("")

    print(
        "staging =",
        STAGING_CSV,
    )

    print(
        "team review =",
        TEAM_REVIEW_CSV,
    )

    print(
        "league review =",
        LEAGUE_REVIEW_CSV,
    )

    print(
        "summary =",
        SUMMARY_TXT,
    )


if __name__ == "__main__":
    main()