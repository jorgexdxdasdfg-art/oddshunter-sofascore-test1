from __future__ import annotations

import json
import re
import sqlite3
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from rapidfuzz import fuzz, process


DB_URI = "file:data/oddshunter.db?mode=ro"

ALIASES_PATH = Path(
    r"data\manifests\team_aliases.json"
)

FUZZY_THRESHOLD = 97.0
FUZZY_MIN_GAP = 5.0


def normalize_team_name(
    value: str | None,
) -> str:
    """
    Normalización ESTRICTA.

    NO elimina:
    FC
    CF
    AFC
    SC

    porque existen clubes distintos como:
    Libertad FC != Libertad
    Vitória SC != Vitória
    """

    if value is None:
        return ""

    text = str(value).strip().lower()

    if not text:
        return ""

    text = unicodedata.normalize(
        "NFKD",
        text,
    )

    text = "".join(
        ch
        for ch in text
        if not unicodedata.combining(ch)
    )

    text = text.replace(
        "&",
        " and ",
    )

    text = re.sub(
        r"[-_/.,'’`´()]",
        " ",
        text,
    )

    text = re.sub(
        r"[^a-z0-9\s]",
        " ",
        text,
    )

    text = re.sub(
        r"\s+",
        " ",
        text,
    ).strip()

    return text


@dataclass(frozen=True)
class TeamRecord:
    team_id: int
    sofascore_id: int
    name: str
    league_id: int
    country: str
    league_name: str
    season: str
    normalized_name: str


@dataclass(frozen=True)
class TeamResolution:
    source: str
    source_name: str
    normalized_name: str

    team_id: Optional[int]
    sofascore_id: Optional[int]
    canonical_name: Optional[str]

    method: str
    score: float

    review_required: bool


class TeamMapper:
    """
    TeamMapper oficial de OddsHunter Bulk.

    REGLAS:

    1. teams.team_id actual ES el ID canónico.
    2. teams.sofascore_id se conserva.
    3. SQLite se abre READ ONLY.
    4. No crea equipos.
    5. No modifica oddshunter.db.
    6. Alias explícito puede resolver automáticamente.
    7. Nombre normalizado único puede resolver automáticamente.
    8. Fuzzy solamente propone. Nunca decide por defecto.
    """

    def __init__(
        self,
        db_uri: str = DB_URI,
        aliases_path: Path = ALIASES_PATH,
    ) -> None:

        self.db_uri = db_uri
        self.aliases_path = aliases_path

        self.teams: dict[int, TeamRecord] = {}

        self.normalized_index: dict[
            str,
            list[int],
        ] = {}

        self.sofascore_index: dict[
            int,
            int,
        ] = {}

        self.aliases: dict[
            str,
            dict[str, int],
        ] = {}

        self._load_teams()
        self._load_aliases()

    def _connect(
        self,
    ) -> sqlite3.Connection:

        conn = sqlite3.connect(
            self.db_uri,
            uri=True,
        )

        conn.row_factory = sqlite3.Row

        return conn

    def _load_teams(
        self,
    ) -> None:

        with self._connect() as conn:

            rows = conn.execute(
                """
                SELECT
                    t.team_id,
                    t.sofascore_id,
                    t.name,
                    t.league_id,
                    l.country,
                    l.name AS league_name,
                    l.season
                FROM teams AS t
                LEFT JOIN leagues AS l
                    ON l.league_id = t.league_id
                ORDER BY t.team_id
                """
            ).fetchall()

        for row in rows:

            if row["sofascore_id"] is None:
                raise RuntimeError(
                    "Equipo sin sofascore_id: "
                    f"team_id={row['team_id']}"
                )

            if row["league_id"] is None:
                raise RuntimeError(
                    "Equipo sin league_id: "
                    f"team_id={row['team_id']}"
                )

            record = TeamRecord(
                team_id=int(
                    row["team_id"]
                ),
                sofascore_id=int(
                    row["sofascore_id"]
                ),
                name=str(
                    row["name"]
                ),
                league_id=int(
                    row["league_id"]
                ),
                country=str(
                    row["country"] or ""
                ),
                league_name=str(
                    row["league_name"] or ""
                ),
                season=str(
                    row["season"] or ""
                ),
                normalized_name=(
                    normalize_team_name(
                        row["name"]
                    )
                ),
            )

            self.teams[
                record.team_id
            ] = record

            self.sofascore_index[
                record.sofascore_id
            ] = record.team_id

            self.normalized_index.setdefault(
                record.normalized_name,
                [],
            ).append(
                record.team_id
            )

    def _load_aliases(
        self,
    ) -> None:

        self.aliases = {}

        if not self.aliases_path.exists():
            return

        raw_text = (
            self.aliases_path.read_text(
                encoding="utf-8-sig",
            )
        )

        if not raw_text.strip():
            raw = {}
        else:
            raw = json.loads(
                raw_text
            )

        if not isinstance(
            raw,
            dict,
        ):
            raise ValueError(
                "team_aliases.json debe ser "
                "un objeto JSON."
            )

        for source, mapping in raw.items():

            if not isinstance(
                mapping,
                dict,
            ):
                raise ValueError(
                    "Aliases inválidos para "
                    f"source={source}"
                )

            source_key = (
                str(source)
                .strip()
                .lower()
            )

            self.aliases[
                source_key
            ] = {}

            for alias, team_id in (
                mapping.items()
            ):

                normalized = (
                    normalize_team_name(
                        alias
                    )
                )

                canonical_id = int(
                    team_id
                )

                if canonical_id not in self.teams:
                    raise ValueError(
                        f"{source}:{alias} "
                        "apunta a team_id "
                        f"inexistente={canonical_id}"
                    )

                self.aliases[
                    source_key
                ][
                    normalized
                ] = canonical_id

    def resolve_sofascore_id(
        self,
        sofascore_id: int,
    ) -> TeamResolution:

        sid = int(
            sofascore_id
        )

        team_id = (
            self.sofascore_index
            .get(
                sid
            )
        )

        if team_id is None:

            return TeamResolution(
                source="sofascore",
                source_name=str(
                    sid
                ),
                normalized_name="",
                team_id=None,
                sofascore_id=None,
                canonical_name=None,
                method="SOFASCORE_NOT_FOUND",
                score=0.0,
                review_required=True,
            )

        team = self.teams[
            team_id
        ]

        return TeamResolution(
            source="sofascore",
            source_name=str(
                sid
            ),
            normalized_name=(
                team.normalized_name
            ),
            team_id=(
                team.team_id
            ),
            sofascore_id=(
                team.sofascore_id
            ),
            canonical_name=(
                team.name
            ),
            method="SOFASCORE_EXACT",
            score=100.0,
            review_required=False,
        )

    def resolve(
        self,
        source: str,
        source_name: str,
        *,
        country: str | None = None,
        allow_auto_fuzzy: bool = False,
    ) -> TeamResolution:

        source_key = (
            str(source)
            .strip()
            .lower()
        )

        normalized = (
            normalize_team_name(
                source_name
            )
        )

        if not normalized:

            return TeamResolution(
                source=source_key,
                source_name=str(
                    source_name
                ),
                normalized_name="",
                team_id=None,
                sofascore_id=None,
                canonical_name=None,
                method="EMPTY",
                score=0.0,
                review_required=True,
            )

        # ==================================================
        # 1. ALIAS EXPLÍCITO
        # ==================================================

        alias_team_id = (
            self.aliases
            .get(
                source_key,
                {},
            )
            .get(
                normalized
            )
        )

        if alias_team_id is not None:

            team = self.teams[
                alias_team_id
            ]

            return TeamResolution(
                source=source_key,
                source_name=source_name,
                normalized_name=normalized,
                team_id=team.team_id,
                sofascore_id=team.sofascore_id,
                canonical_name=team.name,
                method="ALIAS_EXACT",
                score=100.0,
                review_required=False,
            )

        # ==================================================
        # 2. NOMBRE NORMALIZADO EXACTO
        # ==================================================
        #
        # IMPORTANTE:
        #
        # NO filtramos primero por country.
        #
        # teams.league_id puede apuntar actualmente
        # a Champions, Sudamericana, etc.
        #
        # Ejemplos reales:
        #
        # Manchester City:
        # country actual = Europe
        #
        # River Plate:
        # country actual = South America
        #
        # pero siguen siendo los clubes correctos.
        # ==================================================

        exact_ids = list(
            self.normalized_index.get(
                normalized,
                [],
            )
        )

        if len(exact_ids) == 1:

            team = self.teams[
                exact_ids[0]
            ]

            return TeamResolution(
                source=source_key,
                source_name=source_name,
                normalized_name=normalized,
                team_id=team.team_id,
                sofascore_id=team.sofascore_id,
                canonical_name=team.name,
                method="NORMALIZED_EXACT",
                score=100.0,
                review_required=False,
            )

        # Si alguna vez aparecen dos clubes con el mismo
        # nombre EXACTO, NO elegimos automáticamente.
        #
        # El campo country recibido puede servir luego
        # como evidencia auxiliar, pero NO es suficiente
        # hoy para modificar identidad automáticamente.

        if len(exact_ids) > 1:

            return TeamResolution(
                source=source_key,
                source_name=source_name,
                normalized_name=normalized,
                team_id=None,
                sofascore_id=None,
                canonical_name=None,
                method="AMBIGUOUS_EXACT",
                score=100.0,
                review_required=True,
            )

        # ==================================================
        # 3. FUZZY
        # ==================================================
        #
        # El fuzzy busca candidatos globalmente.
        #
        # NO filtramos por country porque el country
        # almacenado actualmente depende del league_id
        # asociado al equipo y puede ser:
        #
        # Europe
        # South America
        # etc.
        #
        # Fuzzy es sugerencia solamente.
        # ==================================================

        choices = {
            team.team_id:
                team.normalized_name
            for team in self.teams.values()
        }

        fuzzy_results = (
            process.extract(
                normalized,
                choices,
                scorer=fuzz.WRatio,
                limit=2,
            )
        )

        if not fuzzy_results:

            return TeamResolution(
                source=source_key,
                source_name=source_name,
                normalized_name=normalized,
                team_id=None,
                sofascore_id=None,
                canonical_name=None,
                method="NO_MATCH",
                score=0.0,
                review_required=True,
            )

        (
            _,
            best_score,
            best_team_id,
        ) = fuzzy_results[0]

        second_score = (
            fuzzy_results[1][1]
            if len(fuzzy_results) > 1
            else 0.0
        )

        gap = (
            float(best_score)
            -
            float(second_score)
        )

        best_team = self.teams[
            int(best_team_id)
        ]

        # --------------------------------------------------
        # Por seguridad, auto fuzzy está deshabilitado
        # operativamente salvo solicitud explícita.
        # --------------------------------------------------

        auto_ok = (
            allow_auto_fuzzy
            and
            float(best_score)
            >= FUZZY_THRESHOLD
            and
            gap
            >= FUZZY_MIN_GAP
        )

        if auto_ok:

            return TeamResolution(
                source=source_key,
                source_name=source_name,
                normalized_name=normalized,
                team_id=best_team.team_id,
                sofascore_id=best_team.sofascore_id,
                canonical_name=best_team.name,
                method="FUZZY_AUTO",
                score=float(
                    best_score
                ),
                review_required=False,
            )

        return TeamResolution(
            source=source_key,
            source_name=source_name,
            normalized_name=normalized,
            team_id=None,
            sofascore_id=None,
            canonical_name=best_team.name,
            method="FUZZY_REVIEW",
            score=float(
                best_score
            ),
            review_required=True,
        )


def main() -> None:

    mapper = TeamMapper()

    print(
        "TEAMMAPPER READ ONLY = OK"
    )

    print(
        "teams loaded =",
        len(
            mapper.teams
        ),
    )

    print(
        "sofascore ids loaded =",
        len(
            mapper.sofascore_index
        ),
    )

    duplicate_normalized = sum(
        1
        for ids
        in mapper.normalized_index.values()
        if len(ids) > 1
    )

    print(
        "duplicate normalized groups =",
        duplicate_normalized,
    )

    print(
        "alias sources =",
        sorted(
            mapper.aliases
        ),
    )


if __name__ == "__main__":
    main()