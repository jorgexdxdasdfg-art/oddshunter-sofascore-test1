from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional


DB_URI = "file:data/oddshunter.db?mode=ro"


@dataclass(frozen=True)
class MatchRecord:
    match_id: int
    sofascore_id: Optional[int]

    league_id: int
    season: str

    kickoff: str

    home_team_id: int
    away_team_id: int

    home_goals: Optional[int]
    away_goals: Optional[int]

    status: str
    identity_validated: int


@dataclass(frozen=True)
class MatchResolution:
    match_id: Optional[int]
    sofascore_id: Optional[int]

    method: str

    candidate_count: int

    kickoff: Optional[str]

    review_required: bool
    new_match: bool


def parse_datetime(
    value: str | datetime | None,
) -> tuple[Optional[datetime], bool]:
    """
    Devuelve:
        datetime normalizado
        date_only

    date_only=True significa que la fuente solamente
    entregó una fecha como 2025-08-17.
    """

    if value is None:
        return None, False

    if isinstance(value, datetime):
        dt = value

        if dt.tzinfo is None:
            dt = dt.replace(
                tzinfo=timezone.utc
            )

        return dt.astimezone(
            timezone.utc
        ), False

    raw = str(value).strip()

    if not raw:
        return None, False

    # Fecha pura.
    try:
        if len(raw) == 10:
            dt = datetime.strptime(
                raw,
                "%Y-%m-%d",
            ).replace(
                tzinfo=timezone.utc
            )

            return dt, True
    except ValueError:
        pass

    formats = [
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%d/%m/%Y %H:%M",
        "%d/%m/%Y",
    ]

    for fmt in formats:
        try:
            dt = datetime.strptime(
                raw,
                fmt,
            )

            if dt.tzinfo is None:
                dt = dt.replace(
                    tzinfo=timezone.utc
                )

            date_only = (
                fmt == "%d/%m/%Y"
            )

            return dt.astimezone(
                timezone.utc
            ), date_only

        except ValueError:
            continue

    # ISO 8601.
    try:
        iso = raw.replace(
            "Z",
            "+00:00",
        )

        dt = datetime.fromisoformat(
            iso
        )

        if dt.tzinfo is None:
            dt = dt.replace(
                tzinfo=timezone.utc
            )

        return dt.astimezone(
            timezone.utc
        ), False

    except ValueError:
        return None, False


def parse_db_datetime(
    value: str | None,
) -> Optional[datetime]:

    if value is None:
        return None

    raw = str(value).strip()

    if not raw:
        return None

    try:
        dt = datetime.fromisoformat(
            raw.replace(
                "Z",
                "+00:00",
            )
        )

        if dt.tzinfo is None:
            dt = dt.replace(
                tzinfo=timezone.utc
            )

        return dt.astimezone(
            timezone.utc
        )

    except ValueError:
        return None


class MatchMapper:
    """
    MatchMapper READ ONLY para OddsHunter Bulk.

    NO crea partidos.
    NO modifica matches.
    NO cambia identity_validated.
    """

    def __init__(
        self,
        db_uri: str = DB_URI,
    ) -> None:

        self.db_uri = db_uri

    def _connect(
        self,
    ) -> sqlite3.Connection:

        conn = sqlite3.connect(
            self.db_uri,
            uri=True,
        )

        conn.row_factory = sqlite3.Row

        return conn

    @staticmethod
    def _record(
        row: sqlite3.Row,
    ) -> MatchRecord:

        return MatchRecord(
            match_id=int(
                row["match_id"]
            ),
            sofascore_id=(
                int(row["sofascore_id"])
                if row["sofascore_id"] is not None
                else None
            ),
            league_id=int(
                row["league_id"]
            ),
            season=str(
                row["season"] or ""
            ),
            kickoff=str(
                row["kickoff"] or ""
            ),
            home_team_id=int(
                row["home_team_id"]
            ),
            away_team_id=int(
                row["away_team_id"]
            ),
            home_goals=(
                int(row["home_goals"])
                if row["home_goals"] is not None
                else None
            ),
            away_goals=(
                int(row["away_goals"])
                if row["away_goals"] is not None
                else None
            ),
            status=str(
                row["status"] or ""
            ),
            identity_validated=int(
                row["identity_validated"] or 0
            ),
        )

    def resolve_sofascore(
        self,
        sofascore_id: int,
    ) -> MatchResolution:

        with self._connect() as conn:

            rows = conn.execute(
                """
                SELECT
                    match_id,
                    sofascore_id,
                    league_id,
                    season,
                    kickoff,
                    home_team_id,
                    away_team_id,
                    home_goals,
                    away_goals,
                    status,
                    identity_validated
                FROM matches
                WHERE sofascore_id = ?
                """,
                (
                    int(sofascore_id),
                ),
            ).fetchall()

        if len(rows) == 1:

            match = self._record(
                rows[0]
            )

            return MatchResolution(
                match_id=match.match_id,
                sofascore_id=match.sofascore_id,
                method="SOFASCORE_EXACT",
                candidate_count=1,
                kickoff=match.kickoff,
                review_required=False,
                new_match=False,
            )

        if len(rows) > 1:

            return MatchResolution(
                match_id=None,
                sofascore_id=None,
                method="AMBIGUOUS_SOFASCORE",
                candidate_count=len(rows),
                kickoff=None,
                review_required=True,
                new_match=False,
            )

        return MatchResolution(
            match_id=None,
            sofascore_id=None,
            method="SOFASCORE_NOT_FOUND",
            candidate_count=0,
            kickoff=None,
            review_required=True,
            new_match=True,
        )

    def resolve(
        self,
        *,
        league_id: int,
        home_team_id: int,
        away_team_id: int,
        kickoff: str | datetime | None,
        home_goals: int | None = None,
        away_goals: int | None = None,
        sofascore_id: int | None = None,
    ) -> MatchResolution:

        # ==============================================
        # 1. SOFASCORE ID AUTORITATIVO SI VIENE
        # ==============================================

        if sofascore_id is not None:

            by_sid = self.resolve_sofascore(
                int(sofascore_id)
            )

            if not by_sid.new_match:
                return by_sid

        # ==============================================
        # 2. VALIDACIONES BÁSICAS
        # ==============================================

        league_id = int(
            league_id
        )

        home_team_id = int(
            home_team_id
        )

        away_team_id = int(
            away_team_id
        )

        if home_team_id == away_team_id:

            return MatchResolution(
                match_id=None,
                sofascore_id=None,
                method="INVALID_SAME_TEAM",
                candidate_count=0,
                kickoff=None,
                review_required=True,
                new_match=False,
            )

        source_dt, date_only = parse_datetime(
            kickoff
        )

        if source_dt is None:

            return MatchResolution(
                match_id=None,
                sofascore_id=None,
                method="INVALID_DATE",
                candidate_count=0,
                kickoff=None,
                review_required=True,
                new_match=False,
            )

        # ==============================================
        # 3. TRAER CANDIDATOS POR IDENTIDAD FUERTE
        # ==============================================

        with self._connect() as conn:

            rows = conn.execute(
                """
                SELECT
                    match_id,
                    sofascore_id,
                    league_id,
                    season,
                    kickoff,
                    home_team_id,
                    away_team_id,
                    home_goals,
                    away_goals,
                    status,
                    identity_validated
                FROM matches
                WHERE league_id = ?
                  AND home_team_id = ?
                  AND away_team_id = ?
                ORDER BY kickoff
                """,
                (
                    league_id,
                    home_team_id,
                    away_team_id,
                ),
            ).fetchall()

        candidates = [
            self._record(row)
            for row in rows
        ]

        if not candidates:

            return MatchResolution(
                match_id=None,
                sofascore_id=None,
                method="NEW_MATCH",
                candidate_count=0,
                kickoff=None,
                review_required=True,
                new_match=True,
            )

        # ==============================================
        # 4. FECHA EXACTA
        # ==============================================

        exact_day = []

        for candidate in candidates:

            candidate_dt = parse_db_datetime(
                candidate.kickoff
            )

            if candidate_dt is None:
                continue

            if (
                candidate_dt.date()
                ==
                source_dt.date()
            ):
                exact_day.append(
                    candidate
                )

        if len(exact_day) == 1:

            match = exact_day[0]

            # Marcador como validación adicional cuando
            # la fuente lo trae y DB también.
            if (
                home_goals is not None
                and away_goals is not None
                and match.home_goals is not None
                and match.away_goals is not None
            ):
                if (
                    int(home_goals)
                    != match.home_goals
                    or int(away_goals)
                    != match.away_goals
                ):
                    return MatchResolution(
                        match_id=None,
                        sofascore_id=None,
                        method="SCORE_MISMATCH",
                        candidate_count=1,
                        kickoff=match.kickoff,
                        review_required=True,
                        new_match=False,
                    )

            return MatchResolution(
                match_id=match.match_id,
                sofascore_id=match.sofascore_id,
                method="IDENTITY_DATE_EXACT",
                candidate_count=1,
                kickoff=match.kickoff,
                review_required=False,
                new_match=False,
            )

        # ==============================================
        # 5. VARIOS EN EL MISMO DÍA
        # ==============================================

        if len(exact_day) > 1:

            if (
                home_goals is not None
                and away_goals is not None
            ):

                score_matches = [
                    match
                    for match in exact_day
                    if (
                        match.home_goals is not None
                        and match.away_goals is not None
                        and match.home_goals
                            == int(home_goals)
                        and match.away_goals
                            == int(away_goals)
                    )
                ]

                if len(score_matches) == 1:

                    match = score_matches[0]

                    return MatchResolution(
                        match_id=match.match_id,
                        sofascore_id=match.sofascore_id,
                        method="IDENTITY_DATE_SCORE",
                        candidate_count=len(exact_day),
                        kickoff=match.kickoff,
                        review_required=False,
                        new_match=False,
                    )

            return MatchResolution(
                match_id=None,
                sofascore_id=None,
                method="AMBIGUOUS_SAME_DAY",
                candidate_count=len(exact_day),
                kickoff=None,
                review_required=True,
                new_match=False,
            )

        # ==============================================
        # 6. SI LA FUENTE TRAE HORA, TOLERANCIA CONTROLADA
        # ==============================================

        if not date_only:

            near = []

            for candidate in candidates:

                candidate_dt = parse_db_datetime(
                    candidate.kickoff
                )

                if candidate_dt is None:
                    continue

                delta_hours = abs(
                    (
                        candidate_dt
                        -
                        source_dt
                    ).total_seconds()
                ) / 3600.0

                if delta_hours <= 12.0:
                    near.append(
                        (
                            delta_hours,
                            candidate,
                        )
                    )

            near.sort(
                key=lambda item: item[0]
            )

            if len(near) == 1:

                match = near[0][1]

                return MatchResolution(
                    match_id=match.match_id,
                    sofascore_id=match.sofascore_id,
                    method="IDENTITY_TIME_TOLERANCE",
                    candidate_count=1,
                    kickoff=match.kickoff,
                    review_required=False,
                    new_match=False,
                )

            if len(near) > 1:

                return MatchResolution(
                    match_id=None,
                    sofascore_id=None,
                    method="AMBIGUOUS_TIME",
                    candidate_count=len(near),
                    kickoff=None,
                    review_required=True,
                    new_match=False,
                )

        # ==============================================
        # 7. PARTIDO POSIBLE EN FECHA CERCANA
        #    NO AUTO-ASIGNAR
        # ==============================================

        near_day = []

        for candidate in candidates:

            candidate_dt = parse_db_datetime(
                candidate.kickoff
            )

            if candidate_dt is None:
                continue

            days = abs(
                (
                    candidate_dt.date()
                    -
                    source_dt.date()
                ).days
            )

            if days <= 1:
                near_day.append(
                    candidate
                )

        if near_day:

            return MatchResolution(
                match_id=None,
                sofascore_id=None,
                method="DATE_NEAR_REVIEW",
                candidate_count=len(near_day),
                kickoff=None,
                review_required=True,
                new_match=False,
            )

        # ==============================================
        # 8. NO EXISTE EN ESA FECHA
        # ==============================================

        return MatchResolution(
            match_id=None,
            sofascore_id=None,
            method="NEW_MATCH",
            candidate_count=0,
            kickoff=None,
            review_required=True,
            new_match=True,
        )


def main() -> None:

    mapper = MatchMapper()

    with mapper._connect() as conn:

        total = conn.execute(
            "SELECT COUNT(*) FROM matches"
        ).fetchone()[0]

        sample = conn.execute(
            """
            SELECT
                match_id,
                sofascore_id,
                league_id,
                kickoff,
                home_team_id,
                away_team_id,
                home_goals,
                away_goals
            FROM matches
            WHERE sofascore_id IS NOT NULL
              AND kickoff IS NOT NULL
            ORDER BY match_id
            LIMIT 1
            """
        ).fetchone()

    print(
        "MATCHMAPPER READ ONLY = OK"
    )

    print(
        "matches visible =",
        total,
    )

    if sample is None:
        raise RuntimeError(
            "No encontré partido de prueba."
        )

    by_sofascore = mapper.resolve(
        league_id=sample["league_id"],
        home_team_id=sample["home_team_id"],
        away_team_id=sample["away_team_id"],
        kickoff=sample["kickoff"],
        home_goals=sample["home_goals"],
        away_goals=sample["away_goals"],
        sofascore_id=sample["sofascore_id"],
    )

    print("")
    print(
        "SOFASCORE SELF TEST =",
        by_sofascore.method,
        "| match_id=",
        by_sofascore.match_id,
        "| review=",
        by_sofascore.review_required,
    )

    if (
        by_sofascore.match_id
        != int(sample["match_id"])
        or by_sofascore.review_required
    ):
        raise RuntimeError(
            "Self test SofaScore falló."
        )

    by_identity = mapper.resolve(
        league_id=sample["league_id"],
        home_team_id=sample["home_team_id"],
        away_team_id=sample["away_team_id"],
        kickoff=sample["kickoff"],
        home_goals=sample["home_goals"],
        away_goals=sample["away_goals"],
    )

    print(
        "IDENTITY SELF TEST =",
        by_identity.method,
        "| match_id=",
        by_identity.match_id,
        "| review=",
        by_identity.review_required,
    )

    if (
        by_identity.match_id
        != int(sample["match_id"])
        or by_identity.review_required
    ):
        raise RuntimeError(
            "Self test de identidad falló."
        )

    print("")
    print(
        "self tests = 2/2 PASS"
    )


if __name__ == "__main__":
    main()