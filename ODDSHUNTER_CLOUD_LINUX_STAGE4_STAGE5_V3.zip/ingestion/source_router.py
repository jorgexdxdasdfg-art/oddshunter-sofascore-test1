from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


PROFILE_PATH = Path(
    r"data\manifests\source_profiles.json"
)


SUPPORTED_METRICS = {
    "goals",
    "xg",
    "corners",
    "yellow_cards",
    "shots",
    "shots_on_target",
    "goals_1h",
    "player_shots_on_target",
    "lineups",
}


@dataclass(frozen=True)
class MetricRoute:
    metric: str
    sources: tuple[str, ...]


@dataclass(frozen=True)
class SourcePlan:
    region: str
    competition_key: str | None
    routes: tuple[MetricRoute, ...]


class SourceRouter:
    """
    Decide qué fuentes intentar por MÉTRICA.

    NO descarga.
    NO escribe SQLite.
    NO modifica OddsHunter.

    Filosofía:

    EUROPA:
        Kaggle / Understat / FBref primero.
        Después:
        SofaScore -> Futbol24 -> Flashscore
        sólo si todavía falta el dato.

    LATAM:
        OpenFootball como base masiva cuando aplique.
        Después:
        SofaScore -> Futbol24 -> Flashscore
        para completar métricas faltantes.

    El router nunca obliga a consultar una fuente
    si la métrica ya existe localmente.
    """

    def __init__(
        self,
        profile_path: Path = PROFILE_PATH,
    ) -> None:

        self.profile_path = profile_path
        self.config = self._load_config()

    def _load_config(
        self,
    ) -> dict:

        raw = self.profile_path.read_text(
            encoding="utf-8-sig"
        )

        config = json.loads(raw)

        if not isinstance(config, dict):
            raise ValueError(
                "source_profiles.json debe ser un objeto JSON."
            )

        regions = config.get("regions")

        if not isinstance(regions, dict):
            raise ValueError(
                "source_profiles.json no contiene regions válidas."
            )

        return config

    @staticmethod
    def normalize_region(
        region: str,
    ) -> str:

        value = (
            str(region)
            .strip()
            .lower()
        )

        aliases = {
            "latin america": "latam",
            "latinoamerica": "latam",
            "latinoamérica": "latam",
            "south america": "latam",
            "central america": "latam",
            "america latina": "latam",
            "américa latina": "latam",

            "europe": "europe",
            "europa": "europe",
        }

        return aliases.get(
            value,
            value,
        )

    def _region_config(
        self,
        region: str,
    ) -> dict:

        normalized = self.normalize_region(
            region
        )

        regions = self.config["regions"]

        if normalized not in regions:
            raise KeyError(
                f"Región no configurada: {region}"
            )

        result = regions[
            normalized
        ]

        if not isinstance(result, dict):
            raise ValueError(
                f"Configuración inválida para {normalized}"
            )

        return result

    def route(
        self,
        *,
        region: str,
        metric: str,
        competition_key: str | None = None,
    ) -> MetricRoute:

        metric = (
            str(metric)
            .strip()
            .lower()
        )

        if metric not in SUPPORTED_METRICS:
            raise KeyError(
                f"Métrica no soportada: {metric}"
            )

        region_key = self.normalize_region(
            region
        )

        region_config = self._region_config(
            region_key
        )

        routes = dict(
            region_config.get(
                "metrics",
                {}
            )
        )

        # -----------------------------------------
        # Override opcional por competición.
        # -----------------------------------------

        if competition_key:

            competition_key = (
                str(competition_key)
                .strip()
                .lower()
            )

            overrides = self.config.get(
                "competitions",
                {}
            )

            competition_config = overrides.get(
                competition_key,
                {}
            )

            competition_metrics = (
                competition_config.get(
                    "metrics",
                    {}
                )
            )

            if metric in competition_metrics:
                routes[metric] = (
                    competition_metrics[
                        metric
                    ]
                )

        sources = routes.get(
            metric,
            []
        )

        if not isinstance(
            sources,
            list,
        ):
            raise ValueError(
                f"Ruta inválida para {region_key}:{metric}"
            )

        # Eliminar repetidos preservando orden.
        clean = []

        for source in sources:

            source = (
                str(source)
                .strip()
                .lower()
            )

            if not source:
                continue

            if source not in clean:
                clean.append(
                    source
                )

        return MetricRoute(
            metric=metric,
            sources=tuple(
                clean
            ),
        )

    def plan(
        self,
        *,
        region: str,
        metrics: Iterable[str],
        competition_key: str | None = None,
        already_available: Iterable[str] | None = None,
    ) -> SourcePlan:
        """
        Construye plan SOLAMENTE para métricas faltantes.

        Ejemplo:

        metrics:
            goals
            xg
            corners
            yellow_cards

        already_available:
            goals
            corners

        Resultado:
            xg
            yellow_cards

        No vuelve a pedir goals/corners.
        """

        available = {
            str(metric)
            .strip()
            .lower()

            for metric in (
                already_available
                or []
            )
        }

        requested = []

        for metric in metrics:

            normalized = (
                str(metric)
                .strip()
                .lower()
            )

            if normalized not in SUPPORTED_METRICS:
                raise KeyError(
                    f"Métrica no soportada: {normalized}"
                )

            if normalized in available:
                continue

            if normalized not in requested:
                requested.append(
                    normalized
                )

        routes = tuple(
            self.route(
                region=region,
                metric=metric,
                competition_key=competition_key,
            )
            for metric in requested
        )

        return SourcePlan(
            region=self.normalize_region(
                region
            ),
            competition_key=competition_key,
            routes=routes,
        )

    @staticmethod
    def print_plan(
        plan: SourcePlan,
    ) -> None:

        print(
            f"REGION = {plan.region}"
        )

        print(
            "COMPETITION =",
            plan.competition_key
            or "-"
        )

        for route in plan.routes:

            print(
                f"{route.metric:24}"
                f" -> "
                f"{' -> '.join(route.sources)}"
            )


def main() -> None:

    router = SourceRouter()

    print(
        "SOURCEROUTER = OK"
    )

    # ======================================================
    # TEST 1
    # EUROPA
    # ======================================================

    europe = router.plan(
        region="europe",
        metrics=[
            "goals",
            "xg",
            "corners",
            "yellow_cards",
            "shots",
            "shots_on_target",
            "goals_1h",
            "player_shots_on_target",
            "lineups",
        ],
    )

    print("")
    print("=" * 70)
    print("EUROPE TEST")
    print("=" * 70)

    router.print_plan(
        europe
    )

    europe_map = {
        route.metric:
        route.sources
        for route in europe.routes
    }

    assert (
        europe_map["goals"][0]
        == "kaggle"
    )

    assert (
        europe_map["xg"][0]
        == "understat"
    )

    assert (
        europe_map[
            "player_shots_on_target"
        ][0]
        == "fbref"
    )

    # ======================================================
    # TEST 2
    # LATAM
    # ======================================================

    latam = router.plan(
        region="latam",
        metrics=[
            "goals",
            "xg",
            "corners",
            "yellow_cards",
            "shots",
            "shots_on_target",
            "goals_1h",
            "player_shots_on_target",
            "lineups",
        ],
    )

    print("")
    print("=" * 70)
    print("LATAM TEST")
    print("=" * 70)

    router.print_plan(
        latam
    )

    latam_map = {
        route.metric:
        route.sources
        for route in latam.routes
    }

    assert (
        latam_map["goals"][0]
        == "openfootball"
    )

    assert (
        latam_map["xg"][0]
        == "sofascore"
    )

    # ======================================================
    # TEST 3
    # NO REPETIR DATOS YA DISPONIBLES
    # ======================================================

    missing_only = router.plan(
        region="latam",
        metrics=[
            "goals",
            "xg",
            "corners",
            "yellow_cards",
            "shots",
        ],
        already_available=[
            "goals",
            "corners",
            "shots",
        ],
    )

    remaining = [
        route.metric
        for route in missing_only.routes
    ]

    print("")
    print("=" * 70)
    print("MISSING ONLY TEST")
    print("=" * 70)

    router.print_plan(
        missing_only
    )

    assert remaining == [
        "xg",
        "yellow_cards",
    ]

    # ======================================================
    # TEST 4
    # NO DUPLICADOS EN RUTAS
    # ======================================================

    for plan in (
        europe,
        latam,
        missing_only,
    ):

        for route in plan.routes:

            assert (
                len(route.sources)
                ==
                len(set(route.sources))
            )

    print("")
    print(
        "self tests = 4/4 PASS"
    )


if __name__ == "__main__":
    main()