from __future__ import annotations

import json
import re
import sqlite3
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from rapidfuzz import fuzz, process


DB_URI = "file:data/oddshunter.db?mode=ro"

ALIASES_PATH = Path(
    r"data\manifests\league_aliases.json"
)


def normalize_text(
    value: str | None,
) -> str:

    if value is None:
        return ""

    text = str(value).strip().lower()

    if not text:
        return ""

    text = unicodedata.normalize(
        "NFKD",
        text,
    )

    text = "".join(
        ch
        for ch in text
        if not unicodedata.combining(ch)
    )

    text = text.replace("&", " and ")

    text = re.sub(
        r"[-_/.,'’`´()]",
        " ",
        text,
    )

    text = re.sub(
        r"[^a-z0-9\s]",
        " ",
        text,
    )

    text = re.sub(
        r"\s+",
        " ",
        text,
    ).strip()

    return text


@dataclass(frozen=True)
class LeagueRecord:
    league_id: int

    name: str
    country: str
    season: str

    active: int

    source_tournament_id: Optional[int]
    source_season_id: Optional[int]

    normalized_name: str
    normalized_country: str
    normalized_season: str


@dataclass(frozen=True)
class LeagueResolution:
    source: str

    source_name: str
    source_season: str
    source_country: str

    league_id: Optional[int]

    canonical_name: Optional[str]
    canonical_country: Optional[str]
    canonical_season: Optional[str]

    method: str
    score: float

    review_required: bool


class LeagueMapper:
    """
    Mapea liga + temporada externas hacia leagues.league_id
    YA EXISTENTE en OddsHunter.

    NO escribe SQLite.

    REGLAS:

    - leagues.league_id actual es autoritativo.
    - una temporada distinta puede tener league_id distinto.
    - exactos pueden resolverse automáticamente.
    - aliases explícitos pueden resolverse automáticamente.
    - fuzzy solamente propone.
    """

    def __init__(
        self,
        db_uri: str = DB_URI,
        aliases_path: Path = ALIASES_PATH,
    ) -> None:

        self.db_uri = db_uri
        self.aliases_path = aliases_path

        self.leagues: dict[
            int,
            LeagueRecord,
        ] = {}

        self.name_index: dict[
            str,
            list[int],
        ] = {}

        self.aliases: dict[
            str,
            dict[str, int],
        ] = {}

        self._load_leagues()
        self._load_aliases()

    def _connect(
        self,
    ) -> sqlite3.Connection:

        conn = sqlite3.connect(
            self.db_uri,
            uri=True,
        )

        conn.row_factory = sqlite3.Row

        return conn

    def _load_leagues(
        self,
    ) -> None:

        with self._connect() as conn:

            rows = conn.execute(
                """
                SELECT
                    league_id,
                    name,
                    country,
                    season,
                    active,
                    source_tournament_id,
                    source_season_id
                FROM leagues
                ORDER BY league_id
                """
            ).fetchall()

        for row in rows:

            record = LeagueRecord(
                league_id=int(
                    row["league_id"]
                ),
                name=str(
                    row["name"] or ""
                ),
                country=str(
                    row["country"] or ""
                ),
                season=str(
                    row["season"] or ""
                ),
                active=int(
                    row["active"] or 0
                ),
                source_tournament_id=(
                    int(row["source_tournament_id"])
                    if row["source_tournament_id"] is not None
                    else None
                ),
                source_season_id=(
                    int(row["source_season_id"])
                    if row["source_season_id"] is not None
                    else None
                ),
                normalized_name=normalize_text(
                    row["name"]
                ),
                normalized_country=normalize_text(
                    row["country"]
                ),
                normalized_season=normalize_text(
                    row["season"]
                ),
            )

            self.leagues[
                record.league_id
            ] = record

            self.name_index.setdefault(
                record.normalized_name,
                [],
            ).append(
                record.league_id
            )

    def _load_aliases(
        self,
    ) -> None:

        self.aliases = {}

        if not self.aliases_path.exists():
            return

        raw_text = self.aliases_path.read_text(
            encoding="utf-8-sig",
        )

        if not raw_text.strip():
            raw = {}
        else:
            raw = json.loads(
                raw_text
            )

        if not isinstance(raw, dict):
            raise ValueError(
                "league_aliases.json debe ser un objeto JSON."
            )

        for source, mapping in raw.items():

            if not isinstance(mapping, dict):
                raise ValueError(
                    f"Aliases inválidos para source={source}"
                )

            source_key = (
                str(source)
                .strip()
                .lower()
            )

            self.aliases[
                source_key
            ] = {}

            for external_key, league_id in mapping.items():

                canonical_id = int(
                    league_id
                )

                if canonical_id not in self.leagues:
                    raise ValueError(
                        f"{source}:{external_key} "
                        f"apunta a league_id inexistente "
                        f"{canonical_id}"
                    )

                key = normalize_text(
                    external_key
                )

                self.aliases[
                    source_key
                ][key] = canonical_id

    @staticmethod
    def alias_key(
        league_name: str,
        season: str | None = None,
        country: str | None = None,
    ) -> str:

        parts = [
            normalize_text(
                league_name
            ),
            normalize_text(
                season
            ),
            normalize_text(
                country
            ),
        ]

        return normalize_text(
            " | ".join(parts)
        )

    def resolve(
        self,
        source: str,
        league_name: str,
        *,
        season: str | None = None,
        country: str | None = None,
    ) -> LeagueResolution:

        source_key = (
            str(source)
            .strip()
            .lower()
        )

        source_name = str(
            league_name or ""
        )

        source_season = str(
            season or ""
        )

        source_country = str(
            country or ""
        )

        normalized_name = normalize_text(
            source_name
        )

        normalized_season = normalize_text(
            source_season
        )

        normalized_country = normalize_text(
            source_country
        )

        if not normalized_name:

            return LeagueResolution(
                source=source_key,
                source_name=source_name,
                source_season=source_season,
                source_country=source_country,
                league_id=None,
                canonical_name=None,
                canonical_country=None,
                canonical_season=None,
                method="EMPTY",
                score=0.0,
                review_required=True,
            )

        # ==================================================
        # 1. ALIAS EXPLÍCITO
        # ==================================================

        alias_candidates = []

        alias_candidates.append(
            self.alias_key(
                source_name,
                source_season,
                source_country,
            )
        )

        alias_candidates.append(
            self.alias_key(
                source_name,
                source_season,
                None,
            )
        )

        alias_candidates.append(
            self.alias_key(
                source_name,
                None,
                source_country,
            )
        )

        alias_candidates.append(
            self.alias_key(
                source_name,
                None,
                None,
            )
        )

        source_aliases = self.aliases.get(
            source_key,
            {},
        )

        for key in alias_candidates:

            league_id = source_aliases.get(
                key
            )

            if league_id is None:
                continue

            league = self.leagues[
                league_id
            ]

            return LeagueResolution(
                source=source_key,
                source_name=source_name,
                source_season=source_season,
                source_country=source_country,
                league_id=league.league_id,
                canonical_name=league.name,
                canonical_country=league.country,
                canonical_season=league.season,
                method="ALIAS_EXACT",
                score=100.0,
                review_required=False,
            )

        # ==================================================
        # 2. NOMBRE EXACTO
        # ==================================================

        candidate_ids = list(
            self.name_index.get(
                normalized_name,
                [],
            )
        )

        # Temporada es importante porque una liga tiene
        # normalmente un league_id diferente por temporada.
        if normalized_season:

            season_ids = [
                league_id
                for league_id in candidate_ids
                if (
                    self.leagues[
                        league_id
                    ].normalized_season
                    ==
                    normalized_season
                )
            ]

            if season_ids:
                candidate_ids = season_ids

        # El country de leagues sí describe la competición,
        # por lo que aquí sí es una pista válida.
        if normalized_country:

            country_ids = [
                league_id
                for league_id in candidate_ids
                if (
                    self.leagues[
                        league_id
                    ].normalized_country
                    ==
                    normalized_country
                )
            ]

            if country_ids:
                candidate_ids = country_ids

        if len(candidate_ids) == 1:

            league = self.leagues[
                candidate_ids[0]
            ]

            return LeagueResolution(
                source=source_key,
                source_name=source_name,
                source_season=source_season,
                source_country=source_country,
                league_id=league.league_id,
                canonical_name=league.name,
                canonical_country=league.country,
                canonical_season=league.season,
                method="NORMALIZED_EXACT",
                score=100.0,
                review_required=False,
            )

        if len(candidate_ids) > 1:

            return LeagueResolution(
                source=source_key,
                source_name=source_name,
                source_season=source_season,
                source_country=source_country,
                league_id=None,
                canonical_name=None,
                canonical_country=None,
                canonical_season=None,
                method="AMBIGUOUS_EXACT",
                score=100.0,
                review_required=True,
            )

        # ==================================================
        # 3. FUZZY = SÓLO PROPUESTA
        # ==================================================

        choices = {
            league.league_id:
                league.normalized_name
            for league in self.leagues.values()
        }

        fuzzy_results = process.extract(
            normalized_name,
            choices,
            scorer=fuzz.WRatio,
            limit=1,
        )

        if not fuzzy_results:

            return LeagueResolution(
                source=source_key,
                source_name=source_name,
                source_season=source_season,
                source_country=source_country,
                league_id=None,
                canonical_name=None,
                canonical_country=None,
                canonical_season=None,
                method="NO_MATCH",
                score=0.0,
                review_required=True,
            )

        (
            _,
            score,
            suggested_id,
        ) = fuzzy_results[0]

        suggested = self.leagues[
            int(suggested_id)
        ]

        return LeagueResolution(
            source=source_key,
            source_name=source_name,
            source_season=source_season,
            source_country=source_country,
            league_id=None,
            canonical_name=suggested.name,
            canonical_country=suggested.country,
            canonical_season=suggested.season,
            method="FUZZY_REVIEW",
            score=float(
                score
            ),
            review_required=True,
        )


def main() -> None:

    mapper = LeagueMapper()

    print(
        "LEAGUEMAPPER READ ONLY = OK"
    )

    print(
        "leagues loaded =",
        len(
            mapper.leagues
        ),
    )

    print(
        "alias sources =",
        sorted(
            mapper.aliases
        ),
    )

    tests = [
        (
            "internal",
            "Premier League",
            "Premier League 24/25",
            "England",
        ),
        (
            "internal",
            "Premier League",
            "Premier League 25/26",
            "England",
        ),
        (
            "internal",
            "LigaPro Serie A",
            "LigaPro Primera A 2025",
            "Ecuador",
        ),
        (
            "internal",
            "LigaPro Serie A",
            "LigaPro Primera A 2026",
            "Ecuador",
        ),
        (
            "internal",
            "Primera A",
            "Liga DIMAYOR 2026",
            "Colombia",
        ),
        (
            "internal",
            "Serie A",
            "Serie A 24/25",
            "Italy",
        ),
    ]

    print("")
    print("SELF TEST")
    print("=" * 70)

    failures = 0

    for (
        source,
        name,
        season,
        country,
    ) in tests:

        result = mapper.resolve(
            source,
            name,
            season=season,
            country=country,
        )

        print(
            f"{name} | {season} | {country}"
            f" -> {result.method}"
            f" | league_id={result.league_id}"
            f" | canonical={result.canonical_name}"
            f" | canonical_season={result.canonical_season}"
            f" | review={result.review_required}"
        )

        if (
            result.league_id is None
            or result.review_required
        ):
            failures += 1

    print("")
    print(
        "self test failures =",
        failures,
    )

    if failures:
        raise RuntimeError(
            "LeagueMapper self test falló."
        )


if __name__ == "__main__":
    main()