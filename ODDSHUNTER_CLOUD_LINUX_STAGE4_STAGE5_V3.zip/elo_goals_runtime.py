from __future__ import annotations

import argparse
import json
import math
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np

import poisson_dixon_coles_core as core
from elo_goals_engine import DATA_DIR, DB_PATH, model_path, read_json, read_json_optional, write_json
from elo_manager import obtener_elo_prepartido


def parse_timestamp(value: Any) -> int:
    text = str(value or "").strip()
    if not text:
        return int(datetime.now(timezone.utc).timestamp())
    parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return int(parsed.timestamp())


def resolve_team_id(
    connection: sqlite3.Connection,
    source_id: Any,
    name: Any,
) -> int:
    try:
        value = int(source_id)
    except (TypeError, ValueError):
        value = -1

    if value >= 0:
        row = connection.execute(
            "SELECT team_id FROM teams WHERE sofascore_id = ? LIMIT 1",
            (value,),
        ).fetchone()
        if row is not None:
            return int(row[0])

        row = connection.execute(
            "SELECT team_id FROM teams WHERE team_id = ? LIMIT 1",
            (value,),
        ).fetchone()
        if row is not None:
            return int(row[0])

    if name:
        row = connection.execute(
            "SELECT team_id FROM teams WHERE LOWER(name) = LOWER(?) ORDER BY team_id DESC LIMIT 1",
            (str(name),),
        ).fetchone()
        if row is not None:
            return int(row[0])

    raise RuntimeError(f"No se pudo resolver el equipo id={source_id}, nombre={name}.")


def season_context(connection: sqlite3.Connection, key: str) -> dict[str, Any]:
    row = connection.execute(
        """
        SELECT
            et.season_id,
            et.source_league_id AS league_id,
            et.competition_key,
            et.season_name,
            ep.elo_base,
            ep.escala_elo,
            ep.cap_elo
        FROM elo_temporadas AS et
        INNER JOIN elo_parametros_liga AS ep
            ON ep.competition_key = et.competition_key
        WHERE et.source_registry_key = ?
        """,
        (str(key),),
    ).fetchone()
    if row is None:
        raise RuntimeError(f"No existe temporada ELO para '{key}'.")
    return dict(row)


def metadata_only(
    document: dict[str, Any],
    key: str,
    model: dict[str, Any] | None,
    reason: str,
) -> dict[str, Any]:
    info = {
        "available": model is not None,
        "active": bool(model and model.get("active")),
        "applied": False,
        "competition_key": key,
        "reason": reason,
        "model_path": str(model_path(key)),
    }
    document.setdefault("methodology", {})["elo"] = info
    document.setdefault("trained_model", {})["elo"] = info
    return document


def apply_elo(
    key: str,
    ratings_path: Path,
    goals_path: Path,
) -> dict[str, Any]:
    document = read_json(goals_path)
    model = read_json_optional(model_path(key))

    if model is None:
        return metadata_only(document, key, None, "No existe elo_goals_model.json.")

    if not bool(model.get("active")):
        reason = str(model.get("decision", {}).get("reason") or "ELO desactivado por validación.")
        return metadata_only(document, key, model, reason)

    ratings = read_json(ratings_path)
    contexto = core.extraer_contexto(ratings)
    parameters = model.get("parameters", {})
    required = (
        "recent_weight",
        "venue_mix",
        "xg_weight",
        "league_shrinkage",
        "home_advantage",
        "dixon_coles_rho",
        "elo_weight",
    )
    missing = [name for name in required if parameters.get(name) is None]
    if missing:
        raise RuntimeError("Faltan parámetros ELO: " + ", ".join(missing))

    connection = sqlite3.connect(DB_PATH, timeout=30)
    connection.row_factory = sqlite3.Row
    try:
        season = season_context(connection, key)
        match = contexto["match"]
        home_id = resolve_team_id(
            connection,
            match.get("home_team_id") or contexto.get("home_team", {}).get("sofascore_id"),
            match.get("home_team") or contexto.get("home_team", {}).get("name"),
        )
        away_id = resolve_team_id(
            connection,
            match.get("away_team_id") or contexto.get("away_team", {}).get("sofascore_id"),
            match.get("away_team") or contexto.get("away_team", {}).get("name"),
        )
        kickoff_timestamp = parse_timestamp(match.get("kickoff"))
        home_elo = obtener_elo_prepartido(
            connection,
            league_id=int(season["league_id"]),
            season_id=int(season["season_id"]),
            team_id=home_id,
            match_timestamp=kickoff_timestamp,
            elo_inicial=float(season["elo_base"]),
        )
        away_elo = obtener_elo_prepartido(
            connection,
            league_id=int(season["league_id"]),
            season_id=int(season["season_id"]),
            team_id=away_id,
            match_timestamp=kickoff_timestamp,
            elo_inicial=float(season["elo_base"]),
        )

        league_means = core.cargar_medias_liga(
            connection,
            league_id=int(season["league_id"]),
            before_kickoff=str(match.get("kickoff") or "") or None,
        )
    finally:
        connection.close()

    learned_component = {
        "parameters": {
            name: float(parameters[name])
            for name in required[:6]
        }
    }
    model_parameters = core.construir_parametros(
        contexto,
        learned_component,
        league_means,
    )
    learned = model_parameters.get("MODELO_APRENDIDO")
    if not isinstance(learned, dict):
        raise RuntimeError("No se pudo reconstruir MODELO_APRENDIDO.")

    elo_weight = float(parameters["elo_weight"])
    elo_scale = float(model.get("runtime", {}).get("elo_scale") or season["escala_elo"])
    elo_cap = float(model.get("runtime", {}).get("elo_cap") or season["cap_elo"])
    raw_difference = float(home_elo) - float(away_elo)
    clipped_difference = float(np.clip(raw_difference, -elo_cap, elo_cap))
    exponent = elo_weight * clipped_difference / elo_scale
    home_factor = math.exp(exponent)
    away_factor = math.exp(-exponent)

    adjusted_parameters = {
        "lambda_home": float(np.clip(float(learned["lambda_home"]) * home_factor, core.MIN_LAMBDA, core.MAX_LAMBDA)),
        "lambda_away": float(np.clip(float(learned["lambda_away"]) * away_factor, core.MIN_LAMBDA, core.MAX_LAMBDA)),
        "source": (
            "Parámetros aprendidos por liga y ajuste ELO prepartido activado "
            "únicamente porque mejoró la validación walk-forward."
        ),
    }
    rho = float(parameters["dixon_coles_rho"])
    document.setdefault("models", {})["MODELO_APRENDIDO"] = core.analizar_modelo(
        "MODELO_APRENDIDO",
        adjusted_parameters,
        rho,
    )

    info = {
        "available": True,
        "active": True,
        "applied": True,
        "competition_key": key,
        "model_path": str(model_path(key)),
        "home_elo": round(float(home_elo), 4),
        "away_elo": round(float(away_elo), 4),
        "raw_difference": round(raw_difference, 4),
        "clipped_difference": round(clipped_difference, 4),
        "elo_weight": round(elo_weight, 8),
        "elo_scale": round(elo_scale, 4),
        "elo_cap": round(elo_cap, 4),
        "home_factor": round(home_factor, 8),
        "away_factor": round(away_factor, 8),
        "validation_delta": model.get("decision", {}).get("delta"),
        "decision_reason": model.get("decision", {}).get("reason"),
    }
    document.setdefault("methodology", {})["elo"] = info
    document.setdefault("trained_model", {})["elo"] = info
    return document


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Aplica ELO validado al JSON de goles.")
    parser.add_argument("--key", required=True)
    parser.add_argument("--ratings-json", required=True)
    parser.add_argument("--goals-json", required=True)
    parser.add_argument("--latest-json")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    goals_path = Path(args.goals_json)
    result = apply_elo(
        str(args.key),
        Path(args.ratings_json),
        goals_path,
    )
    write_json(goals_path, result)
    if args.latest_json:
        write_json(Path(args.latest_json), result)

    elo_info = result.get("methodology", {}).get("elo", {})
    print("=" * 74)
    print("ELO DEL MODELO DE GOLES")
    print("=" * 74)
    print("Estado: " + ("APLICADO" if elo_info.get("applied") else "NO APLICADO"))
    print(f"Motivo: {elo_info.get('reason') or elo_info.get('decision_reason') or 'N/D'}")
    if elo_info.get("applied"):
        print(
            f"ELO local {elo_info['home_elo']:.2f} | "
            f"ELO visitante {elo_info['away_elo']:.2f} | "
            f"peso {elo_info['elo_weight']:.4f}"
        )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR ELO: {type(exc).__name__}: {exc}")
        raise SystemExit(1)
