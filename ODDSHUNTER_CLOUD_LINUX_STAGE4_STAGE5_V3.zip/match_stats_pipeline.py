from __future__ import annotations

import math
import inspect
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Mapping, Protocol, Sequence

from xg_pipeline import MatchRef


REQUIRED_METRICS = (
    "shots",
    "shots_on_target",
    "corners",
    "yellow_cards",
)
OPTIONAL_METRICS = (
    "red_cards",
    "possession",
    "fouls",
    "offsides",
    "big_chances",
)
ALL_METRICS = REQUIRED_METRICS + OPTIONAL_METRICS


@dataclass(frozen=True)
class MetricPair:
    home: float | int | None
    away: float | int | None

    @property
    def available(self) -> bool:
        return _valid_number(self.home) and _valid_number(self.away)


@dataclass(frozen=True)
class MatchStatsResult:
    values: dict[str, MetricPair]
    sources: dict[str, str]
    updated_at: str
    attempts: list[dict[str, Any]] = field(default_factory=list)
    duration_ms: int = 0

    @property
    def complete(self) -> bool:
        return all(
            self.values.get(metric, MetricPair(None, None)).available
            for metric in REQUIRED_METRICS
        )

    @property
    def missing(self) -> list[str]:
        return [
            metric
            for metric in REQUIRED_METRICS
            if not self.values.get(
                metric,
                MetricPair(None, None),
            ).available
        ]

    def pair(self, metric: str) -> MetricPair:
        return self.values.get(metric, MetricPair(None, None))

    def to_dict(self) -> dict[str, Any]:
        return {
            "values": {
                key: asdict(value)
                for key, value in self.values.items()
            },
            "sources": dict(self.sources),
            "complete": self.complete,
            "missing": self.missing,
            "updated_at": self.updated_at,
            "attempts": list(self.attempts),
            "duration_ms": self.duration_ms,
        }


class MatchStatsSource(Protocol):
    name: str

    def get_match_stats(
        self,
        match: MatchRef,
        *,
        missing_fields: Sequence[str] | None = None,
    ) -> Mapping[str, MetricPair | tuple[Any, Any] | list[Any]]:
        ...


def _valid_number(value: Any) -> bool:
    if value is None or isinstance(value, bool):
        return False
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return False
    return math.isfinite(parsed) and parsed >= 0.0


def _pair(value: Any) -> MetricPair:
    if isinstance(value, MetricPair):
        return value
    if isinstance(value, (tuple, list)) and len(value) >= 2:
        return MetricPair(value[0], value[1])
    if isinstance(value, Mapping):
        return MetricPair(value.get("home"), value.get("away"))
    return MetricPair(None, None)


def _source_stats(
    source: MatchStatsSource,
    match: MatchRef,
    missing_fields: Sequence[str],
) -> Mapping[str, MetricPair | tuple[Any, Any] | list[Any]]:
    """Pide solo los campos pendientes cuando la fuente lo soporta."""

    method = source.get_match_stats
    try:
        supports_missing = "missing_fields" in inspect.signature(
            method
        ).parameters
    except (TypeError, ValueError):
        supports_missing = False
    if supports_missing:
        return method(
            match,
            missing_fields=tuple(missing_fields),
        )
    return method(match)


def recover_match_stats(
    match: MatchRef,
    primary: Mapping[
        str,
        MetricPair | tuple[Any, Any] | list[Any],
    ],
    sources: Sequence[MatchStatsSource],
) -> MatchStatsResult:
    """Completa cada métrica sin reemplazar valores ya publicados.

    El orden es estricto: SofaScore (``primary``), Futbol24 y
    Flashscore. Una fuente solo se consulta si todavía falta al menos una
    métrica obligatoria. Cada campo conserva la fuente que realmente lo
    aportó.
    """

    started = time.monotonic()
    values = {
        metric: _pair(primary.get(metric))
        for metric in ALL_METRICS
    }
    sources_by_metric = {
        metric: "sofascore"
        for metric, pair in values.items()
        if pair.available
    }
    primary_filled = [
        metric
        for metric in REQUIRED_METRICS
        if values[metric].available
    ]
    attempts: list[dict[str, Any]] = [
        {
            "source": "sofascore",
            "state": "PRIMARY_PARSED",
            "requested": list(REQUIRED_METRICS),
            "filled": primary_filled,
            "missing_after": [
                metric
                for metric in REQUIRED_METRICS
                if not values[metric].available
            ],
            "duration_ms": 0,
        }
    ]

    for source in sources:
        missing_before = [
            metric
            for metric in REQUIRED_METRICS
            if not values[metric].available
        ]
        source_name = str(source.name or "unknown").strip().lower()
        if not missing_before:
            attempts.append(
                {
                    "source": source_name,
                    "state": "SKIPPED",
                    "reason": "NO_FIELDS_MISSING",
                    "requested": [],
                    "filled": [],
                    "duration_ms": 0,
                }
            )
            continue

        source_started = time.monotonic()
        try:
            recovered = _source_stats(
                source,
                match,
                missing_before,
            )
        except Exception as exc:
            attempts.append(
                {
                    "source": source_name,
                    "state": "SOURCE_UNAVAILABLE",
                    "requested": missing_before,
                    "error": f"{type(exc).__name__}: {exc}",
                    "duration_ms": round(
                        (time.monotonic() - source_started) * 1000
                    ),
                }
            )
            continue

        recovered = recovered if isinstance(recovered, Mapping) else {}
        filled: list[str] = []
        for metric in ALL_METRICS:
            if values[metric].available:
                continue
            candidate = _pair(recovered.get(metric))
            if not candidate.available:
                continue
            values[metric] = candidate
            sources_by_metric[metric] = source_name
            filled.append(metric)

        attempts.append(
            {
                "source": source_name,
                "state": "USED",
                "requested": missing_before,
                "filled": filled,
                "missing_after": [
                    metric
                    for metric in REQUIRED_METRICS
                    if not values[metric].available
                ],
                "duration_ms": round(
                    (time.monotonic() - source_started) * 1000
                ),
            }
        )

    return MatchStatsResult(
        values=values,
        sources=sources_by_metric,
        updated_at=datetime.now(timezone.utc).isoformat(),
        attempts=attempts,
        duration_ms=round((time.monotonic() - started) * 1000),
    )
