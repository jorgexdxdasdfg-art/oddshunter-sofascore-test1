from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


# ==============================================================================
# 1. RUTAS
# ==============================================================================

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
REGISTRY_PATH = DATA_DIR / "competitions.json"
COMPETITIONS_DIR = DATA_DIR / "competitions"
ANALYSIS_ROOT_DIR = DATA_DIR / "analisis"
DB_PATH = DATA_DIR / "oddshunter.db"

RATINGS_SCRIPT = BASE_DIR / "ratings.py"
GOALS_SCRIPT = BASE_DIR / "poisson_dixon_coles.py"
CORNERS_SCRIPT = BASE_DIR / "corners_model.py"
CARDS_SCRIPT = BASE_DIR / "cards_model.py"
TRAINED_LOADER_SCRIPT = BASE_DIR / "trained_model_loader.py"

RATINGS_DIR = DATA_DIR / "ratings"
GOALS_DIR = DATA_DIR / "modelos"
CORNERS_ROOT_DIR = DATA_DIR / "modelos" / "corners"
CARDS_ROOT_DIR = DATA_DIR / "modelos" / "cards"

REQUIRED_SCRIPTS = (
    RATINGS_SCRIPT,
    GOALS_SCRIPT,
    CORNERS_SCRIPT,
    CARDS_SCRIPT,
    TRAINED_LOADER_SCRIPT,
)

ANALYSIS_ROOT_DIR.mkdir(parents=True, exist_ok=True)


# ==============================================================================
# 2. UTILIDADES
# ==============================================================================

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def slugify(text: str) -> str:
    import re

    value = text.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-")


def read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"No existe:\n{path}")

    data = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(data, dict):
        raise ValueError(f"{path.name} no contiene un objeto JSON válido.")

    return data


def read_json_optional(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None

    return data if isinstance(data, dict) else None


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def copy_json(source: Path, destination: Path) -> dict[str, Any]:
    data = read_json(source)
    write_json(destination, data)
    return data


def event_id_from_document(document: dict[str, Any]) -> int | None:
    for key in ("upcoming_match", "evento"):
        event = document.get(key)

        if not isinstance(event, dict):
            continue

        value = event.get("event_id")

        try:
            return int(value)
        except (TypeError, ValueError):
            continue

    return None


def validate_event_document(
    path: Path,
    expected_event_id: int,
) -> dict[str, Any]:
    document = read_json(path)
    actual_event_id = event_id_from_document(document)

    if actual_event_id != expected_event_id:
        raise RuntimeError(
            f"{path.name} pertenece al evento {actual_event_id}, "
            f"pero se esperaba {expected_event_id}."
        )

    return document


def file_signature(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {
            "exists": False,
            "size": None,
            "mtime_ns": None,
        }

    stat = path.stat()

    return {
        "exists": True,
        "size": stat.st_size,
        "mtime_ns": stat.st_mtime_ns,
    }


def build_fingerprint(
    competition_key: str,
    schedule_generated_at: str | None,
    match: dict[str, Any],
) -> str:
    payload = {
        "competition_key": competition_key,
        "schedule_generated_at": schedule_generated_at,
        "match": {
            "event_id": match.get("event_id"),
            "start_timestamp": match.get("start_timestamp"),
            "kickoff": match.get("kickoff"),
            "home_team_id": match.get("home_team_id"),
            "away_team_id": match.get("away_team_id"),
        },
        "database": file_signature(DB_PATH),
        "trained_model": file_signature(
            DATA_DIR
            / "trained_models"
            / competition_key
            / "latest_model.json"
        ),
        "modules": {
            script.name: file_signature(script)
            for script in REQUIRED_SCRIPTS
        },
    }

    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
    ).encode("utf-8")

    return hashlib.sha256(encoded).hexdigest()


# ==============================================================================
# 3. REGISTRO Y CALENDARIO
# ==============================================================================

def load_registry() -> dict[str, Any]:
    registry = read_json(REGISTRY_PATH)

    if not isinstance(registry.get("competitions"), list):
        raise ValueError(
            "competitions.json no contiene una lista 'competitions'."
        )

    return registry


def find_competition(
    registry: dict[str, Any],
    key: str,
) -> dict[str, Any]:
    normalized = slugify(key)

    for competition in registry["competitions"]:
        current = slugify(str(competition.get("key", "")))

        if current == normalized:
            return competition

    raise ValueError(f"No existe la competición '{key}'.")


def load_upcoming_schedule(
    competition_key: str,
) -> tuple[dict[str, Any], Path]:
    path = (
        COMPETITIONS_DIR
        / competition_key
        / "matches_upcoming.json"
    )

    schedule = read_json(path)
    matches = schedule.get("matches")

    if not isinstance(matches, list):
        raise ValueError(
            f"{path.name} no contiene una lista 'matches'."
        )

    unique: dict[int, dict[str, Any]] = {}

    for match in matches:
        if not isinstance(match, dict):
            continue

        try:
            event_id = int(match["event_id"])
        except (KeyError, TypeError, ValueError):
            continue

        normalized = dict(match)
        normalized["event_id"] = event_id
        unique[event_id] = normalized

    schedule["matches"] = sorted(
        unique.values(),
        key=lambda item: (
            int(item.get("start_timestamp") or 0),
            int(item["event_id"]),
        ),
    )

    return schedule, path


# ==============================================================================
# 4. EJECUCIÓN DE MÓDULOS
# ==============================================================================

def run_module(
    title: str,
    command: list[str],
    log_path: Path,
) -> None:
    environment = os.environ.copy()
    environment["PYTHONUTF8"] = "1"
    environment["PYTHONIOENCODING"] = "utf-8"

    print(f"   ▶ {title}")
    print("     $ " + " ".join(command))

    log_path.parent.mkdir(parents=True, exist_ok=True)

    with log_path.open(
        "w",
        encoding="utf-8",
        errors="replace",
    ) as log_file:
        process = subprocess.Popen(
            command,
            cwd=BASE_DIR,
            env=environment,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
        )

        assert process.stdout is not None

        for line in process.stdout:
            log_file.write(line)
            log_file.flush()

            visible = line.rstrip()

            if visible:
                print(f"     {visible}")

        return_code = process.wait()

    if return_code != 0:
        raise RuntimeError(
            f"{title} terminó con código {return_code}. "
            f"Revisa {log_path}"
        )


def module_paths(
    competition_key: str,
    event_id: int,
) -> dict[str, Path]:
    return {
        "ratings_source": (
            RATINGS_DIR
            / f"ratings_{event_id}.json"
        ),
        "goals_source": (
            GOALS_DIR
            / f"poisson_dixon_coles_{event_id}.json"
        ),
        "corners_source": (
            CORNERS_ROOT_DIR
            / competition_key
            / f"corners_{event_id}.json"
        ),
        "cards_source": (
            CARDS_ROOT_DIR
            / competition_key
            / f"cards_{event_id}.json"
        ),
    }


def destination_paths(event_dir: Path) -> dict[str, Path]:
    return {
        "ratings": event_dir / "ratings.json",
        "goals": event_dir / "goals.json",
        "corners": event_dir / "corners.json",
        "cards": event_dir / "cards.json",
    }


def valid_component(
    path: Path,
    event_id: int,
) -> bool:
    try:
        validate_event_document(path, event_id)
        return True
    except Exception:
        return False


def analyze_match(
    competition: dict[str, Any],
    match: dict[str, Any],
    schedule_generated_at: str | None,
    force: bool,
) -> dict[str, Any]:
    competition_key = slugify(str(competition["key"]))
    event_id = int(match["event_id"])

    event_dir = (
        ANALYSIS_ROOT_DIR
        / competition_key
        / str(event_id)
    )
    event_dir.mkdir(parents=True, exist_ok=True)

    input_path = event_dir / "input_match.json"
    bundle_path = event_dir / "analysis.json"
    status_path = event_dir / "status.json"
    logs_dir = event_dir / "logs"

    fingerprint = build_fingerprint(
        competition_key=competition_key,
        schedule_generated_at=schedule_generated_at,
        match=match,
    )

    previous_bundle = read_json_optional(bundle_path)

    if (
        not force
        and isinstance(previous_bundle, dict)
        and previous_bundle.get("fingerprint") == fingerprint
        and previous_bundle.get("status") == "FULL"
    ):
        files = destination_paths(event_dir)

        if all(
            valid_component(path, event_id)
            for path in files.values()
        ):
            print("   ⏭️ Ya estaba analizado y continúa vigente.")

            return {
                "event_id": event_id,
                "kickoff": match.get("kickoff"),
                "home_team": match.get("home_team"),
                "away_team": match.get("away_team"),
                "status": "SKIPPED",
                "analysis_status": "FULL",
                "path": str(bundle_path),
                "generated_at": previous_bundle.get(
                    "generated_at"
                ),
                "errors": [],
            }

    input_document = {
        "generated_at": utc_now(),
        "competition_key": competition_key,
        "evento": match,
        "upcoming_match": match,
    }
    write_json(input_path, input_document)

    sources = module_paths(
        competition_key,
        event_id,
    )
    destinations = destination_paths(event_dir)

    components: dict[str, dict[str, Any] | None] = {
        "ratings": None,
        "goals": None,
        "corners": None,
        "cards": None,
    }

    errors: list[dict[str, str]] = []

    status_document = {
        "event_id": event_id,
        "competition_key": competition_key,
        "started_at": utc_now(),
        "fingerprint": fingerprint,
        "steps": {},
    }
    write_json(status_path, status_document)

    # --------------------------------------------------------------------------
    # RATINGS
    # --------------------------------------------------------------------------
    try:
        sources["ratings_source"].unlink(missing_ok=True)

        run_module(
            title="Ratings ponderados",
            command=[
                sys.executable,
                "-u",
                str(RATINGS_SCRIPT),
                str(input_path),
                "--key",
                competition_key,
            ],
            log_path=logs_dir / "ratings.log",
        )

        validate_event_document(
            sources["ratings_source"],
            event_id,
        )

        components["ratings"] = copy_json(
            sources["ratings_source"],
            destinations["ratings"],
        )

        status_document["steps"]["ratings"] = "OK"

    except Exception as exc:
        message = f"{type(exc).__name__}: {exc}"
        errors.append(
            {
                "component": "ratings",
                "error": message,
            }
        )
        status_document["steps"]["ratings"] = message

    write_json(status_path, status_document)

    # Sin ratings no se pueden ejecutar los demás modelos.
    if components["ratings"] is None:
        status = "ERROR"

    else:
        # ----------------------------------------------------------------------
        # GOLES
        # ----------------------------------------------------------------------
        try:
            sources["goals_source"].unlink(missing_ok=True)

            run_module(
                title="Poisson + Dixon-Coles",
                command=[
                    sys.executable,
                    "-u",
                    str(GOALS_SCRIPT),
                    str(destinations["ratings"]),
                    "--key",
                    competition_key,
                ],
                log_path=logs_dir / "goals.log",
            )

            validate_event_document(
                sources["goals_source"],
                event_id,
            )

            components["goals"] = copy_json(
                sources["goals_source"],
                destinations["goals"],
            )

            status_document["steps"]["goals"] = "OK"

        except Exception as exc:
            message = f"{type(exc).__name__}: {exc}"
            errors.append(
                {
                    "component": "goals",
                    "error": message,
                }
            )
            status_document["steps"]["goals"] = message

        write_json(status_path, status_document)

        # ----------------------------------------------------------------------
        # CÓRNERS
        # ----------------------------------------------------------------------
        try:
            sources["corners_source"].unlink(missing_ok=True)

            run_module(
                title="Modelo de córners",
                command=[
                    sys.executable,
                    "-u",
                    str(CORNERS_SCRIPT),
                    "--key",
                    competition_key,
                    "--match-json",
                    str(destinations["ratings"]),
                ],
                log_path=logs_dir / "corners.log",
            )

            validate_event_document(
                sources["corners_source"],
                event_id,
            )

            components["corners"] = copy_json(
                sources["corners_source"],
                destinations["corners"],
            )

            status_document["steps"]["corners"] = "OK"

        except Exception as exc:
            message = f"{type(exc).__name__}: {exc}"
            errors.append(
                {
                    "component": "corners",
                    "error": message,
                }
            )
            status_document["steps"]["corners"] = message

        write_json(status_path, status_document)

        # ----------------------------------------------------------------------
        # TARJETAS
        # ----------------------------------------------------------------------
        try:
            sources["cards_source"].unlink(missing_ok=True)

            run_module(
                title="Modelo de tarjetas",
                command=[
                    sys.executable,
                    "-u",
                    str(CARDS_SCRIPT),
                    "--key",
                    competition_key,
                    "--match-json",
                    str(destinations["ratings"]),
                ],
                log_path=logs_dir / "cards.log",
            )

            validate_event_document(
                sources["cards_source"],
                event_id,
            )

            components["cards"] = copy_json(
                sources["cards_source"],
                destinations["cards"],
            )

            status_document["steps"]["cards"] = "OK"

        except Exception as exc:
            message = f"{type(exc).__name__}: {exc}"
            errors.append(
                {
                    "component": "cards",
                    "error": message,
                }
            )
            status_document["steps"]["cards"] = message

        write_json(status_path, status_document)

        available = sum(
            value is not None
            for value in components.values()
        )

        status = (
            "FULL"
            if available == 4
            else "PARTIAL"
        )

    bundle = {
        "generated_at": utc_now(),
        "fingerprint": fingerprint,
        "status": status,
        "competition": {
            "key": competition_key,
            "name": competition.get("name"),
            "country": competition.get("country"),
            "season_name": competition.get("season_name"),
            "season_id": competition.get("season_id"),
        },
        "upcoming_match": match,
        "files": {
            key: str(path)
            for key, path in destinations.items()
        },
        "ratings": components["ratings"],
        "goals": components["goals"],
        "corners": components["corners"],
        "cards": components["cards"],
        "errors": errors,
    }
    write_json(bundle_path, bundle)

    status_document["finished_at"] = utc_now()
    status_document["status"] = status
    status_document["errors"] = errors
    write_json(status_path, status_document)

    return {
        "event_id": event_id,
        "kickoff": match.get("kickoff"),
        "home_team": match.get("home_team"),
        "away_team": match.get("away_team"),
        "status": status,
        "analysis_status": status,
        "path": str(bundle_path),
        "generated_at": bundle["generated_at"],
        "errors": errors,
    }


# ==============================================================================
# 5. ÍNDICE Y ARCHIVOS "ÚLTIMO"
# ==============================================================================

def save_index(
    competition: dict[str, Any],
    schedule: dict[str, Any],
    results: list[dict[str, Any]],
) -> Path:
    competition_key = slugify(str(competition["key"]))
    output_dir = ANALYSIS_ROOT_DIR / competition_key
    output_dir.mkdir(parents=True, exist_ok=True)

    previous = read_json_optional(
        output_dir / "index.json"
    ) or {}

    previous_rows = {
        int(row["event_id"]): row
        for row in previous.get("matches", [])
        if isinstance(row, dict)
        and row.get("event_id") is not None
    }

    for result in results:
        previous_rows[int(result["event_id"])] = result

    schedule_ids = {
        int(match["event_id"])
        for match in schedule.get("matches", [])
        if isinstance(match, dict)
        and match.get("event_id") is not None
    }

    ordered = sorted(
        (
            row
            for event_id, row in previous_rows.items()
            if event_id in schedule_ids
        ),
        key=lambda row: (
            str(row.get("kickoff") or ""),
            int(row.get("event_id") or 0),
        ),
    )

    path = output_dir / "index.json"

    write_json(
        path,
        {
            "generated_at": utc_now(),
            "competition_key": competition_key,
            "competition_name": competition.get("name"),
            "schedule_generated_at": schedule.get("generated_at"),
            "total_upcoming_matches": len(
                schedule.get("matches", [])
            ),
            "full": sum(
                1
                for row in ordered
                if row.get("analysis_status") == "FULL"
            ),
            "partial": sum(
                1
                for row in ordered
                if row.get("analysis_status") == "PARTIAL"
            ),
            "errors": sum(
                1
                for row in ordered
                if row.get("analysis_status") == "ERROR"
            ),
            "matches": ordered,
        },
    )

    return path


def copy_as_latest(
    competition_key: str,
    result: dict[str, Any],
) -> None:
    if result.get("analysis_status") != "FULL":
        return

    event_id = int(result["event_id"])
    event_dir = (
        ANALYSIS_ROOT_DIR
        / competition_key
        / str(event_id)
    )

    mapping = {
        event_dir / "ratings.json": (
            RATINGS_DIR / "ultimo_ratings.json"
        ),
        event_dir / "goals.json": (
            GOALS_DIR
            / "ultimo_poisson_dixon_coles.json"
        ),
        event_dir / "corners.json": (
            CORNERS_ROOT_DIR
            / competition_key
            / "ultimo_corners.json"
        ),
        event_dir / "cards.json": (
            CARDS_ROOT_DIR
            / competition_key
            / "ultimo_cards.json"
        ),
    }

    for source, destination in mapping.items():
        if not source.exists():
            continue

        destination.parent.mkdir(
            parents=True,
            exist_ok=True,
        )
        shutil.copy2(source, destination)


# ==============================================================================
# 6. CLI
# ==============================================================================

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Calcula automáticamente ratings, goles, córners "
            "y tarjetas para todos los próximos partidos."
        )
    )

    parser.add_argument(
        "--key",
        required=True,
        help="Clave de competición, por ejemplo: mls",
    )

    parser.add_argument(
        "--event-id",
        type=int,
        action="append",
        help=(
            "Analiza solo un evento. Puede repetirse varias veces."
        ),
    )

    parser.add_argument(
        "--limit",
        type=int,
        help="Procesa únicamente los primeros N partidos.",
    )

    parser.add_argument(
        "--force",
        action="store_true",
        help="Recalcula aunque el análisis vigente ya exista.",
    )

    parser.add_argument(
        "--no-set-latest",
        action="store_true",
        help=(
            "No actualiza los archivos ultimo_*.json al finalizar."
        ),
    )

    return parser


def main() -> None:
    args = build_parser().parse_args()

    try:
        for script in REQUIRED_SCRIPTS:
            if not script.exists():
                raise FileNotFoundError(
                    f"No se encontró el módulo requerido:\n{script}"
                )

        if not DB_PATH.exists():
            raise FileNotFoundError(
                f"No se encontró la base de datos:\n{DB_PATH}"
            )

        registry = load_registry()
        competition = find_competition(
            registry,
            args.key,
        )
        competition_key = slugify(
            str(competition["key"])
        )

        schedule, schedule_path = load_upcoming_schedule(
            competition_key
        )

        matches = list(schedule["matches"])

        if args.event_id:
            selected_ids = set(args.event_id)
            matches = [
                match
                for match in matches
                if int(match["event_id"]) in selected_ids
            ]

        if args.limit is not None:
            matches = matches[:max(0, int(args.limit))]

        if not matches:
            raise RuntimeError(
                "No hay próximos partidos seleccionados para analizar."
            )

        print("=" * 86)
        print("ODDSHUNTER — ANÁLISIS AUTOMÁTICO DE PRÓXIMOS PARTIDOS")
        print("=" * 86)
        print(
            f"Competición: {competition.get('name')} "
            f"{competition.get('season_name') or ''}".strip()
        )
        print(f"Calendario: {schedule_path}")
        print(f"Partidos seleccionados: {len(matches)}")
        print(
            "Módulos por partido: ratings → goles → córners → tarjetas"
        )
        print()

        results: list[dict[str, Any]] = []

        for index, match in enumerate(matches, start=1):
            event_id = int(match["event_id"])
            home = match.get("home_team") or "Local"
            away = match.get("away_team") or "Visitante"

            print("-" * 86)
            print(
                f"[{index:02d}/{len(matches):02d}] "
                f"{home} vs {away} | event_id={event_id}"
            )

            try:
                result = analyze_match(
                    competition=competition,
                    match=match,
                    schedule_generated_at=schedule.get(
                        "generated_at"
                    ),
                    force=bool(args.force),
                )

            except Exception as exc:
                result = {
                    "event_id": event_id,
                    "kickoff": match.get("kickoff"),
                    "home_team": home,
                    "away_team": away,
                    "status": "ERROR",
                    "analysis_status": "ERROR",
                    "path": None,
                    "generated_at": utc_now(),
                    "errors": [
                        {
                            "component": "orchestrator",
                            "error": (
                                f"{type(exc).__name__}: {exc}"
                            ),
                        }
                    ],
                }

                print(
                    f"   ❌ {type(exc).__name__}: {exc}"
                )

            results.append(result)

            print(
                f"   Resultado: "
                f"{result.get('analysis_status')}"
            )

            save_index(
                competition=competition,
                schedule=schedule,
                results=results,
            )

        index_path = save_index(
            competition=competition,
            schedule=schedule,
            results=results,
        )

        successful = [
            result
            for result in results
            if result.get("analysis_status") == "FULL"
        ]

        if successful and not args.no_set_latest:
            first = sorted(
                successful,
                key=lambda row: (
                    str(row.get("kickoff") or ""),
                    int(row.get("event_id") or 0),
                ),
            )[0]

            copy_as_latest(
                competition_key,
                first,
            )

        print()
        print("=" * 86)
        print("RESUMEN FINAL")
        print("=" * 86)
        print(f"Seleccionados: {len(results)}")
        print(
            "Completos: "
            f"{sum(1 for row in results if row.get('analysis_status') == 'FULL')}"
        )
        print(
            "Parciales: "
            f"{sum(1 for row in results if row.get('analysis_status') == 'PARTIAL')}"
        )
        print(
            "Errores: "
            f"{sum(1 for row in results if row.get('analysis_status') == 'ERROR')}"
        )
        print(
            "Vigentes omitidos: "
            f"{sum(1 for row in results if row.get('status') == 'SKIPPED')}"
        )
        print(f"\nÍndice:\n{index_path}")
        print(
            f"\nAnálisis por partido:\n"
            f"{ANALYSIS_ROOT_DIR / competition_key}"
        )
        print("=" * 86)
        print("✅ ANÁLISIS AUTOMÁTICO TERMINADO")

    except KeyboardInterrupt:
        print(
            "\n⚠️ Proceso interrumpido. "
            "Los partidos terminados permanecen guardados."
        )

    except Exception as exc:
        print(
            f"\n❌ Error: {type(exc).__name__}: {exc}"
        )
        raise SystemExit(1)


if __name__ == "__main__":
    main()
