# OddsHunter Cloud Stage4 + Stage5

Stage4:
- Uses ONLY a copied cloud working SQLite database.
- quick_check + foreign keys + core counts.
- Runs real OddsHunter model probes: ratings, goals, corners, cards and shots.
- Stage4 does not write SQLite and requires the DB to remain byte-identical.
- No training.

Stage5:
- Derives discovery seeds from actual teams in the copied DB across active competitions.
- Futbol24 primary, Flashscore residual, SofaScore OFF.
- Result synchronization writes ONLY to the cloud working DB copy.
- Runs analysis for known future DB events.
- Newly discovered Futbol24 fixtures are staged only; they are NOT blindly inserted using fake SofaScore IDs.
- No training.

The official Windows DB is never present in the GitHub runner. Only ODDSHUNTER_CLOUD_WORKING_STATE.zip is used.


## V3 correction
- Stage4 now probes ONLY genuine future PREPARTIDO DB events.
- Historical FT matches are never rewritten as fake upcoming probes.
- Up to 12 future events can be tried; the probe stops early after FULL + shots PASS.
