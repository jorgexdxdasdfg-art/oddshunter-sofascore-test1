from __future__ import annotations

import argparse
import json
import os
import re
import sqlite3
import time
import subprocess
import sys
import unicodedata
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from playwright.sync_api import BrowserContext, Page, sync_playwright

import bot9_competitions
import sync_upcoming_matches as syncer


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
REGISTRY_PATH = DATA_DIR / "competitions.json"
COMPETITIONS_DIR = DATA_DIR / "competitions"
PROFILE_DIR = DATA_DIR / "browser_profile_bot9_tournaments"
REPORT_DIR = DATA_DIR / "automation" / "bot9_tournaments"
INCREMENTAL_REPORT_DIR = DATA_DIR / "automation" / "incremental_results"
DB_PATH = DATA_DIR / "oddshunter.db"
INCREMENTAL_SCRIPT = BASE_DIR / "incremental_result_sync.py"

MAX_PAGES = 40
IMPORT_BATCH_SIZE = 12
DEFAULT_RESUME_MICRO_BATCH_SIZE = 1


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def normalized_text(value: Any) -> str:
    text = unicodedata.normalize("NFKD", str(value or ""))
    text = "".join(
        character
        for character in text
        if not unicodedata.combining(character)
    )
    return re.sub(r"[^a-z0-9]+", " ", text.lower()).strip()


def read_json(path: Path) -> dict[str, Any]:
    document = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(document, dict):
        raise ValueError(f"{path} no contiene un objeto JSON.")
    return document


def write_json(path: Path, document: Any) -> None:
    """Guarda checkpoints atómicamente y reintenta bloqueos breves de Windows."""

    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(document, ensure_ascii=False, indent=2)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    last_error: OSError | None = None
    for attempt in range(1, 4):
        try:
            temporary.write_text(payload, encoding="utf-8")
            os.replace(temporary, path)
            return
        except OSError as exc:
            last_error = exc
            temporary.unlink(missing_ok=True)
            if attempt < 3:
                time.sleep(0.15 * attempt)
    assert last_error is not None
    raise last_error


def is_managed_competition(
    row: dict[str, Any],
    wanted: str,
) -> bool:
    """Acepta ligas visibles BOT 9 o contextos domésticos verificables.

    Los contextos domésticos se crean dinámicamente y deliberadamente no se
    muestran en la interfaz. Por eso no siempre traen el indicador histórico
    ``bot9_managed``. Solo se aceptan cuando la clave y ambos IDs coinciden de
    manera estricta; un registro oculto arbitrario continúa rechazado.
    """

    if bool(row.get("bot9_managed")):
        return True
    if not bool(row.get("context_only")):
        return False
    if str(row.get("competition_family") or "").upper() != "DOMESTIC":
        return False
    if bool(row.get("visible_in_ui", True)):
        return False
    match = re.fullmatch(r"domestic-context-(\d+)-(\d+)", wanted)
    if match is None:
        return False
    tournament_id = int(row.get("source_competition_id") or 0)
    season_id = int(row.get("season_id") or 0)
    return (
        tournament_id > 0
        and season_id > 0
        and tournament_id == int(match.group(1))
        and season_id == int(match.group(2))
    )


def load_competition(key: str) -> dict[str, Any]:
    registry = read_json(REGISTRY_PATH)
    wanted = syncer.slugify(key)
    for row in registry.get("competitions", []):
        if not isinstance(row, dict):
            continue
        if syncer.slugify(str(row.get("key") or "")) == wanted:
            if not is_managed_competition(row, wanted):
                raise ValueError(
                    f"{wanted} no es una competición administrada por BOT 9."
                )
            return dict(row)
    raise ValueError(f"No existe la competición BOT 9 '{wanted}'.")


def fetch_document(
    page: Page,
    endpoints: tuple[str, ...],
) -> tuple[dict[str, Any] | None, list[str]]:
    failures: list[str] = []
    for endpoint in endpoints:
        status, document = syncer._browser_fetch_json(page, endpoint)
        if status == 200 and isinstance(document, dict):
            return document, failures
        failures.append(f"{endpoint} -> HTTP {status}")
    return None, failures


def resolve_current_season(
    page: Page,
    competition: dict[str, Any],
) -> tuple[int, str]:
    tournament_id = int(competition["source_competition_id"])
    document, failures = fetch_document(
        page,
        (
            f"/api/v1/unique-tournament/{tournament_id}/seasons",
            f"/api/v1/tournament/{tournament_id}/seasons",
        ),
    )
    if document is None:
        configured = competition.get("season_id")
        if configured is None:
            raise RuntimeError(
                "No se pudo resolver la temporada actual: "
                + "; ".join(failures[-2:])
            )
        return int(configured), str(
            competition.get("season_name")
            or competition.get("season_label")
            or configured
        )

    rows = document.get("seasons")
    if not isinstance(rows, list) or not rows:
        raise RuntimeError(
            "SofaScore no devolvió temporadas para "
            f"tournament_id={tournament_id}."
        )

    valid_rows: list[dict[str, Any]] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        try:
            season_id = int(row.get("id"))
        except (TypeError, ValueError):
            continue
        if season_id <= 0:
            continue
        normalized = dict(row)
        normalized["id"] = season_id
        valid_rows.append(normalized)

    if not valid_rows:
        raise RuntimeError("La lista de temporadas no contiene IDs válidos.")

    # SofaScore publica la temporada vigente en la primera posición. Si además
    # marca isCurrent, esa señal tiene prioridad. No se usa una temporada vieja
    # solo porque haya quedado guardada en competitions.json.
    if bool(competition.get("locked_season_id")):
        configured_id = int(competition.get("season_id") or 0)
        for row in valid_rows:
            if int(row["id"]) != configured_id:
                continue
            return configured_id, str(
                row.get("name")
                or row.get("year")
                or competition.get("season_name")
                or configured_id
            )
        raise RuntimeError(
            "La temporada domestica fijada no aparece en SofaScore: "
            f"tournament_id={tournament_id}, season_id={configured_id}."
        )

    current_rows = [
        row
        for row in valid_rows
        if bool(row.get("isCurrent"))
    ]
    selected = current_rows[0] if current_rows else valid_rows[0]
    season_id = int(selected["id"])
    season_name = str(
        selected.get("name")
        or selected.get("year")
        or competition.get("season_name")
        or season_id
    )
    return season_id, season_name


def event_tournament_id(event: dict[str, Any]) -> int | None:
    return syncer.tournament_id(event)


def event_season_id(event: dict[str, Any]) -> int | None:
    return syncer.season_id(event)


def event_in_scope(
    event: dict[str, Any],
    tournament_id: int,
    season_id: int,
) -> bool:
    return (
        event_tournament_id(event) == int(tournament_id)
        and event_season_id(event) == int(season_id)
    )


def fetch_event_pages(
    page: Page,
    tournament_id: int,
    season_id: int,
    direction: str,
) -> tuple[list[dict[str, Any]], list[str]]:
    if direction not in {"last", "next"}:
        raise ValueError(direction)

    captured: dict[int, dict[str, Any]] = {}
    failures: list[str] = []
    for page_number in range(MAX_PAGES):
        document, page_failures = fetch_document(
            page,
            (
                f"/api/v1/unique-tournament/{tournament_id}/season/"
                f"{season_id}/events/{direction}/{page_number}",
                f"/api/v1/tournament/{tournament_id}/season/"
                f"{season_id}/events/{direction}/{page_number}",
            ),
        )
        failures.extend(page_failures)
        if document is None:
            if page_number == 0:
                break
            continue

        events = syncer.extract_events(document)
        scoped_count = 0
        for event in events:
            if not event_in_scope(event, tournament_id, season_id):
                continue
            try:
                event_id = int(event["id"])
            except (KeyError, TypeError, ValueError):
                continue
            captured[event_id] = event
            scoped_count += 1

        if document.get("hasNextPage") is False or not events:
            break
        if scoped_count == 0 and page_number > 0:
            break


    # ODDSHUNTER_BESTA_DYNAMIC_LAST_ENDPOINT_RESCUE_V2
    # SQLite aporta solo IDs FT actuales; cada ausente del endpoint `last`
    # se revalida por /api/v1/event/<id> antes de añadirse a captured.
    if (
        direction == "last"
        and int(tournament_id) == 188
        and int(season_id) == 89094
        and DB_PATH.exists()
    ):
        rescue_connection = sqlite3.connect(DB_PATH)
        try:
            rescue_sql = (
                "SELECT DISTINCT m.sofascore_id "
                "FROM matches m "
                "WHERE m.league_id=1872 "
                "AND UPPER(COALESCE(m.status,'')) IN ('FT','FINISHED') "
                "AND m.sofascore_id IS NOT NULL "
                "ORDER BY m.sofascore_id"
            )
            rescue_rows = rescue_connection.execute(rescue_sql).fetchall()
        finally:
            rescue_connection.close()

        rescue_ids = [
            int(row[0])
            for row in rescue_rows
            if int(row[0]) not in captured
        ]

        for rescue_event_id in rescue_ids:
            rescue_document, _rescue_failures = fetch_document(
                page,
                (f"/api/v1/event/{rescue_event_id}",),
            )

            if rescue_document is None:
                print(
                    "[LAST_ENDPOINT_RESCUE_SKIP] "
                    f"event_id={rescue_event_id} reason=direct_source_unavailable"
                )
                continue

            rescue_event = rescue_document.get("event")
            if not isinstance(rescue_event, dict):
                rescue_candidates = syncer.extract_events(rescue_document)
                rescue_event = next(
                    (
                        event
                        for event in rescue_candidates
                        if int(event.get("id") or 0) == rescue_event_id
                    ),
                    None,
                )

            if not isinstance(rescue_event, dict):
                print(
                    "[LAST_ENDPOINT_RESCUE_SKIP] "
                    f"event_id={rescue_event_id} reason=no_event_payload"
                )
                continue

            if not event_in_scope(
                rescue_event,
                int(tournament_id),
                int(season_id),
            ):
                print(
                    "[LAST_ENDPOINT_RESCUE_SKIP] "
                    f"event_id={rescue_event_id} reason=scope_mismatch"
                )
                continue

            rescue_status = str(
                rescue_event.get("status", {}).get("type") or ""
            ).lower()
            if rescue_status != "finished":
                print(
                    "[LAST_ENDPOINT_RESCUE_SKIP] "
                    f"event_id={rescue_event_id} reason=status_{rescue_status}"
                )
                continue

            captured[rescue_event_id] = rescue_event
            print(
                "[LAST_ENDPOINT_RESCUE] "
                f"tournament_id={tournament_id} "
                f"season_id={season_id} "
                f"event_id={rescue_event_id} "
                "source=/api/v1/event/<id>"
            )
    ordered = sorted(
        captured.values(),
        key=lambda event: (
            int(event.get("startTimestamp") or 0),
            int(event.get("id") or 0),
        ),
    )
    return ordered, failures


def phase_fields(event: dict[str, Any]) -> dict[str, Any]:
    round_info = event.get("roundInfo")
    if not isinstance(round_info, dict):
        round_info = {}
    tournament = event.get("tournament")
    if not isinstance(tournament, dict):
        tournament = {}

    return {
        "round": round_info.get("round"),
        "round_name": (
            round_info.get("name")
            or round_info.get("roundName")
        ),
        "round_slug": round_info.get("slug"),
        "group": (
            round_info.get("group")
            or tournament.get("groupName")
        ),
        "stage": (
            round_info.get("stage")
            or tournament.get("name")
        ),
        "cup_round_type": round_info.get("cupRoundType"),
    }


def event_summary(event: dict[str, Any]) -> dict[str, Any]:
    summary = syncer.event_summary(event)
    summary.update(phase_fields(event))
    return summary


def finished_events_only(
    events: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    return [
        event
        for event in events
        if str(
            event.get("status", {}).get("type") or ""
        ).lower() == "finished"
    ]


def upcoming_events_only(
    events: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    return [event for event in events if syncer.is_upcoming(event)]


def team_catalog_from_events(
    events: list[dict[str, Any]],
) -> dict[int, dict[str, Any]]:
    teams: dict[int, dict[str, Any]] = {}
    for event in events:
        for side in ("homeTeam", "awayTeam"):
            team = event.get(side)
            if not isinstance(team, dict):
                continue
            try:
                team_id = int(team.get("id"))
            except (TypeError, ValueError):
                continue
            name = str(team.get("name") or team_id)
            teams[team_id] = {
                "team_id": team_id,
                "name": name,
                "slug": str(
                    team.get("slug")
                    or syncer.slugify(name)
                ),
            }
    return teams


def latest_history_event_ids(
    finished_events: list[dict[str, Any]],
    per_team: int,
) -> list[int]:
    by_team: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for event in finished_events:
        for side in ("homeTeam", "awayTeam"):
            team = event.get(side)
            if not isinstance(team, dict):
                continue
            try:
                team_id = int(team.get("id"))
            except (TypeError, ValueError):
                continue
            by_team[team_id].append(event)

    selected: set[int] = set()
    for rows in by_team.values():
        rows.sort(
            key=lambda event: (
                int(event.get("startTimestamp") or 0),
                int(event.get("id") or 0),
            ),
            reverse=True,
        )
        for event in rows[: max(1, int(per_team))]:
            selected.add(int(event["id"]))
    return sorted(selected)


def save_catalogs(
    competition: dict[str, Any],
    season_id: int,
    season_name: str,
    finished_events: list[dict[str, Any]],
    upcoming_events: list[dict[str, Any]],
) -> dict[str, Any]:
    key = syncer.slugify(str(competition["key"]))
    output_dir = COMPETITIONS_DIR / key
    output_dir.mkdir(parents=True, exist_ok=True)

    finished_summaries = [
        event_summary(event)
        for event in finished_events
    ]
    upcoming_summaries = [
        event_summary(event)
        for event in upcoming_events
    ]
    finished_summaries.sort(
        key=lambda row: (
            int(row.get("start_timestamp") or 0),
            int(row.get("event_id") or 0),
        )
    )
    upcoming_summaries.sort(
        key=lambda row: (
            int(row.get("start_timestamp") or 0),
            int(row.get("event_id") or 0),
        )
    )

    all_events = [*finished_events, *upcoming_events]
    team_catalog = team_catalog_from_events(all_events)
    by_team_upcoming: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for event, summary in zip(upcoming_events, upcoming_summaries):
        for side in ("homeTeam", "awayTeam"):
            team = event.get(side)
            if not isinstance(team, dict):
                continue
            try:
                team_id = int(team.get("id"))
            except (TypeError, ValueError):
                continue
            by_team_upcoming[team_id].append(summary)

    is_previous_context = str(
        competition.get("context_season_role") or "CURRENT"
    ).upper() == "PREVIOUS"
    common = {
        "competition_key": key,
        "competition_name": competition.get("name"),
        "source_competition_id": int(
            competition["source_competition_id"]
        ),
        "season_id": int(season_id),
        "season_name": season_name,
        "current_season_only": not is_previous_context,
        "context_season_role": (
            "PREVIOUS" if is_previous_context else "CURRENT"
        ),
        "same_competition_only": True,
        "generated_at": utc_now(),
    }
    write_json(
        output_dir / "matches_finished.json",
        {
            **common,
            "total_finished_matches": len(finished_summaries),
            "refresh_scope": "complete_current_tournament_season",
            "matches": finished_summaries,
        },
    )
    write_json(
        output_dir / "matches_upcoming.json",
        {
            **common,
            "selection_rule": "competition_fast_bootstrap",
            "refresh_scope": "complete_current_tournament_season",
            "selection_description": (
                "Solo eventos de la competición y temporada actuales; "
                "incluye clasificación, fase principal y eliminatorias."
            ),
            "total_upcoming_matches": len(upcoming_summaries),
            "matches": upcoming_summaries,
            "failures": [],
        },
    )
    write_json(
        output_dir / "teams.json",
        {
            **common,
            "source": "current_tournament_season_events",
            "total_teams": len(team_catalog),
            "teams": sorted(
                team_catalog.values(),
                key=lambda row: str(row.get("name") or ""),
            ),
        },
    )

    team_rows: list[dict[str, Any]] = []
    for team_id, team in sorted(
        team_catalog.items(),
        key=lambda item: str(item[1].get("name") or ""),
    ):
        matches = sorted(
            by_team_upcoming.get(team_id, []),
            key=lambda row: (
                int(row.get("start_timestamp") or 0),
                int(row.get("event_id") or 0),
            ),
        )
        next_match = dict(matches[0]) if matches else None
        team_rows.append(
            {
                "team_id": team_id,
                "team_name": team["name"],
                "next_event_id": (
                    None
                    if next_match is None
                    else int(next_match["event_id"])
                ),
                "next_match": next_match,
                "updated_at": utc_now(),
                "refreshed_in_current_run": True,
            }
        )
    write_json(
        output_dir / "next_match_by_team.json",
        {
            **common,
            "selection_rule": "next_of_at_least_one_team",
            "refresh_scope": "complete_current_tournament_season",
            "processed_team_ids": sorted(team_catalog),
            "total_teams": len(team_rows),
            "teams_with_next_match": sum(
                1
                for row in team_rows
                if row["next_match"] is not None
            ),
            "teams": team_rows,
        },
    )

    return {
        "competition_key": key,
        "season_id": int(season_id),
        "season_name": season_name,
        "finished_event_ids": [
            int(row["event_id"])
            for row in finished_summaries
        ],
        "upcoming_event_ids": [
            int(row["event_id"])
            for row in upcoming_summaries
        ],
        "team_ids": sorted(team_catalog),
    }


def load_existing_catalog_summary(
    competition_key: str,
    season_id: int,
    season_name: str,
) -> dict[str, Any] | None:
    """Conserva el catálogo local durante fallos transitorios de la fuente."""

    key = syncer.slugify(competition_key)
    output_dir = COMPETITIONS_DIR / key
    finished_path = output_dir / "matches_finished.json"
    upcoming_path = output_dir / "matches_upcoming.json"
    teams_path = output_dir / "teams.json"
    if not (finished_path.exists() and upcoming_path.exists() and teams_path.exists()):
        return None

    try:
        finished = read_json(finished_path)
        upcoming = read_json(upcoming_path)
        teams = read_json(teams_path)
    except (OSError, ValueError, json.JSONDecodeError):
        return None

    documents = (finished, upcoming, teams)
    try:
        same_season = all(
            int(document.get("season_id") or 0) == int(season_id)
            for document in documents
        )
    except (TypeError, ValueError):
        same_season = False
    if not same_season:
        return None

    finished_rows = finished.get("matches")
    upcoming_rows = upcoming.get("matches")
    team_rows = teams.get("teams")
    if not isinstance(finished_rows, list):
        finished_rows = []
    if not isinstance(upcoming_rows, list):
        upcoming_rows = []
    if not isinstance(team_rows, list):
        team_rows = []
    if not (finished_rows or upcoming_rows or team_rows):
        return None

    def identifiers(rows: list[dict[str, Any]], *fields: str) -> list[int]:
        captured: set[int] = set()
        for row in rows:
            if not isinstance(row, dict):
                continue
            for field in fields:
                try:
                    value = int(row.get(field))
                except (TypeError, ValueError):
                    continue
                if value > 0:
                    captured.add(value)
                    break
        return sorted(captured)

    return {
        "competition_key": key,
        "season_id": int(season_id),
        "season_name": str(season_name),
        "finished_event_ids": identifiers(
            finished_rows,
            "event_id",
            "sofascore_id",
        ),
        "upcoming_event_ids": identifiers(
            upcoming_rows,
            "event_id",
            "sofascore_id",
        ),
        "team_ids": identifiers(
            team_rows,
            "team_id",
            "sofascore_id",
        ),
    }



def sqlite_event_progress(event_ids: list[int]) -> dict[int, dict[str, Any]]:
    """Clasifica eventos sin tocar SQLite y sin convertir NULL en cero."""

    result = {
        int(event_id): {
            "event_id": int(event_id),
            "exists": False,
            "status": None,
            "quality": "MISSING",
            "missing_metrics": 10,
        }
        for event_id in event_ids
    }
    if not DB_PATH.exists() or not event_ids:
        return result

    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    try:
        placeholders = ",".join("?" for _ in event_ids)
        rows = connection.execute(
            f"""
            SELECT
                m.sofascore_id AS event_id,
                m.status,
                s.data_quality,
                s.xg_for,
                s.shots,
                s.shots_on_target,
                s.corners_for,
                s.yellow_cards
            FROM matches AS m
            LEFT JOIN team_match_stats AS s
                ON s.match_id = m.match_id
            WHERE m.sofascore_id IN ({placeholders})
            ORDER BY m.sofascore_id, s.stat_id
            """,
            tuple(int(value) for value in event_ids),
        ).fetchall()
    finally:
        connection.close()

    grouped: dict[int, list[sqlite3.Row]] = defaultdict(list)
    for row in rows:
        grouped[int(row["event_id"])].append(row)

    for event_id, event_rows in grouped.items():
        missing = sum(
            1
            for row in event_rows
            for field in (
                "xg_for",
                "shots",
                "shots_on_target",
                "corners_for",
                "yellow_cards",
            )
            if row[field] is None
        )
        full_required = (
            len(event_rows) == 2
            and all(
                str(row["data_quality"] or "").upper() == "FULL"
                for row in event_rows
            )
            and all(
                row[field] is not None
                for row in event_rows
                for field in (
                    "shots",
                    "shots_on_target",
                    "corners_for",
                    "yellow_cards",
                )
            )
        )
        result[event_id] = {
            "event_id": event_id,
            "exists": True,
            "status": str(event_rows[0]["status"] or ""),
            "quality": "FULL" if full_required else "PARTIAL",
            "missing_metrics": missing,
        }
    return result


def load_previous_progress(key: str) -> dict[str, Any]:
    bot9_path = REPORT_DIR / f"{key}_last.json"
    incremental_path = INCREMENTAL_REPORT_DIR / f"{key}_last.json"
    bot9 = read_json(bot9_path) if bot9_path.exists() else {}
    incremental = read_json(incremental_path) if incremental_path.exists() else {}
    return {
        "loaded": bool(bot9 or incremental),
        "bot9_report_path": str(bot9_path),
        "incremental_report_path": str(incremental_path),
        "previous_bot9": bot9,
        "previous_incremental": incremental,
        "previous_checkpoint_event_id": incremental.get(
            "last_checkpoint_event_id"
        ),
        "previous_checkpoint_at": incremental.get("checkpoint_at"),
    }


def resume_event_queue(
    event_ids: list[int],
    *,
    priority_event_ids: list[int] | None = None,
    max_events: int | None = None,
) -> tuple[list[int], dict[str, Any]]:
    progress = sqlite_event_progress(event_ids)
    full = sorted(
        event_id
        for event_id, row in progress.items()
        if row["quality"] == "FULL"
    )
    partial = [
        event_id
        for event_id, row in progress.items()
        if row["quality"] == "PARTIAL"
    ]
    missing = [
        event_id
        for event_id, row in progress.items()
        if row["quality"] == "MISSING"
    ]
    partial.sort(
        key=lambda event_id: (
            -int(progress[event_id]["missing_metrics"]),
            event_id,
        )
    )
    missing.sort()

    priority = [
        int(value)
        for value in (priority_event_ids or [])
        if int(value) in set(partial + missing)
    ]
    queue = list(dict.fromkeys([*priority, *partial, *missing]))
    if max_events is not None:
        queue = queue[: max(0, int(max_events))]

    return queue, {
        "total_catalog_events": len(event_ids),
        "already_full_event_ids": full,
        "already_full_count": len(full),
        "partial_event_ids": partial,
        "partial_count": len(partial),
        "missing_event_ids": missing,
        "missing_count": len(missing),
        "priority_event_ids": priority,
        "selected_event_ids": queue,
        "selected_count": len(queue),
        "full_events_skipped": True,
        "partials_prioritized": True,
    }

def import_finished_events(
    key: str,
    event_ids: list[int],
    flashscore_budget_file: Path | None = None,
    *,
    batch_size: int = IMPORT_BATCH_SIZE,
    max_seconds: int | None = None,
    progress_report_path: Path | None = None,
    progress_report: dict[str, Any] | None = None,
) -> tuple[list[dict[str, Any]], bool]:
    """Importa micro-lotes y guarda el progreso después de cada lote."""

    if not INCREMENTAL_SCRIPT.exists():
        raise FileNotFoundError(INCREMENTAL_SCRIPT)

    results: list[dict[str, Any]] = []
    controlled_limit = False
    started = time.monotonic()
    size = max(1, int(batch_size))

    for offset in range(0, len(event_ids), size):
        elapsed = time.monotonic() - started
        if max_seconds is not None and elapsed >= max_seconds:
            controlled_limit = True
            break

        batch = event_ids[offset : offset + size]
        command = [
            sys.executable,
            "-u",
            str(INCREMENTAL_SCRIPT),
            "--key",
            key,
        ]
        for event_id in batch:
            command.extend(["--event-id", str(event_id)])

        env = os.environ.copy()
        env["PYTHONUTF8"] = "1"
        env["PYTHONIOENCODING"] = "utf-8"
        if flashscore_budget_file is not None:
            env["ODDSHUNTER_FLASHSCORE_BUDGET_FILE"] = str(
                flashscore_budget_file
            )
        env.setdefault(
            "ODDSHUNTER_FLASHSCORE_MAX_MATCHES_PER_CYCLE",
            "3",
        )

        remaining = None
        if max_seconds is not None:
            remaining = max(1.0, max_seconds - elapsed)
        try:
            completed = subprocess.run(
                command,
                cwd=str(BASE_DIR),
                env=env,
                check=False,
                timeout=remaining,
            )
            returncode = int(completed.returncode)
            timed_out = False
        except subprocess.TimeoutExpired:
            returncode = 124
            timed_out = True
            controlled_limit = True

        incremental_report_path = (
            INCREMENTAL_REPORT_DIR / f"{key}_last.json"
        )
        incremental_report = (
            read_json(incremental_report_path)
            if incremental_report_path.exists()
            else {}
        )
        result = {
            "event_ids": batch,
            "returncode": returncode,
            "timed_out": timed_out,
            "started_after_seconds": round(elapsed, 3),
            "finished_after_seconds": round(
                time.monotonic() - started,
                3,
            ),
            "incremental_checkpoint_event_id": incremental_report.get(
                "last_checkpoint_event_id"
            ),
            "incremental_checkpoint_at": incremental_report.get(
                "checkpoint_at"
            ),
            "incremental_errors": incremental_report.get("errors", []),
        }
        results.append(result)

        if progress_report is not None:
            progress_report["import_batches"] = list(results)
            progress_report["processed_event_ids"] = [
                int(event_id)
                for row in results
                for event_id in row["event_ids"]
            ]
            progress_report.setdefault("checkpoints", []).append(
                {
                    "event_ids": batch,
                    "saved_at": utc_now(),
                    "returncode": returncode,
                    "incremental_checkpoint_event_id": result[
                        "incremental_checkpoint_event_id"
                    ],
                }
            )
            if progress_report_path is not None:
                write_json(progress_report_path, progress_report)

        if returncode != 0:
            if timed_out:
                break
            raise RuntimeError(
                "La importación incremental falló para "
                f"{key}, eventos={batch}, código={returncode}."
            )

    return results, controlled_limit

def ensure_empty_season_league(
    competition: dict[str, Any],
    season_name: str,
    events: list[dict[str, Any]],
) -> int:
    """Registra la temporada aunque todavía no tenga finalizados.

    Se usa únicamente cuando el torneo acaba de comenzar. No crea partidos ni
    estadísticas artificiales.
    """

    from database import transaction, upsert_league

    source_name = str(
        competition.get("source_name")
        or competition.get("name")
        or "Competition"
    )
    country = str(competition.get("country") or "")
    if events:
        tournament = events[0].get("tournament", {})
        if isinstance(tournament, dict):
            unique = tournament.get("uniqueTournament", {})
            if isinstance(unique, dict):
                source_name = str(unique.get("name") or source_name)
            category = tournament.get("category", {})
            if isinstance(category, dict):
                country = str(category.get("name") or country)

    with transaction() as connection:
        return int(
            upsert_league(
                connection,
                name=source_name,
                country=country,
                season=season_name,
            )
        )


def launch_context(playwright: Any) -> BrowserContext:
    PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    return playwright.chromium.launch_persistent_context(
        user_data_dir=str(PROFILE_DIR),
        executable_path=str(syncer.encontrar_brave()),
        headless=False,
        chromium_sandbox=True,
        locale="es-ES",
        viewport={"width": 1365, "height": 900},
        args=[
            "--start-maximized",
            "--disable-session-crashed-bubble",
            "--disable-features=InfiniteSessionRestore",
        ],
    )


def synchronize(
    competition_key: str,
    import_finished: bool,
    *,
    resume: bool = False,
    resume_existing_catalog: bool = False,
    micro_batch_size: int = IMPORT_BATCH_SIZE,
    max_events: int | None = None,
    max_seconds: int | None = None,
    priority_event_ids: list[int] | None = None,
) -> dict[str, Any]:
    competition = load_competition(competition_key)
    key = syncer.slugify(str(competition["key"]))
    tournament_id = int(competition["source_competition_id"])
    report_path = REPORT_DIR / f"{key}_last.json"
    previous = load_previous_progress(key)

    last_failures: list[str] = []
    next_failures: list[str] = []
    used_existing_catalog = False
    source_catalog_unavailable = False

    if resume_existing_catalog:
        previous_bot9 = previous.get("previous_bot9") or {}
        season_id = int(
            competition.get("season_id")
            or previous_bot9.get("season_id")
            or 0
        )
        if season_id <= 0:
            raise RuntimeError(
                "No existe season_id previo para reanudar sin recorrer "
                "otra vez el catálogo completo."
            )
        season_name = str(
            competition.get("season_name")
            or previous_bot9.get("season_name")
            or season_id
        )
        history_event_ids = [
            int(value)
            for value in (
                previous_bot9.get("history_event_ids")
                or previous_bot9.get("finished_event_ids")
                or []
            )
        ]
        if not history_event_ids:
            raise RuntimeError(
                "El reporte anterior no contiene eventos para reanudar."
            )
        catalog = {
            "competition_key": key,
            "season_id": season_id,
            "season_name": season_name,
            "finished_event_ids": [
                int(value)
                for value in previous_bot9.get(
                    "finished_event_ids",
                    history_event_ids,
                )
            ],
            "upcoming_event_ids": [
                int(value)
                for value in previous_bot9.get(
                    "upcoming_event_ids",
                    [],
                )
            ],
            "team_ids": [
                int(value)
                for value in previous_bot9.get("team_ids", [])
            ],
        }
        is_domestic_context = bool(
            previous_bot9.get("full_history_import")
        )
        history_limit = int(
            previous_bot9.get("history_limit_per_team")
            or competition.get("history_limit_per_team")
            or 15
        )
        used_existing_catalog = True
    else:
        with sync_playwright() as playwright:
            context = launch_context(playwright)
            try:
                page = (
                    context.pages[0]
                    if context.pages
                    else context.new_page()
                )
                season_id, season_name = resolve_current_season(
                    page,
                    competition,
                )
                bot9_competitions.update_resolved_season(
                    REGISTRY_PATH,
                    key,
                    season_id,
                    season_name,
                )
                competition["season_id"] = season_id
                competition["season_name"] = season_name
                last_events, last_failures = fetch_event_pages(
                    page,
                    tournament_id,
                    season_id,
                    "last",
                )
                next_events, next_failures = fetch_event_pages(
                    page,
                    tournament_id,
                    season_id,
                    "next",
                )
            finally:
                syncer.close_playwright_target(
                    context,
                    "contexto BOT 9",
                )

        finished_events = finished_events_only(last_events)
        upcoming_events = upcoming_events_only(next_events)
        source_catalog_unavailable = bool(
            not finished_events
            and not upcoming_events
            and (last_failures or next_failures)
        )
        if source_catalog_unavailable:
            catalog = load_existing_catalog_summary(
                key,
                season_id,
                season_name,
            )
            if catalog is None:
                raise RuntimeError(
                    "La fuente no respondió y no existe un catálogo local "
                    f"válido para conservar: {key}, season_id={season_id}."
                )
            used_existing_catalog = True
        else:
            catalog = save_catalogs(
                competition,
                season_id,
                season_name,
                finished_events,
                upcoming_events,
            )
        history_limit = int(
            competition.get("history_limit_per_team") or 15
        )
        is_domestic_context = bool(
            competition.get("context_only")
        ) or str(
            competition.get("competition_family") or ""
        ).upper() == "DOMESTIC"
        if is_domestic_context:
            history_event_ids = (
                list(catalog["finished_event_ids"])
                if source_catalog_unavailable
                else sorted({
                    int(event["id"])
                    for event in finished_events
                    if event.get("id") is not None
                })
            )
        else:
            history_event_ids = latest_history_event_ids(
                finished_events,
                history_limit,
            )

    queue_metadata: dict[str, Any] = {
        "selected_event_ids": history_event_ids,
        "already_full_event_ids": [],
        "partial_event_ids": [],
        "full_events_skipped": False,
        "partials_prioritized": False,
    }
    selected_event_ids = list(history_event_ids)
    if resume:
        selected_event_ids, queue_metadata = resume_event_queue(
            history_event_ids,
            priority_event_ids=priority_event_ids,
            max_events=max_events,
        )
    elif max_events is not None:
        selected_event_ids = selected_event_ids[: max(0, int(max_events))]

    report: dict[str, Any] = {
        "generated_at": utc_now(),
        **catalog,
        "history_limit_per_team": history_limit,
        "full_history_import": is_domestic_context,
        "history_event_ids": history_event_ids,
        "import_finished": bool(import_finished),
        "resume": {
            "requested": bool(resume),
            "loaded": bool(previous.get("loaded")),
            "used_existing_catalog": used_existing_catalog,
            "previous_checkpoint_event_id": previous.get(
                "previous_checkpoint_event_id"
            ),
            "previous_checkpoint_at": previous.get(
                "previous_checkpoint_at"
            ),
            **queue_metadata,
        },
        "selected_event_ids": selected_event_ids,
        "processed_event_ids": [],
        "import_batches": [],
        "checkpoints": [],
        "controlled_time_limit_reached": False,
        "final_state": (
            "SOURCE_UNAVAILABLE_PRESERVED"
            if source_catalog_unavailable and not import_finished
            else "RUNNING" if import_finished else "COMPLETED"
        ),
        "source_catalog_unavailable": source_catalog_unavailable,
        "existing_catalog_preserved": source_catalog_unavailable,
        "failures": [*last_failures, *next_failures],
        "rules": {
            "same_tournament_id": tournament_id,
            "same_season_id": season_id,
            "domestic_matches_allowed": False,
            "all_current_season_phases_allowed": True,
            "resume_does_not_reprocess_full": bool(resume),
            "micro_batch_size": max(1, int(micro_batch_size)),
            "max_seconds": max_seconds,
            "max_events": max_events,
        },
    }
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    write_json(report_path, report)

    flashscore_budget_file = REPORT_DIR / f"{key}_flashscore_budget.json"
    if import_finished and selected_event_ids:
        flashscore_budget_file.parent.mkdir(parents=True, exist_ok=True)
        write_json(
            flashscore_budget_file,
            {
                "attempted_matches": 0,
                "consecutive_timeouts": 0,
                "circuit_open": False,
                "created_at": utc_now(),
                "directed_resume": bool(resume),
            },
        )
        batches, controlled_limit = import_finished_events(
            key,
            selected_event_ids,
            flashscore_budget_file,
            batch_size=max(1, int(micro_batch_size)),
            max_seconds=max_seconds,
            progress_report_path=report_path,
            progress_report=report,
        )
        report["import_batches"] = batches
        report["controlled_time_limit_reached"] = controlled_limit
    elif import_finished:
        report["no_events_required"] = True

    incremental_report_path = (
        INCREMENTAL_REPORT_DIR / f"{key}_last.json"
    )
    incremental_report = (
        read_json(incremental_report_path)
        if incremental_report_path.exists()
        else {}
    )
    # V4.4.7 R3:
    # Un sync de temporada sin --import-finished NO debe heredar como fallo
    # los errores de un incremental_result_sync ejecutado horas/días antes.
    # Solo los errores capturados por lotes lanzados EN ESTA ejecución pueden
    # cambiar el estado actual a FAILED.
    technical_errors = [
        error
        for batch in report.get("import_batches", [])
        if isinstance(batch, dict)
        for error in batch.get("incremental_errors", [])
        if isinstance(error, dict)
    ]
    stale_incremental_errors = [
        error
        for error in incremental_report.get("errors", [])
        if isinstance(error, dict)
    ]
    report["incremental_report_path"] = str(incremental_report_path)
    report["incremental_errors"] = technical_errors
    report["stale_incremental_errors_ignored"] = (
        stale_incremental_errors
        if not report.get("import_batches")
        else []
    )
    report["incremental_error_policy"] = "CURRENT_RUN_BATCHES_ONLY"
    report["event_16351139_oserror22"] = any(
        int(row.get("event_id") or 0) == 16351139
        and "OSError: [Errno 22]" in str(row.get("error") or "")
        for row in technical_errors
    )
    report["flashscore_budget"] = (
        read_json(flashscore_budget_file)
        if flashscore_budget_file.exists()
        else None
    )

    if report["event_16351139_oserror22"] or technical_errors:
        report["final_state"] = "FAILED"
    elif source_catalog_unavailable and not import_finished:
        report["final_state"] = "SOURCE_UNAVAILABLE_PRESERVED"
    elif report.get("controlled_time_limit_reached"):
        report["final_state"] = "PARTIAL_CONTROLLED"
    elif len(report.get("processed_event_ids", [])) < len(selected_event_ids):
        report["final_state"] = "PARTIAL_CONTROLLED"
    else:
        remaining = resume_event_queue(history_event_ids)[1]
        report["remaining_partial_count"] = remaining["partial_count"]
        report["remaining_missing_count"] = remaining["missing_count"]
        report["final_state"] = (
            "COMPLETED"
            if remaining["partial_count"] == 0
            and remaining["missing_count"] == 0
            else "PARTIAL_CONTROLLED"
        )

    report["completed_at"] = utc_now()
    write_json(report_path, report)
    return report

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Sincroniza una competición BOT 9 y permite reanudarla por "
            "micro-lotes sin repetir eventos completos."
        )
    )
    parser.add_argument("--key", required=True)
    parser.add_argument("--import-finished", action="store_true")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument(
        "--resume-existing-catalog",
        action="store_true",
        help="Carga el catálogo y el checkpoint anteriores sin recorrerlo de nuevo.",
    )
    parser.add_argument(
        "--micro-batch-size",
        type=int,
        default=IMPORT_BATCH_SIZE,
    )
    parser.add_argument("--max-events", type=int)
    parser.add_argument("--max-seconds", type=int)
    parser.add_argument(
        "--prioritize-event-id",
        type=int,
        action="append",
        default=[],
    )
    return parser

def main() -> int:
    args = build_parser().parse_args()
    report = synchronize(
        args.key,
        bool(args.import_finished),
        resume=bool(args.resume),
        resume_existing_catalog=bool(args.resume_existing_catalog),
        micro_batch_size=max(1, int(args.micro_batch_size)),
        max_events=args.max_events,
        max_seconds=args.max_seconds,
        priority_event_ids=list(args.prioritize_event_id or []),
    )
    print("=" * 86)
    print("ODDSHUNTER BOT 9 — TEMPORADA DE TORNEO SINCRONIZADA")
    print("=" * 86)
    print(f"Competición: {report['competition_key']}")
    print(
        f"Temporada: {report['season_name']} "
        f"(season_id={report['season_id']})"
    )
    print(
        f"Finalizados: {len(report['finished_event_ids'])} | "
        f"Próximos: {len(report['upcoming_event_ids'])} | "
        f"Equipos: {len(report['team_ids'])}"
    )
    role = str(
        report.get("context_season_role")
        or report.get("rules", {}).get("context_season_role")
        or "CURRENT"
    ).upper()
    if role == "PREVIOUS":
        print(
            "Contexto doméstico anterior: temporada real inmediatamente "
            "anterior, limitada a los 12 meses previos al partido objetivo."
        )
    else:
        print(
            "Aislamiento: misma competición y temporada configurada; "
            "el historial UEFA permanece separado del contexto doméstico."
        )
    print(f"Estado final: {report.get('final_state')}")
    return (
        0
        if report.get("final_state")
        in {"COMPLETED", "PARTIAL_CONTROLLED"}
        else 1
    )


if __name__ == "__main__":
    raise SystemExit(main())
