from __future__ import annotations

# ODDSHUNTER_V4_4_7_TRAINED_GOALS_WRAPPER
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
CORE_SCRIPT = BASE_DIR / "poisson_dixon_coles_core.py"
RUNTIME_SCRIPT = BASE_DIR / "elo_goals_runtime.py"
DEFAULT_RATINGS = DATA_DIR / "ratings" / "ultimo_ratings.json"
LATEST_GOALS = DATA_DIR / "modelos" / "ultimo_poisson_dixon_coles.json"


def _env() -> dict[str, str]:
    return {
        **os.environ,
        "PYTHONUTF8": "1",
        "PYTHONIOENCODING": "utf-8",
    }


def _read_event_id(path: Path) -> int:
    data = json.loads(path.read_text(encoding="utf-8"))
    event = data.get("upcoming_match") or data.get("evento")
    if not isinstance(event, dict) or event.get("event_id") is None:
        raise ValueError("El archivo de ratings no contiene event_id.")
    return int(event["event_id"])


def main() -> int:
    parser = argparse.ArgumentParser(
        description="OddsHunter V4.4.7 - wrapper de goles con MODELO_APRENDIDO."
    )
    parser.add_argument("ratings_json", nargs="?")
    parser.add_argument("--key")
    args, unknown = parser.parse_known_args()

    ratings_path = Path(args.ratings_json) if args.ratings_json else DEFAULT_RATINGS
    if not ratings_path.is_absolute():
        ratings_path = BASE_DIR / ratings_path

    if not CORE_SCRIPT.exists():
        print(f"ERROR: no existe {CORE_SCRIPT}")
        return 1

    core_command = [
        sys.executable,
        "-u",
        str(CORE_SCRIPT),
        str(ratings_path),
    ]
    if args.key:
        core_command += ["--key", str(args.key)]
    core_command += list(unknown)

    code = subprocess.call(core_command, cwd=BASE_DIR, env=_env())
    if code != 0:
        return int(code)

    event_id = _read_event_id(ratings_path)
    goals_path = DATA_DIR / "modelos" / f"poisson_dixon_coles_{event_id}.json"
    if not goals_path.exists():
        print(f"ERROR: el motor no genero {goals_path}")
        return 1

    # ELO sigue siendo opcional y solo modifica MODELO_APRENDIDO si su propia
    # validacion lo permite. Si el runtime falla, conservamos la salida del core.
    if args.key and RUNTIME_SCRIPT.exists():
        runtime_command = [
            sys.executable,
            "-u",
            str(RUNTIME_SCRIPT),
            "--key",
            str(args.key),
            "--ratings-json",
            str(ratings_path),
            "--goals-json",
            str(goals_path),
            "--latest-json",
            str(LATEST_GOALS),
        ]
        runtime_code = subprocess.call(runtime_command, cwd=BASE_DIR, env=_env())
        if runtime_code != 0:
            print(
                "AVISO: el ajuste ELO no pudo aplicarse; se conserva "
                "la salida base del motor entrenado."
            )
            try:
                LATEST_GOALS.parent.mkdir(parents=True, exist_ok=True)
                LATEST_GOALS.write_bytes(goals_path.read_bytes())
            except OSError:
                pass
    else:
        try:
            LATEST_GOALS.parent.mkdir(parents=True, exist_ok=True)
            LATEST_GOALS.write_bytes(goals_path.read_bytes())
        except OSError:
            pass

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
