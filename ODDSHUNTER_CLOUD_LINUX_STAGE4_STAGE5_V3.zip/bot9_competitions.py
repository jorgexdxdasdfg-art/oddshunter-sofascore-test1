from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any


BOT9_COMPETITIONS: tuple[dict[str, Any], ...] = (
    {
        "key": "uefa-champions-league",
        "name": "Liga de Campeones de la UEFA",
        "source_name": "UEFA Champions League",
        "aliases": [
            "Liga de Campeones de la UEFA",
            "UEFA Champions League",
        ],
        "country": "Europe",
        "source_competition_id": 7,
        "season_id": 96518,
        "season_name": "UEFA Champions League 26/27",
        "season_label": "26/27",
        "active": True,
        "bot9_managed": True,
        "current_season_only": True,
        "same_competition_only": True,
        "include_all_phases": True,
        "history_limit_per_team": 15,
        "recent_matches_emphasis": 5,
    },
    {
        "key": "uefa-conference-league",
        "name": "UEFA Conference League",
        "source_name": "UEFA Conference League",
        "aliases": [
            "UEFA Conference League",
            "UEFA Europa Conference League",
        ],
        "country": "Europe",
        "source_competition_id": 17015,
        "season_id": None,
        "season_name": "UEFA Conference League 26/27",
        "season_label": "26/27",
        "active": True,
        "bot9_managed": True,
        "current_season_only": True,
        "same_competition_only": True,
        "include_all_phases": True,
        "history_limit_per_team": 15,
        "recent_matches_emphasis": 5,
    },
    {
        "key": "conmebol-sudamericana",
        "name": "CONMEBOL Sudamericana",
        "source_name": "CONMEBOL Sudamericana",
        "aliases": [
            "CONMEBOL Sudamericana",
            "Copa Sudamericana",
        ],
        "country": "South America",
        "source_competition_id": 480,
        "season_id": 87770,
        "season_name": "CONMEBOL Sudamericana 2026",
        "season_label": "2026",
        "active": True,
        "bot9_managed": True,
        "current_season_only": True,
        "same_competition_only": True,
        "include_all_phases": True,
        "history_limit_per_team": 15,
        "recent_matches_emphasis": 5,
    },
    {
        "key": "copa-colombia",
        "name": "Copa Colombia",
        "source_name": "Copa Colombia",
        "aliases": ["Copa Colombia"],
        "country": "Colombia",
        "source_competition_id": 1335,
        "season_id": None,
        "season_name": "Copa Colombia 2026",
        "season_label": "2026",
        "active": True,
        "bot9_managed": True,
        "current_season_only": True,
        "same_competition_only": True,
        "include_all_phases": True,
        "history_limit_per_team": 15,
        "recent_matches_emphasis": 5,
    },
)


def slugify(value: Any) -> str:
    text = str(value or "").strip().lower()
    text = re.sub(r"[^a-z0-9]+", "-", text)
    return text.strip("-")


def is_managed_competition(
    row: dict[str, Any],
    competition_key: str,
) -> bool:
    """Valida ligas BOT 9 y contextos domésticos dinámicos seguros.

    Los contextos domésticos son entradas internas, ocultas en la interfaz,
    creadas después de instalar BOT 9. Algunas instalaciones anteriores no
    guardaron ``bot9_managed``. Se aceptan únicamente cuando la clave contiene
    los mismos tournament_id y season_id del registro; así no se amplía el
    acceso a entradas arbitrarias de competitions.json.
    """

    if bool(row.get("bot9_managed")):
        return True
    wanted = slugify(competition_key)
    if not bool(row.get("context_only")):
        return False
    if str(row.get("competition_family") or "").upper() != "DOMESTIC":
        return False
    if bool(row.get("visible_in_ui", True)):
        return False
    match = re.fullmatch(r"domestic-context-(\d+)-(\d+)", wanted)
    if match is None:
        return False
    tournament_id = int(row.get("source_competition_id") or 0)
    season_id = int(row.get("season_id") or 0)
    return (
        tournament_id > 0
        and season_id > 0
        and tournament_id == int(match.group(1))
        and season_id == int(match.group(2))
    )


def _read_registry(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {
            "version": 1,
            "competitions": [],
        }
    document = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(document, dict):
        raise ValueError(f"{path} no contiene un objeto JSON.")
    if not isinstance(document.get("competitions"), list):
        raise ValueError(
            f"{path} no contiene una lista 'competitions'."
        )
    return document


def _atomic_write(path: Path, document: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".bot9.tmp")
    temporary.write_text(
        json.dumps(document, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    os.replace(temporary, path)


def merge_bot9_competitions(
    registry_path: Path,
    competitions_dir: Path | None = None,
) -> dict[str, Any]:
    """Añade o actualiza solo las cuatro competiciones administradas por BOT 9.

    Las entradas preexistentes que no pertenecen a BOT 9 se conservan byte a
    byte a nivel de valores JSON. Una entrada BOT 9 existente conserva campos
    locales desconocidos y recibe únicamente los valores definidos arriba.
    """

    registry = _read_registry(registry_path)
    rows = registry["competitions"]
    positions: dict[str, int] = {}

    for index, row in enumerate(rows):
        if not isinstance(row, dict):
            continue
        key = slugify(row.get("key"))
        if key and key not in positions:
            positions[key] = index

    added: list[str] = []
    updated: list[str] = []
    for specification in BOT9_COMPETITIONS:
        key = slugify(specification["key"])
        if key in positions:
            index = positions[key]
            previous = rows[index]
            merged = dict(previous) if isinstance(previous, dict) else {}
            # Un season_id resuelto en una ejecución anterior tiene prioridad
            # sobre el valor nulo de la plantilla.
            resolved_season = merged.get("season_id")
            merged.update(specification)
            if specification.get("season_id") is None and resolved_season:
                merged["season_id"] = resolved_season
            rows[index] = merged
            updated.append(key)
        else:
            rows.append(dict(specification))
            positions[key] = len(rows) - 1
            added.append(key)

    registry["bot9"] = {
        "enabled": True,
        "managed_competitions": [
            specification["key"]
            for specification in BOT9_COMPETITIONS
        ],
        "scope": "current_season_same_competition_only",
    }
    _atomic_write(registry_path, registry)

    if competitions_dir is not None:
        for specification in BOT9_COMPETITIONS:
            (
                competitions_dir
                / slugify(specification["key"])
            ).mkdir(parents=True, exist_ok=True)

    return {
        "registry_path": str(registry_path),
        "added": added,
        "updated": updated,
        "total_competitions": len(rows),
    }


def update_resolved_season(
    registry_path: Path,
    competition_key: str,
    season_id: int,
    season_name: str,
) -> dict[str, Any]:
    registry = _read_registry(registry_path)
    wanted = slugify(competition_key)
    found = False

    for row in registry["competitions"]:
        if not isinstance(row, dict):
            continue
        if slugify(row.get("key")) != wanted:
            continue
        if not is_managed_competition(row, wanted):
            raise ValueError(
                f"La competición {wanted} no está administrada por BOT 9."
            )
        row["season_id"] = int(season_id)
        row["season_name"] = str(season_name)
        found = True
        break

    if not found:
        raise ValueError(f"No existe la competición BOT 9 '{wanted}'.")

    _atomic_write(registry_path, registry)
    return registry


if __name__ == "__main__":
    base_dir = Path(__file__).resolve().parent
    result = merge_bot9_competitions(
        base_dir / "data" / "competitions.json",
        base_dir / "data" / "competitions",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
