from __future__ import annotations

import argparse
import builtins
import json
import os
import re
import sqlite3
import time
import traceback as traceback_module
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from playwright.sync_api import BrowserContext, Page, Playwright, sync_playwright

import import_competition_stats as importer
import sync_upcoming_matches as browser_syncer
from futbol24_client import Futbol24Client
from flashscore_xg_client import FlashscoreXGClient


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "oddshunter.db"
REGISTRY_PATH = DATA_DIR / "competitions.json"
COMPETITIONS_DIR = DATA_DIR / "competitions"
RAW_ROOT_DIR = DATA_DIR / "raw_competitions"
AUTOMATION_DIR = DATA_DIR / "automation"
REPORT_DIR = AUTOMATION_DIR / "incremental_results"

RESULTS_PROFILE_DIR = DATA_DIR / "brave_oddshunter_results_profile"

REPORT_DIR.mkdir(parents=True, exist_ok=True)
RESULTS_PROFILE_DIR.mkdir(parents=True, exist_ok=True)
RAW_ROOT_DIR.mkdir(parents=True, exist_ok=True)

API_HEADERS = {
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
    "Origin": "https://www.sofascore.com",
    "Referer": "https://www.sofascore.com/",
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/150.0.0.0 Safari/537.36"
    ),
}

SOFASCORE_BROWSER_FALLBACK_STATUSES = {401, 403, 404, 429}


def _env_value(project_root: Path, key: str) -> str | None:
    """Lee una variable del entorno y, si falta, del .env local."""

    value = os.environ.get(key)
    if value is not None:
        return value.strip().strip("\"'")

    try:
        lines = (project_root / ".env").read_text(
            encoding="utf-8-sig"
        ).splitlines()
    except OSError:
        return None

    for raw_line in lines:
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        env_key, separator, env_value = line.partition("=")
        if separator and env_key.strip() == key:
            return env_value.strip().strip("\"'")
    return None


def configured_browser_tabs(project_root: Path = BASE_DIR) -> int:
    """Límite único para las pestañas SofaScore de este proceso."""

    raw_value = _env_value(project_root, "ODDSHUNTER_BRAVE_TABS")
    try:
        configured = int(raw_value or "3")
    except (TypeError, ValueError):
        configured = 3
    return max(1, min(configured, 3))


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def slugify(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-")


def read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(path)

    data = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(data, dict):
        raise ValueError(
            f"{path.name} no contiene un objeto JSON."
        )

    return data


def read_json_optional(
    path: Path,
) -> dict[str, Any] | None:
    try:
        return read_json(path)
    except Exception:
        return None


def write_json(
    path: Path,
    data: Any,
) -> None:
    """Escritura atómica con reintentos cortos para Windows."""

    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(
        data,
        ensure_ascii=False,
        indent=2,
    )
    temporary = path.with_name(
        f".{path.name}.{os.getpid()}.tmp"
    )
    last_error: OSError | None = None
    for attempt in range(1, 4):
        try:
            temporary.write_text(
                payload,
                encoding="utf-8",
            )
            os.replace(temporary, path)
            return
        except OSError as exc:
            last_error = exc
            temporary.unlink(missing_ok=True)
            if attempt < 3:
                time.sleep(0.15 * attempt)
    assert last_error is not None
    raise last_error


_ORIGINAL_PRINT = builtins.print
_CONSOLE_OUTPUT_DISABLED = False


def safe_print(*args: Any, **kwargs: Any) -> None:
    """No convierte un pipe cerrado por el padre en error del evento."""

    global _CONSOLE_OUTPUT_DISABLED
    if _CONSOLE_OUTPUT_DISABLED:
        return
    try:
        _ORIGINAL_PRINT(*args, **kwargs)
    except (OSError, ValueError):
        _CONSOLE_OUTPUT_DISABLED = True


# Todo el módulo usa esta salida tolerante. Los errores reales de datos y
# SQLite continúan propagándose y quedan registrados con traceback.
print = safe_print


def find_competition(
    registry: dict[str, Any],
    key: str,
) -> dict[str, Any]:
    normalized = slugify(key)

    for competition in registry.get("competitions", []):
        if not isinstance(competition, dict):
            continue

        if slugify(str(competition.get("key") or "")) == normalized:
            return competition

    raise ValueError(
        f"No existe la competición '{key}'."
    )


def load_schedule_matches(
    competition_key: str,
) -> dict[int, dict[str, Any]]:
    path = (
        COMPETITIONS_DIR
        / competition_key
        / "matches_upcoming.json"
    )
    document = read_json_optional(path) or {}
    rows = document.get("matches")

    if not isinstance(rows, list):
        return {}

    result: dict[int, dict[str, Any]] = {}

    for row in rows:
        if not isinstance(row, dict):
            continue

        try:
            event_id = int(row["event_id"])
        except (KeyError, TypeError, ValueError):
            continue

        result[event_id] = dict(row)

    return result


def parse_kickoff_timestamp(
    value: Any,
) -> int:
    text = str(value or "").strip()

    if not text:
        return 0

    try:
        parsed = datetime.fromisoformat(
            text.replace("Z", "+00:00")
        )
    except ValueError:
        return 0

    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)

    return int(
        parsed.astimezone(timezone.utc).timestamp()
    )


def load_match_from_sqlite(
    event_id: int,
) -> dict[str, Any] | None:
    if not DB_PATH.exists():
        return None

    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row

    try:
        row = connection.execute(
            """
            SELECT
                m.sofascore_id AS event_id,
                m.kickoff,
                m.home_goals,
                m.away_goals,
                m.status,
                home.sofascore_id AS home_team_id,
                home.name AS home_team,
                away.sofascore_id AS away_team_id,
                away.name AS away_team
            FROM matches AS m
            INNER JOIN teams AS home
                ON home.team_id = m.home_team_id
            INNER JOIN teams AS away
                ON away.team_id = m.away_team_id
            WHERE m.sofascore_id = ?
            LIMIT 1
            """,
            (int(event_id),),
        ).fetchone()
    except sqlite3.Error:
        return None
    finally:
        connection.close()

    if row is None:
        return None

    result = dict(row)
    result["start_timestamp"] = parse_kickoff_timestamp(
        result.get("kickoff")
    )
    result["url"] = (
        f"https://www.sofascore.com/event/{int(event_id)}"
    )
    return result


def _event_source_team_ids(event: dict[str, Any]) -> frozenset[int]:
    values: set[int] = set()
    for key in ("homeTeam", "awayTeam"):
        team = event.get(key)
        try:
            values.add(int((team or {}).get("id")))
        except (TypeError, ValueError):
            continue
    return frozenset(values)


def discover_replacement_event(
    page: Page,
    fallback: dict[str, Any] | None,
    competition: dict[str, Any],
    original_event_id: int,
    *,
    max_history_pages: int = 2,
) -> dict[str, Any] | None:
    """Busca un ID sustituto cuando SofaScore retiró el evento original.

    Los cambios de sede/localía pueden hacer que el proveedor elimine un ID y
    cree otro. La coincidencia exige el mismo par de equipos (sin importar el
    orden), torneo, temporada y un kickoff cercano; nunca se decide solo por el
    nombre ni por la fecha.
    """

    expected = dict(fallback or {})
    try:
        expected_teams = frozenset(
            (
                int(expected["home_team_id"]),
                int(expected["away_team_id"]),
            )
        )
    except (KeyError, TypeError, ValueError):
        return None
    if len(expected_teams) != 2:
        return None

    expected_kickoff = int(
        expected.get("start_timestamp")
        or parse_kickoff_timestamp(expected.get("kickoff"))
        or 0
    )
    if expected_kickoff <= 0:
        return None

    expected_tournament = int(
        competition.get("source_competition_id") or 0
    )
    expected_season = int(competition.get("season_id") or 0)
    candidates: dict[int, tuple[int, dict[str, Any]]] = {}

    for team_id in sorted(expected_teams):
        for page_index in range(max(1, int(max_history_pages))):
            status, document = browser_syncer._browser_fetch_json(
                page,
                f"/api/v1/team/{team_id}/events/last/{page_index}",
            )
            if status != 200 or not isinstance(document, dict):
                break
            rows = document.get("events")
            if not isinstance(rows, list):
                break
            for event in rows:
                if not isinstance(event, dict):
                    continue
                try:
                    candidate_id = int(event.get("id"))
                    kickoff = int(event.get("startTimestamp"))
                except (TypeError, ValueError):
                    continue
                if candidate_id == int(original_event_id):
                    continue
                if _event_source_team_ids(event) != expected_teams:
                    continue
                tournament = event.get("tournament") or {}
                unique = tournament.get("uniqueTournament") or {}
                try:
                    tournament_id = int(
                        unique.get("id") or tournament.get("id") or 0
                    )
                    season_id = int((event.get("season") or {}).get("id") or 0)
                except (TypeError, ValueError):
                    continue
                if expected_tournament and tournament_id != expected_tournament:
                    continue
                if expected_season and season_id != expected_season:
                    continue
                delta = abs(kickoff - expected_kickoff)
                if delta > 72 * 60 * 60:
                    continue
                candidates[candidate_id] = (delta, event)
            if not bool(document.get("hasNextPage")):
                break

    if not candidates:
        return None
    return min(
        candidates.values(),
        key=lambda item: (item[0], int(item[1].get("id") or 0)),
    )[1]


def mark_event_replaced(
    original_event_id: int,
    replacement_event_id: int,
) -> bool:
    """Cierra el ID obsoleto para que no vuelva a la cola automática."""

    if not DB_PATH.exists() or int(original_event_id) == int(replacement_event_id):
        return False
    connection = sqlite3.connect(DB_PATH)
    try:
        cursor = connection.execute(
            """
            UPDATE matches
            SET status = 'CANCELLED',
                updated_at = CURRENT_TIMESTAMP
            WHERE sofascore_id = ?
              AND UPPER(COALESCE(status, '')) NOT IN ('FT', 'FINISHED')
            """,
            (int(original_event_id),),
        )
        connection.commit()
        return bool(cursor.rowcount)
    finally:
        connection.close()


def missing_metric_count(event_id: int) -> int:
    """Cuenta únicamente campos requeridos ausentes; nunca convierte NULL en cero."""

    if not DB_PATH.exists():
        return 8
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    try:
        rows = connection.execute(
            """
            SELECT
                xg_for, shots, shots_on_target, corners_for, yellow_cards
            FROM team_match_stats AS s
            INNER JOIN matches AS m ON m.match_id = s.match_id
            WHERE m.sofascore_id = ?
            """,
            (int(event_id),),
        ).fetchall()
    except sqlite3.Error:
        return 8
    finally:
        connection.close()
    if len(rows) != 2:
        return 8
    return sum(
        1
        for row in rows
        for field in (
            "xg_for",
            "shots",
            "shots_on_target",
            "corners_for",
            "yellow_cards",
        )
        if row[field] is None
    )


def completion_status(quality: str, *, xg_is_estimated: bool) -> str:
    """Clasifica completitud sin cambiar el esquema SQLite existente."""

    if str(quality).upper() != "FULL":
        return "PARTIAL"
    return "FULL_USABLE" if xg_is_estimated else "FULL_REAL"


def prioritize_requested_events(
    requested_ids: list[int],
    schedule: dict[int, dict[str, Any]],
    match_cache: dict[str, Any],
    *,
    now_timestamp: int | None = None,
) -> list[int]:
    """Próximos primero; luego más faltantes, nunca abiertos e históricos."""

    current = int(now_timestamp or datetime.now(timezone.utc).timestamp())

    def priority(event_id: int) -> tuple[Any, ...]:
        fallback = schedule.get(event_id) or load_match_from_sqlite(event_id) or {}
        kickoff = int(
            fallback.get("start_timestamp")
            or parse_kickoff_timestamp(fallback.get("kickoff"))
            or 0
        )
        missing = missing_metric_count(event_id)
        cache_present = any(
            key == f"event:{event_id}" or key.startswith(f"{event_id}|")
            for key in match_cache
        )
        never_opened = 0 if not cache_present else 1
        if kickoff >= current:
            return (0, kickoff, -missing, never_opened, event_id)
        return (1, -missing, never_opened, -kickoff, event_id)

    return sorted(dict.fromkeys(requested_ids), key=priority)


def event_payload(
    document: dict[str, Any] | None,
) -> dict[str, Any] | None:
    if not isinstance(document, dict):
        return None

    possible = document.get("event", document)
    return possible if isinstance(possible, dict) else None


def validate_event_scope(
    document: dict[str, Any],
    competition: dict[str, Any],
) -> None:
    """Impide guardar un evento de otro torneo o de otra temporada."""

    if not (
        bool(competition.get("same_competition_only"))
        or bool(competition.get("current_season_only"))
    ):
        return

    event = event_payload(document)
    if event is None:
        raise ValueError("La respuesta no contiene un evento validable.")

    tournament = event.get("tournament", {})
    unique = (
        tournament.get("uniqueTournament", {})
        if isinstance(tournament, dict)
        else {}
    )
    actual_tournament = (
        unique.get("id")
        or (
            tournament.get("id")
            if isinstance(tournament, dict)
            else None
        )
    )
    expected_tournament = competition.get("source_competition_id")
    if expected_tournament is not None:
        if int(actual_tournament or 0) != int(expected_tournament):
            raise ValueError(
                "Evento fuera de competición: "
                f"esperado={expected_tournament}, actual={actual_tournament}."
            )

    if bool(competition.get("current_season_only")):
        actual_season = event.get("season", {}).get("id")
        expected_season = competition.get("season_id")
        if expected_season is None:
            raise ValueError(
                "La competición exige temporada actual, pero season_id "
                "todavía no fue resuelto."
            )
        if int(actual_season or 0) != int(expected_season):
            raise ValueError(
                "Evento fuera de temporada: "
                f"esperada={expected_season}, actual={actual_season}."
            )


def event_status(
    document: dict[str, Any] | None,
) -> str:
    event = event_payload(document)

    if event is None:
        return "unknown"

    return str(
        event.get("status", {}).get("type")
        or "unknown"
    ).strip().lower()


def match_score(score: dict[str, Any] | None) -> int | float | None:
    """Devuelve el marcador del partido sin sumar la tanda de penaltis."""

    values = score if isinstance(score, dict) else {}
    for key in ("display", "normaltime", "current"):
        value = values.get(key)
        if value is not None:
            return value
    return None


def match_from_event(
    event_document: dict[str, Any],
    fallback: dict[str, Any] | None,
    competition: dict[str, Any],
) -> dict[str, Any]:
    event = event_payload(event_document)

    if event is None:
        raise ValueError(
            "La respuesta no contiene un evento."
        )

    fallback = dict(fallback or {})
    home = event.get("homeTeam", {})
    away = event.get("awayTeam", {})
    home_score = event.get("homeScore", {})
    away_score = event.get("awayScore", {})
    season = event.get("season", {})
    tournament = event.get("tournament", {})
    unique = tournament.get("uniqueTournament", {})

    event_id = int(
        event.get("id")
        or fallback.get("event_id")
    )

    timestamp = int(
        event.get("startTimestamp")
        or fallback.get("start_timestamp")
        or 0
    )

    return {
        **fallback,
        "event_id": event_id,
        "start_timestamp": timestamp,
        "season_id": (
            season.get("id")
            or fallback.get("season_id")
            or competition.get("season_id")
        ),
        "season_name": (
            season.get("name")
            or fallback.get("season_name")
            or competition.get("season_name")
        ),
        "competition_id": (
            unique.get("id")
            or tournament.get("id")
            or fallback.get("competition_id")
            or competition.get("source_competition_id")
        ),
        "competition_name": (
            unique.get("name")
            or tournament.get("name")
            or fallback.get("competition_name")
            or competition.get("name")
        ),
        "home_team_id": int(
            home.get("id")
            or fallback.get("home_team_id")
        ),
        "home_team": (
            home.get("name")
            or fallback.get("home_team")
            or "Local"
        ),
        "away_team_id": int(
            away.get("id")
            or fallback.get("away_team_id")
        ),
        "away_team": (
            away.get("name")
            or fallback.get("away_team")
            or "Visitante"
        ),
        "home_goals": (
            match_score(home_score)
            if match_score(home_score) is not None
            else fallback.get("home_goals")
        ),
        "away_goals": (
            match_score(away_score)
            if match_score(away_score) is not None
            else fallback.get("away_goals")
        ),
        "status": event_status(event_document),
        "url": (
            fallback.get("url")
            or f"https://www.sofascore.com/event/{event_id}"
        ),
        "_competition_key": slugify(
            str(competition["key"])
        ),
        "_competition_country": str(
            competition.get("country") or ""
        ),
        "_registry_name": str(
            competition.get("name") or ""
        ),
        "_registry_season": str(
            competition.get("season_name") or ""
        ),
    }


def event_summary(
    event: dict[str, Any],
    fallback: dict[str, Any],
) -> dict[str, Any]:
    home = event.get("homeTeam", {})
    away = event.get("awayTeam", {})
    home_score = event.get("homeScore", {})
    away_score = event.get("awayScore", {})
    season = event.get("season", {})
    tournament = event.get("tournament", {})
    unique = tournament.get("uniqueTournament", {})

    return {
        "event_id": int(
            event.get("id")
            or fallback["event_id"]
        ),
        "start_timestamp": int(
            event.get("startTimestamp")
            or fallback.get("start_timestamp")
            or 0
        ),
        "season_id": (
            season.get("id")
            or fallback.get("season_id")
        ),
        "season_name": (
            season.get("name")
            or fallback.get("season_name")
        ),
        "competition_id": (
            unique.get("id")
            or tournament.get("id")
            or fallback.get("competition_id")
        ),
        "competition_name": (
            unique.get("name")
            or tournament.get("name")
            or fallback.get("competition_name")
        ),
        "home_team_id": int(
            home.get("id")
            or fallback["home_team_id"]
        ),
        "home_team": (
            home.get("name")
            or fallback.get("home_team")
        ),
        "away_team_id": int(
            away.get("id")
            or fallback["away_team_id"]
        ),
        "away_team": (
            away.get("name")
            or fallback.get("away_team")
        ),
        "home_goals": match_score(home_score),
        "away_goals": match_score(away_score),
        "status": event_status(event),
        "url": fallback.get("url"),
    }


def merge_finished_catalog(
    competition: dict[str, Any],
    summaries: list[dict[str, Any]],
) -> Path:
    key = slugify(str(competition["key"]))
    path = (
        COMPETITIONS_DIR
        / key
        / "matches_finished.json"
    )
    existing = read_json_optional(path) or {}
    rows = existing.get("matches")
    unique: dict[int, dict[str, Any]] = {}

    if isinstance(rows, list):
        for row in rows:
            if not isinstance(row, dict):
                continue

            try:
                event_id = int(row["event_id"])
            except (KeyError, TypeError, ValueError):
                continue
            if bool(competition.get("same_competition_only")):
                try:
                    competition_id = int(row.get("competition_id"))
                except (TypeError, ValueError):
                    continue
                if competition_id != int(
                    competition["source_competition_id"]
                ):
                    continue
            if bool(competition.get("current_season_only")):
                try:
                    row_season_id = int(row.get("season_id"))
                except (TypeError, ValueError):
                    continue
                if row_season_id != int(competition["season_id"]):
                    continue
            unique[event_id] = dict(row)

    for summary in summaries:
        unique[int(summary["event_id"])] = dict(summary)

    ordered = sorted(
        unique.values(),
        key=lambda row: (
            int(row.get("start_timestamp") or 0),
            int(row.get("event_id") or 0),
        ),
    )

    write_json(
        path,
        {
            "competition_key": key,
            "competition_name": competition.get("name"),
            "source_competition_id": competition.get(
                "source_competition_id"
            ),
            "season_id": competition.get("season_id"),
            "season_name": competition.get("season_name"),
            "total_finished_matches": len(ordered),
            "generated_at": utc_now(),
            "update_scope": "incremental_events",
            "matches": ordered,
        },
    )

    return path


class SofaScoreJsonClient:
    """Cliente híbrido con límite Brave leído del entorno o del .env."""

    def __init__(self, playwright: Playwright) -> None:
        self.playwright = playwright
        self.request = playwright.request.new_context(extra_http_headers=API_HEADERS)
        self.context: BrowserContext | None = None
        self.page: Page | None = None
        self.pages: list[Page] = []
        self.assigned_pages: dict[int, Page] = {}
        self.page_cursor = -1
        self.max_tabs = configured_browser_tabs(BASE_DIR)

    @staticmethod
    def _page_open(page: Page | None) -> bool:
        if page is None:
            return False
        try:
            return not page.is_closed()
        except Exception:
            return False

    @staticmethod
    def _browser_session_lost(exc: Exception) -> bool:
        """Reconoce cierres de Brave/Playwright que permiten recrear la sesión."""
        message = f"{type(exc).__name__}: {exc}".lower()
        markers = (
            "targetclosederror",
            "target page, context or browser has been closed",
            "browser has been closed",
            "target.createtarget",
            "failed to open a new tab",
        )
        return any(marker in message for marker in markers)

    def _reset_browser(self) -> None:
        """Descarta solo la sesión de Brave; conserva el cliente HTTP."""
        for page in list(self.pages):
            browser_syncer.close_playwright_target(
                page,
                "página de resultados dañada",
            )
        browser_syncer.close_playwright_target(
            self.context,
            "contexto de resultados dañado",
        )
        self.pages = []
        self.assigned_pages = {}
        self.page = None
        self.page_cursor = -1
        self.context = None

    @staticmethod
    def _event_key(url: str) -> int:
        match = re.search(r"/event/(\d+)", url)
        return int(match.group(1)) if match else 0

    def _prepare_page(self, page: Page) -> Page:
        try:
            page.goto(
                "https://www.sofascore.com/",
                wait_until="domcontentloaded",
                timeout=60_000,
            )
            page.wait_for_timeout(1_500)
        except Exception:
            # Aunque el frontend falle, page.evaluate(fetch) puede seguir
            # funcionando desde la sesión/origen ya inicializados.
            pass
        return page

    def _ensure_context(self) -> BrowserContext:
        if self.context is not None:
            return self.context

        brave = browser_syncer.encontrar_brave()
        self.context = self.playwright.chromium.launch_persistent_context(
            user_data_dir=str(RESULTS_PROFILE_DIR),
            executable_path=str(brave),
            headless=False,
            chromium_sandbox=True,
            locale="es-ES",
            viewport={"width": 1365, "height": 900},
            args=[
                "--start-maximized",
                "--disable-session-crashed-bubble",
                "--disable-features=InfiniteSessionRestore",
                "--no-first-run",
            ],
        )
        existing = [
            page for page in self.context.pages if self._page_open(page)
        ]
        first = existing[0] if existing else self.context.new_page()
        self.pages = [self._prepare_page(first)]
        for extra in existing[1:]:
            browser_syncer.close_playwright_target(extra, "pestaña adicional")
        self.page = self.pages[0]
        return self.context

    def _ensure_browser(self, url: str) -> tuple[int, Page]:
        context = self._ensure_context()
        event_key = self._event_key(url)
        assigned = self.assigned_pages.get(event_key)
        if self._page_open(assigned):
            self.page = assigned
            return event_key, assigned

        self.pages = [page for page in self.pages if self._page_open(page)]
        self.assigned_pages = {
            key: page
            for key, page in self.assigned_pages.items()
            if self._page_open(page)
        }
        if not self.pages:
            self.pages = [self._prepare_page(context.new_page())]

        if not self.assigned_pages:
            page = self.pages[0]
        elif len(self.pages) < self.max_tabs:
            page = self._prepare_page(context.new_page())
            self.pages.append(page)
        else:
            self.page_cursor = (self.page_cursor + 1) % len(self.pages)
            page = self.pages[self.page_cursor]

        self.assigned_pages[event_key] = page
        self.page = page
        print(
            f"   ℹ️ SofaScore/Brave: {len(self.pages)} pestaña(s) "
            f"para {len(self.assigned_pages)} evento(s); máximo "
            f"{self.max_tabs}."
        )
        return event_key, page

    def _discard_page(self, event_key: int, page: Page) -> None:
        self.assigned_pages = {
            key: assigned
            for key, assigned in self.assigned_pages.items()
            if key != event_key and assigned is not page
        }
        browser_syncer.close_playwright_target(
            page,
            "pestaña dañada de resultados",
        )
        self.pages = [
            candidate
            for candidate in self.pages
            if candidate is not page and self._page_open(candidate)
        ]
        if self.page is page:
            self.page = None

    def _browser_get(self, url: str) -> tuple[dict[str, Any] | None, str | None]:
        last_error: str | None = None

        for browser_attempt in range(2):
            event_key = self._event_key(url)
            page: Page | None = None
            try:
                event_key, page = self._ensure_browser(url)
                result = page.evaluate(
                    """
                    async (url) => {
                        const response = await fetch(url, {
                            method: 'GET',
                            credentials: 'include',
                            cache: 'no-store',
                            headers: {
                                'Accept': 'application/json, text/plain, */*',
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        });
                        const text = await response.text();
                        return {status: response.status, ok: response.ok, text};
                    }
                    """,
                    url,
                )
            except Exception as exc:
                last_error = f"Brave {type(exc).__name__}: {exc}"
                session_lost = self._browser_session_lost(exc)

                if session_lost:
                    self._reset_browser()
                elif page is not None:
                    # Un fallo local solo invalida esta pestaña; las demás
                    # asignaciones siguen disponibles.
                    self._discard_page(event_key, page)

                if session_lost and browser_attempt == 0:
                    print(
                        "   ⚠️ Brave se cerró durante la consulta; "
                        "se recreará la sesión y se reintentará una vez."
                    )
                    continue
                return None, last_error

            if not isinstance(result, dict):
                return None, f"Brave devolvió una respuesta inválida en {url}"
            status = int(result.get("status") or 0)
            if not bool(result.get("ok")):
                return None, f"HTTP {status} mediante Brave en {url}"
            try:
                document = json.loads(str(result.get("text") or ""))
            except json.JSONDecodeError as exc:
                return None, f"JSONDecodeError mediante Brave: {exc}"
            return (document, None) if isinstance(document, dict) else (
                None,
                f"Respuesta no JSON mediante Brave en {url}",
            )

        return None, last_error or f"Brave no pudo consultar {url}"

    def get(
        self,
        url: str,
        *,
        attempts: int = 3,
    ) -> tuple[dict[str, Any] | None, str | None]:
        last_error: str | None = None
        for attempt in range(1, attempts + 1):
            response = None
            browser_fallback = False
            try:
                response = self.request.get(
                    url,
                    timeout=30_000,
                    headers=API_HEADERS,
                )
                if response.ok:
                    document = response.json()
                    if isinstance(document, dict):
                        return document, None
                    last_error = f"Respuesta no JSON en {url}"
                else:
                    browser_fallback = (
                        int(response.status)
                        in SOFASCORE_BROWSER_FALLBACK_STATUSES
                    )
                    last_error = f"HTTP {response.status} en {url}"
            except Exception as exc:
                last_error = f"{type(exc).__name__}: {exc}"
            finally:
                if response is not None:
                    try:
                        response.dispose()
                    except Exception:
                        pass

            # Un 403 no se repite tres veces: se cambia de inmediato a Brave.
            # Cada evento conserva su pestaña, hasta un máximo adaptativo de
            # 12; después se reutilizan por lotes sin duplicar eventos.
            if browser_fallback or attempt == attempts:
                document, browser_error = self._browser_get(url)
                if document is not None:
                    return document, None
                last_error = browser_error or last_error
                if browser_fallback:
                    return None, last_error
            if attempt < attempts:
                time.sleep(1.0 * attempt)
        return None, last_error

    def close(self) -> None:
        try:
            self.request.dispose()
        except Exception:
            pass
        self._reset_browser()


def fetch_json(
    client: SofaScoreJsonClient,
    url: str,
    *,
    attempts: int = 3,
) -> tuple[dict[str, Any] | None, str | None]:
    return client.get(url, attempts=attempts)

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Comprueba eventos vencidos, guarda el resultado y descarga "
            "xG, córners, remates y amarillas mediante la API de SofaScore."
        )
    )
    parser.add_argument(
        "--key",
        required=True,
        help="Clave de competición.",
    )
    parser.add_argument(
        "--event-id",
        type=int,
        action="append",
        required=True,
        help="Evento concreto. Puede repetirse.",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()

    registry = read_json(REGISTRY_PATH)
    competition = find_competition(
        registry,
        args.key,
    )
    key = slugify(str(competition["key"]))
    schedule = load_schedule_matches(key)
    requested_ids = sorted(
        set(int(value) for value in args.event_id)
    )

    raw_dir = RAW_ROOT_DIR / key
    raw_dir.mkdir(parents=True, exist_ok=True)

    report_path = REPORT_DIR / f"{key}_last.json"
    previous_report = read_json_optional(report_path) or {}
    report: dict[str, Any] = {
        "generated_at": utc_now(),
        "resume_loaded": bool(previous_report),
        "previous_checkpoint_event_id": previous_report.get(
            "last_checkpoint_event_id"
        ),
        "previous_checkpoint_at": previous_report.get("checkpoint_at"),
        "competition_key": key,
        "requested_event_ids": requested_ids,
        "finished_event_ids": [],
        "full_event_ids": [],
        "full_real_event_ids": [],
        "full_usable_event_ids": [],
        "partial_event_ids": [],
        "already_full_event_ids": [],
        "not_finished": [],
        "terminal_events": [],
        "replaced_events": [],
        "errors": [],
        "event_results": [],
        "affected_team_ids": [],
        "refresh_team_ids": [],
        "finished_catalog": None,
        "checkpoints": [],
    }

    affected_team_ids: set[int] = set()
    refresh_team_ids: set[int] = set()
    finished_summaries: list[dict[str, Any]] = []
    write_json(report_path, report)

    print("=" * 86)
    print("ODDSHUNTER — RESULTADOS Y ESTADÍSTICAS REALES")
    print("=" * 86)
    print(f"Competición: {competition.get('name')}")
    print(f"Eventos concretos: {len(requested_ids)}")
    print(
        "Consulta híbrida: SofaScore y Futbol24 primero; Flashscore se "
        "usa solo para campos realmente faltantes y con presupuesto por ciclo. "
        "Brave respeta el límite "
        "configurado en ODDSHUNTER_BRAVE_TABS para ambas fuentes."
    )
    print()

    with sync_playwright() as playwright:
        client = SofaScoreJsonClient(playwright)
        futbol24_client = Futbol24Client(
            project_root=BASE_DIR,
            logger=lambda message: print(f"   ℹ️ {message}"),
        )
        flashscore_client = FlashscoreXGClient(
            playwright,
            project_root=BASE_DIR,
            logger=lambda message: print(f"   ℹ️ {message}"),
        )
        print(
            "Concurrencia Brave configurada: "
            f"SofaScore={client.max_tabs}, "
            f"Flashscore={flashscore_client.max_tabs}."
        )
        processing_ids = prioritize_requested_events(
            requested_ids,
            schedule,
            flashscore_client.match_cache,
        )
        report["processing_order"] = processing_ids
        print(
            "Prioridad: kickoff más cercano, más campos ausentes, "
            "nunca abierto y finalmente históricos."
        )
        print()

        try:
            for index, event_id in enumerate(
                processing_ids,
                start=1,
            ):
                requested_event_id = int(event_id)
                replacement_original_id: int | None = None
                print("-" * 86)
                print(
                    f"[{index:02d}/{len(processing_ids):02d}] "
                    f"event_id={event_id}"
                )

                fallback = (
                    schedule.get(event_id)
                    or load_match_from_sqlite(event_id)
                )

                try:
                    current_quality = (
                        importer.partido_estado_sqlite(
                            event_id
                        )
                    )

                    if current_quality == "FULL":
                        report[
                            "already_full_event_ids"
                        ].append(event_id)
                        report["event_results"].append(
                            {
                                "event_id": event_id,
                                "result": "already_full",
                            }
                        )
                        print(
                            "   ⏭️ Ya contiene remates, córners y "
                            "amarillas; el xG se conserva cuando la "
                            "fuente lo publica."
                        )
                        continue

                    # Reutiliza el camino SofaScore ya validado por el
                    # importador: una petición directa por endpoint y, ante
                    # 403, fallback desde la MISMA página/contexto Brave.
                    # No se mantiene aquí una segunda implementación para
                    # /event, /statistics y /shotmap.
                    event_url = (
                        str((fallback or {}).get("url") or "").strip()
                        or f"https://www.sofascore.com/event/{event_id}"
                    )
                    _event_key, sofascore_page = client._ensure_browser(
                        event_url
                    )
                    capture_match = {
                        **dict(fallback or {}),
                        "event_id": event_id,
                        "url": event_url,
                    }
                    event_document, captured_stats = (
                        importer.capturar_json_partido(
                            sofascore_page,
                            capture_match,
                            raw_dir,
                        )
                    )
                    event_error = (
                        None
                        if event_document is not None
                        else "SOFASCORE_SOURCE_UNAVAILABLE"
                    )
                    event_from_cache = False
                    if event_document is None:
                        cached_event = read_json_optional(
                            raw_dir / f"event_{event_id}.json"
                        )
                        if cached_event:
                            event_document = cached_event
                            event_from_cache = True
                            print(
                                "   ♻ Evento recuperado desde la caché "
                                "local de SofaScore."
                            )

                    if event_document is None and fallback:
                        replacement = discover_replacement_event(
                            sofascore_page,
                            fallback,
                            competition,
                            event_id,
                        )
                        if replacement is not None:
                            replacement_id = int(replacement["id"])
                            replacement_url = (
                                f"https://www.sofascore.com/event/"
                                f"{replacement_id}"
                            )
                            replacement_match = {
                                **dict(fallback),
                                "event_id": replacement_id,
                                "url": replacement_url,
                            }
                            recovered_event, recovered_stats = (
                                importer.capturar_json_partido(
                                    sofascore_page,
                                    replacement_match,
                                    raw_dir,
                                )
                            )
                            event_document = (
                                recovered_event
                                if isinstance(recovered_event, dict)
                                else {"event": replacement}
                            )
                            captured_stats = recovered_stats
                            replacement_original_id = int(event_id)
                            event_id = replacement_id
                            fallback = replacement_match
                            event_error = None
                            report["replaced_events"].append(
                                {
                                    "original_event_id": replacement_original_id,
                                    "replacement_event_id": replacement_id,
                                    "reason": "provider_event_replaced",
                                }
                            )
                            print(
                                "   ✅ Evento sustituido recuperado: "
                                f"{replacement_original_id} → {replacement_id}."
                            )

                    if event_document is None:
                        report["errors"].append(
                            {
                                "event_id": event_id,
                                "stage": "event",
                                "error": event_error,
                            }
                        )
                        report["event_results"].append(
                            {
                                "event_id": event_id,
                                "result": "technical_error",
                                "error": event_error,
                            }
                        )
                        print(
                            f"   ❌ No se obtuvo el evento: "
                            f"{event_error}"
                        )
                        continue

                    validate_event_scope(
                        event_document,
                        competition,
                    )
                    if replacement_original_id is not None:
                        mark_event_replaced(
                            replacement_original_id,
                            event_id,
                        )

                    match = match_from_event(
                        event_document,
                        fallback,
                        competition,
                    )

                    status = event_status(event_document)
                    home_id = int(match["home_team_id"])
                    away_id = int(match["away_team_id"])

                    if status in {
                        "canceled",
                        "cancelled",
                        "postponed",
                        "abandoned",
                    }:
                        report["terminal_events"].append(
                            {
                                "event_id": event_id,
                                "status": status,
                            }
                        )
                        report["event_results"].append(
                            {
                                "event_id": event_id,
                                "result": "terminal",
                                "status": status,
                            }
                        )
                        # ODDSHUNTER_TERMINAL_NO_REFRESH_V1_2: estado terminal = sin refresh de equipos.
                        print(
                            f"   ⚠️ Estado terminal: {status}."
                        )
                        continue

                    if status != "finished":
                        report["not_finished"].append(
                            {
                                "event_id": event_id,
                                "status": status,
                            }
                        )
                        report["event_results"].append(
                            {
                                "event_id": event_id,
                                "result": "not_finished",
                                "status": status,
                            }
                        )
                        print(
                            f"   ℹ️ Estado actual: {status}."
                        )
                        continue

                    stats_document = (
                        captured_stats
                        if isinstance(captured_stats, dict)
                        and bool(captured_stats)
                        else None
                    )
                    shotmap_document = read_json_optional(
                        raw_dir / f"shotmap_{event_id}.json"
                    )
                    if not shotmap_document:
                        shotmap_document = None
                    stats_error = (
                        None
                        if stats_document is not None
                        else "SOFASCORE_NO_STATISTICS"
                    )
                    shotmap_error = (
                        None
                        if shotmap_document is not None
                        else "SOFASCORE_NO_SHOTMAP"
                    )
                    stats_from_cache = False
                    shotmap_from_cache = False
                    if stats_document is None:
                        cached_stats = read_json_optional(
                            raw_dir / f"statistics_{event_id}.json"
                        )
                        if cached_stats:
                            stats_document = cached_stats
                            stats_from_cache = True
                            print(
                                "   ♻ Estadísticas recuperadas desde la "
                                "caché local de SofaScore."
                            )
                    if shotmap_document is None:
                        cached_shotmap = read_json_optional(
                            raw_dir / f"shotmap_{event_id}.json"
                        )
                        if cached_shotmap:
                            shotmap_document = cached_shotmap
                            shotmap_from_cache = True
                            print(
                                "   ♻ Mapa de remates recuperado desde la "
                                "caché local de SofaScore."
                            )

                    stats_json = (
                        stats_document
                        if isinstance(stats_document, dict)
                        else {"statistics": []}
                    )

                    stats_json, xg_from_shotmap = (
                        importer.completar_xg_desde_shotmap(
                            stats_json,
                            shotmap_document,
                            home_id,
                            away_id,
                        )
                    )

                    write_json(
                        raw_dir / f"event_{event_id}.json",
                        event_document,
                    )
                    write_json(
                        raw_dir / f"statistics_{event_id}.json",
                        stats_json,
                    )
                    write_json(
                        raw_dir / f"shotmap_{event_id}.json",
                        shotmap_document or {},
                    )

                    xg_result = importer.recuperar_xg_partido(
                        match,
                        event_document,
                        stats_json,
                        futbol24_client,
                        flashscore_client,
                        raw_dir,
                    )
                    real_stats_result = importer.recuperar_metricas_partido(
                        match,
                        event_document,
                        stats_json,
                        futbol24_client,
                        flashscore_client,
                        raw_dir,
                    )
                    match_id, quality = importer.guardar_partido(
                        match,
                        event_document,
                        stats_json,
                        xg_result,
                        real_stats_result,
                    )

                    report["finished_event_ids"].append(
                        event_id
                    )
                    quality_bucket = (
                        "full_event_ids"
                        if quality == "FULL"
                        else "partial_event_ids"
                    )
                    report[quality_bucket].append(event_id)
                    completion_status_value = completion_status(
                        quality,
                        xg_is_estimated=bool(xg_result.is_estimated),
                    )
                    if quality == "FULL":
                        completion_bucket = (
                            "full_usable_event_ids"
                            if completion_status_value == "FULL_USABLE"
                            else "full_real_event_ids"
                        )
                        report[completion_bucket].append(event_id)

                    # Si las tres fuentes no producen xG, no se debe reintentar
                    # cada 15 minutos. Queda PARTIAL/N/D y vuelve a la cola de
                    # disponibilidad diferida. Si existen remates suficientes,
                    # recuperar_xg_partido ya habrá generado el estimado.
                    source_unavailable = (
                        quality == "PARTIAL"
                        and (
                            not xg_result.available
                            or bool(real_stats_result.missing)
                        )
                    )
                    result_name = (
                        "full"
                        if quality == "FULL"
                        else "source_unavailable"
                        if source_unavailable
                        else "partial"
                    )

                    report["event_results"].append(
                        {
                            "event_id": event_id,
                            "result": result_name,
                            "quality": quality,
                            "completion_status": completion_status_value,
                            "stats_endpoint": (
                                stats_document is not None
                            ),
                            "shotmap_endpoint": (
                                shotmap_document is not None
                            ),
                            "event_from_cache": event_from_cache,
                            "stats_from_cache": stats_from_cache,
                            "shotmap_from_cache": shotmap_from_cache,
                            "xg_from_shotmap": xg_from_shotmap,
                            "xg_source": xg_result.source,
                            "xg_is_estimated": (
                                xg_result.is_estimated
                            ),
                            "metric_sources": real_stats_result.sources,
                            "missing_metrics": real_stats_result.missing,
                            "stats_error": stats_error,
                            "shotmap_error": shotmap_error,
                        }
                    )

                    affected_team_ids.update(
                        (home_id, away_id)
                    )
                    refresh_team_ids.update(
                        (home_id, away_id)
                    )

                    event = event_payload(event_document)

                    if event is not None:
                        finished_summaries.append(
                            event_summary(
                                event,
                                match,
                            )
                        )

                    print(
                        f"   ✅ Guardado {quality} "
                        f"({completion_status_value}) | match_id={match_id}"
                    )

                    if xg_from_shotmap:
                        print(
                            "   ✅ xG recuperado desde el mapa "
                            "real de remates."
                        )
                    elif xg_result.available:
                        xg_label = (
                            "estimado"
                            if xg_result.is_estimated
                            else "real"
                        )
                        print(
                            f"   ✅ xG {xg_label}: "
                            f"{xg_result.home:.2f} - "
                            f"{xg_result.away:.2f} "
                            f"({xg_result.source})"
                        )

                    if source_unavailable:
                        print(
                            "   ℹ️ SofaScore, Futbol24 y Flashscore no "
                            "publicaron todos los campos para este evento. "
                            "Se conserva lo recuperado y el próximo reintento "
                            "automático será diferido."
                        )
                    elif quality == "PARTIAL":
                        print(
                            "   ⚠️ SofaScore todavía no publicó "
                            "todas las métricas. Se reintentará."
                        )

                except Exception as exc:
                    error = f"{type(exc).__name__}: {exc}"
                    formatted_traceback = traceback_module.format_exc()
                    report["errors"].append(
                        {
                            "event_id": event_id,
                            "stage": "event_processing",
                            "error": error,
                            "traceback": formatted_traceback,
                        }
                    )
                    report["event_results"].append(
                        {
                            "event_id": event_id,
                            "result": "technical_error",
                            "error": error,
                        }
                    )
                    print(f"   ❌ {error}")
                finally:
                    # Checkpoint seguro después de cada partido. Conserva lo
                    # recuperado incluso si una fuente o evento posterior falla.
                    report["affected_team_ids"] = sorted(affected_team_ids)
                    report["refresh_team_ids"] = sorted(refresh_team_ids)
                    report["flashscore_cycle"] = flashscore_client.cycle_stats()
                    report["last_checkpoint_event_id"] = event_id
                    report["checkpoint_at"] = utc_now()
                    report["checkpoints"].append(
                        {
                            "event_id": event_id,
                            "requested_event_id": requested_event_id,
                            "saved_at": report["checkpoint_at"],
                            "finished_count": len(
                                report["finished_event_ids"]
                            ),
                            "error_count": len(report["errors"]),
                        }
                    )
                    write_json(report_path, report)

        finally:
            report["browser_teardown"] = {
                "started_at": utc_now(),
                "completed_at": None,
            }
            write_json(report_path, report)
            report["flashscore_cycle"] = flashscore_client.cycle_stats()
            try:
                flashscore_client.close()
                futbol24_client.close()
                client.close()
            finally:
                report["browser_teardown"]["completed_at"] = utc_now()
                write_json(report_path, report)

    if finished_summaries:
        catalog_path = merge_finished_catalog(
            competition,
            finished_summaries,
        )
        report["finished_catalog"] = str(
            catalog_path
        )

    report["affected_team_ids"] = sorted(
        affected_team_ids
    )
    report["refresh_team_ids"] = sorted(
        refresh_team_ids
    )

    report["completed_at"] = utc_now()
    write_json(report_path, report)

    print()
    print("=" * 86)
    print("RESUMEN")
    print("=" * 86)
    print(
        f"Finalizados guardados: "
        f"{len(report['finished_event_ids'])}"
    )
    print(
        f"Con estadísticas completas: "
        f"{len(report['full_event_ids'])}"
    )
    print(
        f"Pendientes de completar: "
        f"{len(report['partial_event_ids'])}"
    )
    print(
        f"Consultas con error: "
        f"{len(report['errors'])}"
    )
    print(f"Reporte: {report_path}")
    print("=" * 86)

    completed_or_known = (
        len(report["finished_event_ids"])
        + len(report["already_full_event_ids"])
        + len(report["not_finished"])
        + len(report["terminal_events"])
    )
    return 1 if report["errors"] and completed_or_known == 0 else 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\nProceso interrumpido.")
        raise SystemExit(130)
