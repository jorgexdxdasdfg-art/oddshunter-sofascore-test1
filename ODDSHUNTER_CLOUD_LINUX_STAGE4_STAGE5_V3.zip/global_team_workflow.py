from __future__ import annotations

import argparse
import hashlib
import json
import os
import queue
import sqlite3
import subprocess
import sys
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "oddshunter.db"
REGISTRY_PATH = DATA_DIR / "competitions.json"
COMPETITIONS_DIR = DATA_DIR / "competitions"
AUTOMATION_DIR = DATA_DIR / "automation"
STATE_PATH = AUTOMATION_DIR / "state_v2.json"
TRAINED_MODELS_DIR = DATA_DIR / "trained_models"
INCREMENTAL_REPORT_DIR = AUTOMATION_DIR / "incremental_results"

SELECTION_RULE = "next_match_of_each_affected_team_only"
CHECK_INTERVAL_MINUTES = 30
DUE_RETRY_MINUTES = 30.0
TECHNICAL_RETRY_MINUTES = 15.0
PARTIAL_RETRY_FIRST_MINUTES = 6.0 * 60.0
PARTIAL_RETRY_LATER_MINUTES = 24.0 * 60.0
SOURCE_UNAVAILABLE_RETRY_FIRST_MINUTES = 6.0 * 60.0
SOURCE_UNAVAILABLE_RETRY_LATER_MINUTES = 24.0 * 60.0
RECENT_PARTIAL_LOOKBACK_DAYS = 7.0
ASSUMED_MATCH_DURATION_MINUTES = 135
MIN_NEW_MATCHES_FOR_TRAINING = 10
MAX_DAYS_WITH_NEW_DATA = 7.0
REQUIRED_WALK_FORWARD_SAMPLES = 80
TRAINING_INSUFFICIENT_RETRY_HOURS = 24.0
LOCK_MAX_AGE_HOURS = 8.0
MAX_INCREMENTAL_WAVES = 6
GLOBAL_TEAM_PAGE_BUDGET = 8
CALENDAR_MAINTENANCE_MAX_SECONDS = 8 * 60
BOT9_SEASON_REFRESH_HOURS = 24.0
TRAIN_RETRY_HOURS = (1.0, 3.0, 12.0, 24.0)

# V4.4.3 — seguro PREPARTIDO.
# Solo revisa el próximo evento futuro de cada equipo (deduplicado).
# No recorre/calcula todo el calendario.
PREMATCH_GUARD_RETRY_MINUTES = 180.0
PREMATCH_GUARD_URGENT_RETRY_MINUTES = 60.0
PREMATCH_GUARD_CRITICAL_RETRY_MINUTES = 30.0
PREMATCH_ACCEPTED_STATUSES = {"FULL", "PARTIAL_WITH_FALLBACK"}
PREMATCH_REQUIRED_FILES = (
    "ratings.json",
    "goals.json",
    "corners.json",
    "cards.json",
    "shots.json",
)


class AutomationAlreadyRunning(RuntimeError):
    """Indica que otro proceso vivo posee el bloqueo de automatización."""

    def __init__(self, pid: int | None, started_at: str | None) -> None:
        self.pid = pid
        self.started_at = started_at
        details = f"PID {pid}" if pid else "PID desconocido"
        if started_at:
            details += f", iniciado {started_at}"
        super().__init__(
            "Ya existe una automatización en ejecución "
            f"({details})."
        )

STEP_TIMEOUTS_SECONDS = {
    "incremental_result_sync.py": 10 * 60,
    "tournament_season_sync.py": 45 * 60,
    "sync_upcoming_matches.py": 30 * 60,
    "calendar_maintenance_worker.py": 12 * 60,
    "sync_elo.py": 20 * 60,
    "analyze_upcoming_matches.py": 60 * 60,
    "train_models.py": 60 * 60,
    "domestic_context_manager.py": 90 * 60,
}

REQUIRED_SCRIPTS = (
    "incremental_result_sync.py",
    "tournament_season_sync.py",
    "sync_upcoming_matches.py",
    "calendar_maintenance_worker.py",
    "sync_elo.py",
    "analyze_upcoming_matches.py",
    "train_models.py",
    "domestic_context_manager.py",
)

AUTOMATION_DIR.mkdir(parents=True, exist_ok=True)
INCREMENTAL_REPORT_DIR.mkdir(parents=True, exist_ok=True)


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def iso_now() -> str:
    return utc_now().isoformat()


def slugify(value: str) -> str:
    import re

    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-")


def read_json(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None

    return data if isinstance(data, dict) else None


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def parse_datetime(value: Any) -> datetime | None:
    text = str(value or "").strip()

    if not text:
        return None

    try:
        parsed = datetime.fromisoformat(
            text.replace("Z", "+00:00")
        )
    except ValueError:
        return None

    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)

    return parsed.astimezone(timezone.utc)


def load_state() -> dict[str, Any]:
    state = read_json(STATE_PATH) or {}

    if not isinstance(state.get("competitions"), dict):
        state["competitions"] = {}

    return state


def save_state(state: dict[str, Any]) -> None:
    state["updated_at"] = iso_now()
    write_json(STATE_PATH, state)


def competition_state(
    state: dict[str, Any],
    key: str,
) -> dict[str, Any]:
    competitions = state.setdefault("competitions", {})
    row = competitions.setdefault(key, {})

    if not isinstance(row.get("due_attempts"), dict):
        row["due_attempts"] = {}

    if not isinstance(row.get("training"), dict):
        row["training"] = {}

    return row


def active_competitions() -> list[dict[str, Any]]:
    registry = read_json(REGISTRY_PATH)

    if not registry or not isinstance(
        registry.get("competitions"),
        list,
    ):
        raise RuntimeError(
            f"No se pudo leer un registro válido: {REGISTRY_PATH}"
        )

    rows = [
        row
        for row in registry["competitions"]
        if (
            isinstance(row, dict)
            and bool(row.get("active", True))
            and str(row.get("key") or "").strip()
        )
    ]
    rows.sort(
        key=lambda row: str(
            row.get("name") or row.get("key")
        )
    )
    return rows


def reload_competition(key: str) -> dict[str, Any]:
    registry = read_json(REGISTRY_PATH)
    wanted = slugify(key)
    if not registry:
        raise RuntimeError(f"No se pudo leer {REGISTRY_PATH}.")
    for row in registry.get("competitions", []):
        if not isinstance(row, dict):
            continue
        if slugify(str(row.get("key") or "")) == wanted:
            return dict(row)
    raise RuntimeError(
        f"No existe la competición '{wanted}' en {REGISTRY_PATH}."
    )


def connection() -> sqlite3.Connection:
    if not DB_PATH.exists():
        raise FileNotFoundError(
            f"No existe la base SQLite: {DB_PATH}"
        )

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn



def resolve_league_id(
    conn: sqlite3.Connection,
    competition: dict[str, Any],
) -> int:
    key = slugify(
        str(competition.get("key") or "")
    )
    name = str(
        competition.get("name") or ""
    ).strip()
    season = str(
        competition.get("season_name") or ""
    ).strip()

    # Cuando el esquema ELO está disponible, source_registry_key es la
    # asociación más segura entre competitions.json y leagues.
    try:
        row = conn.execute(
            """
            SELECT source_league_id
            FROM elo_temporadas
            WHERE source_registry_key = ?
            ORDER BY active DESC, season_id DESC
            LIMIT 1
            """,
            (key,),
        ).fetchone()

        if row is not None:
            return int(row["source_league_id"])

    except sqlite3.Error:
        pass

    possible_names: list[str] = []
    for value in (
        name,
        competition.get("source_name"),
        *(competition.get("aliases") or []),
    ):
        current = str(value or "").strip()
        if current and current.casefold() not in {
            item.casefold()
            for item in possible_names
        }:
            possible_names.append(current)

    placeholders = ",".join("?" for _ in possible_names)
    rows = conn.execute(
        f"""
        SELECT league_id, name, season
        FROM leagues
        WHERE LOWER(name) IN ({placeholders})
        ORDER BY league_id DESC
        """,
        tuple(value.lower() for value in possible_names),
    ).fetchall()

    if season:
        exact = [
            row
            for row in rows
            if str(row["season"] or "") == season
        ]

        if exact:
            rows = exact

    if not rows:
        raise RuntimeError(
            f"La competición '{name}' [{key}] "
            "no está registrada en SQLite."
        )

    return int(rows[0]["league_id"])



def finished_count(
    conn: sqlite3.Connection,
    league_id: int,
) -> int:
    row = conn.execute(
        """
        SELECT COUNT(*) AS total
        FROM matches
        WHERE league_id = ?
          AND status = 'FT'
        """,
        (league_id,),
    ).fetchone()

    return int(row["total"] if row else 0)



def event_quality(
    conn: sqlite3.Connection,
    league_id: int,
) -> dict[int, dict[str, Any]]:
    rows = conn.execute(
        """
        SELECT
            m.sofascore_id AS event_id,
            m.status AS status,
            m.kickoff AS kickoff,
            COUNT(s.stat_id) AS stat_rows,
            SUM(
                CASE
                    WHEN s.data_quality = 'FULL'
                     AND s.xg_for IS NOT NULL
                     AND s.shots IS NOT NULL
                     AND s.corners_for IS NOT NULL
                     AND s.yellow_cards IS NOT NULL
                    THEN 1 ELSE 0
                END
            ) AS settled_rows
        FROM matches AS m
        LEFT JOIN team_match_stats AS s
          ON s.match_id = m.match_id
        WHERE m.league_id = ?
          AND m.sofascore_id IS NOT NULL
        GROUP BY
            m.match_id,
            m.sofascore_id,
            m.status,
            m.kickoff
        """,
        (league_id,),
    ).fetchall()

    return {
        int(row["event_id"]): {
            "status": str(row["status"] or ""),
            "kickoff": row["kickoff"],
            "stat_rows": int(row["stat_rows"] or 0),
            "settled_rows": int(row["settled_rows"] or 0),
            # Alias conservado para repair_finished_history.py y módulos
            # anteriores que todavía usan el nombre full_rows.
            "full_rows": int(row["settled_rows"] or 0),
        }
        for row in rows
    }



def schedule_path(key: str) -> Path:
    return (
        COMPETITIONS_DIR
        / key
        / "matches_upcoming.json"
    )


def team_schedule_path(key: str) -> Path:
    return (
        COMPETITIONS_DIR
        / key
        / "next_match_by_team.json"
    )


def schedule_is_stale(path: Path) -> bool:
    # Bot 8.6 no dispara refrescos completos por liga.
    # La antigüedad se evalúa por equipo en calendar_maintenance_worker.py.
    return not path.exists()


def schedule_matches(key: str) -> list[dict[str, Any]]:
    document = read_json(schedule_path(key)) or {}
    rows = document.get("matches")

    if not isinstance(rows, list):
        return []

    result: list[dict[str, Any]] = []

    for row in rows:
        if isinstance(row, dict):
            result.append(dict(row))

    result.sort(
        key=lambda row: (
            int(row.get("start_timestamp") or 0),
            int(row.get("event_id") or 0),
        )
    )
    return result



def retry_interval_minutes(
    previous: dict[str, Any],
    *,
    kickoff: datetime | int | float | str | None = None,
    now: datetime | None = None,
) -> float:
    current = now or utc_now()
    kickoff_dt: datetime | None
    if isinstance(kickoff, datetime):
        kickoff_dt = kickoff
    elif isinstance(kickoff, (int, float)):
        kickoff_dt = datetime.fromtimestamp(float(kickoff), tz=timezone.utc)
    else:
        kickoff_dt = parse_datetime(kickoff)
    if kickoff_dt is not None:
        if kickoff_dt.tzinfo is None:
            kickoff_dt = kickoff_dt.replace(tzinfo=timezone.utc)
        minutes_to_kickoff = (kickoff_dt - current).total_seconds() / 60.0
        if minutes_to_kickoff >= 0:
            if minutes_to_kickoff > 24 * 60:
                return 180.0
            if minutes_to_kickoff > 6 * 60:
                return 60.0
            if minutes_to_kickoff > 2 * 60:
                return 20.0
            if minutes_to_kickoff > 30:
                return 10.0
            return 0.0

    result = str(previous.get("result") or "").strip().lower()
    count = max(1, int(previous.get("count") or 1))
    if result in {"partial", "source_unavailable"}:
        if result == "partial":
            return (
                PARTIAL_RETRY_FIRST_MINUTES
                if count <= 1
                else PARTIAL_RETRY_LATER_MINUTES
            )
        return (
            SOURCE_UNAVAILABLE_RETRY_FIRST_MINUTES
            if count <= 1
            else SOURCE_UNAVAILABLE_RETRY_LATER_MINUTES
        )
    if result in {"technical_error", "unknown"}:
        return TECHNICAL_RETRY_MINUTES
    return DUE_RETRY_MINUTES


def retry_allowed(
    row_state: dict[str, Any],
    event_id: int,
    *,
    kickoff: datetime | int | float | str | None = None,
) -> bool:
    attempts = row_state.setdefault(
        "due_attempts",
        {},
    )
    previous = attempts.get(str(event_id))

    if not isinstance(previous, dict):
        return True

    when = parse_datetime(
        previous.get("attempted_at")
    )

    if when is None:
        return True

    elapsed = (
        utc_now() - when
    ).total_seconds() / 60.0

    return elapsed >= retry_interval_minutes(
        previous,
        kickoff=kickoff,
    )




def next_competition_kickoff(
    key: str,
    *,
    now: datetime | None = None,
) -> int | None:
    """Devuelve el próximo kickoff que gobierna la urgencia de reintentos."""

    current = now or utc_now()
    current_timestamp = int(current.timestamp())
    future: list[int] = []
    for match in schedule_matches(key):
        try:
            kickoff = int(match.get("start_timestamp") or 0)
        except (TypeError, ValueError):
            continue
        if kickoff >= current_timestamp:
            future.append(kickoff)
    return min(future) if future else None


def competition_has_imminent_kickoff(
    key: str,
    *,
    within_minutes: int = 30,
    now: datetime | None = None,
) -> bool:
    current = now or utc_now()
    current_timestamp = int(current.timestamp())
    limit = current_timestamp + max(0, int(within_minutes)) * 60
    for match in schedule_matches(key):
        try:
            kickoff = int(match.get("start_timestamp") or 0)
        except (TypeError, ValueError):
            continue
        if current_timestamp <= kickoff <= limit:
            return True
    return False


def select_due_events(
    key: str,
    quality: dict[int, dict[str, Any]],
    row_state: dict[str, Any],
    *,
    ignore_retry: bool = False,
) -> tuple[list[int], dict[str, int]]:
    now = utc_now()
    cutoff = int(
        now.timestamp()
        - ASSUMED_MATCH_DURATION_MINUTES * 60
    )
    due: set[int] = set()
    urgency_kickoff = next_competition_kickoff(key, now=now)
    attempts = row_state.setdefault("due_attempts", {})
    report = {
        "historical_full_events_selected": 0,
        "new_finished_selected": 0,
        "partial_retry_selected": 0,
        "deferred_partials_skipped": 0,
        "unprocessed_selected": 0,
    }

    def may_retry(
        event_id: int,
        historical_kickoff: datetime | int | float | str | None = None,
    ) -> bool:
        _terminal_ids = row_state.get("terminal_event_ids", [])
        try:
            if int(event_id) in {int(value) for value in _terminal_ids}:
                return False
        except (TypeError, ValueError):
            pass
        _previous_terminal = attempts.get(str(event_id))
        if (
            isinstance(_previous_terminal, dict)
            and str(_previous_terminal.get("result") or "").strip().lower() == "terminal"
        ):
            return False

        retry_reference = (
            urgency_kickoff
            if urgency_kickoff is not None
            else historical_kickoff
        )
        return (
            ignore_retry
            or retry_allowed(
                row_state,
                event_id,
                kickoff=retry_reference,
            )
        )

    # Solo eventos del calendario cuyo kickoff ya venció. Los FULL nunca se
    # seleccionan y no se envía el catálogo histórico a tournament_season_sync.
    for match in schedule_matches(key):
        try:
            event_id = int(match["event_id"])
            kickoff = int(match["start_timestamp"])
        except (KeyError, TypeError, ValueError):
            continue

        if kickoff > cutoff:
            continue

        current = quality.get(event_id, {})
        status = str(current.get("status") or "").upper()
        settled = int(current.get("settled_rows") or 0) == 2
        if status == "CANCELED" or settled:
            continue

        previous = attempts.get(str(event_id))
        if not may_retry(event_id, kickoff):
            if status == "FT" and isinstance(previous, dict):
                report["deferred_partials_skipped"] += 1
            continue

        due.add(event_id)
        if status == "FT" and isinstance(previous, dict):
            report["partial_retry_selected"] += 1
        elif status == "FT":
            report["new_finished_selected"] += 1
        else:
            report["unprocessed_selected"] += 1

    # PARTIAL recientes que ya salieron del calendario. Incluso con --force se
    # conserva la ventana reciente: una comprobación manual no vuelve a mandar
    # todo el histórico.
    recent_limit = now - timedelta(days=RECENT_PARTIAL_LOOKBACK_DAYS)
    for event_id, current in quality.items():
        event_id = int(event_id)
        if event_id in due:
            continue
        status = str(current.get("status") or "").upper()
        settled = int(current.get("settled_rows") or 0) == 2
        kickoff = parse_datetime(current.get("kickoff"))
        if status != "FT" or settled or kickoff is None:
            continue
        if kickoff < recent_limit:
            continue
        previous = attempts.get(str(event_id))
        if may_retry(event_id, kickoff):
            due.add(event_id)
            if isinstance(previous, dict):
                report["partial_retry_selected"] += 1
            else:
                report["new_finished_selected"] += 1
        elif isinstance(previous, dict):
            report["deferred_partials_skipped"] += 1

    report["selected_total"] = len(due)
    return sorted(due), report


def due_event_ids(
    key: str,
    quality: dict[int, dict[str, Any]],
    row_state: dict[str, Any],
    *,
    ignore_retry: bool = False,
) -> list[int]:
    selected, _report = select_due_events(
        key,
        quality,
        row_state,
        ignore_retry=ignore_retry,
    )
    return selected



def record_due_attempt(
    row_state: dict[str, Any],
    event_ids: list[int],
    result: str,
) -> None:
    # ODDSHUNTER_TERMINAL_PERSISTENCE_V1_2: terminales persistentes, incluso con --force.
    _terminal_ids_raw = row_state.setdefault("terminal_event_ids", [])
    if not isinstance(_terminal_ids_raw, list):
        _terminal_ids_raw = []
        row_state["terminal_event_ids"] = _terminal_ids_raw
    if str(result or "").strip().lower() == "terminal":
        for _terminal_event_id in event_ids:
            try:
                _terminal_event_id = int(_terminal_event_id)
            except (TypeError, ValueError):
                continue
            if _terminal_event_id not in _terminal_ids_raw:
                _terminal_ids_raw.append(_terminal_event_id)
        _terminal_ids_raw.sort()

    attempts = row_state.setdefault(
        "due_attempts",
        {},
    )

    for event_id in event_ids:
        previous = attempts.get(str(event_id))
        previous_count = (
            int(previous.get("count") or 0)
            if isinstance(previous, dict)
            else 0
        )

        attempts[str(event_id)] = {
            "attempted_at": iso_now(),
            "result": str(result),
            "count": previous_count + 1,
        }

    if len(attempts) > 300:
        ordered = sorted(
            attempts.items(),
            key=lambda item: str(
                item[1].get("attempted_at") or ""
            ),
            reverse=True,
        )
        row_state["due_attempts"] = dict(
            ordered[:300]
        )



def selected_event_ids(key: str) -> list[int]:
    result: list[int] = []

    for match in schedule_matches(key):
        try:
            result.append(int(match["event_id"]))
        except (KeyError, TypeError, ValueError):
            continue

    return sorted(set(result))


def affected_selected_event_ids(
    key: str,
    affected_team_ids: set[int],
) -> list[int]:
    """Devuelve SOLO el próximo partido futuro de cada equipo afectado.

    Un resultado finalizado cambia el historial de sus dos equipos. Por eso
    cada equipo puede invalidar únicamente su siguiente predicción pendiente.
    No se recorren ni se reanalizan todos sus partidos futuros del calendario.

    Si ambos equipos afectados comparten el mismo próximo evento, el event_id
    se deduplica y se analiza una sola vez.
    """
    if not affected_team_ids:
        return []

    now_ts = int(utc_now().timestamp())
    next_by_team: dict[int, tuple[int, int]] = {}

    for match in schedule_matches(key):
        try:
            event_id = int(match["event_id"])
            home_id = int(match["home_team_id"])
            away_id = int(match["away_team_id"])
        except (KeyError, TypeError, ValueError):
            continue

        try:
            kickoff_ts = int(match.get("start_timestamp") or 0)
        except (TypeError, ValueError):
            kickoff_ts = 0

        if kickoff_ts <= 0:
            kickoff_dt = parse_datetime(match.get("kickoff"))
            kickoff_ts = int(kickoff_dt.timestamp()) if kickoff_dt else 0

        # Nunca genera una predicción nueva para un partido ya iniciado.
        if kickoff_ts <= now_ts:
            continue

        for team_id in (home_id, away_id):
            if team_id not in affected_team_ids:
                continue
            previous = next_by_team.get(team_id)
            candidate = (kickoff_ts, event_id)
            if previous is None or candidate < previous:
                next_by_team[team_id] = candidate

    ordered = sorted(
        set(next_by_team.values()),
        key=lambda item: (item[0], item[1]),
    )
    return [event_id for _kickoff, event_id in ordered]



def next_unique_event_ids(key: str) -> list[int]:
    """Un único próximo evento por equipo, deduplicado por event_id."""
    now_ts = int(utc_now().timestamp())
    next_by_team: dict[int, tuple[int, int]] = {}

    for match in schedule_matches(key):
        try:
            event_id = int(match["event_id"])
            home_id = int(match["home_team_id"])
            away_id = int(match["away_team_id"])
        except (KeyError, TypeError, ValueError):
            continue

        try:
            kickoff_ts = int(match.get("start_timestamp") or 0)
        except (TypeError, ValueError):
            kickoff_ts = 0

        if kickoff_ts <= 0:
            kickoff_dt = parse_datetime(match.get("kickoff"))
            kickoff_ts = int(kickoff_dt.timestamp()) if kickoff_dt else 0

        if kickoff_ts <= now_ts:
            continue

        candidate = (kickoff_ts, event_id)
        for team_id in (home_id, away_id):
            previous = next_by_team.get(team_id)
            if previous is None or candidate < previous:
                next_by_team[team_id] = candidate

    ordered = sorted(
        set(next_by_team.values()),
        key=lambda item: (item[0], item[1]),
    )
    return [event_id for _kickoff, event_id in ordered]


def pre_match_analysis_state(
    key: str,
    event_id: int,
) -> tuple[bool, bool, str]:
    """
    Retorna:
      ready       -> PREPARTIDO completo y aceptado.
      needs_force -> existe análisis previo pero está parcial/dañado.
      reason      -> diagnóstico corto.
    """
    event_dir = DATA_DIR / "analisis" / key / str(int(event_id))
    analysis_path = event_dir / "analysis.json"

    if not analysis_path.exists():
        return False, False, "ANALYSIS_MISSING"

    document = read_json(analysis_path)
    if not isinstance(document, dict):
        return False, True, "ANALYSIS_INVALID"

    missing = [
        name
        for name in PREMATCH_REQUIRED_FILES
        if not (event_dir / name).exists()
    ]
    if missing:
        return (
            False,
            True,
            "MISSING_COMPONENTS:" + ",".join(missing),
        )

    status = str(document.get("status") or "").upper()
    if status not in PREMATCH_ACCEPTED_STATUSES:
        return False, True, f"STATUS:{status or 'N_D'}"

    return True, False, "OK"


def _prematch_guard_retry_minutes(hours_to_kickoff: float) -> float:
    if hours_to_kickoff <= 6.0:
        return PREMATCH_GUARD_CRITICAL_RETRY_MINUTES
    if hours_to_kickoff <= 24.0:
        return PREMATCH_GUARD_URGENT_RETRY_MINUTES
    return PREMATCH_GUARD_RETRY_MINUTES


def pre_match_guard_candidates(
    key: str,
    row_state: dict[str, Any],
) -> tuple[list[int], set[int], list[dict[str, Any]]]:
    """
    Seguro ligero:
    - inspecciona solo el próximo evento de cada equipo;
    - no recalcula eventos ya FULL/PARTIAL_WITH_FALLBACK;
    - nunca toca eventos iniciados;
    - aplica backoff a errores parciales para no gastar cada 30 minutos.
    """
    now = utc_now()
    now_ts = int(now.timestamp())
    attempts = row_state.setdefault("prematch_guard_attempts", {})
    if not isinstance(attempts, dict):
        attempts = {}
        row_state["prematch_guard_attempts"] = attempts

    schedule_by_id: dict[int, dict[str, Any]] = {}
    for match in schedule_matches(key):
        try:
            schedule_by_id[int(match["event_id"])] = match
        except (KeyError, TypeError, ValueError):
            continue

    selected: list[int] = []
    force_ids: set[int] = set()
    details: list[dict[str, Any]] = []
    live_ids = set(next_unique_event_ids(key))

    # Elimina intentos de eventos que ya no son "el próximo".
    for stale in list(attempts):
        try:
            stale_id = int(stale)
        except (TypeError, ValueError):
            attempts.pop(stale, None)
            continue
        if stale_id not in live_ids:
            attempts.pop(stale, None)

    for event_id in sorted(live_ids):
        match = schedule_by_id.get(event_id) or {}
        try:
            kickoff_ts = int(match.get("start_timestamp") or 0)
        except (TypeError, ValueError):
            kickoff_ts = 0
        if kickoff_ts <= 0:
            kickoff_dt = parse_datetime(match.get("kickoff"))
            kickoff_ts = int(kickoff_dt.timestamp()) if kickoff_dt else 0

        if kickoff_ts <= now_ts:
            continue

        ready, needs_force, reason = pre_match_analysis_state(key, event_id)
        if ready:
            attempts.pop(str(event_id), None)
            continue

        hours_to_kickoff = max(0.0, (kickoff_ts - now_ts) / 3600.0)
        retry_minutes = _prematch_guard_retry_minutes(hours_to_kickoff)
        previous = attempts.get(str(event_id))
        last_attempt = (
            parse_datetime(previous.get("last_attempt_at"))
            if isinstance(previous, dict)
            else None
        )
        due = (
            last_attempt is None
            or (now - last_attempt).total_seconds() >= retry_minutes * 60.0
        )

        details.append(
            {
                "event_id": event_id,
                "reason": reason,
                "hours_to_kickoff": round(hours_to_kickoff, 2),
                "retry_minutes": retry_minutes,
                "due": due,
            }
        )

        if not due:
            continue

        selected.append(event_id)
        if needs_force:
            force_ids.add(event_id)

    return selected, force_ids, details


def record_prematch_guard_attempts(
    row_state: dict[str, Any],
    event_ids: list[int],
    reasons: dict[int, str],
) -> None:
    attempts = row_state.setdefault("prematch_guard_attempts", {})
    if not isinstance(attempts, dict):
        attempts = {}
        row_state["prematch_guard_attempts"] = attempts

    for event_id in event_ids:
        key = str(int(event_id))
        previous = attempts.get(key)
        count = (
            int(previous.get("attempts") or 0)
            if isinstance(previous, dict)
            else 0
        )
        attempts[key] = {
            "last_attempt_at": iso_now(),
            "attempts": count + 1,
            "last_reason": reasons.get(int(event_id)),
        }


def clear_repaired_prematch_attempts(
    competition_key: str,
    row_state: dict[str, Any],
    event_ids: list[int],
) -> list[int]:
    attempts = row_state.setdefault("prematch_guard_attempts", {})
    repaired: list[int] = []
    for event_id in event_ids:
        ready, _force, _reason = pre_match_analysis_state(
            competition_key,
            event_id,
        )
        if ready:
            attempts.pop(str(int(event_id)), None)
            repaired.append(int(event_id))
    return repaired


def missing_analysis_event_ids(key: str) -> list[int]:
    result: list[int] = []

    for event_id in selected_event_ids(key):
        path = (
            DATA_DIR
            / "analisis"
            / key
            / str(event_id)
            / "analysis.json"
        )

        if not path.exists():
            result.append(event_id)

    return result


def file_digest(path: Path) -> str | None:
    if not path.exists():
        return None

    digest = hashlib.sha256()

    with path.open("rb") as file:
        for chunk in iter(
            lambda: file.read(1024 * 1024),
            b"",
        ):
            digest.update(chunk)

    return digest.hexdigest()


def candidate_path(key: str) -> Path:
    return (
        TRAINED_MODELS_DIR
        / key
        / "last_candidate.json"
    )


def latest_model_path(key: str) -> Path:
    return (
        TRAINED_MODELS_DIR
        / key
        / "latest_model.json"
    )


def training_baseline(
    key: str,
    training_state: dict[str, Any],
) -> tuple[int, datetime | None]:
    completed_count = int(
        training_state.get(
            "finished_at_last_completed",
            0,
        )
        or 0
    )
    completed_at = parse_datetime(
        training_state.get(
            "last_completed_at"
        )
    )

    if completed_count > 0 or completed_at is not None:
        return completed_count, completed_at

    document = (
        read_json(candidate_path(key))
        or read_json(latest_model_path(key))
    )

    if not document:
        return 0, None

    data = (
        document.get("data")
        if isinstance(document.get("data"), dict)
        else {}
    )

    return (
        int(data.get("finished_matches") or 0),
        parse_datetime(
            document.get("generated_at")
        ),
    )


def training_retry_available(
    training_state: dict[str, Any],
) -> tuple[bool, str | None]:
    next_retry = parse_datetime(
        training_state.get("next_retry_at")
    )

    if next_retry is None:
        return True, None

    if utc_now() >= next_retry:
        return True, None

    return (
        False,
        "Próximo reintento técnico: "
        + next_retry.astimezone().strftime(
            "%Y-%m-%d %H:%M"
        ),
    )


def should_train(
    key: str,
    current_finished: int,
    training_state: dict[str, Any],
) -> tuple[bool, str]:
    retry_ok, retry_reason = training_retry_available(
        training_state
    )

    if not retry_ok:
        return False, retry_reason or "Reintento pendiente."

    previous_count, previous_time = training_baseline(
        key,
        training_state,
    )
    new_matches = max(
        0,
        current_finished - previous_count,
    )

    if previous_time is None:
        return (
            True,
            "No existe entrenamiento completado; se intentará una vez.",
        )

    age_days = (
        utc_now() - previous_time
    ).total_seconds() / 86400.0

    if new_matches >= MIN_NEW_MATCHES_FOR_TRAINING:
        return (
            True,
            f"Se acumularon {new_matches} partidos nuevos.",
        )

    if (
        new_matches > 0
        and age_days >= MAX_DAYS_WITH_NEW_DATA
    ):
        return (
            True,
            f"Hay {new_matches} partidos nuevos y pasaron "
            f"{age_days:.1f} días desde el último entrenamiento completado.",
        )

    if new_matches == 0:
        return (
            False,
            "Sin partidos nuevos para reentrenar.",
        )

    return (
        False,
        f"Hay {new_matches} partidos nuevos; se esperan "
        f"{MIN_NEW_MATCHES_FOR_TRAINING} o "
        f"{MAX_DAYS_WITH_NEW_DATA:.0f} días.",
    )


def mark_training_started(
    training_state: dict[str, Any],
    current_finished: int,
) -> datetime:
    started = utc_now()
    training_state["in_progress"] = True
    training_state["started_at"] = started.isoformat()
    training_state["finished_at_start"] = current_finished
    return started


def mark_training_completed(
    training_state: dict[str, Any],
    current_finished: int,
    candidate: dict[str, Any],
) -> None:
    promotion = (
        candidate.get("promotion")
        if isinstance(
            candidate.get("promotion"),
            dict,
        )
        else {}
    )

    training_state.update(
        {
            "in_progress": False,
            "last_completed_at": iso_now(),
            "finished_at_last_completed": current_finished,
            "last_result": (
                "promoted"
                if promotion.get("promoted")
                else "rejected"
            ),
            "last_candidate_version": candidate.get(
                "version"
            ),
            "last_error": None,
            "consecutive_failures": 0,
            "next_retry_at": None,
        }
    )


def mark_training_failed(
    training_state: dict[str, Any],
    error: str,
) -> None:
    failures = int(
        training_state.get(
            "consecutive_failures",
            0,
        )
        or 0
    ) + 1
    delay_index = min(
        failures - 1,
        len(TRAIN_RETRY_HOURS) - 1,
    )
    delay_hours = TRAIN_RETRY_HOURS[delay_index]
    next_retry = utc_now() + timedelta(
        hours=delay_hours
    )

    training_state.update(
        {
            "in_progress": False,
            "last_failed_at": iso_now(),
            "last_error": error,
            "consecutive_failures": failures,
            "next_retry_at": next_retry.isoformat(),
        }
    )


def _windows_process_name_from_snapshot(pid: int) -> str | None:
    """Lee el ejecutable sin abrir el proceso (sirve con procesos elevados)."""

    import ctypes
    from ctypes import wintypes

    class ProcessEntry32W(ctypes.Structure):
        _fields_ = (
            ("dwSize", wintypes.DWORD),
            ("cntUsage", wintypes.DWORD),
            ("th32ProcessID", wintypes.DWORD),
            ("th32DefaultHeapID", ctypes.c_size_t),
            ("th32ModuleID", wintypes.DWORD),
            ("cntThreads", wintypes.DWORD),
            ("th32ParentProcessID", wintypes.DWORD),
            ("pcPriClassBase", wintypes.LONG),
            ("dwFlags", wintypes.DWORD),
            ("szExeFile", wintypes.WCHAR * 260),
        )

    snapshot = ctypes.windll.kernel32.CreateToolhelp32Snapshot(0x00000002, 0)
    if snapshot in (0, ctypes.c_void_p(-1).value):
        return None
    try:
        entry = ProcessEntry32W()
        entry.dwSize = ctypes.sizeof(entry)
        has_entry = ctypes.windll.kernel32.Process32FirstW(
            snapshot,
            ctypes.byref(entry),
        )
        while has_entry:
            if int(entry.th32ProcessID) == int(pid):
                return str(entry.szExeFile) or None
            has_entry = ctypes.windll.kernel32.Process32NextW(
                snapshot,
                ctypes.byref(entry),
            )
    finally:
        ctypes.windll.kernel32.CloseHandle(snapshot)
    return None


def _windows_process_identity(
    pid: int,
) -> tuple[bool, str | None, datetime | None]:
    """Obtiene ejecutable y hora real de inicio de un PID de Windows."""

    import ctypes
    from ctypes import wintypes

    process_query_limited_information = 0x1000
    handle = ctypes.windll.kernel32.OpenProcess(
        process_query_limited_information,
        False,
        int(pid),
    )
    if not handle:
        # ERROR_ACCESS_DENIED confirma que el proceso existe, aunque Windows
        # no permita abrirlo. Toolhelp todavía permite conocer su ejecutable.
        last_error = int(ctypes.windll.kernel32.GetLastError())
        process_name = _windows_process_name_from_snapshot(pid)
        return (
            last_error == 5 or process_name is not None,
            process_name,
            None,
        )

    class FileTime(ctypes.Structure):
        _fields_ = (
            ("dwLowDateTime", wintypes.DWORD),
            ("dwHighDateTime", wintypes.DWORD),
        )

    try:
        capacity = wintypes.DWORD(32768)
        buffer = ctypes.create_unicode_buffer(capacity.value)
        executable: str | None = None
        if ctypes.windll.kernel32.QueryFullProcessImageNameW(
            handle,
            0,
            buffer,
            ctypes.byref(capacity),
        ):
            executable = buffer.value or None

        created = FileTime()
        exited = FileTime()
        kernel = FileTime()
        user = FileTime()
        created_at: datetime | None = None
        if ctypes.windll.kernel32.GetProcessTimes(
            handle,
            ctypes.byref(created),
            ctypes.byref(exited),
            ctypes.byref(kernel),
            ctypes.byref(user),
        ):
            ticks = (
                int(created.dwHighDateTime) << 32
            ) | int(created.dwLowDateTime)
            unix_seconds = (
                ticks - 116444736000000000
            ) / 10_000_000
            created_at = datetime.fromtimestamp(
                unix_seconds,
                timezone.utc,
            )
        return True, executable, created_at
    finally:
        ctypes.windll.kernel32.CloseHandle(handle)


def process_is_running(
    pid: int | None,
    lock_started_at: str | None = None,
) -> bool:
    """Comprueba que el PID siga siendo el proceso Python del bloqueo."""

    if pid is None or pid <= 0:
        return False
    if pid == os.getpid():
        return True

    if os.name == "nt":
        exists, executable, created_at = _windows_process_identity(int(pid))
        if not exists:
            return False

        # Windows puede reutilizar un PID. El bloqueo solo es válido si aún
        # pertenece a Python, nunca a Code.exe, Brave u otra aplicación.
        if executable:
            process_name = Path(executable).name.lower()
            if process_name not in {"python.exe", "pythonw.exe"}:
                return False

        lock_started = parse_datetime(lock_started_at)
        if created_at is not None and lock_started is not None:
            # El propietario debe haber arrancado antes de crear el bloqueo.
            if created_at > lock_started + timedelta(seconds=5):
                return False
        return True

    try:
        os.kill(int(pid), 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def read_lock_owner(path: Path) -> tuple[int | None, str | None]:
    try:
        document = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None, None
    if not isinstance(document, dict):
        return None, None
    try:
        pid = int(document.get("pid"))
    except (TypeError, ValueError):
        pid = None
    started_at = str(document.get("started_at") or "").strip() or None
    return pid, started_at


def acquire_lock() -> Path:
    path = (
        AUTOMATION_DIR
        / "global_team_workflow.lock"
    )

    payload = json.dumps(
        {
            "started_at": iso_now(),
            "pid": os.getpid(),
        },
        indent=2,
    ).encode("utf-8")

    # O_EXCL evita que dos procesos que arrancan al mismo tiempo creen
    # simultáneamente el mismo bloqueo.
    for _attempt in range(2):
        try:
            descriptor = os.open(
                path,
                os.O_CREAT | os.O_EXCL | os.O_WRONLY,
            )
        except FileExistsError:
            owner_pid, started_at = read_lock_owner(path)
            if process_is_running(owner_pid, started_at):
                raise AutomationAlreadyRunning(owner_pid, started_at)

            # El proceso ya no existe: el bloqueo quedó huérfano por un cierre
            # de Windows, app o terminal. Se recupera de inmediato.
            print(
                "♻ Bloqueo obsoleto recuperado: "
                f"PID {owner_pid or 'desconocido'} ya no pertenece "
                "a esta automatización."
            )
            path.unlink(missing_ok=True)
            continue

        with os.fdopen(descriptor, "wb") as lock_file:
            lock_file.write(payload)
            lock_file.flush()
            os.fsync(lock_file.fileno())
        return path

    raise RuntimeError(
        "No se pudo crear un bloqueo exclusivo para la automatización."
    )


def run_step(
    title: str,
    script: str,
    arguments: list[str],
    log_file: Any,
    timeout_seconds: int | None = None,
) -> None:
    script_path = BASE_DIR / script

    if not script_path.exists():
        raise FileNotFoundError(script_path)

    command = [
        sys.executable,
        "-u",
        str(script_path),
        *arguments,
    ]

    header = (
        "\n"
        + "=" * 86
        + f"\n▶ {title}\n"
        + f"$ {' '.join(command)}\n"
        + "=" * 86
        + "\n"
    )
    print(header, end="")
    log_file.write(header)
    log_file.flush()

    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"

    process = subprocess.Popen(
        command,
        cwd=BASE_DIR,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        bufsize=1,
    )

    assert process.stdout is not None

    output_queue: queue.Queue[str | None] = queue.Queue()

    def reader() -> None:
        try:
            for line in process.stdout:
                output_queue.put(line)
        finally:
            output_queue.put(None)

    thread = threading.Thread(
        target=reader,
        daemon=True,
    )
    thread.start()

    started = time.monotonic()
    stream_closed = False

    while True:
        try:
            item = output_queue.get(timeout=0.25)
        except queue.Empty:
            item = ""

        if item is None:
            stream_closed = True
        elif item:
            print(item, end="")
            log_file.write(item)
            log_file.flush()

        code = process.poll()

        if code is not None and stream_closed:
            break

        if (
            timeout_seconds is not None
            and time.monotonic() - started > timeout_seconds
        ):
            process.kill()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                pass
            raise TimeoutError(
                f"{title} excedió {timeout_seconds // 60} minutos."
            )

    if int(code or 0) != 0:
        raise RuntimeError(
            f"{title} terminó con código {code}."
        )


def run_script(
    title: str,
    script: str,
    arguments: list[str],
    log_file: Any,
) -> None:
    run_step(
        title,
        script,
        arguments,
        log_file,
        timeout_seconds=STEP_TIMEOUTS_SECONDS.get(
            script
        ),
    )


# =============================================================================
# ODDSHUNTER_ANALYSIS_EXIT_PROPAGATION_V2
#
# analyze_upcoming_matches.py puede terminar código 0 aunque alguno de los
# eventos quede PARTIAL_MODULE_ERROR o ERROR.
#
# Después de ejecutar el analizador, este wrapper comprueba index.json.
# Si algún event_id solicitado no queda FULL:
#
#     => SystemExit(2)
#
# SystemExit NO es capturado por los bloques "except Exception" del workflow,
# por lo que el error se propaga al proceso global y ya no puede terminar OK.
# =============================================================================

_OH_RUN_SCRIPT_BEFORE_ANALYSIS_EXIT_V2 = run_script


def _oh_analysis_arguments_v2(arguments):
    _args = [
        str(_x)
        for _x in (
            arguments
            or []
        )
    ]

    _key = None
    _event_ids = []

    _i = 0

    while _i < len(_args):

        _item = _args[_i]

        if (
            _item == "--key"
            and _i + 1 < len(_args)
        ):
            _key = str(
                _args[_i + 1]
            ).strip()

            _i += 2
            continue

        if (
            _item == "--event-id"
            and _i + 1 < len(_args)
        ):
            try:
                _event_ids.append(
                    int(
                        _args[_i + 1]
                    )
                )
            except Exception:
                pass

            _i += 2
            continue

        _i += 1

    return (
        _key,
        sorted(
            set(
                _event_ids
            )
        ),
    )


def _oh_analysis_health_v2(
    script,
    arguments,
    index_path=None,
):
    import json as _json
    from pathlib import Path as _Path

    _script_name = (
        _Path(
            str(
                script
                or ""
            )
        ).name.lower()
    )

    if (
        _script_name
        != "analyze_upcoming_matches.py"
    ):
        return {
            "checked": False,
            "reason": "NOT_ANALYZER",
            "bad": [],
        }

    _key, _event_ids = (
        _oh_analysis_arguments_v2(
            arguments
        )
    )

    if not _key or not _event_ids:
        return {
            "checked": False,
            "reason": "NO_EVENTS",
            "bad": [],
        }

    if index_path is None:
        _index = (
            _Path(__file__).resolve().parent
            / "data"
            / "analisis"
            / str(_key)
            / "index.json"
        )
    else:
        _index = _Path(
            index_path
        )

    if not _index.exists():
        return {
            "checked": True,
            "key": _key,
            "requested": len(
                _event_ids
            ),
            "full": 0,
            "bad": [
                {
                    "event_id": _event_id,
                    "status": "INDEX_MISSING",
                }
                for _event_id in _event_ids
            ],
            "index": str(
                _index
            ),
        }

    try:
        _doc = _json.loads(
            _index.read_text(
                encoding="utf-8-sig"
            )
        )
    except Exception as _exc:
        return {
            "checked": True,
            "key": _key,
            "requested": len(
                _event_ids
            ),
            "full": 0,
            "bad": [
                {
                    "event_id": _event_id,
                    "status": "INDEX_INVALID",
                    "error": str(
                        _exc
                    ),
                }
                for _event_id in _event_ids
            ],
            "index": str(
                _index
            ),
        }

    _rows = (
        _doc.get(
            "matches"
        )
        or _doc.get(
            "results"
        )
        or []
    )

    _by_id = {}

    for _row in _rows:

        if not isinstance(
            _row,
            dict,
        ):
            continue

        try:
            _event_id = int(
                _row.get(
                    "event_id"
                )
            )
        except Exception:
            continue

        _by_id[
            _event_id
        ] = _row

    _bad = []
    _full = 0
    _fallback = 0
    _accepted = 0

    for _event_id in _event_ids:

        _row = _by_id.get(
            _event_id
        )

        if _row is None:

            _bad.append(
                {
                    "event_id": _event_id,
                    "status": "MISSING",
                }
            )

            continue

        _status = str(
            _row.get(
                "analysis_status"
            )
            or _row.get(
                "status"
            )
            or ""
        ).strip().upper()

        if _status == "FULL":

            _full += 1

            _accepted += 1

        elif _status == "PARTIAL_WITH_FALLBACK":

            _fallback += 1

            _accepted += 1

        else:

            _bad.append(
                {
                    "event_id": _event_id,
                    "status": (
                        _status
                        or "UNKNOWN"
                    ),
                }
            )

    return {
        "checked": True,
        "key": _key,
        "requested": len(
            _event_ids
        ),
        "full": _full,
        "fallback": _fallback,
        "accepted": _accepted,
        "bad": _bad,
        "index": str(
            _index
        ),
    }


def _oh_enforce_analysis_health_v2(
    script,
    arguments,
    index_path=None,
):
    _health = (
        _oh_analysis_health_v2(
            script,
            arguments,
            index_path=index_path,
        )
    )

    if not _health.get(
        "checked"
    ):
        return _health

    _bad = list(
        _health.get(
            "bad"
        )
        or []
    )

    if _bad:

        _parts = [
            (
                f"{_row.get('event_id')}="
                f"{_row.get('status')}"
            )
            for _row in _bad
        ]

        _message = (
            "ANALYSIS_HEALTH_ERROR: "
            + ", ".join(
                _parts
            )
        )

        print(
            _message
        )

        raise SystemExit(2)

    print(
        "[ANALYSIS_HEALTH_PASS] "
        f"key={_health.get('key')} "
        f"accepted={_health.get('accepted')}/"
        f"{_health.get('requested')} "
        f"FULL={_health.get('full')} "
        f"fallback={_health.get('fallback')}"
    )

    return _health


def run_script(
    title,
    script,
    arguments,
    log_file,
):
    _result = (
        _OH_RUN_SCRIPT_BEFORE_ANALYSIS_EXIT_V2(
            title,
            script,
            arguments,
            log_file,
        )
    )

    _oh_enforce_analysis_health_v2(
        script,
        arguments,
    )

    return _result


# =============================================================================
# FIN ODDSHUNTER_ANALYSIS_EXIT_PROPAGATION_V2
# =============================================================================




def run_calendar_maintenance(
    max_teams: int,
    log_file: Any,
    force: bool = False,
) -> dict[str, Any]:
    # Incluso con presupuesto de cero equipos se ejecuta el trabajador:
    # todavía puede arrancar una liga vacía con una sola consulta de torneo.
    max_teams = max(0, int(max_teams))
    arguments = [
        "--max-teams",
        str(max_teams),
        "--max-seconds",
        str(CALENDAR_MAINTENANCE_MAX_SECONDS),
    ]
    if force:
        arguments.append("--force")
    run_script(
        "Mantenimiento global limitado de calendarios",
        "calendar_maintenance_worker.py",
        arguments,
        log_file,
    )
    return read_json(
        AUTOMATION_DIR / "calendar_maintenance_last.json"
    ) or {}



def refresh_schedule_teams(
    key: str,
    name: str,
    team_ids: set[int],
    log_file: Any,
) -> None:
    if not team_ids:
        return

    arguments = [
        "--key",
        key,
        "--per-team",
        "3",
        "--merge",
    ]

    for team_id in sorted(team_ids):
        arguments.extend(
            ["--team-id", str(team_id)]
        )

    run_script(
        f"{name}: refrescar solo equipos afectados",
        "sync_upcoming_matches.py",
        arguments,
        log_file,
    )


def run_incremental_result_check(
    key: str,
    name: str,
    event_ids: list[int],
    log_file: Any,
) -> dict[str, Any]:
    arguments = ["--key", key]

    for event_id in event_ids:
        arguments.extend(
            ["--event-id", str(event_id)]
        )

    run_script(
        f"{name}: comprobar únicamente eventos vencidos",
        "incremental_result_sync.py",
        arguments,
        log_file,
    )

    report_path = (
        INCREMENTAL_REPORT_DIR
        / f"{key}_last.json"
    )
    report = read_json(report_path)

    if report is None:
        raise RuntimeError(
            f"No se generó el reporte incremental: {report_path}"
        )

    return report


def training_sample_eligibility(key: str) -> dict[str, Any]:
    try:
        import train_models_core as training_core

        registry = training_core.load_registry()
        competition = training_core.find_competition(registry, key)
        training_connection = training_core.get_connection()
        try:
            league = training_core.resolve_league(
                training_connection,
                competition,
            )
            rows, context_rows = training_core.load_training_rows(
                connection=training_connection,
                registry=registry,
                competition=competition,
                league=league,
            )
        finally:
            training_connection.close()
        available = len(
            training_core.build_training_samples(
                target_rows=rows,
                context_rows=context_rows,
                competition=competition,
            )
        )
        return {
            "eligible": available >= REQUIRED_WALK_FORWARD_SAMPLES,
            "available_walk_forward_samples": available,
            "required_walk_forward_samples": REQUIRED_WALK_FORWARD_SAMPLES,
            "error": None,
        }
    except Exception as exc:
        return {
            "eligible": False,
            "available_walk_forward_samples": None,
            "required_walk_forward_samples": REQUIRED_WALK_FORWARD_SAMPLES,
            "error": f"{type(exc).__name__}: {exc}",
        }


def training_eligibility_decision(
    available: int | None,
    required: int = REQUIRED_WALK_FORWARD_SAMPLES,
) -> tuple[bool, str]:
    if available is None:
        return False, "TRAINING_SKIPPED_ELIGIBILITY_CHECK_FAILED"
    if int(available) < int(required):
        return False, "TRAINING_SKIPPED_INSUFFICIENT_SAMPLE"
    return True, "TRAINING_ELIGIBLE"


def run_training(
    key: str,
    name: str,
    current_finished: int,
    row_state: dict[str, Any],
    state: dict[str, Any],
    log_file: Any,
) -> tuple[bool, bool, str]:
    training_state = row_state.setdefault(
        "training",
        {},
    )

    eligibility = training_sample_eligibility(key)
    eligible, eligibility_code = training_eligibility_decision(
        eligibility.get("available_walk_forward_samples"),
        eligibility.get("required_walk_forward_samples")
        or REQUIRED_WALK_FORWARD_SAMPLES,
    )
    if not eligible:
        retry_at = utc_now() + timedelta(
            hours=TRAINING_INSUFFICIENT_RETRY_HOURS
        )
        training_state.update(
            {
                "in_progress": False,
                "last_result": eligibility_code,
                "last_skipped_at": iso_now(),
                "available_walk_forward_samples": eligibility.get(
                    "available_walk_forward_samples"
                ),
                "required_walk_forward_samples": eligibility.get(
                    "required_walk_forward_samples"
                ),
                "eligibility_error": eligibility.get("error"),
                "next_retry_at": retry_at.isoformat(),
                "last_error": None,
                "consecutive_failures": 0,
            }
        )
        save_state(state)
        message = (
            f"{eligibility_code} | "
            f"required_walk_forward_samples="
            f"{eligibility.get('required_walk_forward_samples')} | "
            f"available_walk_forward_samples="
            f"{eligibility.get('available_walk_forward_samples')} | "
            "MODEL_FALLBACK_USED | code=0"
        )
        print(message)
        log_file.write(message + "\n")
        log_file.flush()
        return False, False, message

    before_candidate_digest = file_digest(
        candidate_path(key)
    )
    before_latest_digest = file_digest(
        latest_model_path(key)
    )

    mark_training_started(
        training_state,
        current_finished,
    )
    save_state(state)

    try:
        run_script(
            f"{name}: entrenar candidato y validar",
            "train_models.py",
            ["--key", key],
            log_file,
        )

        after_candidate_digest = file_digest(
            candidate_path(key)
        )
        candidate = read_json(
            candidate_path(key)
        )

        if (
            candidate is None
            or after_candidate_digest is None
            or after_candidate_digest
            == before_candidate_digest
        ):
            raise RuntimeError(
                "El proceso terminó, pero no generó un candidato nuevo."
            )

        data = (
            candidate.get("data")
            if isinstance(
                candidate.get("data"),
                dict,
            )
            else {}
        )

        trained_finished = int(
            data.get("finished_matches") or 0
        )

        if trained_finished <= 0:
            raise RuntimeError(
                "El candidato no informa partidos finalizados."
            )

        mark_training_completed(
            training_state,
            trained_finished,
            candidate,
        )
        save_state(state)

        after_latest_digest = file_digest(
            latest_model_path(key)
        )
        promoted = (
            after_latest_digest is not None
            and after_latest_digest
            != before_latest_digest
        )

        result = (
            "promoted"
            if promoted
            else "rejected"
        )
        return True, promoted, result

    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
        mark_training_failed(
            training_state,
            error,
        )
        save_state(state)
        return False, False, error



def bot9_season_sync_arguments(
    key: str,
    *,
    import_finished: bool = False,
) -> list[str]:
    arguments = ["--key", key]
    if not import_finished:
        # Refresca identidad, temporada y calendario. Los finalizados exactos
        # se seleccionan después con select_due_events().
        return arguments

    # Inicialización excepcional de una liga todavía ausente: micro-lote
    # acotado, nunca el catálogo histórico completo.
    arguments.extend(
        [
            "--import-finished",
            "--resume",
            "--micro-batch-size",
            "1",
            "--max-events",
            "3",
            "--max-seconds",
            "540",
        ]
    )
    previous_report = (
        AUTOMATION_DIR
        / "bot9_tournaments"
        / f"{key}_last.json"
    )
    if previous_report.exists():
        arguments.append("--resume-existing-catalog")
    if key == "uefa-conference-league" and previous_report.exists():
        arguments.extend(
            [
                "--prioritize-event-id",
                "16351139",
            ]
        )
    return arguments


def process_competition(
    competition: dict[str, Any],
    state: dict[str, Any],
    args: argparse.Namespace,
    log_file: Any,
) -> dict[str, Any]:
    key = slugify(str(competition["key"]))
    name = str(
        competition.get("name") or key
    )
    row_state = competition_state(
        state,
        key,
    )
    warnings: list[str] = []

    print("\n" + "#" * 86)
    print(f"# {name} [{key}]")
    print("#" * 86)

    if bool(competition.get("bot9_managed")):
        last_bot9_sync = parse_datetime(
            row_state.get("last_bot9_season_sync_at")
        )
        sync_age_hours = (
            float("inf")
            if last_bot9_sync is None
            else (
                utc_now() - last_bot9_sync
            ).total_seconds() / 3600.0
        )
        must_sync_season = (
            not schedule_path(key).exists()
            or sync_age_hours >= BOT9_SEASON_REFRESH_HOURS
        )
        if must_sync_season:
            season_timeout = (
                10 * 60
                if key in {
                    "uefa-conference-league",
                    "uefa-champions-league",
                }
                else STEP_TIMEOUTS_SECONDS["tournament_season_sync.py"]
            )
            run_step(
                f"{name}: confirmar temporada BOT 9",
                "tournament_season_sync.py",
                bot9_season_sync_arguments(key, import_finished=False),
                log_file,
                timeout_seconds=season_timeout,
            )
            row_state["last_bot9_season_sync_at"] = iso_now()
            save_state(state)
            refreshed = reload_competition(key)
            competition.clear()
            competition.update(refreshed)

    try:
        with connection() as conn:
            league_id = resolve_league_id(
                conn,
                competition,
            )
    except RuntimeError:
        if not bool(competition.get("bot9_managed")):
            raise
        # Una competición nueva todavía no tiene fila en SQLite. Se obtiene el
        # calendario completo de su temporada vigente y se importa la unión de
        # los últimos 15 partidos por equipo, siempre dentro del mismo torneo.
        season_timeout = (
            10 * 60
            if key in {
                "uefa-conference-league",
                "uefa-champions-league",
            }
            else STEP_TIMEOUTS_SECONDS["tournament_season_sync.py"]
        )
        run_step(
            f"{name}: inicializar temporada BOT 9",
            "tournament_season_sync.py",
            bot9_season_sync_arguments(key, import_finished=True),
            log_file,
            timeout_seconds=season_timeout,
        )
        refreshed = reload_competition(key)
        competition.clear()
        competition.update(refreshed)
        with connection() as conn:
            league_id = resolve_league_id(
                conn,
                competition,
            )

    with connection() as conn:
        before_count = finished_count(
            conn,
            league_id,
        )

    schedule_refreshed_full = False

    all_affected_team_ids: set[int] = set()
    all_finished_event_ids: set[int] = set()
    all_refresh_team_ids: set[int] = set()
    incremental_waves = 0
    result_checks = 0
    selection_totals = {
        "historical_full_events_selected": 0,
        "new_finished_selected": 0,
        "partial_retry_selected": 0,
        "deferred_partials_skipped": 0,
        "unprocessed_selected": 0,
        "selected_total": 0,
    }

    if not args.analyze_only:
        for wave in range(
            1,
            MAX_INCREMENTAL_WAVES + 1,
        ):
            with connection() as conn:
                quality = event_quality(
                    conn,
                    league_id,
                )

            urgent_finalization = bool(
                wave == 1
                and competition_has_imminent_kickoff(
                    key,
                    within_minutes=30,
                )
            )
            due, selection_report = select_due_events(
                key,
                quality,
                row_state,
                # Solo ignora el reloj de retry para PARTIAL recientes; nunca
                # amplía la selección a todo el histórico.
                ignore_retry=bool(
                    (args.force and wave == 1)
                    or urgent_finalization
                ),
            )
            for metric_name in selection_totals:
                selection_totals[metric_name] += int(
                    selection_report.get(metric_name) or 0
                )
            selection_line = (
                "SELECCIÓN SELECTIVA | "
                f"historical_full_events_selected="
                f"{selection_report['historical_full_events_selected']} | "
                f"new_finished_selected="
                f"{selection_report['new_finished_selected']} | "
                f"partial_retry_selected="
                f"{selection_report['partial_retry_selected']} | "
                f"deferred_partials_skipped="
                f"{selection_report['deferred_partials_skipped']}"
            )
            print(selection_line)
            log_file.write(selection_line + "\n")
            log_file.flush()
            if urgent_finalization:
                urgent_message = (
                    f"{name}: finalización urgente pre-kickoff activada."
                )
                print(urgent_message)
                log_file.write(urgent_message + "\n")
                log_file.flush()

            if not due:
                break

            incremental_waves = wave
            result_checks += 1

            try:
                report = run_incremental_result_check(
                    key,
                    name,
                    due,
                    log_file,
                )
            except Exception as exc:
                record_due_attempt(
                    row_state,
                    due,
                    "technical_error",
                )
                save_state(state)
                warnings.append(
                    "Resultados incrementales: "
                    f"{type(exc).__name__}: {exc}"
                )
                break

            finished_ids = {
                int(value)
                for value in report.get(
                    "finished_event_ids",
                    [],
                )
            }
            affected_ids = {
                int(value)
                for value in report.get(
                    "affected_team_ids",
                    [],
                )
            }
            refresh_ids = {
                int(value)
                for value in report.get(
                    "refresh_team_ids",
                    [],
                )
            }
            errors = report.get("errors")

            all_finished_event_ids.update(
                finished_ids
            )
            all_affected_team_ids.update(
                affected_ids
            )
            all_refresh_team_ids.update(
                refresh_ids
            )

            event_results = report.get("event_results")
            accounted: set[int] = set()

            if isinstance(event_results, list):
                for item in event_results:
                    if not isinstance(item, dict):
                        continue

                    try:
                        item_event_id = int(
                            item["event_id"]
                        )
                    except (
                        KeyError,
                        TypeError,
                        ValueError,
                    ):
                        continue

                    result_name = str(
                        item.get("result")
                        or "technical_error"
                    )
                    record_due_attempt(
                        row_state,
                        [item_event_id],
                        result_name,
                    )
                    accounted.add(item_event_id)

            for missing_event_id in set(due) - accounted:
                record_due_attempt(
                    row_state,
                    [missing_event_id],
                    "technical_error",
                )

            save_state(state)

            if isinstance(errors, list) and errors:
                warnings.append(
                    f"{len(errors)} evento(s) con error incremental."
                )

            if refresh_ids:
                try:
                    refresh_schedule_teams(
                        key,
                        name,
                        refresh_ids,
                        log_file,
                    )
                    row_state[
                        "last_incremental_schedule_refresh_at"
                    ] = iso_now()
                    save_state(state)
                except Exception as exc:
                    warnings.append(
                        "Calendario de equipos afectados: "
                        f"{type(exc).__name__}: {exc}"
                    )
                    break

            # Sin un finalizado o cambio terminal no hay una cadena nueva
            # que descubrir en esta misma ejecución.
            if not refresh_ids:
                break

        if all_affected_team_ids:
            try:
                run_script(
                    f"{name}: actualizar ELO pendiente",
                    "sync_elo.py",
                    ["--key", key],
                    log_file,
                )
            except Exception as exc:
                warnings.append(
                    f"ELO: {type(exc).__name__}: {exc}"
                )

    with connection() as conn:
        after_count = finished_count(
            conn,
            league_id,
        )

    new_finished = max(
        0,
        after_count - before_count,
    )

    training_executed = False
    model_promoted = False
    training_result = "not_run"
    training_reason = "No evaluado."

    if not args.analyze_only:
        training_state = row_state.setdefault(
            "training",
            {},
        )
        train, training_reason = should_train(
            key,
            after_count,
            training_state,
        )

        if args.force_train:
            train = True
            training_reason = (
                "Entrenamiento forzado manualmente."
            )

        if train:
            (
                training_executed,
                model_promoted,
                training_result,
            ) = run_training(
                key,
                name,
                after_count,
                row_state,
                state,
                log_file,
            )

            if (
                not training_executed
                and training_result
                and not str(training_result).startswith(
                    "TRAINING_SKIPPED_"
                )
            ):
                warnings.append(
                    "Entrenamiento: "
                    + training_result
                )

    # La automatización normal NO rellena todo el calendario.
    # Dos motivos válidos generan análisis:
    #   1) resultado nuevo -> próximo partido de los equipos afectados;
    #   2) seguro PREPARTIDO -> únicamente el próximo partido de cada equipo
    #      que todavía esté incompleto antes del kickoff.
    events_to_analyze: set[int] = set()
    force_analysis_ids: set[int] = set()
    prematch_guard_details: list[dict[str, Any]] = []

    if args.analyze_only:
        # Modo manual explícito: conserva la capacidad de analizar todos los
        # próximos cuando el usuario lo pide a mano.
        events_to_analyze.update(selected_event_ids(key))
        if args.force:
            force_analysis_ids.update(events_to_analyze)
    else:
        if all_affected_team_ids:
            next_event_ids = affected_selected_event_ids(
                key,
                all_affected_team_ids,
            )
            events_to_analyze.update(next_event_ids)
            selective_message = (
                "ANÁLISIS POST-RESULTADO | "
                f"equipos_afectados={len(all_affected_team_ids)} | "
                f"proximos_seleccionados={len(next_event_ids)} | "
                f"event_ids={next_event_ids}"
            )
            print(selective_message)
            log_file.write(selective_message + "\n")
            log_file.flush()

        (
            guard_event_ids,
            guard_force_ids,
            prematch_guard_details,
        ) = pre_match_guard_candidates(key, row_state)

        events_to_analyze.update(guard_event_ids)
        force_analysis_ids.update(guard_force_ids)

        guard_reasons = {
            int(item["event_id"]): str(item.get("reason") or "")
            for item in prematch_guard_details
            if bool(item.get("due"))
        }
        if guard_event_ids:
            record_prematch_guard_attempts(
                row_state,
                guard_event_ids,
                guard_reasons,
            )
            guard_message = (
                "SEGURO PREPARTIDO | "
                f"proximos_revisados={len(next_unique_event_ids(key))} | "
                f"reparaciones={len(guard_event_ids)} | "
                f"event_ids={guard_event_ids}"
            )
            print(guard_message)
            log_file.write(guard_message + "\n")
            log_file.flush()

    if all_finished_event_ids:
        frozen_message = (
            "PREDICCIÓN PREPARTIDO | los análisis ya generados de los "
            "eventos finalizados se conservan; no se recalculan después "
            "del kickoff."
        )
        print(frozen_message)
        log_file.write(frozen_message + "\n")
        log_file.flush()

    analysis_executed = False

    if events_to_analyze:
        arguments = ["--key", key]

        for event_id in sorted(events_to_analyze):
            arguments.extend(
                ["--event-id", str(event_id)]
            )

        # Si al menos uno de los eventos ya tenía un análisis parcial/dañado,
        # fuerza este micro-lote. El lote sigue siendo pequeño: solo próximos
        # afectados + próximos incompletos del seguro.
        if args.force or force_analysis_ids:
            arguments.append("--force")

        try:
            run_script(
                f"{name}: analizar micro-lote PREPARTIDO",
                "analyze_upcoming_matches.py",
                arguments,
                log_file,
            )
            analysis_executed = True

            repaired_ids = clear_repaired_prematch_attempts(
                key,
                row_state,
                list(events_to_analyze),
            )
            if repaired_ids:
                repaired_message = (
                    "SEGURO PREPARTIDO OK | "
                    f"reparados={len(repaired_ids)} | "
                    f"event_ids={sorted(repaired_ids)}"
                )
                print(repaired_message)
                log_file.write(repaired_message + "\n")
                log_file.flush()

        except Exception as exc:
            warnings.append(
                f"Análisis: {type(exc).__name__}: {exc}"
            )

    row_state.update(
        {
            "last_cycle_at": iso_now(),
            "last_finished_count": after_count,
            "last_affected_team_ids": sorted(
                all_affected_team_ids
            ),
            "last_finished_event_ids": sorted(
                all_finished_event_ids
            ),
            "last_analyzed_event_ids": sorted(
                events_to_analyze
            ),
            "last_prematch_guard_details": prematch_guard_details,
            "last_warnings": warnings,
            "last_selective_event_counts": selection_totals,
        }
    )
    save_state(state)

    return {
        "competition_key": key,
        "competition_name": name,
        "finished_before": before_count,
        "finished_after": after_count,
        "new_finished": new_finished,
        "finished_event_ids": sorted(
            all_finished_event_ids
        ),
        "affected_team_ids": sorted(
            all_affected_team_ids
        ),
        "result_checks": result_checks,
        "incremental_waves": incremental_waves,
        "full_schedule_refreshed": (
            schedule_refreshed_full
        ),
        "incremental_schedule_teams": sorted(
            all_refresh_team_ids
        ),
        "analyzed_event_ids": sorted(
            events_to_analyze
        ),
        "analysis_executed": analysis_executed,
        "prematch_guard_details": prematch_guard_details,
        "training_executed": training_executed,
        "model_promoted": model_promoted,
        "training_result": training_result,
        "training_reason": training_reason,
        "selective_event_counts": selection_totals,
        "warnings": warnings,
        "status": (
            "OK"
            if not warnings
            else "WARNING"
        ),
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Automatización incremental: comprueba solo eventos vencidos, "
            "actualiza únicamente sus equipos, reanaliza partidos "
            "relacionados y reentrena por bloques."
        )
    )
    parser.add_argument(
        "--analyze-only",
        action="store_true",
        help=(
            "Analiza eventos disponibles sin comprobar resultados ni entrenar."
        ),
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help=(
            "Fuerza comprobaciones/reintentos y el micro-lote; no convierte "
            "la automatización en un reanálisis masivo del calendario."
        ),
    )
    parser.add_argument(
        "--force-train",
        action="store_true",
        help="Fuerza un intento de entrenamiento por liga.",
    )
    return parser


def main() -> None:
    args = build_parser().parse_args()

    for script in REQUIRED_SCRIPTS:
        if not (BASE_DIR / script).exists():
            raise FileNotFoundError(
                f"Falta módulo requerido: "
                f"{BASE_DIR / script}"
            )

    competitions = active_competitions()

    if not competitions:
        raise RuntimeError(
            "No existen competiciones activas."
        )

    lock: Path | None = None
    state = load_state()
    log_path = (
        AUTOMATION_DIR
        / f"automatic_selective_{utc_now():%Y%m%d_%H%M%S}.log"
    )
    summary: dict[str, Any] = {
        "generated_at": iso_now(),
        "selection_rule": SELECTION_RULE,
        "rules": {
            "check_interval_minutes": CHECK_INTERVAL_MINUTES,
            "result_scope": "due_events_only",
            "schedule_scope_after_result": (
                "affected_teams_only"
            ),
            "analysis_scope_after_result": (
                "next_match_of_each_affected_team_only"
            ),
            "database_mtime_fingerprint": False,
            "team_specific_fingerprint": True,
            "same_league_only": True,
            "include_if_next_for_at_least_one_team": True,
            "require_next_for_both_teams": False,
            "deduplicate_by_event_id": True,
            "allow_multiple_matches_same_week": False,
            "automatic_missing_analysis_backfill": False,
            "prematch_guard": "next_event_per_team_incomplete_only",
            "prematch_guard_retry_minutes": PREMATCH_GUARD_RETRY_MINUTES,
            "prematch_guard_urgent_retry_minutes": PREMATCH_GUARD_URGENT_RETRY_MINUTES,
            "prematch_guard_critical_retry_minutes": PREMATCH_GUARD_CRITICAL_RETRY_MINUTES,
            "automatic_full_reanalysis_on_model_promotion": False,
            "freeze_at_kickoff": True,
            "training_block_matches": (
                MIN_NEW_MATCHES_FOR_TRAINING
            ),
            "training_max_days_with_new_data": (
                MAX_DAYS_WITH_NEW_DATA
            ),
            "training_state_committed_only_after_completion": True,
            "training_retry_hours": list(
                TRAIN_RETRY_HOURS
            ),
            "calendar_maintenance_policy": "global_round_robin_micro_batch",
            "calendar_team_page_budget_per_cycle": GLOBAL_TEAM_PAGE_BUDGET,
            "calendar_maintenance_max_seconds": CALENDAR_MAINTENANCE_MAX_SECONDS,
            "browser_policy": "single_context_single_page",
            "full_league_refresh_in_cycle": False,
            "bot9_current_season_refresh_hours": BOT9_SEASON_REFRESH_HOURS,
        },
        "competitions": [],
    }

    try:
        try:
            lock = acquire_lock()
        except AutomationAlreadyRunning as exc:
            # No es un fallo del bot: otra instancia válida ya está haciendo
            # el trabajo. La segunda solicitud termina con código 0 para que
            # la interfaz no muestre un error falso.
            print("=" * 86)
            print("ODDSHUNTER — AUTOMATIZACIÓN YA EN CURSO")
            print("=" * 86)
            print("ODDSHUNTER_AUTOMATION_ALREADY_RUNNING")
            print(f"ℹ️ {exc}")
            print(
                "La solicitud duplicada se omitió de forma segura; "
                "no se inició una segunda sesión de Brave."
            )
            return

        print("=" * 86)
        print(
            "ODDSHUNTER — AUTOMATIZACIÓN ADAPTATIVA POR MICRO-LOTES"
        )
        print("=" * 86)
        print(f"Ligas activas: {len(competitions)}")
        print(
            "Cada 30 minutos se comprueban únicamente eventos que ya "
            "deberían haber terminado."
        )
        print(
            "Tras un resultado se refrescan sus equipos y se analiza "
            "solo el próximo partido de cada equipo afectado."
        )
        print(
            "El reentrenamiento es automático, pero únicamente al "
            "acumular 10 partidos o 7 días con datos nuevos."
        )
        print(
            "El mantenimiento de calendarios usa una cola global de máximo "
            f"{GLOBAL_TEAM_PAGE_BUDGET} equipos por ciclo, no ligas completas."
        )
        print("Brave reutiliza una sola pestaña y la cierra al terminar.")
        print(f"Registro: {log_path}")

        with log_path.open(
            "a",
            encoding="utf-8",
            errors="replace",
        ) as log_file:
            # Solo abre el trabajador de arranque cuando de verdad existe
            # alguna liga sin próximo kickoff. Antes se lanzaba con
            # --max-teams 0 incluso con todos los calendarios llenos, lo que
            # obligaba a enumerar cientos de candidatos para terminar en cero.
            empty_schedule_keys = [
                slugify(str(row.get("key") or ""))
                for row in competitions
                if next_competition_kickoff(
                    slugify(str(row.get("key") or ""))
                ) is None
            ]
            if empty_schedule_keys:
                try:
                    startup_calendar_report = run_calendar_maintenance(
                        0,
                        log_file,
                        force=False,
                    )
                    summary["startup_calendar_recovery"] = (
                        startup_calendar_report
                    )
                except Exception as exc:
                    summary["startup_calendar_recovery"] = {
                        "status": "ERROR",
                        "error": f"{type(exc).__name__}: {exc}",
                    }
                    print(
                        "\n⚠ Recuperación inicial de calendarios: "
                        f"{type(exc).__name__}: {exc}\n"
                    )
            else:
                summary["startup_calendar_recovery"] = {
                    "status": "SKIPPED",
                    "reason": "Todas las ligas ya tienen próximo kickoff.",
                }

            # BOT 9.1.0: descubre membresías multicompetición y procesa como
            # máximo una liga doméstica completa por ciclo. Los contextos
            # UEFA y doméstico permanecen separados en SQLite y ratings.json.
            if not args.analyze_only:
                try:
                    run_script(
                        "Contexto doméstico UEFA: descubrir e importar una liga",
                        "domestic_context_manager.py",
                        ["--discover", "--run-one"],
                        log_file,
                    )
                    summary["domestic_context"] = {"status": "OK"}
                except Exception as exc:
                    summary["domestic_context"] = {
                        "status": "ERROR",
                        "error": f"{type(exc).__name__}: {exc}",
                    }
                    print(
                        "\n⚠ Contexto doméstico: "
                        f"{type(exc).__name__}: {exc}\n"
                    )

            for competition in competitions:
                try:
                    result = process_competition(
                        competition,
                        state,
                        args,
                        log_file,
                    )
                except Exception as exc:
                    result = {
                        "competition_key": slugify(
                            str(
                                competition.get("key")
                                or ""
                            )
                        ),
                        "competition_name": (
                            competition.get("name")
                        ),
                        "status": "ERROR",
                        "warnings": [
                            f"{type(exc).__name__}: {exc}"
                        ],
                    }
                    print(
                        f"\n❌ {competition.get('name')}: "
                        f"{type(exc).__name__}: {exc}\n"
                    )

                summary["competitions"].append(
                    result
                )

            affected_pages = sum(
                len(row.get("incremental_schedule_teams") or [])
                for row in summary["competitions"]
            )
            maintenance_budget = max(
                0,
                GLOBAL_TEAM_PAGE_BUDGET - affected_pages,
            )
            try:
                maintenance_report = run_calendar_maintenance(
                    maintenance_budget,
                    log_file,
                    force=bool(args.force),
                )
                summary["calendar_maintenance"] = maintenance_report

                # El mantenimiento de calendario solo mantiene fechas y
                # próximos eventos. No dispara análisis masivo. El seguro
                # PREPARTIDO del siguiente ciclo comprobará únicamente el
                # próximo evento de cada equipo y calculará solo los que
                # continúen incompletos.
                summary["calendar_maintenance_analysis"] = {}
                summary["calendar_maintenance_analysis_policy"] = (
                    "no_mass_prediction; next-event prematch guard handles gaps"
                )
            except Exception as exc:
                summary["calendar_maintenance"] = {
                    "status": "ERROR",
                    "error": f"{type(exc).__name__}: {exc}",
                }
                print(
                    f"\n⚠ Mantenimiento de calendarios: "
                    f"{type(exc).__name__}: {exc}\n"
                )

        summary["totals"] = {
            "active_competitions": len(
                competitions
            ),
            "ok": sum(
                1
                for row in summary["competitions"]
                if row.get("status") == "OK"
            ),
            "warnings": sum(
                1
                for row in summary["competitions"]
                if row.get("status") == "WARNING"
            ),
            "errors": sum(
                1
                for row in summary["competitions"]
                if row.get("status") == "ERROR"
            ),
            "new_finished": sum(
                int(row.get("new_finished") or 0)
                for row in summary["competitions"]
            ),
            "affected_teams": sum(
                len(row.get("affected_team_ids") or [])
                for row in summary["competitions"]
            ),
            "analyzed_events": sum(
                len(row.get("analyzed_event_ids") or [])
                for row in summary["competitions"]
            ),
            "training_executed": sum(
                1
                for row in summary["competitions"]
                if row.get("training_executed")
            ),
            "models_promoted": sum(
                1
                for row in summary["competitions"]
                if row.get("model_promoted")
            ),
            "calendar_teams_processed": int(
                (summary.get("calendar_maintenance") or {}).get("processed_count") or 0
            ),
        }

        summary_path = (
            AUTOMATION_DIR
            / "last_run_selective.json"
        )
        write_json(summary_path, summary)

        print("\n" + "=" * 86)
        print("RESUMEN AUTOMÁTICO SELECTIVO")
        print("=" * 86)
        print(
            f"Partidos nuevos: "
            f"{summary['totals']['new_finished']}"
        )
        print(
            f"Equipos afectados: "
            f"{summary['totals']['affected_teams']}"
        )
        print(
            f"Eventos reanalizados: "
            f"{summary['totals']['analyzed_events']}"
        )
        print(
            f"Reentrenamientos: "
            f"{summary['totals']['training_executed']}"
        )
        print(
            f"Modelos promovidos: "
            f"{summary['totals']['models_promoted']}"
        )
        print(
            f"Equipos de mantenimiento: "
            f"{summary['totals']['calendar_teams_processed']}"
        )
        print(
            f"Ligas con advertencias: "
            f"{summary['totals']['warnings']}"
        )
        print(
            f"Ligas con error: "
            f"{summary['totals']['errors']}"
        )
        if summary["totals"]["warnings"]:
            print("Advertencias que quedarán sujetas a reintento:")
            for row in summary["competitions"]:
                if row.get("status") != "WARNING":
                    continue
                key = row.get("competition_key") or "competición"
                for warning in row.get("warnings") or []:
                    print(f"  - {key}: {warning}")
        print(f"Resumen: {summary_path}")
        print("=" * 86)

        if summary["totals"]["errors"]:
            raise SystemExit(2)

        if summary["totals"]["warnings"]:
            print(
                "⚠️ AUTOMATIZACIÓN TERMINADA CON ADVERTENCIAS; "
                "los reintentos permanecen programados."
            )
        else:
            print("✅ AUTOMATIZACIÓN TERMINADA")

    finally:
        if lock is not None:
            lock.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
