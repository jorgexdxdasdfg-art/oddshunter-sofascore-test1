from __future__ import annotations

import json
import math
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import numpy as np

import train_models_core as core


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "oddshunter.db"
VALIDATION_ROOT = DATA_DIR / "elo" / "validation"
MODEL_ROOT = DATA_DIR / "trained_models"

ELO_WEIGHT_BOUNDS = (0.0, 1.50)
ELO_WEIGHT_STARTS = (0.0, 0.35, 0.70, 1.05, 1.40)
DEFAULT_HOLDOUT = 0.25
MIN_ELO_GOALS_SAMPLES = 80


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"No se encontró:\n{path}")
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"{path.name} no contiene un objeto JSON.")
    return data


def read_json_optional(path: Path) -> dict[str, Any] | None:
    try:
        return read_json(path)
    except Exception:
        return None


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2, default=str),
        encoding="utf-8",
    )


def connect() -> sqlite3.Connection:
    if not DB_PATH.exists():
        raise FileNotFoundError(f"No se encontró la base SQLite:\n{DB_PATH}")
    connection = sqlite3.connect(DB_PATH, timeout=30)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA busy_timeout = 30000")
    return connection


def ensure_config_table(connection: sqlite3.Connection) -> None:
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS elo_model_config (
            competition_key TEXT NOT NULL,
            component TEXT NOT NULL,
            enabled INTEGER NOT NULL DEFAULT 0,
            validation_method TEXT,
            validation_delta REAL,
            baseline_log_loss REAL,
            elo_log_loss REAL,
            baseline_brier REAL,
            elo_brier REAL,
            model_path TEXT,
            decision_reason TEXT,
            updated_at TEXT NOT NULL,
            PRIMARY KEY (competition_key, component),
            CHECK (enabled IN (0, 1)),
            FOREIGN KEY (competition_key)
                REFERENCES elo_competiciones(competition_key)
                ON UPDATE CASCADE
                ON DELETE CASCADE
        )
        """
    )


def resolve_season_chain(
    connection: sqlite3.Connection,
    registry_key: str,
) -> dict[str, Any]:
    current = connection.execute(
        """
        SELECT
            et.season_id,
            et.competition_key,
            et.source_league_id,
            et.source_registry_key,
            et.season_name,
            et.previous_season_id,
            ep.elo_base,
            ep.k_elo,
            ep.ventaja_local_elo,
            ep.factor_arrastre_elo,
            ep.escala_elo,
            ep.cap_elo
        FROM elo_temporadas AS et
        INNER JOIN elo_parametros_liga AS ep
            ON ep.competition_key = et.competition_key
        WHERE et.source_registry_key = ?
        """,
        (str(registry_key),),
    ).fetchone()

    if current is None:
        raise RuntimeError(
            f"La competición '{registry_key}' no está registrada en elo_temporadas."
        )

    chain: list[dict[str, Any]] = []
    cursor: dict[str, Any] | None = dict(current)
    visited: set[int] = set()

    while cursor is not None:
        season_id = int(cursor["season_id"])
        if season_id in visited:
            raise RuntimeError("Se detectó un ciclo en previous_season_id.")
        visited.add(season_id)
        chain.append(cursor)

        previous_id = cursor.get("previous_season_id")
        if previous_id is None:
            break

        previous = connection.execute(
            """
            SELECT
                et.season_id,
                et.competition_key,
                et.source_league_id,
                et.source_registry_key,
                et.season_name,
                et.previous_season_id,
                ep.elo_base,
                ep.k_elo,
                ep.ventaja_local_elo,
                ep.factor_arrastre_elo,
                ep.escala_elo,
                ep.cap_elo
            FROM elo_temporadas AS et
            INNER JOIN elo_parametros_liga AS ep
                ON ep.competition_key = et.competition_key
            WHERE et.season_id = ?
            """,
            (int(previous_id),),
        ).fetchone()
        if previous is None:
            raise RuntimeError(
                f"No se encontró previous_season_id={previous_id}."
            )
        cursor = dict(previous)

    chain.reverse()
    return {
        "current": dict(current),
        "chain": chain,
        "league_ids": [int(item["source_league_id"]) for item in chain],
        "season_ids": [int(item["season_id"]) for item in chain],
    }


def load_rows_with_prematch_elo(
    connection: sqlite3.Connection,
    season_context: dict[str, Any],
) -> list[dict[str, Any]]:
    league_ids = season_context["league_ids"]
    season_ids = season_context["season_ids"]
    league_placeholders = ",".join("?" for _ in league_ids)
    season_placeholders = ",".join("?" for _ in season_ids)

    rows = connection.execute(
        f"""
        SELECT
            m.match_id,
            m.sofascore_id AS event_id,
            m.kickoff,
            m.league_id AS source_league_id,
            et.season_id AS elo_season_id,

            COALESCE(home.sofascore_id, 1000000000 + m.home_team_id)
                AS home_team_id,
            COALESCE(away.sofascore_id, 1000000000 + m.away_team_id)
                AS away_team_id,

            m.home_team_id AS source_home_team_id,
            m.away_team_id AS source_away_team_id,
            home.name AS home_team,
            away.name AS away_team,
            m.home_goals,
            m.away_goals,

            hs.goals_for AS home_goals_for,
            hs.goals_against AS home_goals_against,
            hs.xg_for AS home_xg_for,
            hs.xg_against AS home_xg_against,
            hs.corners_for AS home_corners_for,
            hs.corners_against AS home_corners_against,
            hs.yellow_cards AS home_yellow_cards,

            aws.goals_for AS away_goals_for,
            aws.goals_against AS away_goals_against,
            aws.xg_for AS away_xg_for,
            aws.xg_against AS away_xg_against,
            aws.corners_for AS away_corners_for,
            aws.corners_against AS away_corners_against,
            aws.yellow_cards AS away_yellow_cards,

            home_elo.elo_antes AS home_elo_before,
            away_elo.elo_antes AS away_elo_before

        FROM matches AS m
        INNER JOIN elo_temporadas AS et
            ON et.source_league_id = m.league_id
           AND et.season_name = m.season
        INNER JOIN teams AS home
            ON home.team_id = m.home_team_id
        INNER JOIN teams AS away
            ON away.team_id = m.away_team_id
        INNER JOIN team_match_stats AS hs
            ON hs.match_id = m.match_id
           AND hs.venue = 'HOME'
        INNER JOIN team_match_stats AS aws
            ON aws.match_id = m.match_id
           AND aws.venue = 'AWAY'
        INNER JOIN elo_movimientos AS home_elo
            ON home_elo.match_id = m.match_id
           AND home_elo.league_id = m.league_id
           AND home_elo.season_id = et.season_id
           AND home_elo.team_id = m.home_team_id
           AND home_elo.es_local = 1
        INNER JOIN elo_movimientos AS away_elo
            ON away_elo.match_id = m.match_id
           AND away_elo.league_id = m.league_id
           AND away_elo.season_id = et.season_id
           AND away_elo.team_id = m.away_team_id
           AND away_elo.es_local = 0
        WHERE
            m.league_id IN ({league_placeholders})
            AND et.season_id IN ({season_placeholders})
            AND LOWER(TRIM(m.status)) IN ('ft', 'finished')
            AND m.home_goals IS NOT NULL
            AND m.away_goals IS NOT NULL
        ORDER BY m.kickoff ASC, m.match_id ASC
        """,
        tuple([*league_ids, *season_ids]),
    ).fetchall()

    return [dict(row) for row in rows]


def build_elo_map(
    rows: Iterable[dict[str, Any]],
) -> dict[int, tuple[float, float]]:
    result: dict[int, tuple[float, float]] = {}
    for row in rows:
        match_id = int(row["match_id"])
        if row.get("home_elo_before") is None or row.get("away_elo_before") is None:
            raise RuntimeError(f"Falta ELO prepartido para match_id={match_id}.")
        result[match_id] = (
            float(row["home_elo_before"]),
            float(row["away_elo_before"]),
        )
    return result


def elo_factors(
    home_elo: float,
    away_elo: float,
    weight: float,
    scale: float,
    cap: float,
) -> tuple[float, float, float]:
    difference = float(home_elo) - float(away_elo)
    clipped = float(np.clip(difference, -float(cap), float(cap)))
    exponent = float(weight) * clipped / float(scale)
    return math.exp(exponent), math.exp(-exponent), clipped


def elo_goal_prediction(
    sample: core.TrainingSample,
    parameters: np.ndarray,
    elo_by_match: dict[int, tuple[float, float]],
    elo_scale: float,
    elo_cap: float,
) -> tuple[float, float, np.ndarray]:
    base_parameters = np.asarray(parameters[:6], dtype=float)
    elo_weight = float(parameters[6])
    lambda_home, lambda_away, _ = core.goal_prediction(sample, base_parameters)

    try:
        home_elo, away_elo = elo_by_match[int(sample.match_id)]
    except KeyError as exc:
        raise RuntimeError(
            f"No existe ELO prepartido para match_id={sample.match_id}."
        ) from exc

    home_factor, away_factor, _ = elo_factors(
        home_elo,
        away_elo,
        elo_weight,
        elo_scale,
        elo_cap,
    )
    lambda_home = core.clamp(lambda_home * home_factor, 0.05, 6.0)
    lambda_away = core.clamp(lambda_away * away_factor, 0.05, 6.0)
    rho = float(base_parameters[5])
    matrix = core.dixon_coles_matrix(lambda_home, lambda_away, rho)
    probabilities = np.array(
        [
            float(np.tril(matrix, -1).sum()),
            float(np.trace(matrix)),
            float(np.triu(matrix, 1).sum()),
        ],
        dtype=float,
    )
    probabilities /= probabilities.sum()
    return lambda_home, lambda_away, probabilities


def elo_objective(
    parameters: np.ndarray,
    samples: list[core.TrainingSample],
    elo_by_match: dict[int, tuple[float, float]],
    elo_scale: float,
    elo_cap: float,
) -> float:
    losses: list[float] = []
    for sample in samples:
        lambda_home, lambda_away, probabilities = elo_goal_prediction(
            sample,
            parameters,
            elo_by_match,
            elo_scale,
            elo_cap,
        )
        observed = core.outcome_index(sample.home_goals, sample.away_goals)
        outcome_loss = -math.log(
            max(float(probabilities[observed]), core.EPSILON)
        )
        count_loss = 0.5 * (
            core.poisson_nll(sample.home_goals, lambda_home)
            + core.poisson_nll(sample.away_goals, lambda_away)
        )
        losses.append(outcome_loss + 0.20 * count_loss)
    return float(np.mean(losses)) if losses else 1e6


def evaluate_elo_goals(
    parameters: np.ndarray,
    samples: list[core.TrainingSample],
    elo_by_match: dict[int, tuple[float, float]],
    elo_scale: float,
    elo_cap: float,
) -> dict[str, Any]:
    briers: list[float] = []
    log_losses: list[float] = []
    accuracies: list[float] = []
    count_nlls: list[float] = []

    for sample in samples:
        lambda_home, lambda_away, probabilities = elo_goal_prediction(
            sample,
            parameters,
            elo_by_match,
            elo_scale,
            elo_cap,
        )
        observed = core.outcome_index(sample.home_goals, sample.away_goals)
        briers.append(core.brier_multiclass(probabilities, observed))
        log_losses.append(
            -math.log(max(float(probabilities[observed]), core.EPSILON))
        )
        accuracies.append(
            1.0 if int(np.argmax(probabilities)) == observed else 0.0
        )
        count_nlls.append(
            0.5 * (
                core.poisson_nll(sample.home_goals, lambda_home)
                + core.poisson_nll(sample.away_goals, lambda_away)
            )
        )

    return {
        "samples": len(samples),
        "brier_score": round(float(np.mean(briers)), 8),
        "log_loss": round(float(np.mean(log_losses)), 8),
        "accuracy": round(float(np.mean(accuracies)), 8),
        "mean_goal_count_nll": round(float(np.mean(count_nlls)), 8),
        "combined_objective": round(
            float(np.mean(log_losses))
            + 0.20 * float(np.mean(count_nlls)),
            8,
        ),
    }


def fit_baseline(samples: list[core.TrainingSample]) -> np.ndarray:
    parameters, _, _ = core.optimize_with_starts(
        objective=lambda params: core.goals_objective(params, samples),
        starts=core.GOAL_STARTS,
        bounds=core.GOAL_BOUNDS,
    )
    return parameters


def fit_elo_parameters(
    samples: list[core.TrainingSample],
    elo_by_match: dict[int, tuple[float, float]],
    elo_scale: float,
    elo_cap: float,
    baseline_parameters: np.ndarray | None = None,
) -> tuple[np.ndarray, float, list[dict[str, Any]]]:
    baseline = (
        np.asarray(baseline_parameters, dtype=float)
        if baseline_parameters is not None
        else fit_baseline(samples)
    )
    starts = tuple(
        np.concatenate([baseline, np.array([weight], dtype=float)])
        for weight in ELO_WEIGHT_STARTS
    )
    return core.optimize_with_starts(
        objective=lambda params: elo_objective(
            params,
            samples,
            elo_by_match,
            elo_scale,
            elo_cap,
        ),
        starts=starts,
        bounds=core.GOAL_BOUNDS + (ELO_WEIGHT_BOUNDS,),
    )


def validation_report_path(key: str) -> Path:
    return VALIDATION_ROOT / str(key) / "elo_goals_walk_forward.json"


def model_path(key: str) -> Path:
    return MODEL_ROOT / str(key) / "elo_goals_model.json"


def validation_decision(key: str) -> dict[str, Any]:
    path = validation_report_path(key)
    report = read_json_optional(path)
    if report is None:
        return {
            "available": False,
            "enabled": False,
            "path": str(path),
            "reason": "No existe validación walk-forward para esta competición.",
        }

    walk_forward = report.get("walk_forward", {})
    comparison = walk_forward.get("comparison", {})
    baseline = walk_forward.get("baseline", {})
    elo = walk_forward.get("elo", {})
    raw_weights: list[tuple[float, int]] = []
    for block in walk_forward.get("blocks", []):
        if not isinstance(block, dict):
            continue
        try:
            weight = float(block.get("elo_parameters", {}).get("elo_weight"))
            sample_count = int(block.get("evaluation_samples") or 1)
        except (TypeError, ValueError):
            continue
        if math.isfinite(weight) and weight >= 0:
            raw_weights.append((weight, max(1, sample_count)))

    validated_weight = (
        float(np.average(
            [item[0] for item in raw_weights],
            weights=[item[1] for item in raw_weights],
        ))
        if raw_weights
        else 0.0
    )
    improves = bool(comparison.get("elo_candidate_improves", False))
    enabled = bool(improves and validated_weight > 0.01)

    return {
        "available": True,
        "enabled": enabled,
        "path": str(path),
        "reason": (
            "La validación walk-forward demuestra mejora y aprendió un peso ELO útil."
            if enabled
            else (
                "La variante mejoró, pero el peso ELO aprendido fue prácticamente cero."
                if improves
                else "La validación walk-forward no demuestra mejora."
            )
        ),
        "validated_weight": round(validated_weight, 8),
        "block_weights": [round(item[0], 8) for item in raw_weights],
        "method": walk_forward.get("method"),
        "delta": comparison.get("elo_minus_baseline_combined_objective"),
        "baseline": baseline,
        "elo": elo,
        "evaluation_samples": walk_forward.get("evaluation_samples"),
    }


def _parameter_dict(parameters: np.ndarray) -> dict[str, float]:
    names = (
        "recent_weight",
        "venue_mix",
        "xg_weight",
        "league_shrinkage",
        "home_advantage",
        "dixon_coles_rho",
        "elo_weight",
    )
    return {
        name: round(float(value), 8)
        for name, value in zip(names, parameters)
    }


def save_config(
    connection: sqlite3.Connection,
    key: str,
    season_context: dict[str, Any],
    decision: dict[str, Any],
    output_path: Path,
) -> None:
    ensure_config_table(connection)
    current = season_context["current"]
    baseline = decision.get("baseline", {})
    elo = decision.get("elo", {})
    connection.execute(
        """
        INSERT INTO elo_model_config (
            competition_key,
            component,
            enabled,
            validation_method,
            validation_delta,
            baseline_log_loss,
            elo_log_loss,
            baseline_brier,
            elo_brier,
            model_path,
            decision_reason,
            updated_at
        )
        VALUES (?, 'goals', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(competition_key, component) DO UPDATE SET
            enabled = excluded.enabled,
            validation_method = excluded.validation_method,
            validation_delta = excluded.validation_delta,
            baseline_log_loss = excluded.baseline_log_loss,
            elo_log_loss = excluded.elo_log_loss,
            baseline_brier = excluded.baseline_brier,
            elo_brier = excluded.elo_brier,
            model_path = excluded.model_path,
            decision_reason = excluded.decision_reason,
            updated_at = excluded.updated_at
        """,
        (
            str(current["competition_key"]),
            1 if decision.get("enabled") else 0,
            decision.get("method"),
            decision.get("delta"),
            baseline.get("log_loss"),
            elo.get("log_loss"),
            baseline.get("brier_score"),
            elo.get("brier_score"),
            str(output_path),
            str(decision.get("reason") or ""),
            utc_now(),
        ),
    )


def latest_baseline_parameters(key: str) -> np.ndarray:
    latest = read_json_optional(MODEL_ROOT / str(key) / "latest_model.json") or {}
    parameters = latest.get("goals", {}).get("parameters", {})
    names = (
        "recent_weight",
        "venue_mix",
        "xg_weight",
        "league_shrinkage",
        "home_advantage",
        "dixon_coles_rho",
    )
    defaults = np.asarray(core.GOAL_STARTS[0], dtype=float)
    values: list[float] = []
    for index, name in enumerate(names):
        try:
            value = float(parameters.get(name, defaults[index]))
        except (TypeError, ValueError):
            value = float(defaults[index])
        lower, upper = core.GOAL_BOUNDS[index]
        values.append(float(np.clip(value, lower, upper)))
    return np.asarray(values, dtype=float)


def insufficient_sample_decision(
    original: dict[str, Any],
    sample_count: int,
    minimum: int = MIN_ELO_GOALS_SAMPLES,
) -> dict[str, Any]:
    """Representa una carencia esperada como fallback válido, no como error."""
    return {
        **dict(original),
        "available": False,
        "enabled": False,
        "insufficient_samples": True,
        "sample_count": int(sample_count),
        "minimum_samples": int(minimum),
        "reason": (
            "ELO permanece solo como ranking: se requieren al menos "
            f"{int(minimum)} muestras y actualmente hay {int(sample_count)}. "
            "El modelo principal de goles continúa activo."
        ),
    }


def fit_and_save(key: str, holdout: float = DEFAULT_HOLDOUT) -> dict[str, Any]:
    if not 0.15 <= float(holdout) <= 0.40:
        raise ValueError("holdout debe estar entre 0.15 y 0.40.")

    decision = validation_decision(key)

    with connect() as connection:
        season_context = resolve_season_chain(connection, key)
        rows = load_rows_with_prematch_elo(connection, season_context)

    elo_by_match = build_elo_map(rows)
    samples = core.build_samples(rows)
    if len(samples) < MIN_ELO_GOALS_SAMPLES:
        decision = insufficient_sample_decision(
            decision,
            len(samples),
        )
        baseline_parameters = latest_baseline_parameters(key)
        output_path = model_path(key)
        output = {
            "generated_at": utc_now(),
            "competition_key": str(key),
            "active": False,
            "decision": decision,
            "season_context": season_context,
            "data": {
                "finished_matches_with_elo": len(rows),
                "walk_forward_samples": len(samples),
                "train_samples": 0,
                "validation_samples": 0,
                "holdout": float(holdout),
            },
            "runtime": {
                "prematch_elo_only": True,
                "goal_difference_multiplier": False,
                "fallback": "baseline_goals_model",
            },
            "holdout_check": {
                "baseline": None,
                "elo": None,
            },
            "parameters": {
                **{
                    name: round(float(value), 8)
                    for name, value in zip(
                        (
                            "recent_weight",
                            "venue_mix",
                            "xg_weight",
                            "league_shrinkage",
                            "home_advantage",
                            "dixon_coles_rho",
                        ),
                        baseline_parameters,
                    )
                },
                "elo_weight": 0.0,
            },
            "training_objective": None,
            "optimizer_attempts": [],
        }
        write_json(output_path, output)
        with connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            save_config(
                connection,
                key,
                season_context,
                decision,
                output_path,
            )
            connection.commit()
        return output

    current = season_context["current"]
    elo_scale = float(current["escala_elo"])
    elo_cap = float(current["cap_elo"])
    output_path = model_path(key)

    split_index = int(round(len(samples) * (1.0 - float(holdout))))
    split_index = max(40, min(split_index, len(samples) - 25))
    train_samples = samples[:split_index]
    validation_samples = samples[split_index:]

    baseline_parameters = latest_baseline_parameters(key)
    baseline_validation: dict[str, Any] | None = None

    fitted_parameters: np.ndarray | None = None
    fit_attempts: list[dict[str, Any]] = []
    fit_objective: float | None = None
    elo_validation: dict[str, Any] | None = None

    if decision.get("enabled"):
        baseline_parameters = fit_baseline(train_samples)
        baseline_validation = core.evaluate_goals(
            baseline_parameters,
            validation_samples,
        )
        candidate_parameters, fit_objective, fit_attempts = fit_elo_parameters(
            samples=train_samples,
            elo_by_match=elo_by_match,
            elo_scale=elo_scale,
            elo_cap=elo_cap,
            baseline_parameters=baseline_parameters,
        )
        elo_validation = evaluate_elo_goals(
            candidate_parameters,
            validation_samples,
            elo_by_match,
            elo_scale,
            elo_cap,
        )

        full_baseline = fit_baseline(samples)
        fitted_parameters, fit_objective, fit_attempts = fit_elo_parameters(
            samples=samples,
            elo_by_match=elo_by_match,
            elo_scale=elo_scale,
            elo_cap=elo_cap,
            baseline_parameters=full_baseline,
        )
        validated_weight = float(decision.get("validated_weight") or 0.0)
        if float(fitted_parameters[6]) <= 0.01 and validated_weight > 0.01:
            fitted_parameters = np.asarray(fitted_parameters, dtype=float)
            fitted_parameters[6] = float(np.clip(
                validated_weight,
                ELO_WEIGHT_BOUNDS[0],
                ELO_WEIGHT_BOUNDS[1],
            ))

    output: dict[str, Any] = {
        "generated_at": utc_now(),
        "competition_key": str(key),
        "active": bool(decision.get("enabled")),
        "decision": decision,
        "season_context": season_context,
        "data": {
            "finished_matches_with_elo": len(rows),
            "walk_forward_samples": len(samples),
            "train_samples": len(train_samples),
            "validation_samples": len(validation_samples),
            "holdout": float(holdout),
        },
        "runtime": {
            "prematch_elo_only": True,
            "goal_difference_multiplier": False,
            "elo_scale": elo_scale,
            "elo_cap": elo_cap,
            "formula": (
                "lambda_home *= exp(elo_weight * clipped_elo_difference / elo_scale); "
                "lambda_away *= exp(-elo_weight * clipped_elo_difference / elo_scale)"
            ),
        },
        "holdout_check": {
            "baseline": baseline_validation,
            "elo": elo_validation,
        },
        "parameters": (
            _parameter_dict(fitted_parameters)
            if fitted_parameters is not None
            else {
                **{
                    name: round(float(value), 8)
                    for name, value in zip(
                        (
                            "recent_weight",
                            "venue_mix",
                            "xg_weight",
                            "league_shrinkage",
                            "home_advantage",
                            "dixon_coles_rho",
                        ),
                        baseline_parameters,
                    )
                },
                "elo_weight": 0.0,
            }
        ),
        "training_objective": (
            round(float(fit_objective), 8)
            if fit_objective is not None
            else None
        ),
        "optimizer_attempts": fit_attempts,
    }

    write_json(output_path, output)

    with connect() as connection:
        connection.execute("BEGIN IMMEDIATE")
        save_config(connection, key, season_context, decision, output_path)
        connection.commit()

    return output
