from __future__ import annotations

# OddsHunter shared upcoming UPSERT retained for Champions 1.2

import argparse
import json
import os
import re
import sqlite3
import threading
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

from playwright.sync_api import BrowserContext, Page, Response, sync_playwright


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
REGISTRY_PATH = DATA_DIR / "competitions.json"
COMPETITIONS_DIR = DATA_DIR / "competitions"
DB_PATH = DATA_DIR / "oddshunter.db"
BRAVE_PROFILE_DIR = DATA_DIR / "brave_oddshunter_profile"

PAGE_TIMEOUT_MS = 90_000
PAGE_WAIT_MS = 5_000
NETWORK_WAIT_SECONDS = 15
DEFAULT_MATCHES_PER_TEAM = 3
SELECTION_RULE = "next_of_at_least_one_team"
BROWSER_POLICY = "single_context_single_page"

DATA_DIR.mkdir(parents=True, exist_ok=True)
COMPETITIONS_DIR.mkdir(parents=True, exist_ok=True)
BRAVE_PROFILE_DIR.mkdir(parents=True, exist_ok=True)




# ODDSHUNTER_SQLITE_PROGRESS_DEDUP_V1_2
_ODDSHUNTER_ORIGINAL_PRINT = print
_ODDSHUNTER_LAST_SQLITE_PROGRESS_LINE = None

def _oddshunter_print_dedup_sqlite_progress(*args, **kwargs):
    global _ODDSHUNTER_LAST_SQLITE_PROGRESS_LINE
    text = " ".join(str(value) for value in args)
    normalized = text.strip()
    if normalized.startswith("SQLite próximos:"):
        if normalized == _ODDSHUNTER_LAST_SQLITE_PROGRESS_LINE:
            return
        _ODDSHUNTER_LAST_SQLITE_PROGRESS_LINE = normalized
    else:
        _ODDSHUNTER_LAST_SQLITE_PROGRESS_LINE = None
    _ODDSHUNTER_ORIGINAL_PRINT(*args, **kwargs)

print = _oddshunter_print_dedup_sqlite_progress

def close_playwright_target(target: Any, label: str) -> None:
    """Cierra una página/contexto sin fallar si Brave ya lo cerró."""
    if target is None:
        return

    try:
        is_closed = getattr(target, "is_closed", None)
        if callable(is_closed) and bool(is_closed()):
            if os.environ.get("ODDSHUNTER_BOUNDED_BROWSER_CLOSE") == "1":
                print(f"BROWSER_ALREADY_CLOSED | {label}")
            return
    except Exception:
        # Algunos objetos de Playwright no exponen is_closed o pueden quedar
        # desconectados mientras se consulta. El cierre protegido sigue abajo.
        pass

    bounded = os.environ.get("ODDSHUNTER_BOUNDED_BROWSER_CLOSE") == "1"
    completed = threading.Event()
    timed_out = threading.Event()

    def terminate_owned_browser_processes() -> None:
        timeout_seconds = float(
            os.environ.get("ODDSHUNTER_BROWSER_CLOSE_TIMEOUT_SECONDS", "7")
        )
        if completed.wait(timeout_seconds):
            return
        timed_out.set()
        print(f"BROWSER_CLOSE_TIMEOUT | {label} | {timeout_seconds:.1f}s")
        try:
            import psutil

            descendants = psutil.Process(os.getpid()).children(recursive=True)
            for process in reversed(descendants):
                try:
                    process.terminate()
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
            _, alive = psutil.wait_procs(descendants, timeout=1.0)
            for process in alive:
                try:
                    process.kill()
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
        except Exception as exc:
            print(
                "BROWSER_CLOSE_CLEANUP_ERROR | "
                f"{label} | {type(exc).__name__}: {exc}"
            )

    watchdog = None
    if bounded:
        watchdog = threading.Thread(
            target=terminate_owned_browser_processes,
            name="oddshunter-browser-close-watchdog",
            daemon=True,
        )
        watchdog.start()

    try:
        target.close()
        if bounded and not timed_out.is_set():
            print(f"BROWSER_CLOSE_OK | {label}")
    except Exception as exc:
        # El trabajo principal ya fue guardado. Un TargetClosedError durante
        # la limpieza no debe devolver código 1 ni detener la cola automática.
        message = f"{type(exc).__name__}: {exc}"
        if bounded and (
            "targetclosederror" in message.casefold()
            or "has been closed" in message.casefold()
        ):
            print(f"BROWSER_TARGET_CLOSED | {label} | {message}")
        else:
            print(f"⚠️ Cierre de {label} omitido: {message}")
    finally:
        completed.set()
        if watchdog is not None:
            watchdog.join(timeout=0.1)


def browser_session_lost(exc: Exception) -> bool:
    """Detecta una página o contexto de Brave que debe reconstruirse."""
    message = f"{type(exc).__name__}: {exc}".lower()
    markers = (
        "targetclosederror",
        "target page, context or browser has been closed",
        "browser has been closed",
        "target.createtarget",
        "failed to open a new tab",
    )
    return any(marker in message for marker in markers)


def open_brave_session(
    playwright: Any,
    brave_path: Path,
) -> tuple[BrowserContext, Page]:
    """Abre una sesión limpia con una sola pestaña reutilizable."""
    last_error: Exception | None = None

    for launch_attempt in range(2):
        context: BrowserContext | None = None
        try:
            context = playwright.chromium.launch_persistent_context(
                user_data_dir=str(BRAVE_PROFILE_DIR),
                executable_path=str(brave_path),
                headless=False,
                chromium_sandbox=True,
                locale="es-ES",
                viewport={"width": 1365, "height": 900},
                args=[
                    "--start-maximized",
                    "--disable-session-crashed-bubble",
                    "--disable-features=InfiniteSessionRestore",
                    "--no-first-run",
                ],
            )

            pages = list(context.pages)
            page = pages[0] if pages else context.new_page()
            for extra_page in pages[1:]:
                close_playwright_target(extra_page, "página adicional")
            try:
                page.goto("about:blank", wait_until="domcontentloaded")
            except Exception:
                pass
            return context, page
        except Exception as exc:
            last_error = exc
            close_playwright_target(
                context,
                "contexto incompleto de Brave",
            )
            if launch_attempt == 0 and browser_session_lost(exc):
                print(
                    "   ⚠️ Brave no pudo abrir la pestaña inicial; "
                    "se reintentará la sesión una vez."
                )
                continue
            raise

    assert last_error is not None
    raise last_error


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def now_timestamp() -> int:
    return int(datetime.now(timezone.utc).timestamp())


def slugify(text: str) -> str:
    value = text.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-")


def read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"No existe:\n{path}")

    data = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(data, dict):
        raise ValueError(f"{path.name} no contiene un objeto JSON válido.")

    return data


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def encontrar_brave() -> Path:
    candidates = [
        (
            Path(os.environ.get("PROGRAMFILES", ""))
            / "BraveSoftware"
            / "Brave-Browser"
            / "Application"
            / "brave.exe"
        ),
        (
            Path(os.environ.get("PROGRAMFILES(X86)", ""))
            / "BraveSoftware"
            / "Brave-Browser"
            / "Application"
            / "brave.exe"
        ),
        (
            Path(os.environ.get("LOCALAPPDATA", ""))
            / "BraveSoftware"
            / "Brave-Browser"
            / "Application"
            / "brave.exe"
        ),
    ]

    for candidate in candidates:
        if candidate.exists():
            return candidate

    raise FileNotFoundError("No se encontró Brave automáticamente.")


def load_registry() -> dict[str, Any]:
    registry = read_json(REGISTRY_PATH)

    if not isinstance(registry.get("competitions"), list):
        raise ValueError(
            "competitions.json no contiene una lista 'competitions'."
        )

    return registry


def find_competition(
    registry: dict[str, Any],
    key: str,
) -> dict[str, Any]:
    normalized = slugify(key)

    for competition in registry["competitions"]:
        if slugify(str(competition.get("key", ""))) == normalized:
            return competition

    raise ValueError(f"No existe la competición '{key}'.")


def _normalized_text(value: Any) -> str:
    text = unicodedata.normalize("NFKD", str(value or ""))
    text = "".join(char for char in text if not unicodedata.combining(char))
    return re.sub(r"[^a-z0-9]+", " ", text.lower()).strip()


def _table_columns(connection: sqlite3.Connection, table: str) -> set[str]:
    try:
        return {
            str(row[1])
            for row in connection.execute(f"PRAGMA table_info({table})").fetchall()
        }
    except sqlite3.Error:
        return set()


def _league_ids_from_sqlite(
    connection: sqlite3.Connection,
    competition: dict[str, Any],
) -> list[int]:
    key = slugify(str(competition.get("key") or ""))
    elo_columns = _table_columns(connection, "elo_temporadas")
    if {"source_registry_key", "source_league_id"}.issubset(elo_columns):
        try:
            rows = connection.execute(
                """
                SELECT DISTINCT source_league_id
                FROM elo_temporadas
                WHERE source_registry_key = ?
                  AND source_league_id IS NOT NULL
                ORDER BY active DESC, season_id DESC
                """,
                (key,),
            ).fetchall()
            ids = [int(row[0]) for row in rows if row[0] is not None]
            if ids:
                # El primer registro es la temporada activa/preferida.
                return [ids[0]]
        except sqlite3.Error:
            pass

    try:
        leagues = connection.execute(
            "SELECT league_id, name, country, season FROM leagues"
        ).fetchall()
    except sqlite3.Error:
        return []

    wanted_name = _normalized_text(competition.get("name"))
    wanted_country = _normalized_text(competition.get("country"))
    wanted_season = _normalized_text(competition.get("season_name"))
    key_tokens = {token for token in _normalized_text(key).split() if len(token) > 2}
    scored: list[tuple[int, int]] = []

    for league_id, name, country, season in leagues:
        current_name = _normalized_text(name)
        current_country = _normalized_text(country)
        current_season = _normalized_text(season)
        if wanted_country and current_country and wanted_country != current_country:
            continue
        score = 0
        if current_name == wanted_name and wanted_name:
            score += 100
        if wanted_name and (wanted_name in current_name or current_name in wanted_name):
            score += 35
        score += 8 * len(key_tokens.intersection(current_name.split()))
        if wanted_country and current_country == wanted_country:
            score += 20
        if wanted_season and current_season == wanted_season:
            score += 40
        elif wanted_season and (
            wanted_season in current_season or current_season in wanted_season
        ):
            score += 15
        if score > 0:
            scored.append((score, int(league_id)))

    if not scored:
        return []
    scored.sort(reverse=True)
    return [scored[0][1]]


def _teams_from_sqlite(competition: dict[str, Any]) -> list[dict[str, Any]]:
    if not DB_PATH.exists():
        return []
    connection = sqlite3.connect(DB_PATH)
    try:
        league_ids = _league_ids_from_sqlite(connection, competition)
        if not league_ids:
            return []
        placeholders = ",".join("?" for _ in league_ids)
        rows = connection.execute(
            f"""
            SELECT DISTINCT t.sofascore_id, t.name
            FROM teams AS t
            INNER JOIN (
                SELECT home_team_id AS team_id
                FROM matches
                WHERE league_id IN ({placeholders})
                UNION
                SELECT away_team_id AS team_id
                FROM matches
                WHERE league_id IN ({placeholders})
            ) AS used ON used.team_id = t.team_id
            WHERE t.sofascore_id IS NOT NULL
              AND CAST(t.sofascore_id AS INTEGER) > 0
            ORDER BY t.name
            """,
            tuple(league_ids) + tuple(league_ids),
        ).fetchall()
    except sqlite3.Error:
        return []
    finally:
        connection.close()

    forbidden = {
        _normalized_text(competition.get("country")),
        "usa", "united states", "chile", "mexico", "ecuador", "brazil", "brasil",
    }
    result: list[dict[str, Any]] = []
    seen: set[int] = set()
    for source_id, name in rows:
        try:
            team_id = int(source_id)
        except (TypeError, ValueError):
            continue
        clean_name = str(name or "").strip()
        if not clean_name or _normalized_text(clean_name) in forbidden or team_id in seen:
            continue
        seen.add(team_id)
        result.append({
            "team_id": team_id,
            "name": clean_name,
            "slug": slugify(clean_name),
        })
    return result


def load_teams(competition: dict[str, Any]) -> tuple[list[dict[str, Any]], Path]:
    key = slugify(str(competition["key"]))
    path = COMPETITIONS_DIR / key / "teams.json"
    sqlite_teams = _teams_from_sqlite(competition)

    file_teams: list[dict[str, Any]] = []
    try:
        data = read_json(path)
        rows = data.get("teams")
    except Exception:
        rows = []

    if isinstance(rows, list):
        for team in rows:
            if not isinstance(team, dict):
                continue
            try:
                team_id = int(team["team_id"])
            except (KeyError, TypeError, ValueError):
                continue
            name = str(team.get("name") or "").strip()
            if not name:
                continue
            item = dict(team)
            item["team_id"] = team_id
            item.setdefault("slug", slugify(name))
            file_teams.append(item)

    # SQLite es la fuente autoritativa cuando contiene una plantilla real.
    # Así se eliminan filas espurias como "Chile" o "USA" y se recuperan
    # automáticamente LigaPro, Liga MX y Brasil aunque teams.json esté roto.
    normalized = sqlite_teams if len(sqlite_teams) >= 4 else file_teams
    if not normalized:
        raise ValueError(
            f"No se encontraron equipos válidos para {competition.get('name') or key}."
        )

    normalized.sort(key=lambda item: str(item.get("name") or ""))
    path.parent.mkdir(parents=True, exist_ok=True)
    write_json(
        path,
        {
            "competition_key": key,
            "competition_name": competition.get("name"),
            "generated_at": utc_now(),
            "source": "sqlite_recovered" if sqlite_teams else "existing_file",
            "total_teams": len(normalized),
            "teams": normalized,
        },
    )
    return normalized, path

def construir_url_equipo(team: dict[str, Any]) -> str:
    team_id = int(team["team_id"])
    slug = str(team.get("slug") or team_id)

    return (
        "https://www.sofascore.com/team/football/"
        f"{slug}/{team_id}#tab:matches"
    )


def construir_url_partido(event: dict[str, Any]) -> str:
    event_id = int(event["id"])
    custom_id = event.get("customId")
    slug = event.get("slug")

    if not slug:
        home = event.get("homeTeam", {})
        away = event.get("awayTeam", {})
        slug = (
            f"{home.get('slug') or 'home'}-"
            f"{away.get('slug') or 'away'}"
        )

    if custom_id:
        return (
            "https://www.sofascore.com/football/match/"
            f"{slug}/{custom_id}#id:{event_id}"
        )

    return (
        "https://www.sofascore.com/football/match/"
        f"{slug}/#id:{event_id}"
    )


def iter_objects(data: Any) -> Iterator[dict[str, Any]]:
    if isinstance(data, dict):
        yield data

        for value in data.values():
            yield from iter_objects(value)

    elif isinstance(data, list):
        for value in data:
            yield from iter_objects(value)


def extract_events(data: Any) -> list[dict[str, Any]]:
    events: dict[int, dict[str, Any]] = {}

    for obj in iter_objects(data):
        possible = obj.get("events")

        if isinstance(possible, list):
            for event in possible:
                if not isinstance(event, dict):
                    continue

                event_id = event.get("id")

                if event_id is not None:
                    events[int(event_id)] = event

        if (
            obj.get("id") is not None
            and "homeTeam" in obj
            and "awayTeam" in obj
        ):
            events[int(obj["id"])] = obj

    return list(events.values())


def tournament_id(event: dict[str, Any]) -> int | None:
    tournament = event.get("tournament", {})
    unique = tournament.get("uniqueTournament", {})
    value = unique.get("id") or tournament.get("id")

    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def season_id(event: dict[str, Any]) -> int | None:
    value = event.get("season", {}).get("id")

    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def is_upcoming(event: dict[str, Any]) -> bool:
    status = str(event.get("status", {}).get("type", "")).lower()

    if status in {
        "finished",
        "abandoned",
    }:
        return False

    try:
        timestamp = int(event.get("startTimestamp") or 0)
    except (TypeError, ValueError):
        return False

    # La interfaz clasifica después PRÓXIMO, EN VIVO, APLAZADO o CANCELADO.
    # Aquí se conserva el evento activo aunque el kickoff ya haya ocurrido.
    return timestamp > 0


def _score_value(event: dict[str, Any], side: str) -> int | None:
    score = event.get(f"{side}Score")
    if not isinstance(score, dict):
        return None
    for key in ("current", "display", "normaltime", "period1"):
        try:
            value = score.get(key)
            return int(value) if value is not None else None
        except (TypeError, ValueError):
            continue
    return None


def _live_minute_value(event: dict[str, Any]) -> int | None:
    time_info = event.get("time")
    time_minute = (
        time_info.get("minute")
        if isinstance(time_info, dict)
        else None
    )
    for value in (
        event.get("minute"),
        event.get("currentMinute"),
        time_minute,
    ):
        try:
            minute = int(value)
        except (TypeError, ValueError):
            continue
        if 0 <= minute <= 180:
            return minute
    return None


def event_summary(event: dict[str, Any]) -> dict[str, Any]:
    home = event.get("homeTeam", {})
    away = event.get("awayTeam", {})
    tournament = event.get("tournament", {})
    unique = tournament.get("uniqueTournament", {})
    season = event.get("season", {})

    timestamp = int(event.get("startTimestamp") or 0)

    round_info = event.get("roundInfo", {})
    if not isinstance(round_info, dict):
        round_info = {}

    return {
        "event_id": int(event["id"]),
        "start_timestamp": timestamp,
        "kickoff": (
            datetime.fromtimestamp(
                timestamp,
                tz=timezone.utc,
            ).isoformat()
            if timestamp > 0
            else None
        ),
        "status": event.get("status", {}).get("type"),
        "status_description": event.get("status", {}).get("description"),
        "live_minute": _live_minute_value(event),
        "home_score": _score_value(event, "home"),
        "away_score": _score_value(event, "away"),
        "competition_id": unique.get("id") or tournament.get("id"),
        "competition_name": unique.get("name") or tournament.get("name"),
        "season_id": season.get("id"),
        "season_name": season.get("name"),
        "round": round_info.get("round"),
        "round_name": (
            round_info.get("name")
            or round_info.get("roundName")
        ),
        "round_slug": round_info.get("slug"),
        "group": (
            round_info.get("group")
            or tournament.get("groupName")
        ),
        "stage": (
            round_info.get("stage")
            or tournament.get("name")
        ),
        "cup_round_type": round_info.get("cupRoundType"),
        "home_team_id": home.get("id"),
        "home_team": home.get("name"),
        "away_team_id": away.get("id"),
        "away_team": away.get("name"),
        "venue": event.get("venue", {}).get("name"),
        "url": construir_url_partido(event),
    }


def detectar_verificacion(page: Page) -> bool:
    try:
        text = page.locator("body").inner_text(timeout=5_000).lower()
    except Exception:
        return False

    markers = (
        "verify you are human",
        "verifica que eres humano",
        "verification required",
        "captcha",
        "access denied",
        "acceso denegado",
        "unusual traffic",
        "tráfico inusual",
    )

    return any(marker in text for marker in markers)


def detectar_error_cliente(page: Page) -> bool:
    """Detecta la pantalla vacía de error del frontend de SofaScore."""

    try:
        title = str(page.title() or "").lower()
    except Exception:
        title = ""
    try:
        text = page.locator("body").inner_text(timeout=5_000).lower()
    except Exception:
        text = ""
    markers = (
        "application error",
        "client-side exception",
        "error de aplicación",
        "excepción del lado del cliente",
    )
    combined = f"{title}\n{text}"
    return any(marker in combined for marker in markers)


def abrir_pestana_partidos(page: Page) -> None:
    patterns = (
        r"^Matches$",
        r"^Partidos$",
        r"^Fixtures$",
        r"^Calendario$",
    )

    for pattern in patterns:
        regex = re.compile(pattern, re.IGNORECASE)

        for locator in (
            page.get_by_role("tab", name=regex),
            page.get_by_role("button", name=regex),
            page.get_by_role("link", name=regex),
            page.get_by_text(regex, exact=True),
        ):
            try:
                count = locator.count()
            except Exception:
                continue

            for index in range(count):
                element = locator.nth(index)

                try:
                    if not element.is_visible():
                        continue

                    element.scroll_into_view_if_needed(timeout=5_000)
                    element.click(timeout=8_000)
                    page.wait_for_timeout(2_000)
                    return
                except Exception:
                    continue



def capture_team_upcoming(
    page: Page,
    team: dict[str, Any],
    competition_id: int,
    target_season_id: int | None,
    per_team: int,
) -> list[dict[str, Any]]:
    """Consulta un equipo reutilizando siempre la misma pestaña."""
    team_id = int(team["team_id"])
    captured: dict[int, dict[str, Any]] = {}
    endpoint_seen = False

    def capture_document(data: Any) -> None:
        for event in extract_events(data):
            event_id = event.get("id")
            if event_id is None or not is_upcoming(event):
                continue
            if tournament_id(event) != competition_id:
                continue
            current_season_id = season_id(event)
            if (
                target_season_id is not None
                and current_season_id != target_season_id
            ):
                continue
            captured[int(event_id)] = event

    def ordered_events() -> list[dict[str, Any]]:
        return sorted(
            captured.values(),
            key=lambda event: (
                int(event.get("startTimestamp") or 0),
                int(event.get("id") or 0),
            ),
        )[:per_team]

    def process_response(response: Response) -> None:
        nonlocal endpoint_seen
        if response.status != 200:
            return
        clean_url = response.url.split("?")[0]
        if f"/api/v1/team/{team_id}/events/next/" not in clean_url:
            return
        endpoint_seen = True
        try:
            data = response.json()
        except Exception:
            return
        capture_document(data)

    page.on("response", process_response)
    try:
        # Ruta normal: la API de calendario dentro de la sesión de Brave.
        # Evita cargar el frontend React de cada equipo, que puede mostrar
        # "Application error" aunque el endpoint de datos esté disponible.
        api_answered = False
        for page_index in range(3):
            status, document = _browser_fetch_json(
                page,
                f"/api/v1/team/{team_id}/events/next/{page_index}",
            )
            if status != 200 or not isinstance(document, dict):
                break
            api_answered = True
            capture_document(document)
            if len(captured) >= per_team:
                break
            has_next = document.get("hasNextPage")
            if has_next is False:
                break

        if api_answered:
            return ordered_events()

        # Respaldo: solo si la API desde la sesión no respondió, se intenta la
        # página visual y se intercepta el endpoint como en versiones previas.
        page.goto(
            construir_url_equipo(team),
            wait_until="domcontentloaded",
            timeout=PAGE_TIMEOUT_MS,
        )
        page.wait_for_timeout(PAGE_WAIT_MS)
        if detectar_verificacion(page):
            raise RuntimeError(
                f"Verificación detectada al abrir {team.get('name')}."
            )
        client_error = detectar_error_cliente(page)
        if not client_error:
            abrir_pestana_partidos(page)
            for _ in range(NETWORK_WAIT_SECONDS):
                if endpoint_seen:
                    break
                page.wait_for_timeout(1_000)

        # El frontend de SofaScore puede fallar aunque su API siga operativa.
        # En ese caso (o si la pestaña no disparó el endpoint) se consulta el
        # mismo calendario desde la sesión de Brave y se evita perder al equipo.
        if client_error or not endpoint_seen:
            for page_index in range(3):
                status, document = _browser_fetch_json(
                    page,
                    f"/api/v1/team/{team_id}/events/next/{page_index}",
                )
                if status != 200 or not isinstance(document, dict):
                    break
                capture_document(document)
                if len(captured) >= per_team:
                    break
        return ordered_events()
    finally:
        page.remove_listener("response", process_response)





def _browser_fetch_json(page: Page, path: str) -> tuple[int, dict[str, Any] | None]:
    """Consulta la API desde una pestaña de SofaScore para evitar HTTP 403."""
    if not str(page.url).startswith("https://www.sofascore.com"):
        page.goto(
            "https://www.sofascore.com/",
            wait_until="domcontentloaded",
            timeout=PAGE_TIMEOUT_MS,
        )
        page.wait_for_timeout(1_500)
    url = path if path.startswith("http") else f"https://www.sofascore.com{path}"
    result = page.evaluate(
        """
        async (url) => {
          try {
            const response = await fetch(url, {
              credentials: 'include',
              headers: { 'accept': 'application/json, text/plain, */*' }
            });
            const text = await response.text();
            let data = null;
            try { data = JSON.parse(text); } catch (_) {}
            return { status: response.status, data: data };
          } catch (error) {
            return { status: 0, data: null, error: String(error) };
          }
        }
        """,
        url,
    )
    if not isinstance(result, dict):
        return 0, None
    status = int(result.get("status") or 0)
    data = result.get("data")
    return status, data if isinstance(data, dict) else None


def _season_candidates_from_browser(
    page: Page,
    competition: dict[str, Any],
) -> list[int]:
    competition_id = int(competition["source_competition_id"])
    candidates: list[int] = []
    try:
        configured = int(competition.get("season_id"))
    except (TypeError, ValueError):
        configured = 0
    if configured > 0:
        candidates.append(configured)

    status, document = _browser_fetch_json(
        page,
        f"/api/v1/unique-tournament/{competition_id}/seasons",
    )
    if status == 200 and isinstance(document, dict):
        seasons = document.get("seasons")
        if isinstance(seasons, list):
            current: list[int] = []
            others: list[int] = []
            wanted = _normalized_text(
                competition.get("season_name") or competition.get("season")
            )
            for row in seasons:
                if not isinstance(row, dict):
                    continue
                try:
                    season_id_value = int(row.get("id"))
                except (TypeError, ValueError):
                    continue
                name = _normalized_text(row.get("name") or row.get("year"))
                if bool(row.get("isCurrent")) or (wanted and wanted in name):
                    current.append(season_id_value)
                else:
                    others.append(season_id_value)
            for value in [*current, *others[:6]]:
                if value not in candidates:
                    candidates.append(value)
    return candidates


def capture_competition_upcoming(
    page: Page,
    competition: dict[str, Any],
    max_pages: int = 4,
) -> tuple[list[dict[str, Any]], int | None]:
    """Obtiene una liga completa con una sola pestaña y una sola familia API.

    Es el arranque rápido para Liga MX, LigaPro y Brasil cuando su calendario
    local está vacío. Si la temporada configurada quedó antigua, prueba también
    la temporada actual publicada por SofaScore.
    """
    competition_id = int(competition["source_competition_id"])
    seasons = _season_candidates_from_browser(page, competition)
    if not seasons:
        try:
            seasons = [int(competition["season_id"])]
        except (KeyError, TypeError, ValueError):
            seasons = []

    failures: list[str] = []
    for season_value in seasons:
        captured: dict[int, dict[str, Any]] = {}
        for page_number in range(max(1, int(max_pages))):
            endpoints = (
                f"/api/v1/unique-tournament/{competition_id}/season/{season_value}/events/next/{page_number}",
                f"/api/v1/tournament/{competition_id}/season/{season_value}/events/next/{page_number}",
            )
            document = None
            endpoint_status = 0
            for endpoint in endpoints:
                endpoint_status, candidate = _browser_fetch_json(page, endpoint)
                if endpoint_status == 200 and isinstance(candidate, dict):
                    document = candidate
                    break
            if document is None:
                failures.append(f"season={season_value} page={page_number} status={endpoint_status}")
                if page_number == 0:
                    break
                continue

            page_events = extract_events(document)
            for event in page_events:
                try:
                    event_id = int(event.get("id"))
                except (TypeError, ValueError):
                    continue
                # El endpoint de temporada es la primera barrera, pero se
                # valida también cada evento antes de persistirlo. Esto impide
                # mezclar torneos domésticos o temporadas anteriores.
                if tournament_id(event) != competition_id:
                    continue
                current_season_id = season_id(event)
                if current_season_id != season_value:
                    continue
                if is_upcoming(event):
                    captured[event_id] = event

            has_next = document.get("hasNextPage")
            if has_next is False or not page_events:
                break

        if captured:
            ordered = sorted(
                captured.values(),
                key=lambda event: (
                    int(event.get("startTimestamp") or 0),
                    int(event.get("id") or 0),
                ),
            )
            return ordered, season_value

    if failures:
        print("   ⚠ Arranque rápido sin eventos: " + "; ".join(failures[-4:]))
    return [], seasons[0] if seasons else None


def bootstrap_competition_schedule(
    page: Page,
    competition: dict[str, Any],
) -> dict[str, Any]:
    """Crea matches_upcoming.json directamente desde el calendario de liga."""
    key = slugify(str(competition["key"]))
    events, resolved_season_id = capture_competition_upcoming(page, competition)
    if not events:
        return {
            "competition_key": key,
            "status": "EMPTY",
            "event_ids": [],
            "team_ids": [],
        }

    summaries = [event_summary(event) for event in events]
    summaries.sort(
        key=lambda row: (
            int(row.get("start_timestamp") or 0),
            int(row.get("event_id") or 0),
        )
    )

    team_catalog: dict[int, dict[str, Any]] = {}
    by_team: dict[int, list[dict[str, Any]]] = {}
    for event, summary in zip(events, summaries):
        for side in ("homeTeam", "awayTeam"):
            team = event.get(side)
            if not isinstance(team, dict):
                continue
            try:
                team_id = int(team.get("id"))
            except (TypeError, ValueError):
                continue
            name = str(team.get("name") or team_id)
            team_catalog[team_id] = {
                "team_id": team_id,
                "name": name,
                "slug": str(team.get("slug") or slugify(name)),
            }
            by_team.setdefault(team_id, []).append(summary)

    output_dir = COMPETITIONS_DIR / key
    output_dir.mkdir(parents=True, exist_ok=True)
    schedule_path = output_dir / "matches_upcoming.json"
    teams_path = output_dir / "next_match_by_team.json"
    catalog_path = output_dir / "teams.json"

    write_json(
        schedule_path,
        {
            "competition_key": key,
            "competition_name": competition.get("name"),
            "source_competition_id": competition.get("source_competition_id"),
            "season_id": resolved_season_id,
            "season_name": competition.get("season_name"),
            "generated_at": utc_now(),
            "selection_rule": "competition_fast_bootstrap",
            "refresh_scope": "single_league_api_request",
            "selection_description": (
                "Calendario próximo obtenido desde la competición en una sola "
                "pestaña; posteriormente el mantenimiento continúa por micro-lotes."
            ),
            "total_upcoming_matches": len(summaries),
            "matches": summaries,
            "failures": [],
        },
    )

    team_rows: list[dict[str, Any]] = []
    for team_id, team in sorted(team_catalog.items(), key=lambda item: item[1]["name"]):
        team_matches = sorted(
            by_team.get(team_id, []),
            key=lambda row: int(row.get("start_timestamp") or 0),
        )
        next_match = dict(team_matches[0]) if team_matches else None
        team_rows.append(
            {
                "team_id": team_id,
                "team_name": team["name"],
                "next_event_id": None if next_match is None else int(next_match["event_id"]),
                "next_match": next_match,
                "updated_at": utc_now(),
                "refreshed_in_current_run": True,
            }
        )

    write_json(
        teams_path,
        {
            "competition_key": key,
            "competition_name": competition.get("name"),
            "source_competition_id": competition.get("source_competition_id"),
            "season_id": resolved_season_id,
            "season_name": competition.get("season_name"),
            "generated_at": utc_now(),
            "selection_rule": "competition_fast_bootstrap",
            "refresh_scope": "single_league_api_request",
            "processed_team_ids": sorted(team_catalog),
            "total_teams": len(team_rows),
            "teams_with_next_match": sum(1 for row in team_rows if row["next_match"]),
            "teams": team_rows,
        },
    )
    write_json(
        catalog_path,
        {
            "competition_key": key,
            "competition_name": competition.get("name"),
            "generated_at": utc_now(),
            "source": "competition_calendar_bootstrap",
            "total_teams": len(team_catalog),
            "teams": list(sorted(team_catalog.values(), key=lambda row: row["name"])),
        },
    )

    sqlite_report = upsert_upcoming_matches_sqlite(
        competition,
        summaries,
    )
    return {
        "competition_key": key,
        "competition_name": competition.get("name"),
        "status": "OK",
        "event_ids": [int(row["event_id"]) for row in summaries],
        "team_ids": sorted(team_catalog),
        "season_id": resolved_season_id,
        "schedule_path": str(schedule_path),
        "sqlite_upsert": sqlite_report,
    }

FINAL_MATCH_STATUSES = {
    "FT",
    "FINISHED",
    "FINAL",
    "AET",
    "PEN",
    "ABANDONED",
}


def _upcoming_status_for_sqlite(value: Any) -> str:
    normalized = _normalized_text(value).replace(" ", "")
    mapping = {
        "notstarted": "NS",
        "scheduled": "NS",
        "ns": "NS",
        "live": "LIVE",
        "inprogress": "LIVE",
        "inplay": "LIVE",
        "1sthalf": "LIVE",
        "2ndhalf": "LIVE",
        "halftime": "HT",
        "postponed": "POSTPONED",
        "delayed": "DELAYED",
        "cancelled": "CANCELLED",
        "canceled": "CANCELLED",
    }
    return mapping.get(normalized, str(value or "NS").strip().upper() or "NS")


def _validated_kickoff(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        raise ValueError("El próximo no contiene kickoff.")
    candidate = text[:-1] + "+00:00" if text.endswith("Z") else text
    parsed = datetime.fromisoformat(candidate)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc).isoformat()


def _resolve_exact_league(
    connection: sqlite3.Connection,
    competition: dict[str, Any],
) -> sqlite3.Row:
    try:
        tournament_value = int(competition["source_competition_id"])
        season_value = int(competition["season_id"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(
            "La configuración no contiene tournament_id y season_id válidos."
        ) from exc

    rows = connection.execute(
        """
        SELECT league_id, name, country, season,
               source_tournament_id, source_season_id
        FROM leagues
        WHERE source_tournament_id = ?
          AND source_season_id = ?
        ORDER BY active DESC, league_id
        """,
        (tournament_value, season_value),
    ).fetchall()

    # ODDSHUNTER_REGISTRY_LEAGUE_ID_FIRST_V1
    # El league_id explÃ­cito del registry es la identidad canÃ³nica.
    # La cantidad de histÃ³rico NUNCA puede sustituir esa identidad.
    exact_league_id = competition.get("league_id")
    if exact_league_id is not None:
        try:
            exact_id = int(exact_league_id)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"league_id canÃ³nico invÃ¡lido: {exact_league_id!r}") from exc
        exact_rows = []
        for _oh_row in rows:
            try:
                _oh_lid = int(_oh_row["league_id"])
            except Exception:
                _oh_lid = int(_oh_row[0])
            if _oh_lid == exact_id:
                exact_rows.append(_oh_row)
        if len(exact_rows) != 1:
            raise ValueError(
                f"{competition.get('key')}: league_id canÃ³nico {exact_id} no coincide de forma Ãºnica "
                f"con tournament_id={tournament_value}, season_id={season_value}; coincidencias={len(exact_rows)}."
            )
        print(
            "[LEAGUE_RESOLVER_REGISTRY_EXACT] "
            f"key={competition.get('key')} tournament_id={tournament_value} "
            f"season_id={season_value} chosen={exact_id}"
        )
        return exact_rows[0]

    # ODDSHUNTER_DUPLICATE_LEAGUE_FILTER_ROWS_V1
    # Conserva el contrato/retorno original de _resolve_exact_league.
    # Si hay varias filas para la misma pareja tournament/season,
    # filtra a una sola ÚNICAMENTE cuando la evidencia SQLite es
    # estrictamente superior. En empate, el guard original sigue fallando.
    if len(rows) > 1:
        _oh_ranked = []
        _oh_row_by_lid = {}
        _oh_has_memberships = (
            connection.execute(
                "SELECT 1 FROM sqlite_master "
                "WHERE type='table' AND name='team_competition_memberships'"
            ).fetchone() is not None
        )
        for _oh_row in rows:
            try:
                _oh_lid = int(_oh_row["league_id"])
            except Exception:
                _oh_lid = int(_oh_row[0])
            _oh_row_by_lid[_oh_lid] = _oh_row
            _oh_matches = int(
                connection.execute(
                    "SELECT COUNT(*) FROM matches WHERE league_id=?",
                    (_oh_lid,),
                ).fetchone()[0]
            )
            _oh_finished = int(
                connection.execute(
                    "SELECT COUNT(*) FROM matches "
                    "WHERE league_id=? "
                    "AND UPPER(COALESCE(status,'')) IN ('FT','FINISHED')",
                    (_oh_lid,),
                ).fetchone()[0]
            )
            _oh_stats = int(
                connection.execute(
                    "SELECT COUNT(*) FROM team_match_stats s "
                    "JOIN matches m ON m.match_id=s.match_id "
                    "WHERE m.league_id=?",
                    (_oh_lid,),
                ).fetchone()[0]
            )
            _oh_memberships = 0
            if _oh_has_memberships:
                _oh_memberships = int(
                    connection.execute(
                        "SELECT COUNT(*) "
                        "FROM team_competition_memberships "
                        "WHERE league_id=?",
                        (_oh_lid,),
                    ).fetchone()[0]
                )
            _oh_score = (
                _oh_stats,
                _oh_finished,
                _oh_matches,
                _oh_memberships,
            )
            _oh_ranked.append((_oh_score, _oh_lid))
        _oh_ranked.sort(reverse=True)
        if (
            len(_oh_ranked) >= 2
            and _oh_ranked[0][0] != _oh_ranked[1][0]
            and _oh_ranked[0][0] > (0, 0, 0, 0)
        ):
            _oh_chosen = int(_oh_ranked[0][1])
            rows = [_oh_row_by_lid[_oh_chosen]]
            print(
                "[LEAGUE_RESOLVER_CANONICAL] "
                f"key={competition.get('key')} "
                f"tournament_id={competition.get('source_competition_id')} "
                f"season_id={competition.get('season_id')} "
                f"candidates={_oh_ranked} "
                f"chosen={_oh_chosen}"
            )
    if len(rows) != 1:
        raise ValueError(
            "No se resolvió una liga SQLite única para "
            f"tournament_id={tournament_value}, season_id={season_value}; "
            f"coincidencias={len(rows)}."
        )
    return rows[0]


def _resolve_exact_team(
    connection: sqlite3.Connection,
    source_team_id: Any,
    expected_name: Any,
) -> sqlite3.Row:
    try:
        source_value = int(source_team_id)
    except (TypeError, ValueError) as exc:
        raise ValueError(
            f"sofascore_team_id inválido: {source_team_id!r}."
        ) from exc
    rows = connection.execute(
        """
        SELECT team_id, sofascore_id, name, league_id
        FROM teams
        WHERE sofascore_id = ?
        """,
        (source_value,),
    ).fetchall()
    if len(rows) != 1:
        raise ValueError(
            f"No existe un equipo único con sofascore_id={source_value}."
        )
    row = rows[0]
    if not str(row["name"] or "").strip():
        raise ValueError(f"El equipo {source_value} no tiene nombre en SQLite.")
    if expected_name and _normalized_text(expected_name) != _normalized_text(row["name"]):
        # No se altera la identidad guardada. La diferencia se conserva en el
        # reporte para revisión, pero sofascore_id continúa siendo autoritativo.
        pass
    return row


def upsert_upcoming_matches_sqlite(
    competition: dict[str, Any],
    upcoming_rows: list[dict[str, Any]],
) -> dict[str, Any]:
    """Inserta/actualiza próximos sin tocar resultados ni estadísticas.

    Inspecciona el esquema real, usa sofascore_id como identidad única y
    protege cualquier partido que ya tenga resultado final o goles guardados.
    """

    report: dict[str, Any] = {
        "competition_key": slugify(str(competition.get("key") or "")),
        "generated_at": utc_now(),
        "database": str(DB_PATH),
        "requested_event_ids": [],
        "inserted_event_ids": [],
        "updated_event_ids": [],
        "protected_final_event_ids": [],
        "verified_rows": [],
        "errors": [],
    }
    if not DB_PATH.is_file():
        raise FileNotFoundError(DB_PATH)

    unique_rows: dict[int, dict[str, Any]] = {}
    for raw in upcoming_rows:
        if not isinstance(raw, dict):
            continue
        try:
            event_id = int(raw.get("event_id"))
        except (TypeError, ValueError):
            raise ValueError(f"event_id inválido en próximo: {raw!r}")
        if event_id <= 0:
            raise ValueError(f"event_id debe ser positivo: {event_id}")
        unique_rows[event_id] = dict(raw)
    report["requested_event_ids"] = sorted(unique_rows)

    connection = sqlite3.connect(DB_PATH, timeout=30)
    connection.row_factory = sqlite3.Row
    try:
        connection.execute("PRAGMA foreign_keys = ON")
        columns = _table_columns(connection, "matches")
        required = {
            "match_id", "sofascore_id", "league_id", "season", "kickoff",
            "home_team_id", "away_team_id", "home_goals", "away_goals",
            "status", "updated_at", "identity_validated",
        }
        missing = sorted(required - columns)
        if missing:
            raise RuntimeError(
                "La tabla matches no contiene las columnas reales requeridas: "
                + ", ".join(missing)
            )

        league = _resolve_exact_league(connection, competition)
        expected_tournament = int(league["source_tournament_id"])
        expected_season = int(league["source_season_id"])
        league_id = int(league["league_id"])
        season_name = str(league["season"])
        report["resolved_identity"] = {
            "league_id": league_id,
            "tournament_id": expected_tournament,
            "season_id": expected_season,
            "season_name": season_name,
        }

        prepared: list[dict[str, Any]] = []
        for event_id, row in sorted(unique_rows.items()):
            try:
                tournament_value = int(
                    row.get("competition_id")
                    or row.get("tournament_id")
                    or competition.get("source_competition_id")
                )
                season_value = int(
                    row.get("season_id")
                    or competition.get("season_id")
                )
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    f"Identidad tournament/season inválida para event_id={event_id}."
                ) from exc
            if tournament_value != expected_tournament:
                raise ValueError(
                    f"event_id={event_id}: tournament_id={tournament_value}, "
                    f"esperado={expected_tournament}."
                )
            if season_value != expected_season:
                raise ValueError(
                    f"event_id={event_id}: season_id={season_value}, "
                    f"esperado={expected_season}."
                )

            home = _resolve_exact_team(
                connection,
                row.get("home_team_id"),
                row.get("home_team"),
            )
            away = _resolve_exact_team(
                connection,
                row.get("away_team_id"),
                row.get("away_team"),
            )
            home_id = int(home["team_id"])
            away_id = int(away["team_id"])
            if home_id == away_id:
                raise ValueError(
                    f"event_id={event_id}: local y visitante son el mismo equipo."
                )

            prepared.append(
                {
                    "event_id": event_id,
                    "league_id": league_id,
                    "season": season_name,
                    "kickoff": _validated_kickoff(
                        row.get("kickoff")
                        or (
                            datetime.fromtimestamp(
                                int(row.get("start_timestamp") or 0),
                                tz=timezone.utc,
                            ).isoformat()
                            if int(row.get("start_timestamp") or 0) > 0
                            else None
                        )
                    ),
                    "home_team_id": home_id,
                    "away_team_id": away_id,
                    "home_source_id": int(home["sofascore_id"]),
                    "away_source_id": int(away["sofascore_id"]),
                    "home_team": str(home["name"]),
                    "away_team": str(away["name"]),
                    "status": _upcoming_status_for_sqlite(row.get("status")),
                }
            )

        connection.execute("BEGIN IMMEDIATE")
        for row in prepared:
            event_id = int(row["event_id"])
            existing = connection.execute(
                """
                SELECT match_id, sofascore_id, league_id, season, kickoff,
                       home_team_id, away_team_id, home_goals, away_goals,
                       status, identity_validated
                FROM matches
                WHERE sofascore_id = ?
                """,
                (event_id,),
            ).fetchone()

            if existing is None:
                connection.execute(
                    """
                    INSERT INTO matches (
                        sofascore_id, league_id, season, kickoff,
                        home_team_id, away_team_id, status,
                        identity_validated
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, 1)
                    """,
                    (
                        event_id,
                        row["league_id"],
                        row["season"],
                        row["kickoff"],
                        row["home_team_id"],
                        row["away_team_id"],
                        row["status"],
                    ),
                )
                report["inserted_event_ids"].append(event_id)
            else:
                existing_status = str(existing["status"] or "").strip().upper()
                is_final = (
                    existing_status in FINAL_MATCH_STATUSES
                    or existing["home_goals"] is not None
                    or existing["away_goals"] is not None
                )
                if is_final:
                    report["protected_final_event_ids"].append(event_id)
                else:
                    connection.execute(
                        """
                        UPDATE matches
                        SET league_id = ?,
                            season = ?,
                            kickoff = ?,
                            home_team_id = ?,
                            away_team_id = ?,
                            status = ?,
                            identity_validated = 1,
                            updated_at = CURRENT_TIMESTAMP
                        WHERE sofascore_id = ?
                        """,
                        (
                            row["league_id"],
                            row["season"],
                            row["kickoff"],
                            row["home_team_id"],
                            row["away_team_id"],
                            row["status"],
                            event_id,
                        ),
                    )
                    report["updated_event_ids"].append(event_id)

            verified = connection.execute(
                """
                SELECT m.match_id, m.sofascore_id, m.league_id, m.season,
                       m.kickoff, m.home_team_id, m.away_team_id,
                       m.home_goals, m.away_goals, m.status,
                       h.sofascore_id AS home_source_id,
                       h.name AS home_team,
                       a.sofascore_id AS away_source_id,
                       a.name AS away_team,
                       l.source_tournament_id,
                       l.source_season_id
                FROM matches AS m
                JOIN teams AS h ON h.team_id = m.home_team_id
                JOIN teams AS a ON a.team_id = m.away_team_id
                JOIN leagues AS l ON l.league_id = m.league_id
                WHERE m.sofascore_id = ?
                """,
                (event_id,),
            ).fetchone()
            if verified is None:
                raise RuntimeError(
                    f"event_id={event_id} no pudo verificarse dentro de la transacción."
                )
            report["verified_rows"].append(dict(verified))

        duplicate_count = connection.execute(
            """
            SELECT COUNT(*)
            FROM (
                SELECT sofascore_id
                FROM matches
                WHERE sofascore_id IN ({})
                GROUP BY sofascore_id
                HAVING COUNT(*) > 1
            )
            """.format(
                ",".join("?" for _ in report["requested_event_ids"]) or "NULL"
            ),
            tuple(report["requested_event_ids"]),
        ).fetchone()[0]
        if int(duplicate_count or 0) != 0:
            raise RuntimeError("El UPSERT produciría duplicados de event_id.")
        connection.commit()

        rows_after = connection.execute(
            """
            SELECT sofascore_id
            FROM matches
            WHERE league_id = ?
              AND sofascore_id IN ({})
            ORDER BY sofascore_id
            """.format(
                ",".join("?" for _ in report["requested_event_ids"]) or "NULL"
            ),
            (league_id, *report["requested_event_ids"]),
        ).fetchall()
        actual_ids = [int(row[0]) for row in rows_after]
        report["sqlite_event_ids_after"] = actual_ids
        report["missing_event_ids"] = sorted(
            set(report["requested_event_ids"]) - set(actual_ids)
        )
        report["unexpected_event_ids"] = sorted(
            set(actual_ids) - set(report["requested_event_ids"])
        )
        report["upcoming_duplicates"] = int(duplicate_count or 0)
        if report["missing_event_ids"] or report["unexpected_event_ids"]:
            raise RuntimeError(
                "La verificación post-commit no coincide con los próximos solicitados."
            )
    except Exception as exc:
        try:
            connection.rollback()
        except sqlite3.Error:
            pass
        report["errors"].append(f"{type(exc).__name__}: {exc}")
        raise
    finally:
        connection.close()

    report["completed_at"] = utc_now()
    report["success"] = True
    audit_path = (
        DATA_DIR
        / "automation"
        / "upcoming_sqlite"
        / f"{report['competition_key']}_last.json"
    )
    write_json(audit_path, report)
    report["audit_path"] = str(audit_path)
    return report


def load_existing_team_rows(
    competition_key: str,
    expected_season_id: int | None = None,
) -> dict[int, dict[str, Any]]:
    path = (
        COMPETITIONS_DIR
        / competition_key
        / "next_match_by_team.json"
    )

    if not path.exists():
        return {}

    try:
        document = read_json(path)
    except Exception:
        return {}

    if expected_season_id is not None:
        try:
            stored_season_id = int(document.get("season_id"))
        except (TypeError, ValueError):
            stored_season_id = None
        if stored_season_id != int(expected_season_id):
            return {}

    rows = document.get("teams")

    if not isinstance(rows, list):
        return {}

    result: dict[int, dict[str, Any]] = {}

    for row in rows:
        if not isinstance(row, dict):
            continue

        try:
            team_id = int(row["team_id"])
        except (KeyError, TypeError, ValueError):
            continue

        result[team_id] = dict(row)

    return result


def load_existing_schedule_rows(
    competition_key: str,
    expected_season_id: int | None = None,
) -> dict[int, dict[str, Any]]:
    path = (
        COMPETITIONS_DIR
        / competition_key
        / "matches_upcoming.json"
    )
    if not path.exists():
        return {}
    try:
        document = read_json(path)
    except Exception:
        return {}
    if expected_season_id is not None:
        try:
            stored_season_id = int(document.get("season_id"))
        except (TypeError, ValueError):
            stored_season_id = None
        if stored_season_id != int(expected_season_id):
            return {}
    result: dict[int, dict[str, Any]] = {}
    for row in document.get("matches", []):
        if not isinstance(row, dict):
            continue
        try:
            event_id = int(row.get("event_id"))
        except (TypeError, ValueError):
            continue
        result[event_id] = dict(row)
    return result


def save_results(
    competition: dict[str, Any],
    teams: list[dict[str, Any]],
    matches: dict[int, dict[str, Any]],
    by_team: dict[int, list[int]],
    failures: list[dict[str, Any]],
    successful_team_ids: set[int],
    merge_existing: bool,
) -> tuple[Path, Path]:
    key = slugify(str(competition["key"]))
    output_dir = COMPETITIONS_DIR / key
    output_dir.mkdir(parents=True, exist_ok=True)

    existing_rows = (
        load_existing_team_rows(
            key,
            (
                int(competition["season_id"])
                if competition.get("season_id") is not None
                else None
            ),
        )
        if merge_existing
        else {}
    )
    existing_schedule_rows = (
        load_existing_schedule_rows(
            key,
            (
                int(competition["season_id"])
                if competition.get("season_id") is not None
                else None
            ),
        )
        if merge_existing
        else {}
    )

    team_rows: list[dict[str, Any]] = []

    for team in teams:
        team_id = int(team["team_id"])
        team_name = team.get("name")

        if team_id not in successful_team_ids:
            if team_id in existing_rows:
                preserved = dict(existing_rows[team_id])
                preserved["team_id"] = team_id
                preserved["team_name"] = team_name
                preserved["refreshed_in_current_run"] = False
                team_rows.append(preserved)
            else:
                # Un equipo no procesado en este micro-lote no puede quedar
                # marcado como actualizado. Mantener updated_at=None hace que
                # continúe pendiente en el siguiente ciclo de la cola.
                team_rows.append(
                    {
                        "team_id": team_id,
                        "team_name": team_name,
                        "next_event_id": None,
                        "next_match": None,
                        "updated_at": None,
                        "refreshed_in_current_run": False,
                    }
                )
            continue

        event_ids = [
            int(event_id)
            for event_id in by_team.get(team_id, [])
            if int(event_id) in matches
        ]
        event_ids.sort(
            key=lambda event_id: (
                int(matches[event_id].get("start_timestamp") or 0),
                int(event_id),
            )
        )

        next_event_id = event_ids[0] if event_ids else None
        next_match = (
            dict(matches[next_event_id])
            if next_event_id is not None
            else None
        )

        team_rows.append(
            {
                "team_id": team_id,
                "team_name": team_name,
                "next_event_id": next_event_id,
                "next_match": next_match,
                "updated_at": utc_now(),
                "refreshed_in_current_run": True,
            }
        )

    # La salida es la unión del siguiente partido individual de cada equipo.
    # Un evento entra si es el próximo de al menos un club, y se deduplica
    # únicamente por event_id.
    selected_by_event: dict[int, dict[str, Any]] = {}
    selected_priority: dict[int, int] = {}
    trigger_teams_by_event: dict[int, list[int]] = {}

    for row in team_rows:
        next_match = row.get("next_match")

        if not isinstance(next_match, dict):
            continue

        try:
            event_id = int(
                row.get("next_event_id")
                or next_match["event_id"]
            )
            team_id = int(row["team_id"])
        except (KeyError, TypeError, ValueError):
            continue

        candidate = dict(next_match)
        candidate["event_id"] = event_id

        # Los datos recién consultados tienen prioridad. Una fila
        # preservada de otro equipo no puede sobrescribir horario, sede
        # o nombres capturados en esta ejecución.
        priority = (
            1
            if bool(row.get("refreshed_in_current_run"))
            else 0
        )
        previous_priority = selected_priority.get(event_id, -1)

        if event_id not in selected_by_event:
            selected_by_event[event_id] = candidate
            selected_priority[event_id] = priority
        elif priority >= previous_priority:
            selected_by_event[event_id] = {
                **selected_by_event[event_id],
                **candidate,
            }
            selected_priority[event_id] = priority

        trigger_teams_by_event.setdefault(event_id, []).append(team_id)

    # Conserva temporalmente los partidos que acaban de comenzar para que la
    # interfaz pueda moverlos de PRÓXIMO a EN VIVO. Se eliminan al confirmarse
    # finished o cuando una fila pre-match lleva más de seis horas vencida.
    current_timestamp = now_timestamp()
    live_retention_start = current_timestamp - 6 * 3600
    for event_id, previous in existing_schedule_rows.items():
        if event_id in selected_by_event:
            continue
        status = str(previous.get("status") or "").strip().casefold()
        if status in {"finished", "ft", "abandoned"}:
            continue
        try:
            kickoff = int(previous.get("start_timestamp") or 0)
        except (TypeError, ValueError):
            kickoff = 0
        explicit_live = status in {
            "live",
            "inprogress",
            "inplay",
            "1sthalf",
            "2ndhalf",
            "halftime",
            "extratime",
            "penalties",
        }
        special = status in {
            "postponed",
            "cancelled",
            "canceled",
            "delayed",
        }
        recently_started = (
            live_retention_start <= kickoff <= current_timestamp
        )
        if explicit_live or special or recently_started:
            selected_by_event[event_id] = dict(previous)
            selected_priority[event_id] = 0

    selected_matches: list[dict[str, Any]] = []

    for event_id, match in selected_by_event.items():
        row = dict(match)
        row["selected_because_next_for_team_ids"] = sorted(
            set(trigger_teams_by_event.get(event_id, []))
        )
        selected_matches.append(row)

    selected_matches.sort(
        key=lambda match: (
            int(match.get("start_timestamp") or 0),
            int(match.get("event_id") or 0),
        )
    )
    team_rows.sort(
        key=lambda row: str(row.get("team_name") or "")
    )

    schedule_path = output_dir / "matches_upcoming.json"
    teams_path = output_dir / "next_match_by_team.json"

    processed_team_ids = sorted(successful_team_ids)

    write_json(
        schedule_path,
        {
            "competition_key": key,
            "competition_name": competition.get("name"),
            "source_competition_id": competition.get(
                "source_competition_id"
            ),
            "season_id": competition.get("season_id"),
            "season_name": competition.get("season_name"),
            "generated_at": utc_now(),
            "selection_rule": SELECTION_RULE,
            "refresh_scope": (
                "incremental_teams"
                if merge_existing
                else "full_league"
            ),
            "processed_team_ids": processed_team_ids,
            "selection_description": (
                "Unión del próximo partido cronológico de cada equipo. "
                "El evento entra si es el próximo de al menos uno de sus "
                "participantes y se conserva una sola vez por event_id."
            ),
            "total_upcoming_matches": len(selected_matches),
            "matches": selected_matches,
            "failures": failures,
        },
    )

    write_json(
        teams_path,
        {
            "competition_key": key,
            "competition_name": competition.get("name"),
            "source_competition_id": competition.get("source_competition_id"),
            "season_id": competition.get("season_id"),
            "season_name": competition.get("season_name"),
            "generated_at": utc_now(),
            "selection_rule": SELECTION_RULE,
            "refresh_scope": (
                "incremental_teams"
                if merge_existing
                else "full_league"
            ),
            "processed_team_ids": processed_team_ids,
            "total_teams": len(team_rows),
            "teams_with_next_match": sum(
                1
                for row in team_rows
                if row.get("next_match") is not None
            ),
            "teams": team_rows,
        },
    )

    sqlite_report = upsert_upcoming_matches_sqlite(
        competition,
        selected_matches,
    )
    print(
        "   SQLite próximos: "
        f"insertados={len(sqlite_report['inserted_event_ids'])}; "
        f"actualizados={len(sqlite_report['updated_event_ids'])}; "
        f"verificados={len(sqlite_report['sqlite_event_ids_after'])}."
    )
    return schedule_path, teams_path





def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Construye la unión del próximo partido de cada equipo. "
            "También puede refrescar solamente los equipos afectados "
            "y combinar el resultado con el calendario existente."
        )
    )

    parser.add_argument(
        "--key",
        required=True,
        help="Clave de competición, por ejemplo: mls",
    )

    parser.add_argument(
        "--per-team",
        type=int,
        default=DEFAULT_MATCHES_PER_TEAM,
        help=(
            "Profundidad interna de búsqueda por equipo. "
            "La salida conserva el primer partido de cada club."
        ),
    )

    parser.add_argument(
        "--team-id",
        type=int,
        action="append",
        help=(
            "Refresca únicamente este team_id de SofaScore. "
            "Puede repetirse varias veces."
        ),
    )

    parser.add_argument(
        "--merge",
        action="store_true",
        help=(
            "Combina los equipos procesados con el calendario existente. "
            "Se activa automáticamente cuando se usa --team-id."
        ),
    )

    return parser




def main() -> None:
    args = build_parser().parse_args()

    try:
        registry = load_registry()
        competition = find_competition(registry, args.key)
        teams, teams_path = load_teams(competition)

        requested_team_ids = {
            int(team_id)
            for team_id in (args.team_id or [])
        }

        if requested_team_ids:
            selected_teams = [
                team
                for team in teams
                if int(team["team_id"]) in requested_team_ids
            ]

            missing_ids = requested_team_ids - {
                int(team["team_id"])
                for team in selected_teams
            }

            if missing_ids:
                raise ValueError(
                    "No se encontraron los team_id: "
                    + ", ".join(str(value) for value in sorted(missing_ids))
                )
        else:
            selected_teams = list(teams)

        merge_existing = bool(args.merge or requested_team_ids)

        competition_id = int(
            competition["source_competition_id"]
        )

        configured_season_id = competition.get("season_id")
        target_season_id = (
            int(configured_season_id)
            if configured_season_id is not None
            else None
        )

        per_team = max(1, min(int(args.per_team), 10))
        brave_path = encontrar_brave()

        print("=" * 80)
        print("ODDSHUNTER — PRÓXIMOS PARTIDOS POR EQUIPO")
        print("=" * 80)
        print(f"Competición: {competition.get('name')}")
        print(f"Equipos registrados: {len(teams)}")
        print(f"Equipos a refrescar: {len(selected_teams)}")
        print(
            "Modo: "
            + (
                "incremental con combinación"
                if merge_existing
                else "sincronización completa"
            )
        )
        print(f"Fuente: {teams_path}")
        print(f"Profundidad por equipo: {per_team}")
        print()

        matches: dict[int, dict[str, Any]] = {}
        by_team: dict[int, list[int]] = {}
        failures: list[dict[str, Any]] = []
        successful_team_ids: set[int] = set()

        with sync_playwright() as playwright:
            context, page = open_brave_session(
                playwright,
                brave_path,
            )

            try:
                for index, team in enumerate(selected_teams, start=1):
                    team_id = int(team["team_id"])
                    team_name = str(team.get("name") or team_id)

                    print(
                        f"[{index:02d}/{len(selected_teams):02d}] "
                        f"{team_name}..."
                    )

                    for browser_attempt in range(2):
                        try:
                            events = capture_team_upcoming(
                                page=page,
                                team=team,
                                competition_id=competition_id,
                                target_season_id=target_season_id,
                                per_team=per_team,
                            )

                            event_ids: list[int] = []

                            for event in events:
                                summary = event_summary(event)
                                event_id = int(summary["event_id"])
                                matches[event_id] = summary
                                event_ids.append(event_id)

                            by_team[team_id] = event_ids
                            successful_team_ids.add(team_id)

                            if events:
                                first = event_summary(events[0])
                                print(
                                    "   ✅ "
                                    f"{first['kickoff']} | "
                                    f"{first['home_team']} vs "
                                    f"{first['away_team']}"
                                )
                            else:
                                print(
                                    "   ⚠️ No se encontró próximo partido "
                                    "de esta competición."
                                )
                            break

                        except Exception as exc:
                            if (
                                browser_attempt == 0
                                and browser_session_lost(exc)
                            ):
                                print(
                                    "   ⚠️ Brave se cerró; se recreará "
                                    "la sesión y se reintentará este equipo una vez."
                                )
                                close_playwright_target(
                                    page,
                                    "página principal dañada",
                                )
                                close_playwright_target(
                                    context,
                                    "contexto de Brave dañado",
                                )
                                context, page = open_brave_session(
                                    playwright,
                                    brave_path,
                                )
                                continue

                            failures.append(
                                {
                                    "team_id": team_id,
                                    "team_name": team_name,
                                    "error": (
                                        f"{type(exc).__name__}: {exc}"
                                    ),
                                }
                            )
                            print(
                                f"   ❌ {type(exc).__name__}: {exc}"
                            )

                            if "verificación" in str(exc).lower():
                                raise
                            break

                    save_results(
                        competition=competition,
                        teams=teams,
                        matches=matches,
                        by_team=by_team,
                        failures=failures,
                        successful_team_ids=successful_team_ids,
                        merge_existing=merge_existing,
                    )

            finally:
                close_playwright_target(page, "página principal")
                close_playwright_target(context, "contexto de Brave")

        schedule_path, teams_output_path = save_results(
            competition=competition,
            teams=teams,
            matches=matches,
            by_team=by_team,
            failures=failures,
            successful_team_ids=successful_team_ids,
            merge_existing=merge_existing,
        )

        print()
        print("=" * 80)
        print("✅ PRÓXIMOS PARTIDOS SINCRONIZADOS")
        print("=" * 80)
        print(f"Equipos refrescados: {len(successful_team_ids)}")
        print(f"Fallos: {len(failures)}")
        print(f"\nCalendario:\n{schedule_path}")
        print(f"\nPróximo partido por equipo:\n{teams_output_path}")

        if failures and not successful_team_ids:
            print(
                "\n❌ Ninguno de los equipos solicitados pudo refrescarse. "
                "El calendario existente se conservó, pero el proceso "
                "devuelve error para que el orquestador programe un reintento."
            )
            raise SystemExit(2)
        if failures:
            print(
                "\n⚠️ Refresco parcial: los equipos fallidos quedaron "
                "registrados para revisión."
            )

    except KeyboardInterrupt:
        print(
            "\n⚠️ Proceso interrumpido. "
            "El avance disponible quedó guardado."
        )
        raise SystemExit(130)

    except Exception as exc:
        print(
            f"\n❌ Error: {type(exc).__name__}: {exc}"
        )
        raise SystemExit(1)


if __name__ == "__main__":
    main()
