from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from playwright.sync_api import sync_playwright

from cloud_match_discovery import discover
from flashscore_xg_client import FlashscoreXGClient
from futbol24_client import Futbol24Client
from xg_pipeline import MatchRef


ROOT = Path(__file__).resolve().parent
ARTIFACTS = ROOT / "artifacts"
CORE_METRICS = ("shots", "shots_on_target", "corners", "yellow_cards")


def _pair_dict(pair: Any) -> dict[str, Any]:
    if pair is None:
        return {"home": None, "away": None}
    return {"home": getattr(pair, "home", None), "away": getattr(pair, "away", None)}


def _matchref(row: dict[str, Any]) -> MatchRef:
    return MatchRef(
        match_id=None,
        kickoff=str(row.get("kickoff") or ""),
        home_team=str(row.get("home_team") or ""),
        away_team=str(row.get("away_team") or ""),
        competition=str(row.get("competition") or ""),
        season=str(row.get("season") or ""),
        sofascore_event_id=None,
        home_goals=row.get("home_goals"),
        away_goals=row.get("away_goals"),
    )


def _select_different_competitions(rows: list[dict[str, Any]], limit: int) -> list[dict[str, Any]]:
    selected: list[dict[str, Any]] = []
    seen: set[str] = set()
    for row in rows:
        comp = str(row.get("competition") or "")
        if comp and comp not in seen:
            selected.append(row)
            seen.add(comp)
            if len(selected) >= limit:
                return selected
    for row in rows:
        if row not in selected:
            selected.append(row)
            if len(selected) >= limit:
                break
    return selected


def _f24_validate_rows(
    client: Futbol24Client,
    rows: list[dict[str, Any]],
    *,
    expect_finished: bool,
) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    for row in rows:
        ref = _matchref(row)
        snap = client.get_match_snapshot(ref)
        item: dict[str, Any] = {
            "match": row,
            "snapshot": snap,
            "state_ok": False,
            "score_ok": None,
            "xg": {"home": None, "away": None},
            "metrics": {},
            "core_metrics_complete": False,
        }
        if isinstance(snap, dict):
            expected_states = {"finished"} if expect_finished else {"scheduled", "live"}
            item["state_ok"] = snap.get("state") in expected_states
            if expect_finished:
                item["score_ok"] = bool(
                    snap.get("home_goals") is not None
                    and snap.get("away_goals") is not None
                    and snap.get("home_goals") == row.get("home_goals")
                    and snap.get("away_goals") == row.get("away_goals")
                )
                direct = client.get_direct_xg(ref)
                item["xg"] = {
                    "home": getattr(direct, "home", None),
                    "away": getattr(direct, "away", None),
                }
                metrics = client.get_match_stats(ref, missing_fields=CORE_METRICS)
                item["metrics"] = {k: _pair_dict(v) for k, v in metrics.items()}
                item["core_metrics_complete"] = all(
                    item["metrics"].get(k, {}).get("home") is not None
                    and item["metrics"].get(k, {}).get("away") is not None
                    for k in CORE_METRICS
                )
        results.append(item)
    return results


def _flashscore_regression() -> dict[str, Any]:
    # Anchor previamente certificado en ambas fuentes. No usa SofaScore.
    ref = MatchRef(
        match_id=None,
        kickoff="2026-08-24T16:30:00+00:00",
        home_team="Bologna",
        away_team="Lazio",
        competition="Serie A",
        season="2026/2027",
        sofascore_event_id=None,
        home_goals=0,
        away_goals=1,
    )
    result: dict[str, Any] = {
        "match": "Bologna-Lazio 2026-08-24",
        "xg": {"home": None, "away": None},
        "metrics": {},
        "pass": False,
    }
    with sync_playwright() as playwright:
        client = FlashscoreXGClient(
            playwright,
            project_root=ROOT,
            logger=lambda msg: print(f"FLASH> {msg}"),
        )
        try:
            xg = client.get_direct_xg(ref)
            metrics = client.get_match_stats(ref)
            result["xg"] = {
                "home": getattr(xg, "home", None),
                "away": getattr(xg, "away", None),
            }
            result["metrics"] = {
                k: _pair_dict(v)
                for k, v in metrics.items()
                if k in {*CORE_METRICS, "possession", "fouls", "offsides", "big_chances"}
            }
            result["pass"] = bool(
                result["xg"]["home"] is not None
                and result["xg"]["away"] is not None
                and all(
                    result["metrics"].get(k, {}).get("home") is not None
                    and result["metrics"].get(k, {}).get("away") is not None
                    for k in CORE_METRICS
                )
            )
        finally:
            client.close()
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--past-days", type=int, default=8)
    parser.add_argument("--future-days", type=int, default=14)
    args = parser.parse_args()

    stage2_path = ARTIFACTS / "cloud_stage2_discovery.json"
    if stage2_path.exists():
        stage2 = json.loads(stage2_path.read_text(encoding="utf-8"))
    else:
        stage2 = discover(past_days=args.past_days, future_days=args.future_days)

    f24 = Futbol24Client(project_root=ROOT, logger=lambda msg: print(f"F24> {msg}"))

    upcoming_rows = _select_different_competitions(list(stage2.get("upcoming") or []), 3)
    finished_rows = _select_different_competitions(list(stage2.get("finished") or []), 4)

    upcoming_checks = _f24_validate_rows(f24, upcoming_rows, expect_finished=False)
    finished_checks = _f24_validate_rows(f24, finished_rows, expect_finished=True)

    scheduled_verified = sum(1 for item in upcoming_checks if item["state_ok"])
    finished_verified = sum(
        1 for item in finished_checks
        if item["state_ok"] and item["score_ok"] is True
    )
    metric_complete = sum(
        1 for item in finished_checks
        if item["core_metrics_complete"]
        and item["xg"]["home"] is not None
        and item["xg"]["away"] is not None
    )
    finished_competitions = {
        str(item["match"].get("competition") or "")
        for item in finished_checks
        if item["state_ok"] and item["score_ok"] is True
    }

    flash = _flashscore_regression()

    live_discovered = [
        row for row in (stage2.get("upcoming") or [])
        if row.get("state") == "live"
    ]

    criteria = {
        "stage2_pass": stage2.get("stage2_pass") is True,
        "scheduled_snapshots_verified_at_least_2": scheduled_verified >= min(2, len(upcoming_rows)) and len(upcoming_rows) >= 2,
        "finished_score_snapshots_verified_at_least_3": finished_verified >= 3,
        "finished_verified_at_least_2_competitions": len(finished_competitions) >= 2,
        "futbol24_xg_and_core_metrics_at_least_2": metric_complete >= 2,
        "flashscore_residual_regression_pass": flash.get("pass") is True,
        "sofascore_not_used": True,
    }

    report = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source_order": ["futbol24", "flashscore"],
        "sofascore_enabled": False,
        "stage2_summary": {
            "upcoming_count": stage2.get("upcoming_count"),
            "upcoming_competitions": stage2.get("upcoming_competitions"),
            "finished_count": stage2.get("finished_count"),
            "finished_competitions": stage2.get("finished_competitions"),
            "stage2_pass": stage2.get("stage2_pass"),
        },
        "upcoming_checks": upcoming_checks,
        "finished_checks": finished_checks,
        "flashscore_regression": flash,
        "live_observation": {
            "found": len(live_discovered),
            "required_for_pass": False,
            "note": "LIVE se valida cuando exista una muestra real durante la ejecución; no se inventa una muestra.",
        },
        "counts": {
            "scheduled_verified": scheduled_verified,
            "finished_verified": finished_verified,
            "finished_verified_competitions": len(finished_competitions),
            "futbol24_metric_complete": metric_complete,
        },
        "criteria": criteria,
        "stage3_pass": all(criteria.values()),
    }

    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    out = ARTIFACTS / "cloud_stage3_certification.json"
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    print("=" * 80)
    print("ODDSHUNTER CLOUD STAGE3 — MULTI MATCH / MULTI LEAGUE CERTIFICATION")
    print("=" * 80)
    print("SOFASCORE_ENABLED =", report["sofascore_enabled"])
    print("SCHEDULED_VERIFIED =", scheduled_verified)
    print("FINISHED_VERIFIED =", finished_verified)
    print("FINISHED_VERIFIED_COMPETITIONS =", len(finished_competitions))
    print("FUTBOL24_METRIC_COMPLETE =", metric_complete)
    print("FLASHSCORE_REGRESSION_PASS =", flash.get("pass"))
    print("LIVE_FOUND =", len(live_discovered), "(optional)")
    print("CRITERIA =", criteria)
    print("STAGE3_PASS =", report["stage3_pass"])
    print("REPORT =", out)
    return 0 if report["stage3_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
