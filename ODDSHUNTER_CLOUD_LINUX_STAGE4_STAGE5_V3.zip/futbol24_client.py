from __future__ import annotations

import json
import math
import re
import unicodedata
from datetime import datetime, timezone
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Callable, Sequence
from urllib.parse import urlencode
from urllib.request import Request, urlopen

try:
    import requests
except ModuleNotFoundError:
    class _RequestException(Exception):
        pass

    class _UrllibResponse:
        def __init__(self, status_code: int, payload: bytes) -> None:
            self.status_code = status_code
            self._payload = payload

        def json(self) -> Any:
            return json.loads(self._payload.decode("utf-8"))

    class _UrllibSession:
        def __init__(self) -> None:
            self.headers: dict[str, str] = {}

        def get(
            self,
            url: str,
            *,
            params: dict[str, Any] | None = None,
            timeout: float = 30.0,
        ) -> _UrllibResponse:
            query = urlencode(params or {}, doseq=True)
            target = f"{url}?{query}" if query else url
            try:
                with urlopen(
                    Request(target, headers=dict(self.headers)),
                    timeout=timeout,
                ) as response:
                    return _UrllibResponse(
                        int(getattr(response, "status", 200)),
                        response.read(),
                    )
            except Exception as exc:  # pragma: no cover - solo sin requests
                raise _RequestException(str(exc)) from exc

        def close(self) -> None:
            return None

    class _RequestsCompatibility:
        RequestException = _RequestException
        Session = _UrllibSession

    requests = _RequestsCompatibility()  # type: ignore[assignment]

from match_stats_pipeline import MetricPair
from team_identity_registry import get_default_team_identity_registry
from xg_estimator import AggregateStats
from xg_pipeline import DirectXG, MatchAggregateStats, MatchRef


BASE_URL = "https://api.futbol24.com/api"
MATCH_URL = "https://www.futbol24.com/match/{slug}"
STAT_CODES = {
    "total_shots": "SHOTS_TOTAL",
    "shots_on_target": "SHOTS_ON_TARGET",
    "shots_off_target": "SHOTS_OFF_TARGET",
    "blocked_shots": "SHOTS_BLOCKED",
}
MATCH_STAT_CODES = {
    "shots": "SHOTS_TOTAL",
    "shots_on_target": "SHOTS_ON_TARGET",
    "corners": "CORNERS",
    "yellow_cards": "YELLOWCARDS",
    "red_cards": "REDCARDS",
    "possession": "BALL_POSSESSION",
    "fouls": "FOULS",
    "offsides": "OFFSIDES",
    "big_chances": "BIG_CHANCES",
}
GENERIC_TEAM_WORDS = {
    "afc",
    "cf",
    "club",
    "de",
    "fc",
    "fk",
    "sc",
    "sk",
    "the",
}


def _normalize(value: Any) -> str:
    text = unicodedata.normalize("NFKD", str(value or "").casefold())
    text = "".join(
        character
        for character in text
        if not unicodedata.combining(character)
    )
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return " ".join(text.split())


def _team_tokens(value: Any) -> set[str]:
    return {
        token
        for token in _normalize(value).split()
        if token not in GENERIC_TEAM_WORDS
    }


def _name_score(expected: Any, candidate: Any) -> float:
    left = _normalize(expected)
    right = _normalize(candidate)
    if not left or not right:
        return 0.0
    if left == right:
        return 1.0
    left_tokens = _team_tokens(left)
    right_tokens = _team_tokens(right)
    token_score = (
        len(left_tokens & right_tokens)
        / max(len(left_tokens | right_tokens), 1)
    )
    containment = 0.92 if left in right or right in left else 0.0
    sequence = SequenceMatcher(None, left, right).ratio()
    return max(token_score, containment, sequence)


def _to_number(value: Any) -> float | None:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        number = float(value)
    else:
        match = re.search(r"-?\d+(?:[.,]\d+)?", str(value).replace("%", ""))
        if match is None:
            return None
        try:
            number = float(match.group().replace(",", "."))
        except ValueError:
            return None
    if not math.isfinite(number) or number < 0:
        return None
    return number


def _parse_datetime(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


class Futbol24Client:
    """Fuente principal del runtime cloud; resuelve identidad y métricas reales."""

    name = "futbol24"

    def __init__(
        self,
        *,
        project_root: str | Path,
        timeout_seconds: float = 30.0,
        logger: Callable[[str], None] | None = None,
    ) -> None:
        self.project_root = Path(project_root)
        self.timeout_seconds = float(timeout_seconds)
        self.logger = logger or (lambda _message: None)
        self.identity_registry = get_default_team_identity_registry(
            self.project_root
        )
        self.session = requests.Session()
        self.session.headers.clear()
        self.session.headers.update(
            {
                "Accept": "application/json",
                "Origin": "https://www.futbol24.com",
                "Referer": "https://www.futbol24.com/",
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/127.0 Safari/537.36"
                ),
            }
        )
        # Solo memoria: no escribe cache ni altera históricos.
        self._prepared: dict[str, dict[str, Any] | None] = {}
        self.last_identity_validation: dict[str, Any] | None = None

    @property
    def available(self) -> bool:
        return True

    def _request(
        self,
        endpoint: str,
        params: dict[str, Any] | None = None,
    ) -> Any | None:
        try:
            response = self.session.get(
                f"{BASE_URL}{endpoint}",
                params=params,
                timeout=self.timeout_seconds,
            )
            if response.status_code != 200:
                self.logger(
                    "Futbol24 no respondió correctamente "
                    f"({response.status_code})."
                )
                return None
            return response.json()
        except (requests.RequestException, ValueError) as exc:
            self.logger(f"Futbol24: {type(exc).__name__}: {exc}")
            return None

    @staticmethod
    def _match_key(match: MatchRef) -> str:
        identity = match.sofascore_event_id or match.match_id or "none"
        kickoff = _parse_datetime(match.kickoff)
        date = kickoff.date().isoformat() if kickoff else str(match.kickoff)
        return "|".join(
            (
                str(identity),
                _normalize(match.competition),
                _normalize(match.season),
                date,
                _normalize(match.home_team),
                _normalize(match.away_team),
            )
        )

    def _expected_names(self, value: Any) -> list[str]:
        verified = self.identity_registry.futbol24_variants(value)
        return list(
            dict.fromkeys(
                [
                    *verified,
                    str(value or "").strip(),
                ]
            )
        )

    def _candidate_score(
        self,
        match: MatchRef,
        candidate: dict[str, Any],
    ) -> float:
        validation = self._candidate_validation(
            match,
            candidate,
            require_score=False,
        )
        if not validation["valid"]:
            return -1.0
        home_score = float(validation["home_score"])
        away_score = float(validation["away_score"])
        hours = float(validation["date_delta_hours"])
        competition_score = float(validation["competition_score"])
        score = home_score * 4.0 + away_score * 4.0
        score += max(0.0, 1.5 - hours / 24.0)
        score += competition_score

        league = candidate.get("league") or {}
        expected_year = re.search(r"\d{4}", str(match.season or ""))
        league_slug = str(league.get("slug") or "")
        if expected_year is not None and expected_year.group() in league_slug:
            score += 0.5
        return score

    @staticmethod
    def _score_pair(candidate: dict[str, Any]) -> tuple[float | None, float | None]:
        actual = candidate.get("match") if isinstance(candidate.get("match"), dict) else candidate
        team1 = actual.get("team1") if isinstance(actual.get("team1"), dict) else {}
        team2 = actual.get("team2") if isinstance(actual.get("team2"), dict) else {}

        def first_number(*values: Any) -> float | None:
            for value in values:
                number = _to_number(value)
                if number is not None:
                    return number
            return None

        # Futbol24 puede devolver el marcador completo en un único campo
        # (por ejemplo score1="0-1"). Antes de tratar score1/score2 como
        # números individuales, intenta extraer el par completo.
        for key in (
            "score",
            "score1",
            "result",
            "result_score",
            "full_score",
            "ft_score",
        ):
            raw = actual.get(key)
            if isinstance(raw, str):
                match_score = re.search(r"(\d+)\s*[-:]\s*(\d+)", raw)
                if match_score is not None:
                    return float(match_score.group(1)), float(match_score.group(2))

        home = first_number(
            actual.get("team1_score"),
            actual.get("home_score"),
            actual.get("score1"),
            actual.get("goals1"),
            team1.get("score"),
            team1.get("goals"),
        )
        away = first_number(
            actual.get("team2_score"),
            actual.get("away_score"),
            actual.get("score2"),
            actual.get("goals2"),
            team2.get("score"),
            team2.get("goals"),
        )
        if home is None or away is None:
            for key in ("score", "score1", "result", "result_score", "full_score", "ft_score"):
                raw_score = str(actual.get(key) or "")
                match_score = re.search(r"(\d+)\s*[-:]\s*(\d+)", raw_score)
                if match_score is not None:
                    home = float(match_score.group(1))
                    away = float(match_score.group(2))
                    break
        return home, away

    def _candidate_validation(
        self,
        match: MatchRef,
        candidate: dict[str, Any],
        *,
        require_score: bool,
    ) -> dict[str, Any]:
        team1 = candidate.get("team1") or {}
        team2 = candidate.get("team2") or {}
        home_score = max(
            _name_score(expected, candidate_name)
            for expected in self._expected_names(match.home_team)
            for candidate_name in (
                team1.get("name"),
                team1.get("name_short"),
            )
        )
        away_score = max(
            _name_score(expected, candidate_name)
            for expected in self._expected_names(match.away_team)
            for candidate_name in (
                team2.get("name"),
                team2.get("name_short"),
            )
        )
        expected_date = _parse_datetime(match.kickoff)
        candidate_date = _parse_datetime(candidate.get("date"))
        league = candidate.get("league") or {}
        competition_score = max(
            _name_score(match.competition, league.get("name")),
            _name_score(match.competition, league.get("slug")),
        )
        hours = (
            abs((candidate_date - expected_date).total_seconds()) / 3600.0
            if expected_date is not None and candidate_date is not None
            else float("inf")
        )
        date_pass = bool(
            expected_date is not None
            and candidate_date is not None
            and expected_date.date() == candidate_date.date()
        )
        expected_score_known = (
            _to_number(match.home_goals) is not None
            and _to_number(match.away_goals) is not None
        )
        actual_home, actual_away = self._score_pair(candidate)
        score_pass = True
        if require_score and expected_score_known:
            score_pass = bool(
                actual_home == _to_number(match.home_goals)
                and actual_away == _to_number(match.away_goals)
            )
        checks = {
            "home_score": round(home_score, 4),
            "away_score": round(away_score, 4),
            "date_delta_hours": round(hours, 3) if math.isfinite(hours) else None,
            "competition_score": round(competition_score, 4),
            "home_pass": home_score >= 0.82,
            "away_pass": away_score >= 0.82,
            "date_pass": date_pass,
            "competition_pass": competition_score >= 0.55,
            "score_required": bool(require_score and expected_score_known),
            "score_pass": score_pass,
            "expected_score": [match.home_goals, match.away_goals],
            "actual_score": [actual_home, actual_away],
        }
        checks["valid"] = all(
            checks[key]
            for key in (
                "home_pass",
                "away_pass",
                "date_pass",
                "competition_pass",
                "score_pass",
            )
        )
        return checks

    def _find_match(self, match: MatchRef) -> dict[str, Any] | None:
        home_names = self._expected_names(match.home_team)[:2]
        away_names = self._expected_names(match.away_team)[:2]
        rows_by_identity: dict[str, dict[str, Any]] = {}
        for home_name in home_names:
            for away_name in away_names:
                query = f"{home_name} {away_name}"
                document = self._request(
                    "/search/match",
                    {"query": query},
                )
                if not isinstance(document, list):
                    continue
                for row in document:
                    if not isinstance(row, dict):
                        continue
                    identity = str(
                        row.get("id")
                        or row.get("slug")
                        or json.dumps(row, sort_keys=True, default=str)
                    )
                    rows_by_identity[identity] = row
                # El par exacto verificado suele resolver en la primera
                # consulta; se evita multiplicar peticiones sin necesidad.
                if any(
                    self._candidate_score(match, row) >= 6.0
                    for row in rows_by_identity.values()
                ):
                    break
            else:
                continue
            break
        candidates = [
            (self._candidate_score(match, row), row)
            for row in rows_by_identity.values()
        ]
        candidates = [item for item in candidates if item[0] >= 6.0]
        if not candidates:
            self.logger(
                "Futbol24 no encontró una coincidencia segura para "
                f"{match.home_team} - {match.away_team}."
            )
            return None
        candidates.sort(key=lambda item: item[0], reverse=True)
        return candidates[0][1]

    def _details_match_expected(
        self,
        match: MatchRef,
        details: dict[str, Any],
    ) -> bool:
        actual = details.get("match") or {}
        candidate = {
            "date": actual.get("date"),
            "team1": actual.get("team1"),
            "team2": actual.get("team2"),
            "league": details.get("league"),
            "match": actual,
        }
        validation = self._candidate_validation(
            match,
            candidate,
            require_score=True,
        )
        self.last_identity_validation = validation
        self.logger(
            "Futbol24 identity: "
            f"home={'PASS' if validation['home_pass'] else 'FAIL'} "
            f"away={'PASS' if validation['away_pass'] else 'FAIL'} "
            f"date={'PASS' if validation['date_pass'] else 'FAIL'} "
            f"competition={'PASS' if validation['competition_pass'] else 'FAIL'} "
            f"score={'PASS' if validation['score_pass'] else 'FAIL'}"
        )
        return bool(validation["valid"])

    def _prepare(self, match: MatchRef) -> dict[str, Any] | None:
        key = self._match_key(match)
        if key in self._prepared:
            return self._prepared[key]
        candidate = self._find_match(match)
        slug = candidate.get("slug") if isinstance(candidate, dict) else None
        if not slug:
            self._prepared[key] = None
            return None
        document = self._request("/match/details", {"slug": slug})
        details = document.get("details") if isinstance(document, dict) else None
        if not isinstance(details, dict) or not self._details_match_expected(match, details):
            self.logger(
                "Futbol24 descartó los detalles porque no corresponden "
                "inequívocamente al partido solicitado."
            )
            self._prepared[key] = None
            return None
        self._prepared[key] = details
        return details

    @staticmethod
    def _stats_by_code(details: dict[str, Any] | None) -> dict[str, dict[str, Any]]:
        if not isinstance(details, dict):
            return {}
        return {
            str(row.get("code") or "").upper(): row
            for row in details.get("stats") or []
            if isinstance(row, dict) and row.get("code")
        }

    @staticmethod
    def _identity(details: dict[str, Any]) -> dict[str, Any]:
        match = details.get("match") or {}
        slug = str(match.get("slug") or "")
        return {
            "futbol24_match_id": details.get("id"),
            "futbol24_slug": slug or None,
            "futbol24_url": MATCH_URL.format(slug=slug) if slug else None,
        }

    @staticmethod
    def _status_snapshot(candidate: dict[str, Any]) -> tuple[str, str | None]:
        status = candidate.get("status") if isinstance(candidate.get("status"), dict) else {}
        raw_name = str(
            status.get("name")
            or status.get("type")
            or status.get("description")
            or ""
        ).strip()
        normalized = _normalize(raw_name)
        ended = bool(status.get("is_ended") or status.get("ended"))
        in_play = bool(status.get("in_play") or status.get("inPlay"))

        if ended or normalized in {
            "ft", "finished", "final", "after extra time", "after penalties"
        }:
            return "finished", raw_name or None
        if in_play or normalized in {
            "live", "in play", "1st half", "2nd half", "halftime", "extra time"
        }:
            return "live", raw_name or None
        if any(
            marker in normalized
            for marker in (
                "cancel",
                "postpon",
                "abandon",
                "suspend",
                "walkover",
            )
        ):
            return "terminal", raw_name or None
        return "scheduled", raw_name or None

    def get_match_snapshot(self, match: MatchRef) -> dict[str, Any] | None:
        """Estado/marcador verificado desde la búsqueda real de Futbol24.

        No usa SofaScore y no escribe disco. La identidad exige equipos,
        competición y fecha antes de aceptar el candidato.
        """

        candidate = self._find_match(match)
        if not isinstance(candidate, dict):
            return None

        validation = self._candidate_validation(
            match,
            candidate,
            require_score=False,
        )
        if not bool(validation.get("valid")):
            self.logger(
                "Futbol24 snapshot descartado: identidad de búsqueda no segura."
            )
            return None

        slug = str(candidate.get("slug") or "").strip()
        details: dict[str, Any] | None = None
        if slug:
            document = self._request("/match/details", {"slug": slug})
            possible = document.get("details") if isinstance(document, dict) else None
            if isinstance(possible, dict):
                actual = possible.get("match") or {}
                detail_candidate = {
                    "date": actual.get("date"),
                    "team1": actual.get("team1"),
                    "team2": actual.get("team2"),
                    "league": possible.get("league"),
                    "match": actual,
                }
                detail_validation = self._candidate_validation(
                    match,
                    detail_candidate,
                    require_score=False,
                )
                if bool(detail_validation.get("valid")):
                    details = possible

        home_score, away_score = self._score_pair(candidate)
        state, provider_status = self._status_snapshot(candidate)
        kickoff = _parse_datetime(candidate.get("date"))

        return {
            "source": "futbol24",
            "state": state,
            "provider_status": provider_status,
            "home_goals": (
                int(home_score) if home_score is not None and home_score.is_integer()
                else home_score
            ),
            "away_goals": (
                int(away_score) if away_score is not None and away_score.is_integer()
                else away_score
            ),
            "kickoff": kickoff.isoformat() if kickoff is not None else None,
            "futbol24_match_id": candidate.get("id"),
            "futbol24_slug": slug or None,
            "futbol24_url": MATCH_URL.format(slug=slug) if slug else None,
            "identity_validation": validation,
            "details_available": details is not None,
        }

    def get_direct_xg(self, match: MatchRef) -> DirectXG | None:
        details = self._prepare(match)
        stats = self._stats_by_code(details)
        row = stats.get("EXPECTED_GOALS")
        if not isinstance(row, dict) or not isinstance(details, dict):
            return None
        home = _to_number(row.get("home"))
        away = _to_number(row.get("away"))
        if home is None or away is None or home > 15 or away > 15:
            return None
        return DirectXG(
            home=round(home, 2),
            away=round(away, 2),
            details={**self._identity(details), "field": row.get("name")},
        )

    @staticmethod
    def _aggregate(
        stats: dict[str, dict[str, Any]],
        side: str,
    ) -> AggregateStats | None:
        values = {
            field: _to_number((stats.get(code) or {}).get(side))
            for field, code in STAT_CODES.items()
        }
        if values["total_shots"] is None or values["shots_on_target"] is None:
            return None
        return AggregateStats(**values)

    def get_aggregate_stats(self, match: MatchRef) -> MatchAggregateStats | None:
        details = self._prepare(match)
        stats = self._stats_by_code(details)
        home = self._aggregate(stats, "home")
        away = self._aggregate(stats, "away")
        if home is None or away is None or not isinstance(details, dict):
            return None
        return MatchAggregateStats(
            home=home,
            away=away,
            details=self._identity(details),
        )

    def get_match_stats(
        self,
        match: MatchRef,
        *,
        missing_fields: Sequence[str] | None = None,
    ) -> dict[str, MetricPair]:
        details = self._prepare(match)
        stats = self._stats_by_code(details)
        requested = set(missing_fields or MATCH_STAT_CODES)
        return {
            metric: MetricPair(
                _to_number((stats.get(code) or {}).get("home")),
                _to_number((stats.get(code) or {}).get("away")),
            )
            for metric, code in MATCH_STAT_CODES.items()
            if metric in requested
        }

    def close(self) -> None:
        self.session.close()
