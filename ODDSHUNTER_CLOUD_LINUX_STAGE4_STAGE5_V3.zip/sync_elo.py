from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from elo_manager import (
    crear_tablas_elo,
    inicializar_temporada_elo,
    obtener_equipos_temporada,
    procesar_partidos_pendientes_elo,
    validar_temporada_elo,
)


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "oddshunter.db"
REGISTRY_PATH = DATA_DIR / "competitions.json"
BACKUP_DIR = DATA_DIR / "backups"
REPORT_DIR = DATA_DIR / "elo" / "sync_reports"

KNOWN_FAMILIES = {
    "mls": "mls",
    "ligapro": "ligapro",
    "ligamx-apertura": "liga-mx",
    "ligamx-clausura": "liga-mx",
    "chile-primera": "chile-primera",
    "brasil-serie-a": "brasil-serie-a",
}


def configure_utf8() -> None:
    os.environ.setdefault("PYTHONUTF8", "1")
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def normalize(value: Any) -> str:
    text = str(value or "").strip().lower()
    replacements = str.maketrans(
        {
            "á": "a",
            "é": "e",
            "í": "i",
            "ó": "o",
            "ú": "u",
            "ñ": "n",
        }
    )
    text = text.translate(replacements)
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def read_registry() -> dict[str, Any]:
    if not REGISTRY_PATH.exists():
        raise FileNotFoundError(f"No se encontró:\n{REGISTRY_PATH}")

    data = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("competitions.json no contiene un objeto JSON.")
    if not isinstance(data.get("competitions"), list):
        raise ValueError("competitions.json no contiene la lista competitions.")
    return data


def connect() -> sqlite3.Connection:
    if not DB_PATH.exists():
        raise FileNotFoundError(f"No se encontró:\n{DB_PATH}")

    connection = sqlite3.connect(DB_PATH, timeout=30)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA busy_timeout = 30000")
    return connection


def parse_timestamp(value: Any) -> int | None:
    text = str(value or "").strip()
    if not text:
        return None

    parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return int(parsed.timestamp())


def create_backup(label: str) -> Path:
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = BACKUP_DIR / f"oddshunter_before_{label}_{stamp}.db"
    shutil.copy2(DB_PATH, path)
    return path


def selected_competitions(
    registry: dict[str, Any],
    key: str | None,
    all_active: bool,
) -> list[dict[str, Any]]:
    rows = [
        dict(item)
        for item in registry["competitions"]
        if isinstance(item, dict) and item.get("key")
    ]

    if all_active:
        selected = [
            item for item in rows
            if bool(item.get("active", True))
        ]
        if not selected:
            raise RuntimeError("No hay competiciones activas.")
        return selected

    normalized_key = str(key or "").strip().lower()
    for item in rows:
        if str(item["key"]).strip().lower() == normalized_key:
            return [item]

    raise ValueError(f"No existe la competición '{key}'.")


def existing_season(
    connection: sqlite3.Connection,
    registry_key: str,
) -> dict[str, Any] | None:
    row = connection.execute(
        """
        SELECT
            et.season_id,
            et.competition_key,
            et.source_league_id AS league_id,
            et.source_registry_key,
            et.season_name,
            et.previous_season_id,
            ep.elo_base,
            ep.k_elo,
            ep.ventaja_local_elo,
            ep.factor_arrastre_elo
        FROM elo_temporadas AS et
        INNER JOIN elo_parametros_liga AS ep
            ON ep.competition_key = et.competition_key
        WHERE et.source_registry_key = ?
        """,
        (registry_key,),
    ).fetchone()

    return dict(row) if row is not None else None


def league_candidates(
    connection: sqlite3.Connection,
) -> list[dict[str, Any]]:
    rows = connection.execute(
        """
        SELECT
            l.league_id,
            l.name,
            l.country,
            l.season,
            MIN(m.kickoff) AS first_match,
            MAX(m.kickoff) AS last_match,
            SUM(
                CASE
                    WHEN LOWER(TRIM(m.status)) IN ('ft', 'finished')
                     AND m.home_goals IS NOT NULL
                     AND m.away_goals IS NOT NULL
                    THEN 1 ELSE 0
                END
            ) AS finished_matches
        FROM leagues AS l
        LEFT JOIN matches AS m
            ON m.league_id = l.league_id
        GROUP BY l.league_id
        ORDER BY l.league_id
        """
    ).fetchall()

    return [dict(row) for row in rows]


def find_league(
    connection: sqlite3.Connection,
    competition: dict[str, Any],
) -> dict[str, Any]:
    name = normalize(competition.get("name"))
    season_name = normalize(competition.get("season_name"))
    country = normalize(competition.get("country"))

    # ODDSHUNTER_EXACT_REGISTRY_LEAGUE_RESOLVER_V1
    # competitions.json contiene la identidad league_id canÃ³nica.
    exact_league_id = competition.get("league_id")
    if exact_league_id is not None:
        try:
            exact_id = int(exact_league_id)
        except (TypeError, ValueError):
            exact_id = -1
        if exact_id >= 0:
            exact = next(
                (row for row in league_candidates(connection)
                 if int(row["league_id"]) == exact_id),
                None,
            )
            if exact is None:
                raise RuntimeError(
                    "{}: league_id exacto {} no existe en SQLite.".format(competition["key"], exact_id)
                )
            # ODDSHUNTER_EXACT_REGISTRY_LEAGUE_RESOLVER_V1_6_1
            # league_id del registry sigue siendo autoritativo.
            # No usar league_candidates.finished_matches como guard porque dio falsos 0.
            return exact

    already_used = {
        int(row[0])
        for row in connection.execute(
            "SELECT source_league_id FROM elo_temporadas"
        ).fetchall()
    }

    scored: list[tuple[int, dict[str, Any]]] = []

    for league in league_candidates(connection):
        league_id = int(league["league_id"])
        if league_id in already_used:
            continue

        league_name = normalize(league.get("name"))
        league_season = normalize(league.get("season"))
        league_country = normalize(league.get("country"))

        score = 0
        if season_name and season_name == league_season:
            score += 150
        elif season_name and (
            season_name in league_season
            or league_season in season_name
        ):
            score += 60

        if name and name == league_name:
            score += 90
        elif name and (
            name in league_name
            or league_name in name
        ):
            score += 35

        if country and country == league_country:
            score += 25

        if score:
            scored.append((score, league))

    if not scored:
        raise RuntimeError(
            f"No se encontró una fila nueva en leagues para {competition['key']}."
        )

    scored.sort(
        key=lambda item: (item[0], int(item[1]["league_id"])),
        reverse=True,
    )
    score, league = scored[0]

    if score < 80:
        raise RuntimeError(
            f"Mapeo ambiguo para {competition['key']}; puntuación={score}."
        )

    if int(league.get("finished_matches") or 0) == 0:
        raise RuntimeError(
            f"{competition['key']} todavía no tiene partidos FT importados."
        )

    return league


def canonical_key(
    competition: dict[str, Any],
) -> str:
    explicit = str(
        competition.get("elo_competition_key") or ""
    ).strip()
    if explicit:
        return explicit

    registry_key = str(competition["key"])
    return KNOWN_FAMILIES.get(registry_key, registry_key)


def ensure_competition_and_parameters(
    connection: sqlite3.Connection,
    competition: dict[str, Any],
    family_key: str,
) -> None:
    connection.execute(
        """
        INSERT INTO elo_competiciones (
            competition_key,
            display_name,
            country,
            active,
            updated_at
        )
        VALUES (?, ?, ?, ?, CAST(strftime('%s', 'now') AS INTEGER))
        ON CONFLICT(competition_key) DO UPDATE SET
            display_name = excluded.display_name,
            country = excluded.country,
            active = excluded.active,
            updated_at = excluded.updated_at
        """,
        (
            family_key,
            str(competition.get("elo_display_name")
                or competition.get("name")
                or family_key),
            str(competition.get("country") or ""),
            1 if bool(competition.get("active", True)) else 0,
        ),
    )

    connection.execute(
        """
        INSERT INTO elo_parametros_liga (
            competition_key,
            elo_base,
            k_elo,
            ventaja_local_elo,
            factor_arrastre_elo,
            escala_elo,
            cap_elo,
            updated_at
        )
        VALUES (?, 1500.0, 20.0, 0.0, 0.60, 400.0, 120.0,
                CAST(strftime('%s', 'now') AS INTEGER))
        ON CONFLICT(competition_key) DO NOTHING
        """,
        (family_key,),
    )


def resolve_previous_season_id(
    connection: sqlite3.Connection,
    competition: dict[str, Any],
    family_key: str,
    first_timestamp: int | None,
) -> int | None:
    explicit_previous = str(
        competition.get("elo_previous_registry_key") or ""
    ).strip()

    if explicit_previous:
        row = connection.execute(
            """
            SELECT season_id
            FROM elo_temporadas
            WHERE source_registry_key = ?
            """,
            (explicit_previous,),
        ).fetchone()

        if row is None:
            raise RuntimeError(
                "No existe la temporada ELO indicada en "
                f"elo_previous_registry_key={explicit_previous}."
            )
        return int(row["season_id"])

    if first_timestamp is None:
        return None

    row = connection.execute(
        """
        SELECT season_id
        FROM elo_temporadas
        WHERE competition_key = ?
          AND first_match_timestamp IS NOT NULL
          AND first_match_timestamp < ?
        ORDER BY first_match_timestamp DESC, season_id DESC
        LIMIT 1
        """,
        (
            family_key,
            int(first_timestamp),
        ),
    ).fetchone()

    return int(row["season_id"]) if row is not None else None


def create_season(
    connection: sqlite3.Connection,
    competition: dict[str, Any],
) -> dict[str, Any]:
    league = find_league(connection, competition)
    family_key = canonical_key(competition)

    ensure_competition_and_parameters(
        connection,
        competition,
        family_key,
    )

    first_timestamp = parse_timestamp(league.get("first_match"))
    last_timestamp = parse_timestamp(league.get("last_match"))
    previous_id = resolve_previous_season_id(
        connection,
        competition,
        family_key,
        first_timestamp,
    )

    connection.execute(
        """
        INSERT INTO elo_temporadas (
            competition_key,
            source_league_id,
            source_registry_key,
            source_season_id,
            season_name,
            first_match_timestamp,
            last_match_timestamp,
            previous_season_id,
            active,
            updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,
                CAST(strftime('%s', 'now') AS INTEGER))
        """,
        (
            family_key,
            int(league["league_id"]),
            str(competition["key"]),
            (
                int(competition["season_id"])
                if competition.get("season_id") is not None
                else None
            ),
            str(league["season"]),
            first_timestamp,
            last_timestamp,
            previous_id,
            1 if bool(competition.get("active", True)) else 0,
        ),
    )

    return existing_season(
        connection,
        str(competition["key"]),
    ) or {}


def pending_count(
    connection: sqlite3.Connection,
    season: dict[str, Any],
) -> int:
    row = connection.execute(
        """
        SELECT COUNT(*) AS total
        FROM matches AS m
        WHERE m.league_id = ?
          AND m.season = ?
          AND LOWER(TRIM(m.status)) IN ('ft', 'finished')
          AND m.home_goals IS NOT NULL
          AND m.away_goals IS NOT NULL
          AND NOT EXISTS (
              SELECT 1
              FROM elo_movimientos AS em
              WHERE em.match_id = m.match_id
                AND em.league_id = m.league_id
                AND em.season_id = ?
          )
        """,
        (
            int(season["league_id"]),
            str(season["season_name"]),
            int(season["season_id"]),
        ),
    ).fetchone()
    return int(row["total"])


def process_one(
    connection: sqlite3.Connection,
    competition: dict[str, Any],
) -> dict[str, Any]:
    registry_key = str(competition["key"])
    season = existing_season(connection, registry_key)
    created = False

    if season is None:
        season = create_season(connection, competition)
        created = True

    if not season:
        raise RuntimeError(
            f"No se pudo resolver la temporada ELO para {registry_key}."
        )

    league_id = int(season["league_id"])
    season_id = int(season["season_id"])

    teams = obtener_equipos_temporada(
        connection,
        league_id,
        str(season["season_name"]),
    )

    init_result = inicializar_temporada_elo(
        conexion=connection,
        league_id=league_id,
        season_id=season_id,
        team_ids=teams,
        previous_season_id=(
            int(season["previous_season_id"])
            if season["previous_season_id"] is not None
            else None
        ),
        elo_base=float(season["elo_base"]),
        factor_arrastre=float(season["factor_arrastre_elo"]),
    )

    before_pending = pending_count(connection, season)

    process_result = procesar_partidos_pendientes_elo(
        conexion=connection,
        league_id=league_id,
        season_id=season_id,
        k=float(season["k_elo"]),
        ventaja_local_elo=float(season["ventaja_local_elo"]),
        elo_base=float(season["elo_base"]),
    )

    if process_result["errores"]:
        raise RuntimeError(
            json.dumps(
                process_result["errores"][:5],
                ensure_ascii=False,
            )
        )

    validation = validar_temporada_elo(
        connection,
        league_id,
        season_id,
    )

    if not validation["movimientos_completos"]:
        raise RuntimeError(
            "La cantidad de movimientos ELO es incompleta."
        )
    if validation["partidos_incompletos"] != 0:
        raise RuntimeError(
            "Existen partidos con movimientos ELO incompletos."
        )
    if not validation["suma_deltas_cero"]:
        raise RuntimeError(
            "La suma de variaciones ELO no es cero."
        )

    return {
        "registry_key": registry_key,
        "competition_key": season["competition_key"],
        "created_season": created,
        "league_id": league_id,
        "season_id": season_id,
        "season_name": season["season_name"],
        "previous_season_id": season["previous_season_id"],
        "pending_before": before_pending,
        "initialization": init_result,
        "processing": process_result,
        "validation": validation,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Registra nuevas ligas/temporadas y actualiza el ELO pendiente."
    )
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--key")
    group.add_argument("--all-active", action="store_true")
    return parser


def main() -> int:
    configure_utf8()
    args = build_parser().parse_args()

    registry = read_registry()
    selected = selected_competitions(
        registry,
        args.key,
        args.all_active,
    )

    with connect() as connection:
        crear_tablas_elo(connection)

        plans = []
        for competition in selected:
            season = existing_season(
                connection,
                str(competition["key"]),
            )
            plans.append(
                {
                    "key": str(competition["key"]),
                    "season_exists": season is not None,
                    "pending": (
                        pending_count(connection, season)
                        if season is not None
                        else None
                    ),
                }
            )

    needs_write = any(
        not plan["season_exists"] or int(plan["pending"] or 0) > 0
        for plan in plans
    )

    print("=" * 88)
    print("ODDSHUNTER - SINCRONIZACIÓN INCREMENTAL ELO")
    print("=" * 88)

    if not needs_write:
        for plan in plans:
            print(
                f"{plan['key']}: temporada registrada | "
                f"pendientes={plan['pending']}"
            )
        print()
        print("ELO YA ESTÁ ACTUALIZADO. NO SE MODIFICÓ SQLITE.")
        return 0

    backup = create_backup("elo_incremental")
    print(f"Respaldo:\n{backup}")

    reports = []

    try:
        with connect() as connection:
            connection.execute("BEGIN IMMEDIATE")

            for competition in selected:
                print()
                print(f"Procesando: {competition['key']}")
                result = process_one(connection, competition)
                reports.append(result)
                print(
                    f"league_id={result['league_id']} | "
                    f"season_id={result['season_id']} | "
                    f"pendientes={result['pending_before']} | "
                    f"actualizados={result['processing']['actualizados']}"
                )

            connection.commit()

            integrity = str(
                connection.execute(
                    "PRAGMA integrity_check"
                ).fetchone()[0]
            )
            foreign_key_errors = [
                dict(row)
                for row in connection.execute(
                    "PRAGMA foreign_key_check"
                ).fetchall()
            ]

    except Exception:
        shutil.copy2(backup, DB_PATH)
        raise

    report = {
        "generated_at": utc_now(),
        "backup": str(backup),
        "competitions": reports,
        "integrity_check": integrity,
        "foreign_key_errors": foreign_key_errors,
    }

    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    report_path = (
        REPORT_DIR
        / f"sync_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    )
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2, default=str),
        encoding="utf-8",
    )

    if integrity.lower() != "ok":
        raise RuntimeError("SQLite no devolvió integrity_check=ok.")
    if foreign_key_errors:
        raise RuntimeError("Se detectaron errores de claves foráneas.")

    print()
    print("=" * 88)
    print("SINCRONIZACIÓN INCREMENTAL ELO TERMINADA")
    print("=" * 88)
    print(f"integrity_check: {integrity}")
    print(f"foreign_key_errors: {len(foreign_key_errors)}")
    print(f"Reporte:\n{report_path}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print()
        print(f"ERROR: {type(exc).__name__}: {exc}")
        raise SystemExit(1)
