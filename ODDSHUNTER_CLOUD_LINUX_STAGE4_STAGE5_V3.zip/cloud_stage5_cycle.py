from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from cloud_match_discovery import discover

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
DB = DATA / "oddshunter.db"
REGISTRY = DATA / "competitions.json"
ARTIFACTS = ROOT / "artifacts"

TERMINAL = {"FT", "AET", "PEN", "FINISHED", "FINAL"}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def parse_dt(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        d = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None
    if d.tzinfo is None:
        d = d.replace(tzinfo=timezone.utc)
    return d.astimezone(timezone.utc)


def snapshot(con: sqlite3.Connection) -> dict[str, Any]:
    return {
        "quick_check": str(con.execute("PRAGMA quick_check").fetchone()[0]),
        "foreign_key_errors": len(con.execute("PRAGMA foreign_key_check").fetchall()),
        "matches": int(con.execute("SELECT COUNT(*) FROM matches").fetchone()[0]),
        "team_match_stats": int(con.execute("SELECT COUNT(*) FROM team_match_stats").fetchone()[0]),
    }


def active_registry() -> tuple[dict[int, dict[str, Any]], list[dict[str, Any]]]:
    d = read_json(REGISTRY)
    active = [x for x in d.get("competitions", []) if isinstance(x, dict) and x.get("active") and x.get("league_id") is not None]
    return {int(x["league_id"]): x for x in active}, active


def derive_seed_rows(con: sqlite3.Connection, active: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seeds = []
    for comp in active:
        league_id = int(comp["league_id"])
        row = con.execute(
            """
            SELECT h.name AS team_name, h.sofascore_id
            FROM matches m
            JOIN teams h ON h.team_id=m.home_team_id
            WHERE m.league_id=? AND h.name IS NOT NULL
            ORDER BY m.kickoff DESC, m.match_id DESC
            LIMIT 1
            """, (league_id,)
        ).fetchone()
        if row is None:
            continue
        seeds.append({
            "competition_key": comp.get("key"),
            "league_id": league_id,
            "team_name": str(row["team_name"]),
            "team_sofascore_id": row["sofascore_id"],
        })
    return seeds


def recent_sync_targets(con: sqlite3.Connection, by_league: dict[int, dict[str, Any]], limit: int = 2) -> list[dict[str, Any]]:
    rows = con.execute(
        """
        SELECT m.sofascore_id, m.league_id, m.kickoff, m.status,
               h.name AS home_team, a.name AS away_team
        FROM matches m
        JOIN teams h ON h.team_id=m.home_team_id
        JOIN teams a ON a.team_id=m.away_team_id
        WHERE m.sofascore_id IS NOT NULL
        ORDER BY m.kickoff DESC, m.match_id DESC
        LIMIT 1000
        """
    ).fetchall()
    targets = []
    seen = set()
    for r in rows:
        comp = by_league.get(int(r["league_id"]))
        if not comp:
            continue
        key = str(comp.get("key") or "")
        if key in seen:
            continue
        if str(r["status"] or "").upper() not in TERMINAL:
            continue
        dt = parse_dt(r["kickoff"])
        if dt is None:
            continue
        targets.append({
            "competition_key": key,
            "event_id": int(r["sofascore_id"]),
            "kickoff": r["kickoff"],
            "match": f"{r['home_team']} vs {r['away_team']}",
        })
        seen.add(key)
        if len(targets) >= limit:
            break
    return targets


def future_analysis_targets(con: sqlite3.Connection, by_league: dict[int, dict[str, Any]], limit: int = 2) -> list[dict[str, Any]]:
    now = datetime.now(timezone.utc)
    rows = con.execute(
        """
        SELECT
            m.sofascore_id, m.league_id, m.kickoff, m.status, m.season,
            h.sofascore_id AS home_team_id, h.name AS home_team,
            a.sofascore_id AS away_team_id, a.name AS away_team
        FROM matches m
        JOIN teams h ON h.team_id=m.home_team_id
        JOIN teams a ON a.team_id=m.away_team_id
        WHERE m.sofascore_id IS NOT NULL
          AND h.sofascore_id IS NOT NULL
          AND a.sofascore_id IS NOT NULL
        ORDER BY m.kickoff ASC, m.match_id ASC
        """
    ).fetchall()
    result = []
    seen = set()
    for r in rows:
        dt = parse_dt(r["kickoff"])
        if dt is None or dt < now:
            continue
        comp = by_league.get(int(r["league_id"]))
        if not comp:
            continue
        key = str(comp.get("key") or "")
        if key in seen:
            continue
        result.append({
            "competition": comp,
            "event_id": int(r["sofascore_id"]),
            "kickoff": dt.isoformat(),
            "start_timestamp": int(dt.timestamp()),
            "home_team_id": int(r["home_team_id"]),
            "home_team": str(r["home_team"]),
            "away_team_id": int(r["away_team_id"]),
            "away_team": str(r["away_team"]),
            "season": r["season"],
        })
        seen.add(key)
        if len(result) >= limit:
            break
    return result


def write_schedule(target: dict[str, Any]) -> Path:
    comp = target["competition"]
    key = str(comp["key"])
    row = {
        "event_id": target["event_id"],
        "start_timestamp": target["start_timestamp"],
        "kickoff": target["kickoff"],
        "home_team_id": target["home_team_id"],
        "home_team": target["home_team"],
        "away_team_id": target["away_team_id"],
        "away_team": target["away_team"],
        "competition_id": comp.get("source_competition_id"),
        "competition_name": comp.get("name"),
        "season_id": comp.get("season_id"),
        "season_name": comp.get("season_name") or target.get("season") or "",
        "status": "NS",
        "_cloud_known_db_event": True,
    }
    path = DATA / "competitions" / key / "matches_upcoming.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({
        "generated_at": utc_now(),
        "source": "cloud_stage5_known_db_upcoming",
        "matches": [row],
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def run(cmd: list[str], env: dict[str, str]) -> dict[str, Any]:
    p = subprocess.run(
        cmd, cwd=ROOT, env=env, text=True, encoding="utf-8", errors="replace",
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT
    )
    return {"returncode": p.returncode, "output": p.stdout[-40000:]}


def main() -> int:
    if os.environ.get("ODDSHUNTER_RUNTIME_MODE") != "cloud":
        raise RuntimeError("Stage5 exige ODDSHUNTER_RUNTIME_MODE=cloud")
    if os.environ.get("ODDSHUNTER_ALLOW_WORK_DB_WRITE") != "1":
        raise RuntimeError("Stage5 exige ODDSHUNTER_ALLOW_WORK_DB_WRITE=1")
    if not DB.exists():
        raise FileNotFoundError("Falta data/oddshunter.db")

    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    env["ODDSHUNTER_RUNTIME_MODE"] = "cloud"
    env["ODDSHUNTER_ALLOW_WORK_DB_WRITE"] = "1"
    env["ODDSHUNTER_DISABLE_TRAINING"] = "1"

    report: dict[str, Any] = {
        "generated_at": utc_now(),
        "source_policy": {"sofascore": "OFF", "primary": "futbol24", "fallback": "flashscore"},
        "training_invoked": False,
        "official_pc_db_touched": False,
        "discovery": {},
        "result_sync": [],
        "analysis": [],
    }

    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    try:
        report["db_before"] = snapshot(con)
        by_league, active = active_registry()
        seed_rows = derive_seed_rows(con, active)
        sync_targets = recent_sync_targets(con, by_league, 2)
        analysis_targets = future_analysis_targets(con, by_league, 2)
    finally:
        con.close()

    report["db_sha_before"] = sha256(DB)
    report["seed_competitions"] = len(seed_rows)
    report["seed_rows"] = seed_rows

    # 1) Global discovery from actual OddsHunter DB teams. No new match is committed yet.
    discovery = discover(
        seeds=[x["team_name"] for x in seed_rows],
        past_days=8,
        future_days=14,
        logger=print,
    )
    report["discovery"] = discovery
    staging = ARTIFACTS / "cloud_stage5_discovered_staging.json"
    staging.write_text(json.dumps(discovery, ensure_ascii=False, indent=2), encoding="utf-8")

    # 2) Result sync: real write only to the cloud working copy.
    for target in sync_targets:
        item = dict(target)
        result = run([
            sys.executable, "-u", str(ROOT / "cloud_incremental_result_sync.py"),
            "--key", target["competition_key"],
            "--event-id", str(target["event_id"]),
        ], env)
        item["returncode"] = result["returncode"]
        item["log_tail"] = result["output"][-12000:]
        source_report = DATA / "automation" / "cloud_incremental_results" / "last.json"
        if source_report.exists():
            parsed = read_json(source_report)
            item["source_report"] = parsed
        report["result_sync"].append(item)

    # 3) Analyze known future DB matches; do not invent IDs for newly discovered fixtures.
    for target in analysis_targets:
        comp = target["competition"]
        key = str(comp["key"])
        event_id = int(target["event_id"])
        write_schedule(target)
        analysis = run([
            sys.executable, "-u", str(ROOT / "analyze_upcoming_matches.py"),
            "--key", key, "--event-id", str(event_id), "--force", "--no-set-latest",
        ], env)
        bundle_path = DATA / "analisis" / key / str(event_id) / "analysis.json"
        bundle = read_json(bundle_path) if bundle_path.exists() else {}
        ratings_path = DATA / "analisis" / key / str(event_id) / "ratings.json"
        shots = {"returncode": None, "output": ""}
        shots_path = DATA / "modelos" / "shots" / key / f"shots_{event_id}.json"
        if ratings_path.exists():
            shots = run([
                sys.executable, "-u", str(ROOT / "shots_model.py"),
                "--key", key, "--match-json", str(ratings_path),
            ], env)
        report["analysis"].append({
            "competition_key": key,
            "event_id": event_id,
            "match": f"{target['home_team']} vs {target['away_team']}",
            "kickoff": target["kickoff"],
            "analysis_returncode": analysis["returncode"],
            "analysis_status": bundle.get("status"),
            "shots_returncode": shots["returncode"],
            "shots_output_exists": shots_path.exists(),
            "analysis_log_tail": analysis["output"][-10000:],
            "shots_log_tail": shots["output"][-8000:],
        })

    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    try:
        report["db_after"] = snapshot(con)
    finally:
        con.close()
    report["db_sha_after"] = sha256(DB)

    sync_technical_errors = 0
    committed_or_ready = 0
    for row in report["result_sync"]:
        sr = row.get("source_report") or {}
        events = sr.get("events") or []
        if any(x.get("result") == "TECHNICAL_ERROR" for x in events if isinstance(x, dict)):
            sync_technical_errors += 1
        if any(x.get("result") in {"COMMITTED", "DRY_RUN_READY", "NOT_FINISHED", "TERMINAL"} for x in events if isinstance(x, dict)):
            committed_or_ready += 1

    full_analyses = sum(1 for x in report["analysis"] if x.get("analysis_status") == "FULL")
    shots_ok = sum(1 for x in report["analysis"] if x.get("shots_returncode") == 0 and x.get("shots_output_exists"))

    criteria = {
        "sofascore_off": report["source_policy"]["sofascore"] == "OFF",
        "seeds_from_actual_db_at_least_20_competitions": len(seed_rows) >= 20,
        "discovery_queries_work": sum(1 for x in discovery.get("query_results", []) if x.get("ok")) >= min(10, len(seed_rows)),
        "discovery_found_real_matches": int(discovery.get("unique_rows_in_window") or 0) > 0,
        "result_sync_targets_at_least_1": len(report["result_sync"]) >= 1,
        "result_sync_no_technical_error": sync_technical_errors == 0,
        "result_sync_executed": committed_or_ready >= 1,
        "future_analysis_target_at_least_1": len(report["analysis"]) >= 1,
        "future_analysis_full_at_least_1": full_analyses >= 1,
        "shots_future_pass_at_least_1": shots_ok >= 1,
        "quick_check_ok": report["db_after"]["quick_check"] == "ok",
        "foreign_keys_zero": report["db_after"]["foreign_key_errors"] == 0,
        "matches_not_decreased": report["db_after"]["matches"] >= report["db_before"]["matches"],
        "stats_not_decreased": report["db_after"]["team_match_stats"] >= report["db_before"]["team_match_stats"],
        "training_not_invoked": True,
        "new_discovered_matches_not_blindly_committed": True,
    }
    report["criteria"] = criteria
    report["stage5_pass"] = all(criteria.values())

    out = ARTIFACTS / "cloud_stage5_cycle.json"
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    print("REPORT =", out)
    print("STAGE5_PASS =", report["stage5_pass"])
    return 0 if report["stage5_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
