from __future__ import annotations

import argparse
import json
import re
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

from futbol24_client import Futbol24Client


ROOT = Path(__file__).resolve().parent
ARTIFACTS = ROOT / "artifacts"

DEFAULT_SEEDS = (
    "Liverpool",
    "Manchester City",
    "Arsenal",
    "Paris Saint-Germain",
    "FC Bayern München",
    "Ajax",
    "Galatasaray",
    "Club Brugge KV",
    "Lazio",
)


def _parse_dt(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _name(obj: Any) -> str:
    if isinstance(obj, dict):
        return str(obj.get("name") or obj.get("name_short") or obj.get("slug") or "").strip()
    return str(obj or "").strip()


def _league_name(row: dict[str, Any]) -> str:
    return _name(row.get("league"))


def _country_name(row: dict[str, Any]) -> str:
    return _name(row.get("category") or row.get("country"))


def _slug_season(slug: str) -> str:
    m = re.search(r"/(\d{4}-\d{4})/", str(slug or ""))
    return m.group(1).replace("-", "/") if m else ""


def _identity(row: dict[str, Any]) -> str:
    return str(row.get("id") or row.get("slug") or json.dumps(row, sort_keys=True, default=str))


@dataclass(frozen=True)
class DiscoveredMatch:
    source: str
    query_seed: str
    futbol24_match_id: Any
    slug: str
    kickoff: str
    state: str
    provider_status: str | None
    home_team: str
    away_team: str
    competition: str
    country: str
    season: str
    home_goals: int | float | None
    away_goals: int | float | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def discover(
    *,
    seeds: Iterable[str] = DEFAULT_SEEDS,
    past_days: int = 8,
    future_days: int = 14,
    logger=print,
) -> dict[str, Any]:
    client = Futbol24Client(project_root=ROOT, logger=lambda msg: logger(f"F24> {msg}"))
    now = datetime.now(timezone.utc)
    floor = now - timedelta(days=max(1, int(past_days)))
    ceiling = now + timedelta(days=max(1, int(future_days)))

    rows: dict[str, tuple[str, dict[str, Any]]] = {}
    query_results: list[dict[str, Any]] = []

    for seed in seeds:
        seed = str(seed or "").strip()
        if not seed:
            continue
        document = client._request("/search/match", {"query": seed})
        ok = isinstance(document, list)
        query_results.append(
            {
                "seed": seed,
                "ok": ok,
                "rows": len(document) if isinstance(document, list) else 0,
            }
        )
        logger(f"DISCOVERY seed={seed!r} ok={ok} rows={len(document) if isinstance(document, list) else 0}")
        if not isinstance(document, list):
            continue
        for row in document:
            if isinstance(row, dict):
                rows.setdefault(_identity(row), (seed, row))

    all_matches: list[DiscoveredMatch] = []
    for seed, row in rows.values():
        kickoff_dt = _parse_dt(row.get("date"))
        if kickoff_dt is None or kickoff_dt < floor or kickoff_dt > ceiling:
            continue

        home = _name(row.get("team1"))
        away = _name(row.get("team2"))
        competition = _league_name(row)
        if not home or not away or not competition:
            continue

        state, status = client._status_snapshot(row)
        hg, ag = client._score_pair(row)
        def clean_score(v: float | None):
            if v is None:
                return None
            return int(v) if float(v).is_integer() else float(v)

        all_matches.append(
            DiscoveredMatch(
                source="futbol24",
                query_seed=seed,
                futbol24_match_id=row.get("id"),
                slug=str(row.get("slug") or ""),
                kickoff=kickoff_dt.isoformat(),
                state=state,
                provider_status=status,
                home_team=home,
                away_team=away,
                competition=competition,
                country=_country_name(row),
                season=_slug_season(str(row.get("slug") or "")),
                home_goals=clean_score(hg),
                away_goals=clean_score(ag),
            )
        )

    all_matches.sort(key=lambda item: item.kickoff)
    upcoming = [
        m for m in all_matches
        if _parse_dt(m.kickoff) is not None
        and _parse_dt(m.kickoff) >= now - timedelta(hours=3)
        and m.state in {"scheduled", "live"}
    ]
    finished = [
        m for m in all_matches
        if m.state == "finished"
        and _parse_dt(m.kickoff) is not None
        and _parse_dt(m.kickoff) >= floor
    ]

    upcoming_leagues = sorted({m.competition for m in upcoming})
    finished_leagues = sorted({m.competition for m in finished})

    search_ok = sum(1 for item in query_results if item["ok"])
    criteria = {
        "search_queries_ok_at_least_5": search_ok >= min(5, len(query_results)),
        "upcoming_at_least_3": len(upcoming) >= 3,
        "upcoming_at_least_2_competitions": len(upcoming_leagues) >= 2,
        "finished_at_least_3": len(finished) >= 3,
        "finished_at_least_2_competitions": len(finished_leagues) >= 2,
        "sofascore_not_used": True,
    }

    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source_order": ["futbol24", "flashscore"],
        "sofascore_enabled": False,
        "window": {
            "past_days": past_days,
            "future_days": future_days,
            "now_utc": now.isoformat(),
        },
        "query_results": query_results,
        "unique_rows_in_window": len(all_matches),
        "upcoming_count": len(upcoming),
        "upcoming_competitions": upcoming_leagues,
        "finished_count": len(finished),
        "finished_competitions": finished_leagues,
        "upcoming": [m.to_dict() for m in upcoming],
        "finished": [m.to_dict() for m in finished],
        "criteria": criteria,
        "stage2_pass": all(criteria.values()),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--past-days", type=int, default=8)
    parser.add_argument("--future-days", type=int, default=14)
    parser.add_argument("--seed", action="append", default=[])
    args = parser.parse_args()

    report = discover(
        seeds=args.seed or DEFAULT_SEEDS,
        past_days=args.past_days,
        future_days=args.future_days,
    )
    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    out = ARTIFACTS / "cloud_stage2_discovery.json"
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    print("=" * 80)
    print("ODDSHUNTER CLOUD STAGE2 — FUTBOL24 DISCOVERY")
    print("=" * 80)
    print("SOFASCORE_ENABLED =", report["sofascore_enabled"])
    print("UPCOMING_COUNT =", report["upcoming_count"])
    print("UPCOMING_COMPETITIONS =", report["upcoming_competitions"])
    print("FINISHED_COUNT =", report["finished_count"])
    print("FINISHED_COMPETITIONS =", report["finished_competitions"])
    print("CRITERIA =", report["criteria"])
    print("STAGE2_PASS =", report["stage2_pass"])
    print("REPORT =", out)
    return 0 if report["stage2_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
