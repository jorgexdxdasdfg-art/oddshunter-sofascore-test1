# OddsHunter Cloud Stage2 + Stage3

No reemplaza `sync_upcoming_matches.py` del bot Windows.

## Stage2
`cloud_match_discovery.py`
- SofaScore OFF.
- Descubrimiento por búsquedas reales de Futbol24 usando equipos semilla.
- No necesita conocer de antemano el rival.
- Clasifica scheduled/live/finished.
- No escribe SQLite.

## Stage3
`cloud_stage3_certify.py`
- Revalida próximos partidos con Futbol24.
- Revalida FT + marcador en varios partidos y competiciones.
- Comprueba xG + shots + SOT + corners + yellow en Futbol24.
- Revalida Flashscore como residual usando Bologna-Lazio.
- LIVE es evidencia opcional: solo se certifica si existe una muestra real en el momento.
- No contiene ni modifica oddshunter.db.

## Gate
El workflow combinado ejecuta primero Stage1 V1.1. Si el marcador 0-1 de Bologna-Lazio no queda correcto, Stage2 y Stage3 no continúan.
