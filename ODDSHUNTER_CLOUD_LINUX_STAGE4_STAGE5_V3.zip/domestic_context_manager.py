from __future__ import annotations

import argparse
import asyncio
import json
import os
import sqlite3
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

from database import (
    get_connection,
    upsert_league,
    upsert_team,
    upsert_team_competition_membership,
)


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
REGISTRY_PATH = DATA_DIR / "competitions.json"
COMPETITIONS_DIR = DATA_DIR / "competitions"
BRAVE_PROFILE_DIR = DATA_DIR / "brave_oddshunter_profile"
SOFASCORE_API = "https://www.sofascore.com/api/v1"


def _env_value(project_root: Path, key: str) -> str | None:
    value = os.environ.get(key)
    if value is not None:
        return value.strip().strip("\"'")

    try:
        lines = (project_root / ".env").read_text(
            encoding="utf-8-sig"
        ).splitlines()
    except OSError:
        return None

    for raw_line in lines:
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        env_key, separator, env_value = line.partition("=")
        if separator and env_key.strip() == key:
            return env_value.strip().strip("\"'")
    return None


def configured_browser_tabs(project_root: Path = BASE_DIR) -> int:
    """Usa el límite doméstico específico o el límite Brave global."""

    raw_value = _env_value(project_root, "ODDSHUNTER_DOMESTIC_TABS")
    if raw_value is None:
        raw_value = _env_value(project_root, "ODDSHUNTER_BRAVE_TABS")
    try:
        requested = int(raw_value or "3")
    except (TypeError, ValueError):
        requested = 3
    return max(1, min(requested, 3))


MAX_DOMESTIC_BROWSER_TABS = configured_browser_tabs()


def slug(value: Any) -> str:
    return "-".join(
        part for part in "".join(
            char.lower() if char.isalnum() else " "
            for char in str(value or "")
        ).split()
        if part
    )


def family_for(specification: dict[str, Any]) -> tuple[str, str]:
    explicit = str(specification.get("competition_family") or "").upper()
    role = str(specification.get("context_role") or "").upper()
    if explicit:
        return explicit, role or "PRIMARY_COMPETITION"
    value = slug(f"{specification.get('key')} {specification.get('name')}")
    if any(token in value for token in ("champions", "conference", "europa-league")):
        return "UEFA", "UEFA_PRIMARY"
    if any(token in value for token in ("sudamericana", "libertadores")):
        return "CONMEBOL", "INTERNATIONAL_PRIMARY"
    return "DOMESTIC", role or "PRIMARY_COMPETITION"


def registry_rows() -> list[dict[str, Any]]:
    if not REGISTRY_PATH.exists():
        return []
    document = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
    rows = document.get("competitions")
    return [row for row in rows or [] if isinstance(row, dict)]


def registry_document() -> dict[str, Any]:
    if not REGISTRY_PATH.exists():
        return {"version": 1, "competitions": []}
    document = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
    if not isinstance(document.get("competitions"), list):
        document["competitions"] = []
    return document


def save_registry(document: dict[str, Any]) -> None:
    temporary = REGISTRY_PATH.with_suffix(".json.tmp")
    temporary.write_text(
        json.dumps(document, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    temporary.replace(REGISTRY_PATH)


def upcoming_uefa_teams() -> dict[int, str]:
    """Lee equipos de próximos reales, no de una lista fija."""

    teams: dict[int, str] = {}
    for specification in registry_rows():
        family, _ = family_for(specification)
        if family != "UEFA":
            continue
        key = slug(specification.get("key"))
        path = COMPETITIONS_DIR / key / "matches_upcoming.json"
        if not path.exists():
            continue
        try:
            document = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        matches = document.get("matches") or document.get("events") or []
        for match in matches:
            if not isinstance(match, dict):
                continue
            for side in ("home", "away"):
                team_id = match.get(f"{side}_team_id")
                name = match.get(f"{side}_team") or match.get(f"{side}_name")
                try:
                    if team_id is not None:
                        teams[int(team_id)] = str(name or team_id)
                except (TypeError, ValueError):
                    continue
    return teams


def http_json(url: str) -> dict[str, Any] | None:
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0 OddsHunter/9.1",
            "Accept": "application/json,text/plain,*/*",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            payload = json.loads(response.read().decode("utf-8"))
            return payload if isinstance(payload, dict) else None
    except (OSError, urllib.error.HTTPError, json.JSONDecodeError):
        return None


def _team_country(payload: dict[str, Any] | None) -> tuple[str, str]:
    team = (payload or {}).get("team", payload or {})
    country = team.get("country", {}) if isinstance(team, dict) else {}
    return (
        str(country.get("alpha2") or "").upper(),
        str(country.get("name") or ""),
    )


def _country_matches(
    expected_code: str,
    expected_name: str,
    actual_code: str,
    actual_name: str,
) -> bool:
    """Tolera las variantes británicas de SofaScore sin mezclar países."""

    expected_code = str(expected_code or "").upper()
    actual_code = str(actual_code or "").upper()
    if not expected_code or not actual_code or expected_code == actual_code:
        return True
    british = {"GB", "UK", "EN", "SC", "WA", "WL", "NI"}
    if expected_code in british and actual_code in british:
        return True
    return bool(
        slug(expected_name)
        and slug(actual_name)
        and slug(expected_name) == slug(actual_name)
    )


def _domestic_candidate(
    event: dict[str, Any],
    country_code: str,
    country_name: str = "",
) -> tuple[int, int, str, str, str, int] | None:
    tournament = event.get("tournament", {})
    unique = tournament.get("uniqueTournament", {})
    season = event.get("season", {})
    category = tournament.get("category", {})
    category_country = category.get("country", {})
    event_country = str(category_country.get("alpha2") or "").upper()
    event_country_name = str(
        category_country.get("name") or category.get("name") or ""
    )
    if not _country_matches(
        country_code,
        country_name,
        event_country,
        event_country_name,
    ):
        return None
    name = str(unique.get("name") or tournament.get("name") or "").strip()
    normalized = slug(name)
    forbidden = (
        "champions", "conference", "europa-league", "sudamericana",
        "libertadores", "club-world", "friendly", "qualification",
        "cup", "copa", "pokal", "coupe", "supercup",
    )
    if not name or any(token in normalized for token in forbidden):
        return None
    tournament_id = unique.get("id") or tournament.get("id")
    season_id = season.get("id")
    try:
        return (
            int(tournament_id), int(season_id), name,
            str(category.get("name") or ""),
            str(season.get("name") or season_id),
            int(event.get("startTimestamp") or 0),
        )
    except (TypeError, ValueError):
        return None


def _select_domestic_answer(
    candidates: list[tuple[int, int, str, str, str, int]],
    country_name: str,
    seasons_document: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    if not candidates:
        return None
    grouped: dict[int, list[tuple[int, int, str, str, str, int]]] = {}
    for row in candidates:
        grouped.setdefault(row[0], []).append(row)
    selected_tournament = max(
        grouped,
        key=lambda tournament_id: (
            max(row[5] for row in grouped[tournament_id]),
            len(grouped[tournament_id]),
            tournament_id,
        ),
    )
    selected = max(grouped[selected_tournament], key=lambda row: row[5])
    current_season: dict[str, Any] | None = None
    season_rows = [
        row
        for row in (seasons_document or {}).get("seasons") or []
        if isinstance(row, dict) and row.get("id") is not None
    ]
    for season in season_rows:
        if isinstance(season, dict) and bool(season.get("isCurrent")):
            current_season = season
            break
    season_id = selected[1]
    season_name = selected[4]
    if current_season is not None:
        try:
            season_id = int(current_season.get("id"))
            season_name = str(
                current_season.get("name")
                or current_season.get("year")
                or season_id
            )
        except (TypeError, ValueError):
            pass
    selected_index: int | None = None
    for index, season in enumerate(season_rows):
        try:
            if int(season.get("id")) == int(season_id):
                selected_index = index
                break
        except (TypeError, ValueError):
            continue
    previous: dict[str, Any] | None = None
    if selected_index is not None:
        for season in season_rows[selected_index + 1:]:
            try:
                candidate_id = int(season.get("id"))
            except (TypeError, ValueError):
                continue
            if candidate_id == int(season_id):
                continue
            previous = {
                "season_id": candidate_id,
                "season_name": str(
                    season.get("name")
                    or season.get("year")
                    or candidate_id
                ),
            }
            break
    return {
        "tournament_id": selected[0],
        "season_id": season_id,
        "name": selected[2],
        "country": country_name or selected[3],
        "season_name": season_name,
        "previous_season": previous,
    }


def resolve_domestic_with_fetcher(
    team_id: int,
    fetch_json: Any,
) -> dict[str, Any] | None:
    """Resuelve la liga usando cualquier transporte JSON compatible."""

    team_payload = fetch_json(f"/api/v1/team/{team_id}")
    country_code, country_name = _team_country(team_payload)
    candidates: list[tuple[int, int, str, str, str, int]] = []

    # Un próximo doméstico identifica mejor la temporada vigente. Los últimos
    # eventos sirven de respaldo cuando el calendario siguiente aún está vacío.
    paths = [f"/api/v1/team/{team_id}/events/next/0"]
    for path in paths:
        payload = fetch_json(path)
        if not payload:
            continue
        for event in payload.get("events") or []:
            if isinstance(event, dict):
                candidate = _domestic_candidate(
                    event,
                    country_code,
                    country_name,
                )
                if candidate is not None:
                    candidates.append(candidate)

    # Si el calendario próximo ya entregó una liga doméstica, no se consultan
    # tres páginas históricas innecesarias. Si no, se amplía progresivamente.
    if not candidates:
        for page in range(3):
            payload = fetch_json(
                f"/api/v1/team/{team_id}/events/last/{page}"
            )
            if not payload:
                continue
            for event in payload.get("events") or []:
                if not isinstance(event, dict):
                    continue
                candidate = _domestic_candidate(
                    event,
                    country_code,
                    country_name,
                )
                if candidate is not None:
                    candidates.append(candidate)
            if candidates:
                break
    if not candidates:
        return None

    preliminary = _select_domestic_answer(candidates, country_name)
    if preliminary is None:
        return None
    selected_tournament = int(preliminary["tournament_id"])

    # SofaScore marca la temporada actual; si está disponible tiene prioridad
    # sobre una temporada inferida únicamente desde partidos anteriores.
    seasons_document = fetch_json(
        f"/api/v1/unique-tournament/{selected_tournament}/seasons"
    )
    return _select_domestic_answer(
        candidates,
        country_name,
        seasons_document,
    )


def resolve_domestic_api(team_id: int) -> dict[str, Any] | None:
    def fetch(path: str) -> dict[str, Any] | None:
        return http_json(f"https://www.sofascore.com{path}")

    return resolve_domestic_with_fetcher(team_id, fetch)


async def _browser_fetch_json_async(
    page: Any,
    path: str,
) -> dict[str, Any] | None:
    url = path if path.startswith("http") else f"https://www.sofascore.com{path}"
    # Una pestaña nueva consulta directamente el endpoint necesario. Evita
    # esperar la portada pesada de SofaScore, que puede quedar en about:blank
    # o fallar aunque la API sí responda.
    if not str(page.url).startswith("https://www.sofascore.com"):
        try:
            response = await page.goto(
                url,
                wait_until="commit",
                timeout=20_000,
            )
            if response is not None and int(response.status) == 200:
                document = await response.json()
                if isinstance(document, dict):
                    return document
        except Exception:
            # La navegación solo inicializa el origen. El fetch controlado de
            # abajo sigue siendo el respaldo de esta misma pestaña.
            pass
    try:
        result = await asyncio.wait_for(
            page.evaluate(
                """
                async (url) => {
                  const controller = new AbortController();
                  const timer = setTimeout(() => controller.abort(), 20000);
                  try {
                    const response = await fetch(url, {
                      credentials: 'include',
                      cache: 'no-store',
                      signal: controller.signal,
                      headers: { 'accept': 'application/json, text/plain, */*' }
                    });
                    const text = await response.text();
                    let data = null;
                    try { data = JSON.parse(text); } catch (_) {}
                    return { status: response.status, data: data };
                  } catch (error) {
                    return { status: 0, data: null, error: String(error) };
                  } finally {
                    clearTimeout(timer);
                  }
                }
                """,
                url,
            ),
            timeout=25.0,
        )
    except Exception:
        return None
    if not isinstance(result, dict) or int(result.get("status") or 0) != 200:
        return None
    document = result.get("data")
    return document if isinstance(document, dict) else None


async def _resolve_domestic_async(
    page: Any,
    team_id: int,
) -> dict[str, Any] | None:
    team_payload = await _browser_fetch_json_async(
        page,
        f"/api/v1/team/{team_id}",
    )
    country_code, country_name = _team_country(team_payload)
    candidates: list[tuple[int, int, str, str, str, int]] = []

    async def collect(path: str) -> None:
        payload = await _browser_fetch_json_async(page, path)
        for event in (payload or {}).get("events") or []:
            if not isinstance(event, dict):
                continue
            candidate = _domestic_candidate(event, country_code, country_name)
            if candidate is not None:
                candidates.append(candidate)

    await collect(f"/api/v1/team/{team_id}/events/next/0")
    if not candidates:
        for page_index in range(3):
            await collect(
                f"/api/v1/team/{team_id}/events/last/{page_index}"
            )
            if candidates:
                break
    preliminary = _select_domestic_answer(candidates, country_name)
    if preliminary is None:
        return None
    seasons = await _browser_fetch_json_async(
        page,
        "/api/v1/unique-tournament/"
        f"{int(preliminary['tournament_id'])}/seasons",
    )
    return _select_domestic_answer(candidates, country_name, seasons)


def distribute_team_ids(
    team_ids: list[int],
    maximum_tabs: int = MAX_DOMESTIC_BROWSER_TABS,
) -> list[list[int]]:
    unique_ids = list(dict.fromkeys(int(value) for value in team_ids))
    if not unique_ids:
        return []
    tab_count = min(max(1, int(maximum_tabs)), len(unique_ids), 12)
    buckets: list[list[int]] = [[] for _ in range(tab_count)]
    for index, team_id in enumerate(unique_ids):
        buckets[index % tab_count].append(team_id)
    return buckets


async def _resolve_domestic_browser_async(
    team_ids: list[int],
) -> tuple[dict[int, dict[str, Any]], str | None]:
    from playwright.async_api import async_playwright
    import sync_upcoming_matches as syncer

    buckets = distribute_team_ids(team_ids)
    if not buckets:
        return {}, None
    tab_count = len(buckets)
    resolved: dict[int, dict[str, Any]] = {}
    errors: list[str] = []

    async with async_playwright() as playwright:
        context = await playwright.chromium.launch_persistent_context(
            user_data_dir=str(BRAVE_PROFILE_DIR),
            executable_path=str(syncer.encontrar_brave()),
            headless=False,
            chromium_sandbox=True,
            locale="es-ES",
            viewport={"width": 1365, "height": 900},
            args=[
                "--start-maximized",
                "--disable-session-crashed-bubble",
                "--disable-features=InfiniteSessionRestore",
                "--no-first-run",
            ],
        )
        pages = list(context.pages)
        while len(pages) < tab_count:
            pages.append(await context.new_page())
        for extra_page in pages[tab_count:]:
            try:
                await extra_page.close()
            except Exception:
                pass
        pages = pages[:tab_count]
        async def worker(page: Any, bucket: list[int]) -> None:
            for team_id in bucket:
                print(
                    f"[Brave] Resolviendo equipo {team_id}...",
                    flush=True,
                )
                try:
                    answer = await asyncio.wait_for(
                        _resolve_domestic_async(page, team_id),
                        timeout=90.0,
                    )
                    if answer is not None:
                        resolved[team_id] = answer
                        print(
                            "[Brave] Equipo "
                            f"{team_id}: torneo={answer['tournament_id']} "
                            f"temporada={answer['season_id']}",
                            flush=True,
                        )
                    else:
                        print(
                            f"[Brave] Equipo {team_id}: sin liga resuelta.",
                            flush=True,
                        )
                except Exception as exc:
                    errors.append(
                        f"team_id={team_id}: {type(exc).__name__}: {exc}"
                    )
                    print(
                        f"[Brave] Equipo {team_id}: "
                        f"{type(exc).__name__}: {exc}",
                        flush=True,
                    )

        await asyncio.gather(
            *(worker(page, bucket) for page, bucket in zip(pages, buckets)),
            return_exceptions=True,
        )
        for page in pages:
            try:
                await asyncio.wait_for(page.close(), timeout=5.0)
            except Exception:
                pass
        try:
            await asyncio.wait_for(context.close(), timeout=10.0)
        except Exception:
            pass
    return resolved, "; ".join(errors[:5]) or None


def resolve_domestic_browser(
    team_ids: list[int],
) -> tuple[dict[int, dict[str, Any]], str | None]:
    """Procesa hasta 12 pestañas concurrentes, reutilizadas por lotes."""

    if not team_ids:
        return {}, None
    try:
        return asyncio.run(_resolve_domestic_browser_async(team_ids))
    except Exception as exc:
        return {}, f"{type(exc).__name__}: {exc}"


def ensure_domestic_specification(
    resolved: dict[str, Any],
    *,
    previous: bool = False,
) -> dict[str, Any]:
    document = registry_document()
    tournament_id = int(resolved["tournament_id"])
    previous_row = resolved.get("previous_season")
    if previous:
        if not isinstance(previous_row, dict):
            raise ValueError("No existe una temporada domÃ©stica anterior resuelta.")
        season_id = int(previous_row["season_id"])
        season_name = str(previous_row.get("season_name") or season_id)
    else:
        season_id = int(resolved["season_id"])
        season_name = str(resolved.get("season_name") or season_id)
    for row in document["competitions"]:
        if (
            int(row.get("source_competition_id") or 0) == tournament_id
            and int(row.get("season_id") or 0) == season_id
        ):
            row.update({
                "active": False,
                "context_only": True,
                "competition_family": "DOMESTIC",
                "context_role": (
                    "UEFA_DOMESTIC_CONTEXT_PREVIOUS"
                    if previous
                    else "UEFA_DOMESTIC_CONTEXT"
                ),
                "visible_in_ui": False,
                "same_competition_only": True,
                "current_season_only": not previous,
                "locked_season_id": True,
                "context_season_role": (
                    "PREVIOUS" if previous else "CURRENT"
                ),
                "lookback_months": 12,
            })
            save_registry(document)
            return row
    specification = {
        "key": f"domestic-context-{tournament_id}-{season_id}",
        "name": str(resolved["name"]),
        "country": str(resolved.get("country") or ""),
        "source": "sofascore",
        "source_competition_id": tournament_id,
        "season_id": season_id,
        "season_name": season_name,
        "bot9_managed": True,
        "active": False,
        "context_only": True,
        "competition_family": "DOMESTIC",
        "context_role": (
            "UEFA_DOMESTIC_CONTEXT_PREVIOUS"
            if previous
            else "UEFA_DOMESTIC_CONTEXT"
        ),
        "visible_in_ui": False,
        "same_competition_only": True,
        "current_season_only": not previous,
        "locked_season_id": True,
        "context_season_role": "PREVIOUS" if previous else "CURRENT",
        "lookback_months": 12,
    }
    document["competitions"].append(specification)
    save_registry(document)
    return specification


def persist_domestic_resolution(
    conn: sqlite3.Connection,
    sofascore_id: int,
    team_name: str,
    resolved: dict[str, Any],
) -> None:
    specification = ensure_domestic_specification(resolved)
    league_id = upsert_league(
        conn,
        name=str(specification["name"]),
        country=str(specification.get("country") or ""),
        season=str(specification.get("season_name") or resolved["season_id"]),
        active=False,
        source_tournament_id=int(resolved["tournament_id"]),
        source_season_id=int(resolved["season_id"]),
        competition_family="DOMESTIC",
        context_role="UEFA_DOMESTIC_CONTEXT",
        visible_in_ui=False,
    )
    team_id = upsert_team(conn, sofascore_id, team_name, None)
    upsert_team_competition_membership(
        conn,
        team_id=team_id,
        league_id=league_id,
        sofascore_tournament_id=int(resolved["tournament_id"]),
        sofascore_season_id=int(resolved["season_id"]),
        membership_role="DOMESTIC_CONTEXT",
    )
    if isinstance(resolved.get("previous_season"), dict):
        previous_specification = ensure_domestic_specification(
            resolved,
            previous=True,
        )
        previous_league_id = upsert_league(
            conn,
            name=str(previous_specification["name"]),
            country=str(previous_specification.get("country") or ""),
            season=str(previous_specification["season_name"]),
            active=False,
            source_tournament_id=int(resolved["tournament_id"]),
            source_season_id=int(previous_specification["season_id"]),
            competition_family="DOMESTIC",
            context_role="UEFA_DOMESTIC_CONTEXT_PREVIOUS",
            visible_in_ui=False,
        )
        upsert_team_competition_membership(
            conn,
            team_id=team_id,
            league_id=previous_league_id,
            sofascore_tournament_id=int(resolved["tournament_id"]),
            sofascore_season_id=int(previous_specification["season_id"]),
            membership_role="DOMESTIC_CONTEXT_PREVIOUS",
        )


def previous_season_from_document(
    document: dict[str, Any] | None,
    current_season_id: int,
) -> dict[str, Any] | None:
    rows = [
        row
        for row in (document or {}).get("seasons") or []
        if isinstance(row, dict)
    ]
    current_index: int | None = None
    for index, row in enumerate(rows):
        try:
            if int(row.get("id")) == int(current_season_id):
                current_index = index
                break
        except (TypeError, ValueError):
            continue
    if current_index is None:
        return None
    for row in rows[current_index + 1:]:
        try:
            season_id = int(row.get("id"))
        except (TypeError, ValueError):
            continue
        if season_id == int(current_season_id):
            continue
        return {
            "season_id": season_id,
            "season_name": str(
                row.get("name") or row.get("year") or season_id
            ),
        }
    return None


def persist_previous_for_league(
    conn: sqlite3.Connection,
    current_league: sqlite3.Row,
    previous: dict[str, Any],
) -> int:
    resolved = {
        "tournament_id": int(current_league["source_tournament_id"]),
        "season_id": int(current_league["source_season_id"]),
        "season_name": str(current_league["season"] or ""),
        "name": str(current_league["name"] or "Domestic context"),
        "country": str(current_league["country"] or ""),
        "previous_season": previous,
    }
    specification = ensure_domestic_specification(resolved, previous=True)
    previous_league_id = upsert_league(
        conn,
        name=str(specification["name"]),
        country=str(specification.get("country") or ""),
        season=str(specification.get("season_name") or previous["season_id"]),
        active=False,
        source_tournament_id=int(resolved["tournament_id"]),
        source_season_id=int(previous["season_id"]),
        competition_family="DOMESTIC",
        context_role="UEFA_DOMESTIC_CONTEXT_PREVIOUS",
        visible_in_ui=False,
    )
    members = conn.execute(
        """
        SELECT team_id
        FROM team_competition_memberships
        WHERE league_id=?;
        """,
        (int(current_league["league_id"]),),
    ).fetchall()
    for member in members:
        upsert_team_competition_membership(
            conn,
            team_id=int(member["team_id"]),
            league_id=previous_league_id,
            sofascore_tournament_id=int(resolved["tournament_id"]),
            sofascore_season_id=int(previous["season_id"]),
            membership_role="DOMESTIC_CONTEXT_PREVIOUS",
        )
    return len(members)


async def _previous_seasons_browser_async(
    requests: list[tuple[int, int]],
) -> tuple[dict[tuple[int, int], dict[str, Any]], str | None]:
    from playwright.async_api import async_playwright
    import sync_upcoming_matches as syncer

    unique = list(dict.fromkeys(requests))
    if not unique:
        return {}, None
    tab_count = min(MAX_DOMESTIC_BROWSER_TABS, len(unique), 12)
    buckets = [unique[index::tab_count] for index in range(tab_count)]
    resolved: dict[tuple[int, int], dict[str, Any]] = {}
    errors: list[str] = []
    async with async_playwright() as playwright:
        context = await playwright.chromium.launch_persistent_context(
            user_data_dir=str(BRAVE_PROFILE_DIR),
            executable_path=str(syncer.encontrar_brave()),
            headless=False,
            chromium_sandbox=True,
            locale="es-ES",
            viewport={"width": 1365, "height": 900},
            args=["--start-maximized", "--no-first-run"],
        )
        pages = list(context.pages)
        while len(pages) < tab_count:
            pages.append(await context.new_page())
        pages = pages[:tab_count]

        async def worker(page: Any, bucket: list[tuple[int, int]]) -> None:
            for tournament_id, current_season_id in bucket:
                try:
                    document = await _browser_fetch_json_async(
                        page,
                        f"/api/v1/unique-tournament/{tournament_id}/seasons",
                    )
                    previous = previous_season_from_document(
                        document,
                        current_season_id,
                    )
                    if previous is not None:
                        resolved[(tournament_id, current_season_id)] = previous
                except Exception as exc:
                    errors.append(
                        f"{tournament_id}: {type(exc).__name__}: {exc}"
                    )

        await asyncio.gather(
            *(worker(page, bucket) for page, bucket in zip(pages, buckets)),
            return_exceptions=True,
        )
        for page in pages:
            try:
                await asyncio.wait_for(page.close(), timeout=5.0)
            except Exception:
                pass
        try:
            await asyncio.wait_for(context.close(), timeout=10.0)
        except Exception:
            pass
    return resolved, "; ".join(errors[:5]) or None


def ensure_previous_domestic_contexts(
    conn: sqlite3.Connection,
) -> dict[str, Any]:
    """Descubre la temporada inmediatamente anterior de contextos existentes."""

    rows = conn.execute(
        """
        SELECT league_id, name, country, season,
               source_tournament_id, source_season_id
        FROM leagues
        WHERE competition_family='DOMESTIC'
          AND source_tournament_id IS NOT NULL
          AND source_season_id IS NOT NULL
          AND COALESCE(context_role, '') != 'UEFA_DOMESTIC_CONTEXT_PREVIOUS'
          AND EXISTS (
              SELECT 1
              FROM team_competition_memberships AS membership
              WHERE membership.league_id=leagues.league_id
                AND EXISTS (
                    SELECT 1
                    FROM team_competition_memberships AS uefa
                    JOIN leagues AS uefa_league
                      ON uefa_league.league_id=uefa.league_id
                    WHERE uefa.team_id=membership.team_id
                      AND uefa_league.competition_family='UEFA'
                )
          );
        """
    ).fetchall()
    found = 0
    pending: list[sqlite3.Row] = []
    consecutive_failures = 0
    for row in rows:
        tournament_id = int(row["source_tournament_id"])
        current_season_id = int(row["source_season_id"])
        existing = conn.execute(
            """
            SELECT league_id, source_season_id FROM leagues
            WHERE source_tournament_id=?
              AND context_role='UEFA_DOMESTIC_CONTEXT_PREVIOUS'
            LIMIT 1;
            """,
            (tournament_id,),
        ).fetchone()
        if existing is not None:
            members = conn.execute(
                """
                SELECT team_id FROM team_competition_memberships
                WHERE league_id=?;
                """,
                (int(row["league_id"]),),
            ).fetchall()
            for member in members:
                upsert_team_competition_membership(
                    conn,
                    team_id=int(member["team_id"]),
                    league_id=int(existing["league_id"]),
                    sofascore_tournament_id=tournament_id,
                    sofascore_season_id=int(existing["source_season_id"]),
                    membership_role="DOMESTIC_CONTEXT_PREVIOUS",
                )
            continue
        if consecutive_failures >= 2:
            pending.append(row)
            continue
        document = http_json(
            f"{SOFASCORE_API}/unique-tournament/{tournament_id}/seasons"
        )
        previous = previous_season_from_document(document, current_season_id)
        if previous is None:
            consecutive_failures += 1
            pending.append(row)
            continue
        consecutive_failures = 0
        persist_previous_for_league(conn, row, previous)
        found += 1

    browser_error = None
    browser_found = 0
    if pending:
        requests = [
            (int(row["source_tournament_id"]), int(row["source_season_id"]))
            for row in pending
        ]
        try:
            browser_results, browser_error = asyncio.run(
                _previous_seasons_browser_async(requests)
            )
        except Exception as exc:
            browser_results = {}
            browser_error = f"{type(exc).__name__}: {exc}"
        for row in pending:
            key = (
                int(row["source_tournament_id"]),
                int(row["source_season_id"]),
            )
            previous = browser_results.get(key)
            if previous is None:
                continue
            persist_previous_for_league(conn, row, previous)
            found += 1
            browser_found += 1
    return {
        "found": found,
        "unresolved": max(0, len(pending) - browser_found),
        "browser_tabs": min(len(pending), MAX_DOMESTIC_BROWSER_TABS),
        "browser_error": browser_error,
    }


def discover_missing_domestic_contexts(
    conn: sqlite3.Connection,
) -> dict[str, Any]:
    """Resuelve dinámicamente liga/temporada para próximos equipos UEFA."""

    found = 0
    direct_found = 0
    browser_found = 0
    pending: list[tuple[int, str]] = []
    for sofascore_id, team_name in upcoming_uefa_teams().items():
        existing = conn.execute(
            """
            SELECT 1
            FROM team_competition_memberships AS membership
            JOIN teams AS team ON team.team_id=membership.team_id
            JOIN leagues AS league ON league.league_id=membership.league_id
            WHERE team.sofascore_id=?
              AND league.competition_family='DOMESTIC'
            LIMIT 1;
            """,
            (sofascore_id,),
        ).fetchone()
        if existing is not None:
            continue
        pending.append((sofascore_id, team_name))

    # Dos fallos consecutivos suelen indicar el HTTP 403 global de SofaScore.
    # En ese caso se evita repetir cientos de consultas directas y se pasa el
    # resto del lote a una única sesión reutilizable de Brave.
    browser_pending: list[tuple[int, str]] = []
    consecutive_direct_failures = 0
    for sofascore_id, team_name in pending:
        if consecutive_direct_failures >= 2:
            browser_pending.append((sofascore_id, team_name))
            continue
        resolved = resolve_domestic_api(sofascore_id)
        if resolved is None:
            consecutive_direct_failures += 1
            browser_pending.append((sofascore_id, team_name))
            continue
        consecutive_direct_failures = 0
        persist_domestic_resolution(
            conn,
            sofascore_id,
            team_name,
            resolved,
        )
        direct_found += 1
        found += 1

    browser_error = None
    if browser_pending:
        browser_results, browser_error = resolve_domestic_browser(
            [team_id for team_id, _ in browser_pending]
        )
        for sofascore_id, team_name in browser_pending:
            resolved = browser_results.get(sofascore_id)
            if resolved is None:
                continue
            persist_domestic_resolution(
                conn,
                sofascore_id,
                team_name,
                resolved,
            )
            browser_found += 1
            found += 1

    unresolved_ids = [
        team_id
        for team_id, _ in browser_pending
        if team_id not in (
            browser_results if browser_pending else {}
        )
    ]
    return {
        "found": found,
        "direct_found": direct_found,
        "browser_found": browser_found,
        "browser_tabs": min(
            MAX_DOMESTIC_BROWSER_TABS,
            len(browser_pending),
        ),
        "unresolved": len(unresolved_ids),
        "unresolved_team_ids": unresolved_ids[:12],
        "browser_error": browser_error,
    }


def bootstrap_metadata(conn: sqlite3.Connection) -> int:
    """Vincula leagues existentes con IDs del registro sin recrearlas."""

    updated = 0
    for specification in registry_rows():
        tournament_id = specification.get("source_competition_id")
        season_id = specification.get("season_id")
        if tournament_id is None or season_id is None:
            continue
        family, role = family_for(specification)
        names = {
            str(value).strip().casefold()
            for value in (
                specification.get("name"),
                specification.get("source_name"),
                *(specification.get("aliases") or []),
            )
            if str(value or "").strip()
        }
        season = str(specification.get("season_name") or "").strip().casefold()
        for league in conn.execute(
            "SELECT league_id, name, season FROM leagues;"
        ).fetchall():
            if str(league["name"] or "").strip().casefold() not in names:
                continue
            if season and str(league["season"] or "").strip().casefold() != season:
                continue
            conn.execute(
                """
                UPDATE leagues
                SET source_tournament_id = ?,
                    source_season_id = ?,
                    competition_family = ?,
                    context_role = ?,
                    visible_in_ui = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE league_id = ?;
                """,
                (
                    int(tournament_id), int(season_id), family, role,
                    int(bool(specification.get("visible_in_ui", True))),
                    int(league["league_id"]),
                ),
            )
            updated += 1
    return updated


def rebuild_memberships(conn: sqlite3.Connection) -> int:
    """Deriva membresías de partidos ya almacenados sin duplicar clubes."""

    rows = conn.execute(
        """
        SELECT DISTINCT
            stats.team_id,
            matches.league_id,
            leagues.source_tournament_id,
            leagues.source_season_id
        FROM team_match_stats AS stats
        JOIN matches ON matches.match_id = stats.match_id
        JOIN leagues ON leagues.league_id = matches.league_id
        WHERE leagues.source_tournament_id IS NOT NULL
          AND leagues.source_season_id IS NOT NULL;
        """
    ).fetchall()
    for row in rows:
        upsert_team_competition_membership(
            conn,
            team_id=int(row["team_id"]),
            league_id=int(row["league_id"]),
            sofascore_tournament_id=int(row["source_tournament_id"]),
            sofascore_season_id=int(row["source_season_id"]),
        )
    return len(rows)


def enqueue_domestic_contexts(conn: sqlite3.Connection) -> int:
    """Encola cada liga doméstica una vez para participantes UEFA."""

    rows = conn.execute(
        """
        SELECT DISTINCT
            uefa.team_id,
            domestic.league_id,
            domestic.sofascore_tournament_id,
            domestic.sofascore_season_id
        FROM team_competition_memberships AS uefa
        JOIN leagues AS uefa_league ON uefa_league.league_id = uefa.league_id
        JOIN team_competition_memberships AS domestic
          ON domestic.team_id = uefa.team_id
        JOIN leagues AS domestic_league
          ON domestic_league.league_id = domestic.league_id
        WHERE uefa_league.competition_family = 'UEFA'
          AND domestic_league.competition_family = 'DOMESTIC'
          AND COALESCE(domestic.membership_role, '')
              != 'DOMESTIC_CONTEXT_PREVIOUS';
        """
    ).fetchall()
    before = conn.total_changes
    for row in rows:
        conn.execute(
            """
            INSERT INTO domestic_import_queue (
                team_id, domestic_tournament_id, domestic_season_id,
                domestic_league_id, status, priority
            )
            VALUES (?, ?, ?, ?, 'PENDING', 100)
            ON CONFLICT(domestic_tournament_id, domestic_season_id)
            DO UPDATE SET
                domestic_league_id = COALESCE(
                    domestic_import_queue.domestic_league_id,
                    excluded.domestic_league_id
                ),
                updated_at = CURRENT_TIMESTAMP;
            """,
            (
                int(row["team_id"]),
                int(row["sofascore_tournament_id"]),
                int(row["sofascore_season_id"]),
                int(row["league_id"]),
            ),
        )
    return conn.total_changes - before


def team_market_counts(
    conn: sqlite3.Connection,
    team_id: int,
    league_id: int,
) -> dict[str, int]:
    row = conn.execute(
        """
        SELECT
          COUNT(DISTINCT CASE
            WHEN stats.goals_for IS NOT NULL AND stats.goals_against IS NOT NULL
            THEN matches.match_id END) AS goals,
          COUNT(DISTINCT CASE
            WHEN stats.xg_for IS NOT NULL AND stats.xg_against IS NOT NULL
            THEN matches.match_id END) AS xg,
          COUNT(DISTINCT CASE
            WHEN stats.shots IS NOT NULL THEN matches.match_id END) AS shots,
          COUNT(DISTINCT CASE
            WHEN stats.corners_for IS NOT NULL AND stats.corners_against IS NOT NULL
            THEN matches.match_id END) AS corners,
          COUNT(DISTINCT CASE
            WHEN stats.yellow_cards IS NOT NULL THEN matches.match_id END) AS cards
        FROM team_match_stats AS stats
        JOIN matches ON matches.match_id=stats.match_id
        WHERE stats.team_id=? AND matches.league_id=?
          AND matches.status='FT';
        """,
        (int(team_id), int(league_id)),
    ).fetchone()
    return {
        market: int(row[market] or 0)
        for market in ("goals", "xg", "shots", "corners", "cards")
    }


def enqueue_previous_season_if_needed(
    conn: sqlite3.Connection,
    tournament_id: int,
    current_season_id: int,
) -> int:
    current = conn.execute(
        """
        SELECT league_id
        FROM leagues
        WHERE source_tournament_id=? AND source_season_id=?
        LIMIT 1;
        """,
        (int(tournament_id), int(current_season_id)),
    ).fetchone()
    previous = conn.execute(
        """
        SELECT league_id, source_season_id
        FROM leagues
        WHERE source_tournament_id=?
          AND context_role='UEFA_DOMESTIC_CONTEXT_PREVIOUS'
        ORDER BY league_id DESC
        LIMIT 1;
        """,
        (int(tournament_id),),
    ).fetchone()
    if current is None or previous is None:
        return 0
    candidates = conn.execute(
        """
        SELECT DISTINCT current_member.team_id
        FROM team_competition_memberships AS current_member
        WHERE current_member.league_id=?
          AND EXISTS (
            SELECT 1
            FROM team_competition_memberships AS uefa
            JOIN leagues AS league ON league.league_id=uefa.league_id
            WHERE uefa.team_id=current_member.team_id
              AND league.competition_family='UEFA'
          );
        """,
        (int(current["league_id"]),),
    ).fetchall()
    needing = [
        int(row["team_id"])
        for row in candidates
        if min(
            team_market_counts(
                conn,
                int(row["team_id"]),
                int(current["league_id"]),
            ).values(),
            default=0,
        ) < 15
    ]
    if not needing:
        return 0
    representative = needing[0]
    before = conn.total_changes
    conn.execute(
        """
        INSERT INTO domestic_import_queue (
            team_id, domestic_tournament_id, domestic_season_id,
            domestic_league_id, status, priority
        ) VALUES (?, ?, ?, ?, 'PENDING', 200)
        ON CONFLICT(domestic_tournament_id, domestic_season_id)
        DO UPDATE SET
            status = CASE
                WHEN domestic_import_queue.status='DONE' THEN 'DONE'
                ELSE 'PENDING'
            END,
            domestic_league_id=excluded.domestic_league_id,
            updated_at=CURRENT_TIMESTAMP;
        """,
        (
            representative,
            int(tournament_id),
            int(previous["source_season_id"]),
            int(previous["league_id"]),
        ),
    )
    return conn.total_changes - before


def specification_for(
    tournament_id: int,
    season_id: int,
) -> dict[str, Any] | None:
    for row in registry_rows():
        if (
            int(row.get("source_competition_id") or 0) == tournament_id
            and int(row.get("season_id") or 0) == season_id
        ):
            return row
    return None


def run_command(arguments: list[str]) -> None:
    completed = subprocess.run(arguments, cwd=BASE_DIR, check=False)
    if completed.returncode != 0:
        raise RuntimeError(
            f"El comando terminó con código {completed.returncode}: {arguments}"
        )


def run_one(conn: sqlite3.Connection) -> dict[str, Any] | None:
    row = conn.execute(
        """
        SELECT *
        FROM domestic_import_queue
        WHERE status IN ('PENDING', 'ERROR')
        ORDER BY priority ASC, created_at ASC, queue_id ASC
        LIMIT 1;
        """
    ).fetchone()
    if row is None:
        return None
    queue_id = int(row["queue_id"])
    tournament_id = int(row["domestic_tournament_id"])
    season_id = int(row["domestic_season_id"])
    specification = specification_for(tournament_id, season_id)
    if specification is None:
        conn.execute(
            """
            UPDATE domestic_import_queue
            SET status='SKIPPED',
                last_error='La liga no existe en data/competitions.json',
                updated_at=CURRENT_TIMESTAMP,
                finished_at=CURRENT_TIMESTAMP
            WHERE queue_id=?;
            """,
            (queue_id,),
        )
        conn.commit()
        return {"queue_id": queue_id, "status": "SKIPPED"}

    key = str(specification.get("key") or "").strip()
    conn.execute(
        """
        UPDATE domestic_import_queue
        SET status='RUNNING', attempts=attempts+1,
            started_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP,
            last_error=NULL
        WHERE queue_id=?;
        """,
        (queue_id,),
    )
    conn.commit()
    try:
        # La liga doméstica ya está identificada por tournament_id/season_id.
        # Se consulta el calendario completo del torneo; no se vuelve a abrir
        # visualmente cada club como hacía sync_competition.py. La importación
        # incremental posterior conserva el paralelismo multifuente existente.
        run_command([
            sys.executable,
            "tournament_season_sync.py",
            "--key",
            key,
            "--import-finished",
        ])
        previous_queued = 0
        if str(specification.get("context_season_role") or "CURRENT").upper() == "CURRENT":
            previous_queued = enqueue_previous_season_if_needed(
                conn,
                tournament_id,
                season_id,
            )
    except Exception as exc:
        conn.execute(
            """
            UPDATE domestic_import_queue
            SET status='ERROR', last_error=?, updated_at=CURRENT_TIMESTAMP
            WHERE queue_id=?;
            """,
            (f"{type(exc).__name__}: {exc}", queue_id),
        )
        conn.commit()
        return {"queue_id": queue_id, "status": "ERROR", "error": str(exc)}

    conn.execute(
        """
        UPDATE domestic_import_queue
        SET status='DONE', updated_at=CURRENT_TIMESTAMP,
            finished_at=CURRENT_TIMESTAMP
        WHERE queue_id=?;
        """,
        (queue_id,),
    )
    conn.commit()
    return {
        "queue_id": queue_id,
        "status": "DONE",
        "key": key,
        "previous_season_queued": previous_queued,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Prepara e importa contextos domésticos, una liga por ejecución."
    )
    parser.add_argument("--discover", action="store_true")
    parser.add_argument("--run-one", action="store_true")
    args = parser.parse_args()
    with get_connection() as conn:
        metadata = bootstrap_metadata(conn)
        memberships = rebuild_memberships(conn)
        dynamic = discover_missing_domestic_contexts(conn) if args.discover else {
            "found": 0,
            "unresolved": 0,
        }
        previous = ensure_previous_domestic_contexts(conn) if args.discover else {
            "found": 0,
            "unresolved": 0,
        }
        queued = enqueue_domestic_contexts(conn)
        conn.commit()
        result = run_one(conn) if args.run_one else None
    print(json.dumps({
        "metadata_updated": metadata,
        "memberships_rebuilt": memberships,
        "dynamic_discovery": dynamic,
        "previous_season_discovery": previous,
        "queue_changes": queued,
        "execution": result,
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
