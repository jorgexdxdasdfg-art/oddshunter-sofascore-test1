from __future__ import annotations

import argparse
import json
import time
from collections import defaultdict, deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from playwright.sync_api import sync_playwright
import sync_upcoming_matches as syncer

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
AUTOMATION_DIR = DATA_DIR / "automation"
COMPETITIONS_DIR = DATA_DIR / "competitions"
STATE_PATH = AUTOMATION_DIR / "calendar_queue_state.json"
REPORT_PATH = AUTOMATION_DIR / "calendar_maintenance_last.json"

DEFAULT_MAX_TEAMS = 8
DEFAULT_MAX_SECONDS = 8 * 60
URGENT_WINDOW_HOURS = 72.0
URGENT_REFRESH_HOURS = 6.0
EMPTY_REFRESH_HOURS = 12.0
NORMAL_REFRESH_HOURS = 24.0


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def iso_now() -> str:
    return utc_now().isoformat()


def parse_datetime(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def read_json(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return data if isinstance(data, dict) else None


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def active_competitions() -> list[dict[str, Any]]:
    registry = syncer.load_registry()
    rows = [
        row for row in registry.get("competitions", [])
        if isinstance(row, dict)
        and bool(row.get("active", True))
        and str(row.get("key") or "").strip()
    ]
    rows.sort(key=lambda row: str(row.get("name") or row.get("key")))
    return rows


def existing_rows(key: str) -> dict[int, dict[str, Any]]:
    path = COMPETITIONS_DIR / key / "next_match_by_team.json"
    document = read_json(path) or {}
    rows = document.get("teams")
    result: dict[int, dict[str, Any]] = {}
    if not isinstance(rows, list):
        return result
    for row in rows:
        if not isinstance(row, dict):
            continue
        try:
            result[int(row["team_id"])] = dict(row)
        except (KeyError, TypeError, ValueError):
            continue
    return result


def schedule_is_empty(key: str) -> bool:
    path = COMPETITIONS_DIR / key / "matches_upcoming.json"
    document = read_json(path) or {}
    matches = document.get("matches")
    return not isinstance(matches, list) or len(matches) == 0


def candidate_for_team(
    competition: dict[str, Any],
    team: dict[str, Any],
    row: dict[str, Any] | None,
    force: bool,
) -> dict[str, Any] | None:
    now = utc_now()
    key = syncer.slugify(str(competition["key"]))
    updated = parse_datetime(row.get("updated_at")) if row else None
    age_hours = 10_000.0 if updated is None else max(0.0, (now - updated).total_seconds() / 3600.0)
    next_match = row.get("next_match") if row else None
    kickoff_ts = None
    if isinstance(next_match, dict):
        try:
            kickoff_ts = int(next_match.get("start_timestamp"))
        except (TypeError, ValueError):
            kickoff_ts = None
    hours_to_kickoff = None
    if kickoff_ts is not None:
        hours_to_kickoff = (kickoff_ts - int(now.timestamp())) / 3600.0

    league_empty = schedule_is_empty(key)
    if league_empty:
        priority = 0
        due = True
        reason = "liga sin próximos partidos sincronizados"
    elif row is None:
        priority = 0
        due = True
        reason = "equipo sin calendario guardado"
    elif next_match is None:
        priority = 1
        due = age_hours >= EMPTY_REFRESH_HOURS
        reason = "equipo sin próximo partido"
    elif hours_to_kickoff is not None and -1.0 <= hours_to_kickoff <= URGENT_WINDOW_HOURS:
        priority = 1
        due = age_hours >= URGENT_REFRESH_HOURS
        reason = "partido dentro de 72 horas"
    else:
        priority = 2
        due = age_hours >= NORMAL_REFRESH_HOURS
        reason = "mantenimiento periódico por equipo"

    if force:
        due = True
    if not due:
        return None

    return {
        "competition_key": key,
        "competition_name": competition.get("name") or key,
        "competition": competition,
        "team": team,
        "team_id": int(team["team_id"]),
        "team_name": team.get("name") or str(team["team_id"]),
        "priority": priority,
        "age_hours": round(age_hours, 2),
        "hours_to_kickoff": None if hours_to_kickoff is None else round(hours_to_kickoff, 2),
        "reason": reason,
    }


def select_round_robin(
    competitions: list[dict[str, Any]],
    max_teams: int,
    force: bool,
) -> tuple[list[dict[str, Any]], int, int]:
    state = read_json(STATE_PATH) or {}
    start_cursor = int(state.get("competition_cursor") or 0)
    per_key: dict[str, list[dict[str, Any]]] = {}
    total_candidates = 0

    for competition in competitions:
        key = syncer.slugify(str(competition["key"]))
        try:
            teams, _ = syncer.load_teams(competition)
        except Exception:
            continue
        rows = existing_rows(key)
        candidates: list[dict[str, Any]] = []
        for team in teams:
            item = candidate_for_team(competition, team, rows.get(int(team["team_id"])), force)
            if item is not None:
                candidates.append(item)
        candidates.sort(key=lambda item: (int(item["priority"]), -float(item["age_hours"]), str(item["team_name"])))
        if candidates:
            per_key[key] = candidates
            total_candidates += len(candidates)

    keys = [syncer.slugify(str(row["key"])) for row in competitions if syncer.slugify(str(row["key"])) in per_key]
    if not keys or max_teams <= 0:
        return [], start_cursor, total_candidates

    start_cursor %= len(keys)
    rotated = keys[start_cursor:] + keys[:start_cursor]
    queues = {key: deque(per_key[key]) for key in rotated}
    selected: list[dict[str, Any]] = []

    for priority in (0, 1, 2):
        progressed = True
        while progressed and len(selected) < max_teams:
            progressed = False
            for key in rotated:
                queue_for_key = queues[key]
                while queue_for_key and int(queue_for_key[0]["priority"]) < priority:
                    queue_for_key.popleft()
                if queue_for_key and int(queue_for_key[0]["priority"]) == priority:
                    selected.append(queue_for_key.popleft())
                    progressed = True
                    if len(selected) >= max_teams:
                        break

    next_cursor = (start_cursor + 1) % len(keys)
    return selected, next_cursor, total_candidates


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Mantiene calendarios mediante una cola global limitada por equipos. "
            "Nunca recorre una liga completa en un solo ciclo."
        )
    )
    parser.add_argument("--max-teams", type=int, default=DEFAULT_MAX_TEAMS)
    parser.add_argument("--max-seconds", type=int, default=DEFAULT_MAX_SECONDS)
    parser.add_argument("--force", action="store_true")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    max_teams = max(0, min(int(args.max_teams), 30))
    max_seconds = max(60, int(args.max_seconds))
    competitions = active_competitions()

    # Una liga completamente vacía se intenta arrancar con una sola consulta
    # de competición. Esto evita esperar varios ciclos de ocho equipos para
    # que Liga MX, LigaPro o Brasil aparezcan por primera vez.
    empty_competitions = [
        competition
        for competition in competitions
        if schedule_is_empty(syncer.slugify(str(competition["key"])))
    ]

    # El arranque de recuperación usa --max-teams 0. En ese modo no tiene
    # sentido recorrer todos los equipos y construir cientos de candidatos:
    # únicamente interesan las ligas realmente vacías.
    if max_teams <= 0 and not bool(args.force):
        state = read_json(STATE_PATH) or {}
        selected = []
        next_cursor = int(state.get("competition_cursor") or 0)
        total_candidates = 0
    else:
        selected, next_cursor, total_candidates = select_round_robin(
            competitions,
            max_teams,
            bool(args.force),
        )

    report: dict[str, Any] = {
        "generated_at": iso_now(),
        "policy": "global_round_robin_micro_batch",
        "browser_policy": "single_context_single_page",
        "max_teams": max_teams,
        "max_seconds": max_seconds,
        "total_candidates": total_candidates,
        "selected": [
            {k: row[k] for k in ("competition_key", "competition_name", "team_id", "team_name", "priority", "age_hours", "hours_to_kickoff", "reason")}
            for row in selected
        ],
        "processed": [],
        "bootstrapped": [],
        "errors": [],
    }

    print("=" * 82)
    print("ODDSHUNTER — COLA GLOBAL ADAPTATIVA")
    print("=" * 82)
    print(f"Ligas activas: {len(competitions)}")
    print(f"Candidatos pendientes: {total_candidates}")
    print(f"Ligas vacías para arranque rápido: {len(empty_competitions)}")
    print(f"Límite de este ciclo: {max_teams} equipos o {max_seconds // 60} minutos")
    print("Política: arranque rápido por liga vacía + micro-lotes por equipo.")

    if not selected and not empty_competitions:
        write_json(REPORT_PATH, report)
        write_json(STATE_PATH, {"updated_at": iso_now(), "competition_cursor": next_cursor})
        print("No hay equipos que requieran mantenimiento ahora.")
        return

    grouped: dict[str, dict[str, Any]] = {}
    for item in selected:
        key = str(item["competition_key"])
        if key not in grouped:
            competition = item["competition"]
            teams, _ = syncer.load_teams(competition)
            grouped[key] = {
                "competition": competition,
                "teams": teams,
                "matches": {},
                "by_team": {},
                "failures": [],
                "successful": set(),
            }

    brave = syncer.encontrar_brave()
    started = time.monotonic()
    processed_count = 0

    with sync_playwright() as playwright:
        context = playwright.chromium.launch_persistent_context(
            user_data_dir=str(syncer.BRAVE_PROFILE_DIR),
            executable_path=str(brave),
            headless=False,
            chromium_sandbox=True,
            locale="es-ES",
            viewport={"width": 1365, "height": 900},
            args=[
                "--start-maximized",
                "--disable-session-crashed-bubble",
                "--disable-features=InfiniteSessionRestore",
                "--no-first-run",
            ],
        )
        pages = list(context.pages)
        page = pages[0] if pages else context.new_page()
        for extra in pages[1:]:
            try:
                extra.close()
            except Exception:
                pass
        try:
            page.goto("about:blank", wait_until="domcontentloaded")
        except Exception:
            pass

        try:
            bootstrapped_keys: set[str] = set()
            for competition in empty_competitions:
                key = syncer.slugify(str(competition["key"]))
                name = str(competition.get("name") or key)
                print(f"⚡ Arranque rápido: {name}")
                try:
                    bootstrap = syncer.bootstrap_competition_schedule(page, competition)
                    report["bootstrapped"].append(bootstrap)
                    if bootstrap.get("status") == "OK" and bootstrap.get("event_ids"):
                        bootstrapped_keys.add(key)
                        print(
                            f"   ✅ {len(bootstrap.get('event_ids') or [])} partidos "
                            "sincronizados con una sola pestaña"
                        )
                    else:
                        print("   ⚠ La competición no devolvió próximos partidos; se mantiene el respaldo por equipos.")
                except Exception as exc:
                    error = f"{type(exc).__name__}: {exc}"
                    report["errors"].append({"competition_key": key, "stage": "bootstrap", "error": error})
                    print(f"   ❌ {error}")

            for index, item in enumerate(selected, start=1):
                if str(item["competition_key"]) in bootstrapped_keys:
                    # El calendario completo ya fue creado en una consulta.
                    continue
                if processed_count > 0 and (time.monotonic() - started) >= max_seconds:
                    print("⏱ Presupuesto de tiempo alcanzado; la cola continúa en el siguiente ciclo.")
                    break
                key = str(item["competition_key"])
                bucket = grouped[key]
                competition = bucket["competition"]
                team = item["team"]
                team_id = int(item["team_id"])
                name = str(item["team_name"])
                competition_id = int(competition["source_competition_id"])
                season_value = competition.get("season_id")
                target_season_id = int(season_value) if season_value is not None else None
                print(f"[{index:02d}/{len(selected):02d}] {item['competition_name']} · {name}")
                try:
                    events = syncer.capture_team_upcoming(
                        page=page,
                        team=team,
                        competition_id=competition_id,
                        target_season_id=target_season_id,
                        per_team=3,
                    )
                    event_ids: list[int] = []
                    for event in events:
                        summary = syncer.event_summary(event)
                        event_id = int(summary["event_id"])
                        bucket["matches"][event_id] = summary
                        event_ids.append(event_id)
                    bucket["by_team"][team_id] = event_ids
                    bucket["successful"].add(team_id)
                    report["processed"].append({"competition_key": key, "team_id": team_id, "team_name": name, "events": event_ids})
                    processed_count += 1
                    print("   ✅ procesado en la pestaña reutilizable")
                except Exception as exc:
                    error = f"{type(exc).__name__}: {exc}"
                    bucket["failures"].append({"team_id": team_id, "team_name": name, "error": error})
                    report["errors"].append({"competition_key": key, "team_id": team_id, "team_name": name, "error": error})
                    print(f"   ❌ {error}")
                    if "verificación" in str(exc).lower():
                        break
                finally:
                    syncer.save_results(
                        competition=competition,
                        teams=bucket["teams"],
                        matches=bucket["matches"],
                        by_team=bucket["by_team"],
                        failures=bucket["failures"],
                        successful_team_ids=bucket["successful"],
                        merge_existing=True,
                    )
        finally:
            syncer.close_playwright_target(page, "página de mantenimiento")
            syncer.close_playwright_target(context, "contexto de Brave")

    report["processed_count"] = processed_count
    report["bootstrapped_count"] = sum(
        1 for row in report.get("bootstrapped", [])
        if isinstance(row, dict) and row.get("status") == "OK"
    )
    report["elapsed_seconds"] = round(time.monotonic() - started, 2)
    report["remaining_candidates_estimate"] = max(0, total_candidates - processed_count)
    write_json(REPORT_PATH, report)
    write_json(STATE_PATH, {"updated_at": iso_now(), "competition_cursor": next_cursor})
    print("=" * 82)
    print(f"Ligas arrancadas rápidamente: {report['bootstrapped_count']}")
    print(f"Equipos procesados: {processed_count}")
    print(f"Errores: {len(report['errors'])}")
    print(f"Reporte: {REPORT_PATH}")


if __name__ == "__main__":
    main()
