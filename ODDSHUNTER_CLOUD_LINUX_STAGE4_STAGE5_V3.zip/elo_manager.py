from __future__ import annotations

import math
import sqlite3
from datetime import datetime, timezone
from typing import Any, Iterable, Optional


def _utc_timestamp_from_iso(value: str) -> int:
    text = str(value or "").strip()
    if not text:
        raise ValueError("kickoff vacío.")

    parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)

    return int(parsed.timestamp())


def _row_value(row: sqlite3.Row | tuple[Any, ...], key: str, index: int) -> Any:
    if isinstance(row, sqlite3.Row):
        return row[key]
    return row[index]


def obtener_contexto_temporada(
    conexion: sqlite3.Connection,
    season_id: int,
) -> dict[str, Any]:
    fila = conexion.execute(
        """
        SELECT
            et.season_id,
            et.competition_key,
            et.source_league_id AS league_id,
            et.source_registry_key,
            et.source_season_id,
            et.season_name,
            et.previous_season_id,
            et.active,
            ep.elo_base,
            ep.k_elo,
            ep.ventaja_local_elo,
            ep.factor_arrastre_elo,
            ep.escala_elo,
            ep.cap_elo
        FROM elo_temporadas AS et
        INNER JOIN elo_parametros_liga AS ep
            ON ep.competition_key = et.competition_key
        WHERE et.season_id = ?
        """,
        (int(season_id),),
    ).fetchone()

    if fila is None:
        raise ValueError(f"No existe la temporada ELO season_id={season_id}.")

    return dict(fila)


def crear_tablas_elo(conexion: sqlite3.Connection) -> None:
    """
    Verifica que la migración ELO ya esté instalada.

    La estructura se crea mediante migrar_elo_schema.py. Esta función no intenta
    inventar columnas ni modificar las tablas operativas del proyecto.
    """
    requeridas = {
        "elo_competiciones",
        "elo_temporadas",
        "elo_parametros_liga",
        "elo_ratings",
        "elo_movimientos",
    }

    existentes = {
        str(fila[0])
        for fila in conexion.execute(
            """
            SELECT name
            FROM sqlite_master
            WHERE type = 'table'
            """
        ).fetchall()
    }

    faltantes = sorted(requeridas - existentes)
    if faltantes:
        raise RuntimeError(
            "Falta ejecutar migrar_elo_schema.py. Tablas ausentes: "
            + ", ".join(faltantes)
        )


def inicializar_elo_equipo(
    conexion: sqlite3.Connection,
    league_id: int,
    season_id: int,
    team_id: int,
    elo_inicial: float = 1500.0,
) -> float:
    elo_inicial = float(elo_inicial)

    if elo_inicial <= 0:
        raise ValueError("elo_inicial debe ser mayor que cero.")

    conexion.execute(
        """
        INSERT OR IGNORE INTO elo_ratings (
            league_id,
            season_id,
            team_id,
            elo_inicial,
            elo_actual,
            partidos_jugados
        )
        VALUES (?, ?, ?, ?, ?, 0)
        """,
        (
            int(league_id),
            int(season_id),
            int(team_id),
            elo_inicial,
            elo_inicial,
        ),
    )

    fila = conexion.execute(
        """
        SELECT elo_actual
        FROM elo_ratings
        WHERE league_id = ?
          AND season_id = ?
          AND team_id = ?
        """,
        (
            int(league_id),
            int(season_id),
            int(team_id),
        ),
    ).fetchone()

    if fila is None:
        raise RuntimeError("No fue posible inicializar o recuperar el ELO.")

    return float(_row_value(fila, "elo_actual", 0))


def obtener_elo_equipo(
    conexion: sqlite3.Connection,
    league_id: int,
    season_id: int,
    team_id: int,
    elo_inicial: float = 1500.0,
) -> float:
    fila = conexion.execute(
        """
        SELECT elo_actual
        FROM elo_ratings
        WHERE league_id = ?
          AND season_id = ?
          AND team_id = ?
        """,
        (
            int(league_id),
            int(season_id),
            int(team_id),
        ),
    ).fetchone()

    if fila is not None:
        return float(_row_value(fila, "elo_actual", 0))

    return inicializar_elo_equipo(
        conexion=conexion,
        league_id=league_id,
        season_id=season_id,
        team_id=team_id,
        elo_inicial=elo_inicial,
    )


def obtener_elo_prepartido(
    conexion: sqlite3.Connection,
    league_id: int,
    season_id: int,
    team_id: int,
    match_timestamp: int,
    match_id: int | None = None,
    elo_inicial: float = 1500.0,
) -> float:
    """
    Recupera el ELO que existía justo antes de un kickoff.

    El desempate por match_id evita fuga temporal cuando dos partidos comparten
    exactamente el mismo timestamp.
    """
    parametros: list[Any] = [
        int(league_id),
        int(season_id),
        int(team_id),
        int(match_timestamp),
    ]

    filtro_desempate = ""
    if match_id is not None:
        filtro_desempate = """
          AND (
                em.match_timestamp < ?
                OR (
                    em.match_timestamp = ?
                    AND em.match_id < ?
                )
              )
        """
        parametros = [
            int(league_id),
            int(season_id),
            int(team_id),
            int(match_timestamp),
            int(match_timestamp),
            int(match_id),
        ]
    else:
        filtro_desempate = "AND em.match_timestamp < ?"

    fila = conexion.execute(
        f"""
        SELECT em.elo_despues
        FROM elo_movimientos AS em
        WHERE em.league_id = ?
          AND em.season_id = ?
          AND em.team_id = ?
          {filtro_desempate}
        ORDER BY
            em.match_timestamp DESC,
            em.match_id DESC
        LIMIT 1
        """,
        tuple(parametros),
    ).fetchone()

    if fila is not None:
        return float(_row_value(fila, "elo_despues", 0))

    fila_inicial = conexion.execute(
        """
        SELECT elo_inicial
        FROM elo_ratings
        WHERE league_id = ?
          AND season_id = ?
          AND team_id = ?
        """,
        (
            int(league_id),
            int(season_id),
            int(team_id),
        ),
    ).fetchone()

    if fila_inicial is not None:
        return float(_row_value(fila_inicial, "elo_inicial", 0))

    return float(elo_inicial)


def calcular_actualizacion_elo(
    elo_home: float,
    elo_away: float,
    goles_home: int,
    goles_away: int,
    k: float = 20.0,
    ventaja_local_elo: float = 0.0,
) -> dict[str, float]:
    elo_home = float(elo_home)
    elo_away = float(elo_away)
    k = float(k)
    ventaja_local_elo = float(ventaja_local_elo)

    goles_home = int(goles_home)
    goles_away = int(goles_away)

    if elo_home <= 0 or elo_away <= 0:
        raise ValueError("Los valores ELO deben ser mayores que cero.")

    if k <= 0:
        raise ValueError("k debe ser mayor que cero.")

    if goles_home < 0 or goles_away < 0:
        raise ValueError("Los goles no pueden ser negativos.")

    elo_home_para_expectativa = elo_home + ventaja_local_elo

    esperado_home = 1.0 / (
        1.0
        + 10.0 ** ((elo_away - elo_home_para_expectativa) / 400.0)
    )
    esperado_away = 1.0 - esperado_home

    if goles_home > goles_away:
        resultado_home = 1.0
        resultado_away = 0.0
    elif goles_home < goles_away:
        resultado_home = 0.0
        resultado_away = 1.0
    else:
        resultado_home = 0.5
        resultado_away = 0.5

    delta_home = k * (resultado_home - esperado_home)
    delta_away = k * (resultado_away - esperado_away)

    return {
        "elo_home_antes": elo_home,
        "elo_away_antes": elo_away,
        "esperado_home": esperado_home,
        "esperado_away": esperado_away,
        "resultado_home": resultado_home,
        "resultado_away": resultado_away,
        "delta_home": delta_home,
        "delta_away": delta_away,
        "elo_home_despues": elo_home + delta_home,
        "elo_away_despues": elo_away + delta_away,
    }


def partido_elo_procesado(
    conexion: sqlite3.Connection,
    match_id: int,
    league_id: int,
    season_id: int,
) -> bool:
    cantidad = int(
        conexion.execute(
            """
            SELECT COUNT(*)
            FROM elo_movimientos
            WHERE match_id = ?
              AND league_id = ?
              AND season_id = ?
            """,
            (
                int(match_id),
                int(league_id),
                int(season_id),
            ),
        ).fetchone()[0]
    )

    if cantidad == 0:
        return False

    if cantidad == 2:
        return True

    raise RuntimeError(
        f"El partido {match_id} tiene {cantidad} movimientos ELO. "
        "Debe tener cero o dos."
    )


def _savepoint_name(match_id: int) -> str:
    return f"elo_match_{abs(int(match_id))}"


def actualizar_elo_partido(
    conexion: sqlite3.Connection,
    match_id: int,
    league_id: int,
    season_id: int,
    home_team_id: int,
    away_team_id: int,
    goles_home: int,
    goles_away: int,
    match_timestamp: int,
    k: float = 20.0,
    ventaja_local_elo: float = 0.0,
    elo_inicial_home: float = 1500.0,
    elo_inicial_away: float = 1500.0,
) -> dict[str, Any]:
    if int(home_team_id) == int(away_team_id):
        raise ValueError("El equipo local y visitante no pueden ser el mismo.")

    goles_home = int(goles_home)
    goles_away = int(goles_away)

    if goles_home < 0 or goles_away < 0:
        raise ValueError("Los goles no pueden ser negativos.")

    savepoint = _savepoint_name(match_id)
    conexion.execute(f"SAVEPOINT {savepoint}")

    try:
        if partido_elo_procesado(
            conexion=conexion,
            match_id=match_id,
            league_id=league_id,
            season_id=season_id,
        ):
            conexion.execute(f"RELEASE SAVEPOINT {savepoint}")
            return {
                "actualizado": False,
                "motivo": "partido_ya_procesado",
                "match_id": int(match_id),
            }

        elo_home = obtener_elo_equipo(
            conexion=conexion,
            league_id=league_id,
            season_id=season_id,
            team_id=home_team_id,
            elo_inicial=elo_inicial_home,
        )
        elo_away = obtener_elo_equipo(
            conexion=conexion,
            league_id=league_id,
            season_id=season_id,
            team_id=away_team_id,
            elo_inicial=elo_inicial_away,
        )

        calculo = calcular_actualizacion_elo(
            elo_home=elo_home,
            elo_away=elo_away,
            goles_home=goles_home,
            goles_away=goles_away,
            k=k,
            ventaja_local_elo=ventaja_local_elo,
        )

        actualizaciones = (
            (
                int(home_team_id),
                calculo["elo_home_despues"],
            ),
            (
                int(away_team_id),
                calculo["elo_away_despues"],
            ),
        )

        for team_id, nuevo_elo in actualizaciones:
            cursor = conexion.execute(
                """
                UPDATE elo_ratings
                SET elo_actual = ?,
                    partidos_jugados = partidos_jugados + 1,
                    ultimo_partido_id = ?,
                    ultimo_partido_timestamp = ?,
                    updated_at = CAST(strftime('%s', 'now') AS INTEGER)
                WHERE league_id = ?
                  AND season_id = ?
                  AND team_id = ?
                """,
                (
                    float(nuevo_elo),
                    int(match_id),
                    int(match_timestamp),
                    int(league_id),
                    int(season_id),
                    int(team_id),
                ),
            )

            if cursor.rowcount != 1:
                raise RuntimeError(
                    f"No se actualizó exactamente una fila ELO para team_id={team_id}."
                )

        movimientos = (
            (
                int(home_team_id),
                int(away_team_id),
                1,
                goles_home,
                goles_away,
                calculo["resultado_home"],
                calculo["esperado_home"],
                calculo["elo_home_antes"],
                calculo["delta_home"],
                calculo["elo_home_despues"],
            ),
            (
                int(away_team_id),
                int(home_team_id),
                0,
                goles_away,
                goles_home,
                calculo["resultado_away"],
                calculo["esperado_away"],
                calculo["elo_away_antes"],
                calculo["delta_away"],
                calculo["elo_away_despues"],
            ),
        )

        for movimiento in movimientos:
            conexion.execute(
                """
                INSERT INTO elo_movimientos (
                    match_id,
                    league_id,
                    season_id,
                    team_id,
                    opponent_team_id,
                    es_local,
                    goles_favor,
                    goles_contra,
                    resultado_real,
                    resultado_esperado,
                    elo_antes,
                    variacion_elo,
                    elo_despues,
                    k_utilizado,
                    ventaja_local_utilizada,
                    match_timestamp
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    int(match_id),
                    int(league_id),
                    int(season_id),
                    *movimiento,
                    float(k),
                    float(ventaja_local_elo),
                    int(match_timestamp),
                ),
            )

        conexion.execute(f"RELEASE SAVEPOINT {savepoint}")

        return {
            "actualizado": True,
            "match_id": int(match_id),
            "home_team_id": int(home_team_id),
            "away_team_id": int(away_team_id),
            "elo_home_antes": round(calculo["elo_home_antes"], 2),
            "elo_home_despues": round(calculo["elo_home_despues"], 2),
            "delta_home": round(calculo["delta_home"], 2),
            "elo_away_antes": round(calculo["elo_away_antes"], 2),
            "elo_away_despues": round(calculo["elo_away_despues"], 2),
            "delta_away": round(calculo["delta_away"], 2),
        }

    except Exception:
        conexion.execute(f"ROLLBACK TO SAVEPOINT {savepoint}")
        conexion.execute(f"RELEASE SAVEPOINT {savepoint}")
        raise


def obtener_equipos_temporada(
    conexion: sqlite3.Connection,
    league_id: int,
    season_name: str,
) -> list[int]:
    filas = conexion.execute(
        """
        SELECT team_id
        FROM (
            SELECT home_team_id AS team_id
            FROM matches
            WHERE league_id = ?
              AND season = ?

            UNION

            SELECT away_team_id AS team_id
            FROM matches
            WHERE league_id = ?
              AND season = ?
        )
        ORDER BY team_id
        """,
        (
            int(league_id),
            str(season_name),
            int(league_id),
            str(season_name),
        ),
    ).fetchall()

    return [int(fila[0]) for fila in filas]


def inicializar_temporada_elo(
    conexion: sqlite3.Connection,
    league_id: int,
    season_id: int,
    team_ids: Iterable[int],
    previous_season_id: Optional[int] = None,
    elo_base: float = 1500.0,
    factor_arrastre: float = 0.60,
) -> dict[str, int]:
    elo_base = float(elo_base)
    factor_arrastre = float(factor_arrastre)

    if elo_base <= 0:
        raise ValueError("elo_base debe ser mayor que cero.")

    if not 0.0 <= factor_arrastre <= 1.0:
        raise ValueError("factor_arrastre debe estar entre 0.0 y 1.0.")

    equipos = sorted({int(team_id) for team_id in team_ids})

    if not equipos:
        return {
            "inicializados": 0,
            "con_arrastre": 0,
            "nuevos": 0,
            "ya_existentes": 0,
        }

    elos_anteriores: dict[int, float] = {}

    if previous_season_id is not None:
        placeholders = ",".join("?" for _ in equipos)

        filas = conexion.execute(
            f"""
            SELECT team_id, elo_actual
            FROM elo_ratings
            WHERE season_id = ?
              AND team_id IN ({placeholders})
            """,
            (
                int(previous_season_id),
                *equipos,
            ),
        ).fetchall()

        elos_anteriores = {
            int(fila[0]): float(fila[1])
            for fila in filas
        }

    inicializados = 0
    con_arrastre = 0
    nuevos = 0
    ya_existentes = 0

    for team_id in equipos:
        existe = conexion.execute(
            """
            SELECT 1
            FROM elo_ratings
            WHERE league_id = ?
              AND season_id = ?
              AND team_id = ?
            LIMIT 1
            """,
            (
                int(league_id),
                int(season_id),
                int(team_id),
            ),
        ).fetchone()

        if existe is not None:
            ya_existentes += 1
            continue

        elo_anterior = elos_anteriores.get(team_id)

        if elo_anterior is None:
            elo_inicial = elo_base
            nuevos += 1
        else:
            elo_inicial = (
                elo_base
                + factor_arrastre * (elo_anterior - elo_base)
            )
            con_arrastre += 1

        conexion.execute(
            """
            INSERT INTO elo_ratings (
                league_id,
                season_id,
                team_id,
                elo_inicial,
                elo_actual,
                partidos_jugados
            )
            VALUES (?, ?, ?, ?, ?, 0)
            """,
            (
                int(league_id),
                int(season_id),
                int(team_id),
                float(elo_inicial),
                float(elo_inicial),
            ),
        )
        inicializados += 1

    return {
        "inicializados": inicializados,
        "con_arrastre": con_arrastre,
        "nuevos": nuevos,
        "ya_existentes": ya_existentes,
    }


def buscar_movimientos_incompletos(
    conexion: sqlite3.Connection,
    league_id: int,
    season_id: int,
) -> list[dict[str, int]]:
    filas = conexion.execute(
        """
        SELECT
            match_id,
            COUNT(*) AS cantidad
        FROM elo_movimientos
        WHERE league_id = ?
          AND season_id = ?
        GROUP BY match_id
        HAVING COUNT(*) <> 2
        ORDER BY match_id
        """,
        (
            int(league_id),
            int(season_id),
        ),
    ).fetchall()

    return [
        {
            "match_id": int(fila["match_id"]),
            "cantidad": int(fila["cantidad"]),
        }
        for fila in filas
    ]


def procesar_partidos_pendientes_elo(
    conexion: sqlite3.Connection,
    league_id: int,
    season_id: int,
    k: float = 20.0,
    ventaja_local_elo: float = 0.0,
    elo_base: float = 1500.0,
    hasta_timestamp: Optional[int] = None,
) -> dict[str, Any]:
    contexto = obtener_contexto_temporada(conexion, season_id)

    if int(contexto["league_id"]) != int(league_id):
        raise ValueError(
            "league_id no coincide con la temporada ELO."
        )

    incompletos = buscar_movimientos_incompletos(
        conexion,
        league_id,
        season_id,
    )
    if incompletos:
        raise RuntimeError(
            "Existen partidos con movimientos incompletos: "
            + str(incompletos[:10])
        )

    parametros: list[Any] = [
        int(league_id),
        str(contexto["season_name"]),
    ]
    filtro_fecha = ""

    if hasta_timestamp is not None:
        filtro_fecha = """
          AND CAST(strftime('%s', m.kickoff) AS INTEGER) <= ?
        """
        parametros.append(int(hasta_timestamp))

    partidos = conexion.execute(
        f"""
        SELECT
            m.match_id,
            m.home_team_id,
            m.away_team_id,
            m.home_goals,
            m.away_goals,
            m.kickoff,
            CAST(strftime('%s', m.kickoff) AS INTEGER) AS match_timestamp
        FROM matches AS m
        WHERE m.league_id = ?
          AND m.season = ?
          AND LOWER(TRIM(m.status)) IN ('ft', 'finished')
          AND m.home_goals IS NOT NULL
          AND m.away_goals IS NOT NULL
          {filtro_fecha}
          AND NOT EXISTS (
              SELECT 1
              FROM elo_movimientos AS em
              WHERE em.match_id = m.match_id
                AND em.league_id = m.league_id
                AND em.season_id = ?
          )
        ORDER BY
            m.kickoff ASC,
            m.match_id ASC
        """,
        tuple([*parametros, int(season_id)]),
    ).fetchall()

    actualizados = 0
    omitidos = 0
    errores: list[dict[str, Any]] = []

    for partido in partidos:
        try:
            timestamp = partido["match_timestamp"]
            if timestamp is None:
                timestamp = _utc_timestamp_from_iso(partido["kickoff"])

            resultado = actualizar_elo_partido(
                conexion=conexion,
                match_id=int(partido["match_id"]),
                league_id=int(league_id),
                season_id=int(season_id),
                home_team_id=int(partido["home_team_id"]),
                away_team_id=int(partido["away_team_id"]),
                goles_home=int(partido["home_goals"]),
                goles_away=int(partido["away_goals"]),
                match_timestamp=int(timestamp),
                k=float(k),
                ventaja_local_elo=float(ventaja_local_elo),
                elo_inicial_home=float(elo_base),
                elo_inicial_away=float(elo_base),
            )

            if resultado["actualizado"]:
                actualizados += 1
            else:
                omitidos += 1

        except Exception as error:
            errores.append(
                {
                    "match_id": int(partido["match_id"]),
                    "error": f"{type(error).__name__}: {error}",
                }
            )

    return {
        "encontrados": len(partidos),
        "actualizados": actualizados,
        "omitidos": omitidos,
        "errores": errores,
    }


def obtener_ranking_elo(
    conexion: sqlite3.Connection,
    league_id: int,
    season_id: int,
) -> list[dict[str, Any]]:
    filas = conexion.execute(
        """
        SELECT
            er.team_id,
            t.name AS team_name,
            er.elo_inicial,
            er.elo_actual,
            er.partidos_jugados,
            er.elo_actual - er.elo_inicial AS variacion_temporada,
            er.ultimo_partido_timestamp
        FROM elo_ratings AS er
        INNER JOIN teams AS t
            ON t.team_id = er.team_id
        WHERE er.league_id = ?
          AND er.season_id = ?
        ORDER BY
            er.elo_actual DESC,
            t.name ASC
        """,
        (
            int(league_id),
            int(season_id),
        ),
    ).fetchall()

    return [
        {
            "posicion": posicion,
            "team_id": int(fila["team_id"]),
            "team_name": str(fila["team_name"]),
            "elo_inicial": round(float(fila["elo_inicial"]), 2),
            "elo_actual": round(float(fila["elo_actual"]), 2),
            "partidos_jugados": int(fila["partidos_jugados"]),
            "variacion_temporada": round(
                float(fila["variacion_temporada"]),
                2,
            ),
            "ultimo_partido_timestamp": fila["ultimo_partido_timestamp"],
        }
        for posicion, fila in enumerate(filas, start=1)
    ]


def validar_temporada_elo(
    conexion: sqlite3.Connection,
    league_id: int,
    season_id: int,
) -> dict[str, Any]:
    partidos = int(
        conexion.execute(
            """
            SELECT COUNT(*)
            FROM matches AS m
            INNER JOIN elo_temporadas AS et
                ON et.source_league_id = m.league_id
               AND et.season_name = m.season
            WHERE et.season_id = ?
              AND m.league_id = ?
              AND LOWER(TRIM(m.status)) IN ('ft', 'finished')
              AND m.home_goals IS NOT NULL
              AND m.away_goals IS NOT NULL
            """,
            (
                int(season_id),
                int(league_id),
            ),
        ).fetchone()[0]
    )

    movimientos = int(
        conexion.execute(
            """
            SELECT COUNT(*)
            FROM elo_movimientos
            WHERE league_id = ?
              AND season_id = ?
            """,
            (
                int(league_id),
                int(season_id),
            ),
        ).fetchone()[0]
    )

    ratings = int(
        conexion.execute(
            """
            SELECT COUNT(*)
            FROM elo_ratings
            WHERE league_id = ?
              AND season_id = ?
            """,
            (
                int(league_id),
                int(season_id),
            ),
        ).fetchone()[0]
    )

    suma_deltas = float(
        conexion.execute(
            """
            SELECT COALESCE(SUM(variacion_elo), 0.0)
            FROM elo_movimientos
            WHERE league_id = ?
              AND season_id = ?
            """,
            (
                int(league_id),
                int(season_id),
            ),
        ).fetchone()[0]
    )

    inconsistencias_partidos = int(
        conexion.execute(
            """
            SELECT COUNT(*)
            FROM (
                SELECT match_id
                FROM elo_movimientos
                WHERE league_id = ?
                  AND season_id = ?
                GROUP BY match_id
                HAVING COUNT(*) <> 2
            )
            """,
            (
                int(league_id),
                int(season_id),
            ),
        ).fetchone()[0]
    )

    return {
        "partidos_finalizados": partidos,
        "ratings": ratings,
        "movimientos": movimientos,
        "movimientos_esperados": partidos * 2,
        "movimientos_completos": movimientos == partidos * 2,
        "partidos_incompletos": inconsistencias_partidos,
        "suma_deltas": round(suma_deltas, 10),
        "suma_deltas_cero": abs(suma_deltas) < 1e-7,
    }
