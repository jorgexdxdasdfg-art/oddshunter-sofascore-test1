from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator


# ==============================================================================
# 1. RUTAS
# ==============================================================================

# database.py estará en la raíz del proyecto.
PROJECT_ROOT = Path(__file__).resolve().parent
DATA_DIR = PROJECT_ROOT / "data"
DB_PATH = DATA_DIR / "oddshunter.db"


XG_PROVENANCE_COLUMNS = {
    "xg_source": "TEXT",
    "xg_is_estimated": "INTEGER NOT NULL DEFAULT 0",
    "xg_method_version": "TEXT",
    "xg_updated_at": "TEXT",
}

LEAGUE_CONTEXT_COLUMNS = {
    "source_tournament_id": "INTEGER",
    "source_season_id": "INTEGER",
    "competition_family": "TEXT NOT NULL DEFAULT 'DOMESTIC'",
    "context_role": "TEXT NOT NULL DEFAULT 'PRIMARY_COMPETITION'",
    "visible_in_ui": "INTEGER NOT NULL DEFAULT 1",
}

MATCH_IDENTITY_COLUMNS = {
    "identity_validated": "INTEGER NOT NULL DEFAULT 0",
}

# BOT 9.1 ya podÃ­a contener una versiÃ³n anterior de esta tabla. SQLite no
# amplÃ­a una tabla existente con ``CREATE TABLE IF NOT EXISTS`` y tampoco
# permite aÃ±adir CURRENT_TIMESTAMP como DEFAULT no constante mediante ALTER.
# Por eso estas columnas se crean primero con definiciones compatibles y se
# rellenan antes de construir los Ã­ndices de BOT 10.1.
MEMBERSHIP_MIGRATION_COLUMNS = {
    "source_tournament_id": "INTEGER",
    "source_season_id": "INTEGER",
    "competition_key": "TEXT",
    "sofascore_tournament_id": "INTEGER",
    "sofascore_season_id": "INTEGER",
    "membership_role": "TEXT NOT NULL DEFAULT 'PARTICIPANT'",
    "membership_status": "TEXT NOT NULL DEFAULT 'ACTIVE'",
    "entry_round": "TEXT",
    "current_round": "TEXT",
    "transferred_from_tournament_id": "INTEGER",
    "transferred_to_tournament_id": "INTEGER",
    "first_seen_at": "TEXT",
    "last_seen_at": "TEXT",
    "status_changed_at": "TEXT",
}



def _table_exists(conn: sqlite3.Connection, table: str) -> bool:
    return conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?;",
        (table,),
    ).fetchone() is not None


def _column_names(conn: sqlite3.Connection, table: str) -> set[str]:
    if not _table_exists(conn, table):
        return set()
    return {
        str(row[1])
        for row in conn.execute(f"PRAGMA table_info({table});").fetchall()
    }


def _ensure_columns(
    conn: sqlite3.Connection,
    table: str,
    definitions: dict[str, str],
) -> None:
    if not _table_exists(conn, table):
        return
    columns = _column_names(conn, table)
    for name, definition in definitions.items():
        if name not in columns:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {definition};")


def _row_value(row: sqlite3.Row, columns: set[str], *names: str) -> Any:
    for name in names:
        if name in columns and row[name] is not None:
            return row[name]
    return None


def _migrate_memberships(conn: sqlite3.Connection) -> None:
    """Adapta la tabla BOT 9.1 sin perder sus columnas históricas."""

    if not _table_exists(conn, "team_competition_memberships"):
        conn.executescript(
            """
            CREATE TABLE team_competition_memberships (
                team_id INTEGER NOT NULL,
                league_id INTEGER NOT NULL,
                source_tournament_id INTEGER,
                source_season_id INTEGER,
                competition_key TEXT,
                sofascore_tournament_id INTEGER,
                sofascore_season_id INTEGER,
                membership_role TEXT NOT NULL DEFAULT 'PARTICIPANT',
                membership_status TEXT NOT NULL DEFAULT 'ACTIVE',
                entry_round TEXT,
                current_round TEXT,
                transferred_from_tournament_id INTEGER,
                transferred_to_tournament_id INTEGER,
                first_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                last_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                status_changed_at TEXT,
                FOREIGN KEY (team_id) REFERENCES teams(team_id) ON DELETE CASCADE,
                FOREIGN KEY (league_id) REFERENCES leagues(league_id) ON DELETE CASCADE
            );
            """
        )
    else:
        _ensure_columns(
            conn,
            "team_competition_memberships",
            MEMBERSHIP_MIGRATION_COLUMNS,
        )

    columns = _column_names(conn, "team_competition_memberships")
    if {"source_tournament_id", "sofascore_tournament_id"} <= columns:
        conn.execute(
            """
            UPDATE team_competition_memberships
            SET sofascore_tournament_id = COALESCE(
                    sofascore_tournament_id,
                    source_tournament_id,
                    (SELECT source_tournament_id FROM leagues
                     WHERE leagues.league_id=team_competition_memberships.league_id)
                ),
                source_tournament_id = COALESCE(
                    source_tournament_id,
                    sofascore_tournament_id,
                    (SELECT source_tournament_id FROM leagues
                     WHERE leagues.league_id=team_competition_memberships.league_id)
                );
            """
        )
    if {"source_season_id", "sofascore_season_id"} <= columns:
        conn.execute(
            """
            UPDATE team_competition_memberships
            SET sofascore_season_id = COALESCE(
                    sofascore_season_id,
                    source_season_id,
                    (SELECT source_season_id FROM leagues
                     WHERE leagues.league_id=team_competition_memberships.league_id)
                ),
                source_season_id = COALESCE(
                    source_season_id,
                    sofascore_season_id,
                    (SELECT source_season_id FROM leagues
                     WHERE leagues.league_id=team_competition_memberships.league_id)
                );
            """
        )
    conn.execute(
        """
        UPDATE team_competition_memberships
        SET membership_role=COALESCE(NULLIF(membership_role, ''), 'PARTICIPANT'),
            membership_status=COALESCE(NULLIF(membership_status, ''), 'ACTIVE'),
            first_seen_at=COALESCE(first_seen_at, CURRENT_TIMESTAMP),
            last_seen_at=COALESCE(last_seen_at, first_seen_at, CURRENT_TIMESTAMP);
        """
    )

    # Una membresía representa un club en un torneo/temporada. Si una base
    # antigua contiene duplicados equivalentes, conserva la fila más reciente.
    duplicates = conn.execute(
        """
        SELECT team_id, sofascore_tournament_id, sofascore_season_id,
               GROUP_CONCAT(rowid) AS rowids, COUNT(*) AS amount
        FROM team_competition_memberships
        WHERE sofascore_tournament_id IS NOT NULL
          AND sofascore_season_id IS NOT NULL
        GROUP BY team_id, sofascore_tournament_id, sofascore_season_id
        HAVING COUNT(*) > 1;
        """
    ).fetchall()
    for duplicate in duplicates:
        rowids = [int(value) for value in str(duplicate["rowids"]).split(",")]
        keep = max(rowids)
        conn.execute(
            "DELETE FROM team_competition_memberships "
            f"WHERE rowid IN ({','.join('?' for _ in rowids)}) AND rowid<>?;",
            (*rowids, keep),
        )

    conn.executescript(
        """
        DROP INDEX IF EXISTS uq_memberships_team_tournament_season;
        CREATE UNIQUE INDEX uq_memberships_team_tournament_season
        ON team_competition_memberships(
            team_id, sofascore_tournament_id, sofascore_season_id
        );
        CREATE INDEX IF NOT EXISTS idx_memberships_league_status
        ON team_competition_memberships(league_id, membership_status, team_id);
        """
    )


def _canonical_queue_table(conn: sqlite3.Connection, table: str) -> None:
    conn.execute(
        f"""
        CREATE TABLE {table} (
            queue_id INTEGER PRIMARY KEY AUTOINCREMENT,
            team_id INTEGER,
            domestic_tournament_id INTEGER NOT NULL,
            domestic_season_id INTEGER,
            domestic_league_id INTEGER,
            status TEXT NOT NULL DEFAULT 'PENDING'
                CHECK (status IN ('PENDING', 'RUNNING', 'DONE', 'ERROR', 'SKIPPED')),
            priority INTEGER NOT NULL DEFAULT 100,
            attempts INTEGER NOT NULL DEFAULT 0,
            last_error TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            started_at TEXT,
            finished_at TEXT,
            competition_key TEXT,
            triggered_by_team_id INTEGER,
            triggered_by_uefa_event_id INTEGER,
            triggered_by_uefa_tournament_id INTEGER,
            reason TEXT,
            detected_at TEXT,
            completed_at TEXT,
            error_message TEXT,
            UNIQUE(domestic_tournament_id, domestic_season_id),
            FOREIGN KEY (team_id) REFERENCES teams(team_id) ON DELETE CASCADE,
            FOREIGN KEY (domestic_league_id) REFERENCES leagues(league_id) ON DELETE SET NULL
        );
        """
    )


def _normalize_queue_status(value: Any) -> str:
    status = str(value or "PENDING").strip().upper()
    return {
        "COMPLETED": "DONE",
        "FAILED": "ERROR",
    }.get(status, status if status in {"PENDING", "RUNNING", "DONE", "ERROR", "SKIPPED"} else "PENDING")


def _migrate_domestic_queue(conn: sqlite3.Connection) -> None:
    """Reconstruye cualquier variante heredada en el esquema canónico."""

    if not _table_exists(conn, "domestic_import_queue"):
        _canonical_queue_table(conn, "domestic_import_queue")
    else:
        columns = _column_names(conn, "domestic_import_queue")
        table_sql_row = conn.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='domestic_import_queue';"
        ).fetchone()
        table_sql = str(table_sql_row[0] or "") if table_sql_row else ""
        canonical_columns = {
            "queue_id", "team_id", "domestic_tournament_id",
            "domestic_season_id", "domestic_league_id", "status",
            "priority", "attempts", "last_error", "created_at",
            "updated_at", "started_at", "finished_at",
        }
        canonical_constraints = (
            "'DONE'" in table_sql
            and "'ERROR'" in table_sql
            and "UNIQUE(domestic_tournament_id, domestic_season_id)" in table_sql
        )
        if canonical_columns <= columns and canonical_constraints:
            conn.execute(
                """
                UPDATE domestic_import_queue
                SET status=CASE
                    WHEN status='COMPLETED' THEN 'DONE'
                    WHEN status='FAILED' THEN 'ERROR'
                    ELSE COALESCE(NULLIF(status, ''), 'PENDING') END,
                    priority=COALESCE(priority, 100),
                    attempts=COALESCE(attempts, 0),
                    created_at=COALESCE(created_at, CURRENT_TIMESTAMP),
                    updated_at=COALESCE(updated_at, created_at, CURRENT_TIMESTAMP);
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_domestic_queue_status_priority
                ON domestic_import_queue(status, priority, created_at);
                """
            )
            return
        rows = conn.execute("SELECT * FROM domestic_import_queue ORDER BY queue_id;").fetchall()
        valid_team_ids = {
            int(row[0]) for row in conn.execute("SELECT team_id FROM teams;").fetchall()
        } if _table_exists(conn, "teams") else set()
        valid_league_ids = {
            int(row[0]) for row in conn.execute("SELECT league_id FROM leagues;").fetchall()
        } if _table_exists(conn, "leagues") else set()
        merged: dict[tuple[int, int | None], dict[str, Any]] = {}
        for row in rows:
            tournament_id = _row_value(row, columns, "domestic_tournament_id")
            if tournament_id is None:
                continue
            season_id = _row_value(row, columns, "domestic_season_id")
            key = (int(tournament_id), int(season_id) if season_id is not None else None)
            raw_team_id = _row_value(row, columns, "team_id", "triggered_by_team_id")
            team_id = int(raw_team_id) if raw_team_id is not None else None
            if team_id is not None and team_id not in valid_team_ids:
                team_id = None
            raw_league_id = _row_value(row, columns, "domestic_league_id")
            league_id = int(raw_league_id) if raw_league_id is not None else None
            if league_id is not None and league_id not in valid_league_ids:
                league_id = None
            item = {
                "queue_id": _row_value(row, columns, "queue_id"),
                "team_id": team_id,
                "domestic_tournament_id": key[0],
                "domestic_season_id": key[1],
                "domestic_league_id": league_id,
                "status": _normalize_queue_status(_row_value(row, columns, "status")),
                "priority": int(_row_value(row, columns, "priority") or 100),
                "attempts": int(_row_value(row, columns, "attempts") or 0),
                "last_error": _row_value(row, columns, "last_error", "error_message"),
                "created_at": _row_value(row, columns, "created_at", "detected_at") or "1970-01-01 00:00:00",
                "updated_at": _row_value(row, columns, "updated_at", "completed_at", "started_at", "detected_at") or "1970-01-01 00:00:00",
                "started_at": _row_value(row, columns, "started_at"),
                "finished_at": _row_value(row, columns, "finished_at", "completed_at"),
                "competition_key": _row_value(row, columns, "competition_key"),
                "triggered_by_team_id": _row_value(row, columns, "triggered_by_team_id", "team_id"),
                "triggered_by_uefa_event_id": _row_value(row, columns, "triggered_by_uefa_event_id"),
                "triggered_by_uefa_tournament_id": _row_value(row, columns, "triggered_by_uefa_tournament_id"),
                "reason": _row_value(row, columns, "reason"),
                "detected_at": _row_value(row, columns, "detected_at", "created_at"),
                "completed_at": _row_value(row, columns, "completed_at", "finished_at"),
                "error_message": _row_value(row, columns, "error_message", "last_error"),
            }
            existing = merged.get(key)
            if existing is None or int(item["queue_id"] or 0) >= int(existing["queue_id"] or 0):
                merged[key] = item

        conn.executescript(
            """
            DROP INDEX IF EXISTS idx_domestic_queue_status_priority;
            DROP INDEX IF EXISTS uq_domestic_queue_resolved;
            DROP INDEX IF EXISTS uq_domestic_queue_unresolved;
            DROP TABLE IF EXISTS domestic_import_queue_bot101_new;
            """
        )
        _canonical_queue_table(conn, "domestic_import_queue_bot101_new")
        for item in merged.values():
            conn.execute(
                """
                INSERT INTO domestic_import_queue_bot101_new (
                    queue_id, team_id, domestic_tournament_id, domestic_season_id,
                    domestic_league_id, status, priority, attempts, last_error,
                    created_at, updated_at, started_at, finished_at,
                    competition_key, triggered_by_team_id,
                    triggered_by_uefa_event_id, triggered_by_uefa_tournament_id,
                    reason, detected_at, completed_at, error_message
                ) VALUES (
                    :queue_id, :team_id, :domestic_tournament_id, :domestic_season_id,
                    :domestic_league_id, :status, :priority, :attempts, :last_error,
                    :created_at, :updated_at, :started_at, :finished_at,
                    :competition_key, :triggered_by_team_id,
                    :triggered_by_uefa_event_id, :triggered_by_uefa_tournament_id,
                    :reason, :detected_at, :completed_at, :error_message
                );
                """,
                item,
            )
        conn.execute("DROP TABLE domestic_import_queue;")
        conn.execute(
            "ALTER TABLE domestic_import_queue_bot101_new RENAME TO domestic_import_queue;"
        )

    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_domestic_queue_status_priority
        ON domestic_import_queue(status, priority, created_at);
        """
    )


def ensure_schema_migrations(conn: sqlite3.Connection) -> None:
    """Migra BOT 9 sin renombrar columnas históricas ni perder datos."""

    _ensure_columns(conn, "team_match_stats", XG_PROVENANCE_COLUMNS)
    _ensure_columns(conn, "leagues", LEAGUE_CONTEXT_COLUMNS)
    _ensure_columns(conn, "matches", MATCH_IDENTITY_COLUMNS)

    # Las tablas heredadas de BOT 9.1 usaban aliases y restricciones
    # incompatibles. Se migran antes de cualquier lectura o encolado.
    if _table_exists(conn, "teams") and _table_exists(conn, "leagues"):
        _migrate_memberships(conn)
        _migrate_domestic_queue(conn)
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS contextual_rating_snapshots (
                context_rating_id INTEGER PRIMARY KEY AUTOINCREMENT,
                team_id INTEGER NOT NULL,
                competition_league_id INTEGER NOT NULL,
                context_league_id INTEGER NOT NULL,
                model_version TEXT NOT NULL,
                venue TEXT NOT NULL DEFAULT 'TOTAL'
                    CHECK (venue IN ('HOME', 'AWAY', 'TOTAL')),
                elo_base REAL,
                metrics_json TEXT NOT NULL DEFAULT '{}',
                matches_by_market_json TEXT NOT NULL DEFAULT '{}',
                inputs_fingerprint TEXT NOT NULL,
                calculated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (team_id) REFERENCES teams(team_id) ON DELETE CASCADE,
                FOREIGN KEY (competition_league_id) REFERENCES leagues(league_id) ON DELETE CASCADE,
                FOREIGN KEY (context_league_id) REFERENCES leagues(league_id) ON DELETE CASCADE
            );

            CREATE INDEX IF NOT EXISTS idx_context_ratings_latest
            ON contextual_rating_snapshots(
                team_id, competition_league_id, context_league_id,
                venue, calculated_at DESC
            );
            """
        )

    if _table_exists(conn, "matches") and "identity_validated" in _column_names(conn, "matches"):
        conn.executescript(
            """
            DROP TRIGGER IF EXISTS prevent_validated_match_identity_change;
            CREATE TRIGGER prevent_validated_match_identity_change
            BEFORE UPDATE OF league_id, season, home_team_id, away_team_id
            ON matches
            WHEN OLD.identity_validated = 1
            AND (
                NEW.league_id IS NOT OLD.league_id
                OR NEW.season IS NOT OLD.season
                OR NEW.home_team_id IS NOT OLD.home_team_id
                OR NEW.away_team_id IS NOT OLD.away_team_id
            )
            BEGIN
                SELECT RAISE(
                    ABORT,
                    'No se puede modificar la identidad de un partido validado'
                );
            END;
            """
        )

    if _table_exists(conn, "matches") and _table_exists(conn, "leagues"):
        conn.execute(
            """
            CREATE VIEW IF NOT EXISTS uefa_matches AS
            SELECT
                m.*,
                l.source_tournament_id,
                l.source_season_id,
                l.competition_family,
                l.context_role
            FROM matches AS m
            JOIN leagues AS l ON l.league_id = m.league_id
            WHERE l.competition_family = 'UEFA';
            """
        )

        conn.execute(
            """
            UPDATE leagues
            SET competition_family = 'UEFA',
                context_role = 'UEFA_PRIMARY'
            WHERE (
                    lower(name) LIKE '%champions%'
                 OR lower(name) LIKE '%conference%'
                 OR lower(name) LIKE '%europa league%'
            )
              AND (
                    lower(COALESCE(country, '')) = 'europe'
                 OR upper(COALESCE(competition_family, '')) = 'UEFA'
              );  -- ODDSHUNTER_UEFA_FAMILY_GUARD_V1
            """
        )
    conn.commit()


# ==============================================================================
# 2. CONEXIÓN
# ==============================================================================

def get_connection(
    db_path: str | Path | None = None
) -> sqlite3.Connection:
    """
    Abre una conexión SQLite configurada para OddsHunter.

    - Activa claves foráneas.
    - Permite leer resultados como diccionarios.
    - Activa WAL para mejorar lecturas y escrituras simultáneas.
    """

    path = Path(db_path) if db_path else DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(
        path,
        timeout=30,
        detect_types=sqlite3.PARSE_DECLTYPES
    )

    conn.row_factory = sqlite3.Row

    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA synchronous = NORMAL;")
    conn.execute("PRAGMA busy_timeout = 30000;")
    ensure_schema_migrations(conn)

    return conn


@contextmanager
def transaction(
    db_path: str | Path | None = None
) -> Iterator[sqlite3.Connection]:
    """
    Contexto para realizar transacciones seguras.

    Ejemplo:

        with transaction() as conn:
            conn.execute(...)
    """

    conn = get_connection(db_path)

    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# ==============================================================================
# 3. CREACIÓN DE TABLAS
# ==============================================================================

def create_tables(conn: sqlite3.Connection) -> None:
    """
    Crea la estructura completa de OddsHunter.
    """

    conn.executescript(
        """
        -- =====================================================================
        -- LIGAS
        -- =====================================================================

        CREATE TABLE IF NOT EXISTS leagues (
            league_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            country TEXT NOT NULL,
            season TEXT NOT NULL,
            active INTEGER NOT NULL DEFAULT 1
                CHECK (active IN (0, 1)),
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

            UNIQUE(name, country, season)
        );


        -- =====================================================================
        -- EQUIPOS
        -- =====================================================================

        CREATE TABLE IF NOT EXISTS teams (
            team_id INTEGER PRIMARY KEY AUTOINCREMENT,
            sofascore_id INTEGER UNIQUE,
            name TEXT NOT NULL,
            league_id INTEGER,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY (league_id)
                REFERENCES leagues(league_id)
                ON DELETE SET NULL
        );


        -- =====================================================================
        -- PARTIDOS
        -- =====================================================================

        CREATE TABLE IF NOT EXISTS matches (
            match_id INTEGER PRIMARY KEY AUTOINCREMENT,

            sofascore_id INTEGER UNIQUE,
            betano_event_id TEXT UNIQUE,
            betano_url TEXT,

            league_id INTEGER NOT NULL,
            season TEXT NOT NULL,
            kickoff TEXT NOT NULL,

            home_team_id INTEGER NOT NULL,
            away_team_id INTEGER NOT NULL,

            home_goals INTEGER
                CHECK (home_goals IS NULL OR home_goals >= 0),

            away_goals INTEGER
                CHECK (away_goals IS NULL OR away_goals >= 0),

            status TEXT NOT NULL DEFAULT 'NS',

            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY (league_id)
                REFERENCES leagues(league_id)
                ON DELETE CASCADE,

            FOREIGN KEY (home_team_id)
                REFERENCES teams(team_id)
                ON DELETE CASCADE,

            FOREIGN KEY (away_team_id)
                REFERENCES teams(team_id)
                ON DELETE CASCADE,

            CHECK (home_team_id <> away_team_id)
        );


        -- =====================================================================
        -- ESTADÍSTICAS POR EQUIPO Y PARTIDO
        -- =====================================================================

        CREATE TABLE IF NOT EXISTS team_match_stats (
            stat_id INTEGER PRIMARY KEY AUTOINCREMENT,

            match_id INTEGER NOT NULL,
            team_id INTEGER NOT NULL,

            venue TEXT NOT NULL
                CHECK (venue IN ('HOME', 'AWAY')),

            goals_for INTEGER
                CHECK (goals_for IS NULL OR goals_for >= 0),

            goals_against INTEGER
                CHECK (goals_against IS NULL OR goals_against >= 0),

            xg_for REAL
                CHECK (xg_for IS NULL OR xg_for >= 0),

            xg_against REAL
                CHECK (xg_against IS NULL OR xg_against >= 0),

            xg_source TEXT,

            xg_is_estimated INTEGER NOT NULL DEFAULT 0
                CHECK (xg_is_estimated IN (0, 1)),

            xg_method_version TEXT,

            xg_updated_at TEXT,

            shots INTEGER
                CHECK (shots IS NULL OR shots >= 0),

            shots_on_target INTEGER
                CHECK (
                    shots_on_target IS NULL
                    OR shots_on_target >= 0
                ),

            corners_for INTEGER
                CHECK (corners_for IS NULL OR corners_for >= 0),

            corners_against INTEGER
                CHECK (
                    corners_against IS NULL
                    OR corners_against >= 0
                ),

            yellow_cards INTEGER
                CHECK (
                    yellow_cards IS NULL
                    OR yellow_cards >= 0
                ),

            red_cards INTEGER
                CHECK (
                    red_cards IS NULL
                    OR red_cards >= 0
                ),

            possession REAL
                CHECK (
                    possession IS NULL
                    OR possession BETWEEN 0 AND 100
                ),

            fouls INTEGER
                CHECK (fouls IS NULL OR fouls >= 0),

            offsides INTEGER
                CHECK (offsides IS NULL OR offsides >= 0),

            big_chances INTEGER
                CHECK (
                    big_chances IS NULL
                    OR big_chances >= 0
                ),

            data_quality TEXT NOT NULL DEFAULT 'FULL'
                CHECK (
                    data_quality IN (
                        'FULL',
                        'PARTIAL',
                        'ESTIMATED'
                    )
                ),

            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY (match_id)
                REFERENCES matches(match_id)
                ON DELETE CASCADE,

            FOREIGN KEY (team_id)
                REFERENCES teams(team_id)
                ON DELETE CASCADE,

            UNIQUE(match_id, team_id)
        );


        -- =====================================================================
        -- CUOTAS DE BETANO
        -- =====================================================================

        CREATE TABLE IF NOT EXISTS odds_snapshots (
            odd_id INTEGER PRIMARY KEY AUTOINCREMENT,

            match_id INTEGER NOT NULL,
            bookmaker TEXT NOT NULL,

            market TEXT NOT NULL,
            selection TEXT NOT NULL,

            line REAL,

            odds REAL NOT NULL
                CHECK (odds > 1.0),

            is_live INTEGER NOT NULL DEFAULT 0
                CHECK (is_live IN (0, 1)),

            captured_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY (match_id)
                REFERENCES matches(match_id)
                ON DELETE CASCADE
        );


        -- =====================================================================
        -- VERSIONES DEL MODELO
        -- =====================================================================

        CREATE TABLE IF NOT EXISTS model_versions (
            model_version TEXT PRIMARY KEY,

            league_id INTEGER,

            description TEXT,

            parameters_json TEXT NOT NULL DEFAULT '{}',

            active INTEGER NOT NULL DEFAULT 1
                CHECK (active IN (0, 1)),

            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY (league_id)
                REFERENCES leagues(league_id)
                ON DELETE SET NULL
        );


        -- =====================================================================
        -- RATINGS DE LOS EQUIPOS
        -- =====================================================================

        CREATE TABLE IF NOT EXISTS rating_snapshots (
            rating_id INTEGER PRIMARY KEY AUTOINCREMENT,

            team_id INTEGER NOT NULL,
            model_version TEXT NOT NULL,

            calculated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

            venue TEXT NOT NULL DEFAULT 'TOTAL'
                CHECK (venue IN ('HOME', 'AWAY', 'TOTAL')),

            elo REAL NOT NULL,

            attack_rating REAL NOT NULL
                CHECK (attack_rating >= 0),

            defense_rating REAL NOT NULL
                CHECK (defense_rating >= 0),

            form_rating REAL NOT NULL,

            weighted_gf REAL,
            weighted_ga REAL,

            weighted_xgf REAL,
            weighted_xga REAL,

            weighted_corners_for REAL,
            weighted_corners_against REAL,

            weighted_cards REAL,

            matches_used INTEGER NOT NULL
                CHECK (matches_used >= 0),

            FOREIGN KEY (team_id)
                REFERENCES teams(team_id)
                ON DELETE CASCADE,

            FOREIGN KEY (model_version)
                REFERENCES model_versions(model_version)
                ON DELETE CASCADE
        );


        -- =====================================================================
        -- EJECUCIONES DEL MODELO
        -- =====================================================================

        CREATE TABLE IF NOT EXISTS prediction_runs (
            run_id INTEGER PRIMARY KEY AUTOINCREMENT,

            match_id INTEGER NOT NULL,
            model_version TEXT NOT NULL,

            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

            lambda_home REAL NOT NULL
                CHECK (lambda_home >= 0),

            lambda_away REAL NOT NULL
                CHECK (lambda_away >= 0),

            dixon_coles_rho REAL NOT NULL DEFAULT -0.03,

            matches_window INTEGER NOT NULL DEFAULT 15,

            data_cutoff TEXT,

            FOREIGN KEY (match_id)
                REFERENCES matches(match_id)
                ON DELETE CASCADE,

            FOREIGN KEY (model_version)
                REFERENCES model_versions(model_version)
                ON DELETE CASCADE
        );


        -- =====================================================================
        -- PREDICCIONES POR MERCADO
        -- =====================================================================

        CREATE TABLE IF NOT EXISTS predictions (
            prediction_id INTEGER PRIMARY KEY AUTOINCREMENT,

            run_id INTEGER NOT NULL,

            market TEXT NOT NULL,
            selection TEXT NOT NULL,

            line REAL,

            probability REAL NOT NULL
                CHECK (probability BETWEEN 0 AND 1),

            fair_odds REAL
                CHECK (fair_odds IS NULL OR fair_odds >= 1.0),

            market_odds REAL
                CHECK (
                    market_odds IS NULL
                    OR market_odds > 1.0
                ),

            expected_value REAL,

            kelly_fraction REAL,

            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY (run_id)
                REFERENCES prediction_runs(run_id)
                ON DELETE CASCADE
        );


        -- =====================================================================
        -- BACKTESTING
        -- =====================================================================

        CREATE TABLE IF NOT EXISTS backtesting (
            backtesting_id INTEGER PRIMARY KEY AUTOINCREMENT,

            prediction_id INTEGER NOT NULL UNIQUE,

            settled_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

            result TEXT NOT NULL
                CHECK (
                    result IN (
                        'WON',
                        'LOST',
                        'VOID',
                        'PUSH',
                        'HALF_WON',
                        'HALF_LOST'
                    )
                ),

            hit INTEGER
                CHECK (
                    hit IS NULL
                    OR hit IN (0, 1)
                ),

            actual_value REAL,

            brier_score REAL,
            log_loss REAL,
            model_error REAL,

            FOREIGN KEY (prediction_id)
                REFERENCES predictions(prediction_id)
                ON DELETE CASCADE
        );


        -- =====================================================================
        -- REGISTRO DE SCRAPERS
        -- =====================================================================

        CREATE TABLE IF NOT EXISTS scraper_logs (
            log_id INTEGER PRIMARY KEY AUTOINCREMENT,

            source TEXT NOT NULL,
            operation TEXT NOT NULL,

            status TEXT NOT NULL
                CHECK (
                    status IN (
                        'SUCCESS',
                        'PARTIAL',
                        'ERROR'
                    )
                ),

            message TEXT,

            records_processed INTEGER NOT NULL DEFAULT 0,

            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );


        -- =====================================================================
        -- ÍNDICES
        -- =====================================================================

        CREATE INDEX IF NOT EXISTS idx_matches_kickoff_status
        ON matches(kickoff, status);

        CREATE INDEX IF NOT EXISTS idx_matches_teams
        ON matches(home_team_id, away_team_id);

        CREATE INDEX IF NOT EXISTS idx_stats_team_match
        ON team_match_stats(team_id, match_id);

        CREATE INDEX IF NOT EXISTS idx_odds_lookup
        ON odds_snapshots(
            match_id,
            bookmaker,
            market,
            selection,
            line,
            captured_at
        );

        CREATE INDEX IF NOT EXISTS idx_ratings_latest
        ON rating_snapshots(
            team_id,
            venue,
            model_version,
            calculated_at DESC
        );

        CREATE INDEX IF NOT EXISTS idx_prediction_runs_match
        ON prediction_runs(match_id, created_at DESC);

        CREATE INDEX IF NOT EXISTS idx_predictions_market
        ON predictions(run_id, market, selection, line);

        CREATE INDEX IF NOT EXISTS idx_scraper_logs_source
        ON scraper_logs(source, created_at DESC);

        CREATE UNIQUE INDEX IF NOT EXISTS uq_prediction_market
        ON predictions(
            run_id,
            market,
            selection,
            IFNULL(line, -9999.0)
        );
        """
    )

    conn.commit()


# ==============================================================================
# 4. FUNCIONES DE INSERCIÓN Y ACTUALIZACIÓN
# ==============================================================================

def upsert_league(
    conn: sqlite3.Connection,
    name: str,
    country: str,
    season: str,
    active: bool = True,
    *,
    source_tournament_id: int | None = None,
    source_season_id: int | None = None,
    competition_family: str = "DOMESTIC",
    context_role: str = "PRIMARY_COMPETITION",
    visible_in_ui: bool = True,
) -> int:
    """
    Crea o actualiza una liga y devuelve su league_id.
    """

    conn.execute(
        """
        INSERT INTO leagues (
            name,
            country,
            season,
            active,
            source_tournament_id,
            source_season_id,
            competition_family,
            context_role,
            visible_in_ui
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)

        ON CONFLICT(name, country, season)
        DO UPDATE SET
            active = excluded.active,
            source_tournament_id = COALESCE(
                excluded.source_tournament_id,
                leagues.source_tournament_id
            ),
            source_season_id = COALESCE(
                excluded.source_season_id,
                leagues.source_season_id
            ),
            competition_family = excluded.competition_family,
            context_role = excluded.context_role,
            visible_in_ui = excluded.visible_in_ui,
            updated_at = CURRENT_TIMESTAMP;
        """,
        (
            name.strip(),
            country.strip(),
            season.strip(),
            int(active),
            source_tournament_id,
            source_season_id,
            competition_family.strip().upper(),
            context_role.strip().upper(),
            int(visible_in_ui),
        )
    )

    row = conn.execute(
        """
        SELECT league_id
        FROM leagues
        WHERE name = ?
          AND country = ?
          AND season = ?;
        """,
        (name.strip(), country.strip(), season.strip())
    ).fetchone()

    if row is None:
        raise RuntimeError("No se pudo obtener league_id.")

    return int(row["league_id"])


def upsert_team(
    conn: sqlite3.Connection,
    sofascore_id: int,
    name: str,
    league_id: int | None = None
) -> int:
    """
    Crea o actualiza un equipo.
    """

    conn.execute(
        """
        INSERT INTO teams (
            sofascore_id,
            name,
            league_id
        )
        VALUES (?, ?, ?)

        ON CONFLICT(sofascore_id)
        DO UPDATE SET
            name = excluded.name,
            league_id = COALESCE(
                teams.league_id,
                excluded.league_id
            ),
            updated_at = CURRENT_TIMESTAMP;
        """,
        (sofascore_id, name.strip(), league_id)
    )

    row = conn.execute(
        """
        SELECT team_id
        FROM teams
        WHERE sofascore_id = ?;
        """,
        (sofascore_id,)
    ).fetchone()

    if row is None:
        raise RuntimeError("No se pudo obtener team_id.")

    return int(row["team_id"])


def upsert_team_competition_membership(
    conn: sqlite3.Connection,
    *,
    team_id: int,
    league_id: int,
    sofascore_tournament_id: int,
    sofascore_season_id: int,
    membership_role: str = "PARTICIPANT",
    membership_status: str = "ACTIVE",
    entry_round: str | None = None,
    current_round: str | None = None,
    transferred_from_tournament_id: int | None = None,
    transferred_to_tournament_id: int | None = None,
) -> None:
    """Registra una participación sin alterar la liga legada del club."""

    role = membership_role.strip().upper()
    status = membership_status.strip().upper()
    existing = conn.execute(
        """
        SELECT membership_status
        FROM team_competition_memberships
        WHERE team_id = ?
          AND sofascore_tournament_id = ?
          AND sofascore_season_id = ?;
        """,
        (team_id, sofascore_tournament_id, sofascore_season_id),
    ).fetchone()
    status_changed = existing is not None and str(existing[0]) != status

    conn.execute(
        """
        INSERT INTO team_competition_memberships (
            team_id, league_id,
            source_tournament_id, source_season_id,
            sofascore_tournament_id, sofascore_season_id,
            membership_role, membership_status,
            entry_round, current_round,
            transferred_from_tournament_id,
            transferred_to_tournament_id,
            status_changed_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                CASE WHEN ? THEN CURRENT_TIMESTAMP ELSE NULL END)
        ON CONFLICT(team_id, sofascore_tournament_id, sofascore_season_id)
        DO UPDATE SET
            league_id = excluded.league_id,
            source_tournament_id = excluded.sofascore_tournament_id,
            source_season_id = excluded.sofascore_season_id,
            membership_role = excluded.membership_role,
            membership_status = excluded.membership_status,
            entry_round = COALESCE(excluded.entry_round, entry_round),
            current_round = COALESCE(excluded.current_round, current_round),
            transferred_from_tournament_id = COALESCE(
                excluded.transferred_from_tournament_id,
                transferred_from_tournament_id
            ),
            transferred_to_tournament_id = COALESCE(
                excluded.transferred_to_tournament_id,
                transferred_to_tournament_id
            ),
            last_seen_at = CURRENT_TIMESTAMP,
            status_changed_at = CASE
                WHEN membership_status IS NOT excluded.membership_status
                THEN CURRENT_TIMESTAMP
                ELSE status_changed_at
            END;
        """,
        (
            team_id, league_id,
            sofascore_tournament_id, sofascore_season_id,
            sofascore_tournament_id, sofascore_season_id,
            role, status, entry_round, current_round,
            transferred_from_tournament_id,
            transferred_to_tournament_id,
            int(status_changed),
        ),
    )


def upsert_match(
    conn: sqlite3.Connection,
    *,
    sofascore_id: int,
    league_id: int,
    season: str,
    kickoff: str,
    home_team_id: int,
    away_team_id: int,
    status: str = "NS",
    home_goals: int | None = None,
    away_goals: int | None = None,
    betano_event_id: str | None = None,
    betano_url: str | None = None,
    identity_validated: bool = True,
) -> int:
    """
    Crea o actualiza un partido.
    """

    conn.execute(
        """
        INSERT INTO matches (
            sofascore_id,
            betano_event_id,
            betano_url,
            league_id,
            season,
            kickoff,
            home_team_id,
            away_team_id,
            home_goals,
            away_goals,
            status,
            identity_validated
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)

        ON CONFLICT(sofascore_id)
        DO UPDATE SET
            betano_event_id = COALESCE(
                excluded.betano_event_id,
                matches.betano_event_id
            ),
            betano_url = COALESCE(
                excluded.betano_url,
                matches.betano_url
            ),
            league_id = excluded.league_id,
            season = excluded.season,
            kickoff = excluded.kickoff,
            home_team_id = excluded.home_team_id,
            away_team_id = excluded.away_team_id,
            home_goals = excluded.home_goals,
            away_goals = excluded.away_goals,
            status = excluded.status,
            identity_validated = MAX(
                matches.identity_validated,
                excluded.identity_validated
            ),
            updated_at = CURRENT_TIMESTAMP;
        """,
        (
            sofascore_id,
            betano_event_id,
            betano_url,
            league_id,
            season,
            kickoff,
            home_team_id,
            away_team_id,
            home_goals,
            away_goals,
            status,
            int(identity_validated),
        )
    )

    row = conn.execute(
        """
        SELECT match_id
        FROM matches
        WHERE sofascore_id = ?;
        """,
        (sofascore_id,)
    ).fetchone()

    if row is None:
        raise RuntimeError("No se pudo obtener match_id.")

    return int(row["match_id"])


def upsert_team_match_stats(
    conn: sqlite3.Connection,
    *,
    match_id: int,
    team_id: int,
    venue: str,
    goals_for: int | None = None,
    goals_against: int | None = None,
    xg_for: float | None = None,
    xg_against: float | None = None,
    xg_source: str | None = None,
    xg_is_estimated: bool = False,
    xg_method_version: str | None = None,
    xg_updated_at: str | None = None,
    shots: int | None = None,
    shots_on_target: int | None = None,
    corners_for: int | None = None,
    corners_against: int | None = None,
    yellow_cards: int | None = None,
    red_cards: int | None = None,
    possession: float | None = None,
    fouls: int | None = None,
    offsides: int | None = None,
    big_chances: int | None = None,
    data_quality: str = "FULL"
) -> None:
    """
    Inserta o actualiza las estadísticas de un equipo en un partido.
    """

    venue = venue.upper()
    data_quality = data_quality.upper()

    conn.execute(
        """
        INSERT INTO team_match_stats (
            match_id,
            team_id,
            venue,
            goals_for,
            goals_against,
            xg_for,
            xg_against,
            xg_source,
            xg_is_estimated,
            xg_method_version,
            xg_updated_at,
            shots,
            shots_on_target,
            corners_for,
            corners_against,
            yellow_cards,
            red_cards,
            possession,
            fouls,
            offsides,
            big_chances,
            data_quality
        )
        VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?
        )

        ON CONFLICT(match_id, team_id)
        DO UPDATE SET
            venue = excluded.venue,
            goals_for = COALESCE(
                excluded.goals_for,
                team_match_stats.goals_for
            ),
            goals_against = COALESCE(
                excluded.goals_against,
                team_match_stats.goals_against
            ),
            xg_for = CASE
                WHEN excluded.xg_for IS NULL
                    OR excluded.xg_against IS NULL
                    THEN team_match_stats.xg_for
                WHEN team_match_stats.xg_for IS NULL
                    OR team_match_stats.xg_against IS NULL
                    THEN excluded.xg_for
                WHEN COALESCE(team_match_stats.xg_is_estimated, 0) = 0
                    AND COALESCE(excluded.xg_is_estimated, 0) = 1
                    THEN team_match_stats.xg_for
                ELSE excluded.xg_for
            END,
            xg_against = CASE
                WHEN excluded.xg_for IS NULL
                    OR excluded.xg_against IS NULL
                    THEN team_match_stats.xg_against
                WHEN team_match_stats.xg_for IS NULL
                    OR team_match_stats.xg_against IS NULL
                    THEN excluded.xg_against
                WHEN COALESCE(team_match_stats.xg_is_estimated, 0) = 0
                    AND COALESCE(excluded.xg_is_estimated, 0) = 1
                    THEN team_match_stats.xg_against
                ELSE excluded.xg_against
            END,
            xg_source = CASE
                WHEN excluded.xg_for IS NULL
                    OR excluded.xg_against IS NULL
                    THEN CASE
                        WHEN team_match_stats.xg_for IS NULL
                            THEN COALESCE(
                                excluded.xg_source,
                                team_match_stats.xg_source
                            )
                        ELSE team_match_stats.xg_source
                    END
                WHEN team_match_stats.xg_for IS NOT NULL
                    AND team_match_stats.xg_against IS NOT NULL
                    AND COALESCE(team_match_stats.xg_is_estimated, 0) = 0
                    AND COALESCE(excluded.xg_is_estimated, 0) = 1
                    THEN team_match_stats.xg_source
                ELSE excluded.xg_source
            END,
            xg_is_estimated = CASE
                WHEN excluded.xg_for IS NULL
                    OR excluded.xg_against IS NULL
                    THEN team_match_stats.xg_is_estimated
                WHEN team_match_stats.xg_for IS NOT NULL
                    AND team_match_stats.xg_against IS NOT NULL
                    AND COALESCE(team_match_stats.xg_is_estimated, 0) = 0
                    AND COALESCE(excluded.xg_is_estimated, 0) = 1
                    THEN team_match_stats.xg_is_estimated
                ELSE excluded.xg_is_estimated
            END,
            xg_method_version = CASE
                WHEN excluded.xg_for IS NULL
                    OR excluded.xg_against IS NULL
                    THEN team_match_stats.xg_method_version
                WHEN team_match_stats.xg_for IS NOT NULL
                    AND team_match_stats.xg_against IS NOT NULL
                    AND COALESCE(team_match_stats.xg_is_estimated, 0) = 0
                    AND COALESCE(excluded.xg_is_estimated, 0) = 1
                    THEN team_match_stats.xg_method_version
                ELSE excluded.xg_method_version
            END,
            xg_updated_at = CASE
                WHEN excluded.xg_for IS NULL
                    OR excluded.xg_against IS NULL
                    THEN team_match_stats.xg_updated_at
                WHEN team_match_stats.xg_for IS NOT NULL
                    AND team_match_stats.xg_against IS NOT NULL
                    AND COALESCE(team_match_stats.xg_is_estimated, 0) = 0
                    AND COALESCE(excluded.xg_is_estimated, 0) = 1
                    THEN team_match_stats.xg_updated_at
                ELSE excluded.xg_updated_at
            END,
            shots = COALESCE(
                excluded.shots,
                team_match_stats.shots
            ),
            shots_on_target = COALESCE(
                excluded.shots_on_target,
                team_match_stats.shots_on_target
            ),
            corners_for = COALESCE(
                excluded.corners_for,
                team_match_stats.corners_for
            ),
            corners_against = COALESCE(
                excluded.corners_against,
                team_match_stats.corners_against
            ),
            yellow_cards = COALESCE(
                excluded.yellow_cards,
                team_match_stats.yellow_cards
            ),
            red_cards = COALESCE(
                excluded.red_cards,
                team_match_stats.red_cards
            ),
            possession = COALESCE(
                excluded.possession,
                team_match_stats.possession
            ),
            fouls = COALESCE(
                excluded.fouls,
                team_match_stats.fouls
            ),
            offsides = COALESCE(
                excluded.offsides,
                team_match_stats.offsides
            ),
            big_chances = COALESCE(
                excluded.big_chances,
                team_match_stats.big_chances
            ),
            data_quality = excluded.data_quality,
            updated_at = CURRENT_TIMESTAMP;
        """,
        (
            match_id,
            team_id,
            venue,
            goals_for,
            goals_against,
            xg_for,
            xg_against,
            xg_source,
            int(bool(xg_is_estimated)),
            xg_method_version,
            xg_updated_at,
            shots,
            shots_on_target,
            corners_for,
            corners_against,
            yellow_cards,
            red_cards,
            possession,
            fouls,
            offsides,
            big_chances,
            data_quality
        )
    )


def insert_odds_snapshot(
    conn: sqlite3.Connection,
    *,
    match_id: int,
    bookmaker: str,
    market: str,
    selection: str,
    odds: float,
    line: float | None = None,
    is_live: bool = False
) -> int:
    """
    Guarda una cuota de Betano u otra casa.

    No reemplaza la anterior: crea un snapshot nuevo para
    conservar el movimiento del mercado.
    """

    cursor = conn.execute(
        """
        INSERT INTO odds_snapshots (
            match_id,
            bookmaker,
            market,
            selection,
            line,
            odds,
            is_live
        )
        VALUES (?, ?, ?, ?, ?, ?, ?);
        """,
        (
            match_id,
            bookmaker.strip().upper(),
            market.strip().upper(),
            selection.strip().upper(),
            line,
            odds,
            int(is_live)
        )
    )

    return int(cursor.lastrowid)


def register_model_version(
    conn: sqlite3.Connection,
    *,
    model_version: str,
    description: str,
    parameters: dict[str, Any],
    league_id: int | None = None,
    active: bool = True
) -> None:
    """
    Registra los parámetros de una versión del modelo.

    Aquí se guardarán los pesos aprendidos mediante backtesting,
    no porcentajes escritos manualmente.
    """

    conn.execute(
        """
        INSERT INTO model_versions (
            model_version,
            league_id,
            description,
            parameters_json,
            active
        )
        VALUES (?, ?, ?, ?, ?)

        ON CONFLICT(model_version)
        DO UPDATE SET
            league_id = excluded.league_id,
            description = excluded.description,
            parameters_json = excluded.parameters_json,
            active = excluded.active;
        """,
        (
            model_version,
            league_id,
            description,
            json.dumps(parameters, ensure_ascii=False),
            int(active)
        )
    )


# ==============================================================================
# 5. INICIALIZACIÓN
# ==============================================================================

def init_db(
    db_path: str | Path | None = None
) -> Path:
    """
    Inicializa la base de datos y devuelve su ruta.
    """

    path = Path(db_path) if db_path else DB_PATH

    conn = get_connection(path)

    try:
        create_tables(conn)
        ensure_schema_migrations(conn)
    finally:
        conn.close()

    print(f"[OK] Base de datos inicializada: {path}")
    return path


if __name__ == "__main__":
    init_db()
