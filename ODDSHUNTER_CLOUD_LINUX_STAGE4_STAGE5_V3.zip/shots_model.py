from __future__ import annotations

import argparse
import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from shots_engine import (
    DEFAULT_RECENT_WEIGHT_SHOTS,
    DEFAULT_RECENT_WEIGHT_SOT,
    database_prediction as shared_database_prediction,
    recent_weight_to_share,
)

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_ROOT = DATA_DIR / "modelos" / "shots"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def slugify(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", value.strip().lower()).strip("-")


def read_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"{path} no contiene un objeto JSON.")
    return data


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def number(value: Any) -> float | None:
    try:
        result = float(str(value).replace(",", "."))
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def parse_log_metric(path: Path, label_pattern: str) -> tuple[float | None, float | None]:
    if not path.exists():
        return None, None
    text = path.read_text(encoding="utf-8", errors="replace")
    pattern = re.compile(
        rf"^\s*{label_pattern}\s*:\s*([0-9]+(?:[.,][0-9]+)?)",
        re.IGNORECASE | re.MULTILINE,
    )
    values = [number(raw) for raw in pattern.findall(text)]
    clean = [value for value in values if value is not None]
    if len(clean) >= 4:
        return clean[1], clean[3]
    if len(clean) >= 2:
        return clean[0], clean[-1]
    return None, None


def database_prediction(
    match: dict[str, Any],
    competition_key: str,
) -> tuple[float | None, float | None, float | None, float | None]:
    """Wrapper mínimo: toda la matemática vive en shots_engine.py."""
    return shared_database_prediction(
        match,
        competition_key,
        shots_recent_weight=DEFAULT_RECENT_WEIGHT_SHOTS,
        sot_recent_weight=DEFAULT_RECENT_WEIGHT_SOT,
    )



# ODDSHUNTER_FRANCIA_SHOTS_HISTORY_SCOPE_V9_2_1
_database_prediction_current_scope_v921 = database_prediction
_HISTORY_SCOPE_USED_V921 = False
_HISTORY_SCOPE_IDS_V921: list[int] = []

def _history_scope_prediction_v921(match: dict[str, Any], competition_key: str):
    import math as _math
    import sqlite3 as _sqlite3
    from pathlib import Path as _Path
    from datetime import datetime as _datetime, timezone as _timezone

    if str(competition_key or "").strip().lower() != "ligue-1":
        return None

    _root = _Path(__file__).resolve().parent
    _db = _root / "data" / "oddshunter.db"
    _registry = _root / "data" / "competitions.json"
    if not _db.exists() or not _registry.exists():
        return None

    try:
        _registry_doc = json.loads(_registry.read_text(encoding="utf-8-sig"))
        _spec = next(
            row for row in (_registry_doc.get("competitions") or [])
            if isinstance(row, dict)
            and str(row.get("key") or "").strip().lower() == "ligue-1"
        )
    except Exception:
        return None

    _pairs = []
    for _item in (_spec.get("history_source_pairs") or []):
        if isinstance(_item, dict):
            _tid = _item.get("tournament_id", _item.get("source_tournament_id"))
            _sid = _item.get("season_id", _item.get("source_season_id"))
        elif isinstance(_item, (list, tuple)) and len(_item) >= 2:
            _tid, _sid = _item[0], _item[1]
        else:
            continue
        try:
            _pair = (int(_tid), int(_sid))
        except Exception:
            continue
        if _pair not in _pairs:
            _pairs.append(_pair)

    if not _pairs:
        return None

    def _source_id(side: str):
        for _key in (
            f"{side}_team_id",
            f"{side}_source_team_id",
            f"{side}_sofascore_id",
            f"{side}_team_source_id",
        ):
            try:
                _value = int(match.get(_key) or 0)
            except Exception:
                continue
            if _value > 0:
                return _value
        return None

    _home_sid = _source_id("home")
    _away_sid = _source_id("away")
    if _home_sid is None or _away_sid is None:
        return None

    _kickoff_text = str(
        match.get("kickoff")
        or match.get("start_time")
        or match.get("date")
        or ""
    ).strip()
    if not _kickoff_text:
        return None

    def _num(value):
        try:
            _v = float(value)
        except Exception:
            return None
        return _v if _math.isfinite(_v) else None

    def _weighted(rows, field, preferred_venue):
        _valid = [r for r in rows if _num(r[field]) is not None]
        _preferred = [
            r for r in _valid
            if str(r["venue"] or "").upper() == preferred_venue
        ]
        _selected = (_preferred if len(_preferred) >= 3 else _valid)[:15]
        _total = 0.0
        _weights = 0.0
        _recent_weight = 1.6363636363636365
        for _index, _row in enumerate(_selected):
            _v = _num(_row[field])
            if _v is None:
                continue
            _w = _recent_weight if _index < 5 else 1.0
            _total += _v * _w
            _weights += _w
        return (_total / _weights) if _weights > 0 else None

    def _sample_size(rows, preferred_venue):
        _valid = [r for r in rows if _num(r["shots"]) is not None]
        _preferred = [
            r for r in _valid
            if str(r["venue"] or "").upper() == preferred_venue
        ]
        _selected = _preferred if len(_preferred) >= 3 else _valid
        return min(15, len(_selected))

    def _profile(rows, preferred_venue):
        return {
            "shots_for": _weighted(rows, "shots", preferred_venue),
            "shots_allowed": _weighted(rows, "opponent_shots", preferred_venue),
            "target_for": _weighted(rows, "shots_on_target", preferred_venue),
            "target_allowed": _weighted(rows, "opponent_sot", preferred_venue),
            "matches": _sample_size(rows, preferred_venue),
        }

    def _shrink(value, baseline, matches):
        if baseline is None:
            return value
        if value is None:
            return baseline
        _w = max(0.0, float(matches)) / (max(0.0, float(matches)) + 5.0)
        return _w * value + (1.0 - _w) * baseline

    def _blend(a, b):
        if a is not None and b is not None and a >= 0 and b >= 0:
            return _math.sqrt(max(a, 0.0) * max(b, 0.0))
        return a if a is not None else b

    _con = _sqlite3.connect(_db)
    _con.row_factory = _sqlite3.Row
    try:
        _league_ids = []
        for _tid, _sid in _pairs:
            _rows = _con.execute(
                "SELECT league_id FROM leagues "
                "WHERE source_tournament_id=? AND source_season_id=? "
                "ORDER BY league_id",
                (_tid, _sid),
            ).fetchall()
            for _row in _rows:
                _lid = int(_row["league_id"])
                if _lid not in _league_ids:
                    _league_ids.append(_lid)

        if not _league_ids:
            return None

        # El season 24/25 aún no existe localmente; se usan solo IDs resueltos.
        _ph_leagues = ",".join("?" for _ in _league_ids)

        def _team_internal_ids(_sid):
            return [
                int(r["team_id"])
                for r in _con.execute(
                    "SELECT team_id FROM teams "
                    "WHERE sofascore_id=? ORDER BY team_id DESC",
                    (_sid,),
                ).fetchall()
            ]

        def _team_rows(_sid):
            _ids = _team_internal_ids(_sid)
            if not _ids:
                return []
            _ph_ids = ",".join("?" for _ in _ids)
            _params = [*_ids, *_league_ids, _kickoff_text]
            return _con.execute(
                f"""
                SELECT
                    s.venue,
                    s.shots,
                    s.shots_on_target,
                    opp.shots AS opponent_shots,
                    opp.shots_on_target AS opponent_sot,
                    m.kickoff
                FROM team_match_stats AS s
                INNER JOIN matches AS m
                    ON m.match_id = s.match_id
                INNER JOIN team_match_stats AS opp
                    ON opp.match_id = s.match_id
                   AND opp.team_id <> s.team_id
                WHERE s.team_id IN ({_ph_ids})
                  AND m.league_id IN ({_ph_leagues})
                  AND UPPER(COALESCE(m.status,'')) IN ('FT','FINISHED')
                  AND m.kickoff < ?
                ORDER BY m.kickoff DESC, m.match_id DESC
                LIMIT 40
                """,
                _params,
            ).fetchall()

        _home_rows = _team_rows(_home_sid)
        _away_rows = _team_rows(_away_sid)
        _home = _profile(_home_rows, "HOME")
        _away = _profile(_away_rows, "AWAY")

        _mean_row = _con.execute(
            f"""
            SELECT
                AVG(hs.shots) AS home_shots,
                AVG(aws.shots) AS away_shots,
                AVG(hs.shots_on_target) AS home_targets,
                AVG(aws.shots_on_target) AS away_targets
            FROM matches AS m
            INNER JOIN team_match_stats AS hs
                ON hs.match_id=m.match_id AND UPPER(hs.venue)='HOME'
            INNER JOIN team_match_stats AS aws
                ON aws.match_id=m.match_id AND UPPER(aws.venue)='AWAY'
            WHERE m.league_id IN ({_ph_leagues})
              AND UPPER(COALESCE(m.status,'')) IN ('FT','FINISHED')
              AND m.kickoff < ?
            """,
            [*_league_ids, _kickoff_text],
        ).fetchone()

        _means = {
            "home_shots": _num(_mean_row["home_shots"]),
            "away_shots": _num(_mean_row["away_shots"]),
            "home_targets": _num(_mean_row["home_targets"]),
            "away_targets": _num(_mean_row["away_targets"]),
        }
    finally:
        _con.close()

    _hm = int(_home.get("matches") or 0)
    _am = int(_away.get("matches") or 0)

    _hs = _blend(
        _shrink(_home["shots_for"], _means["home_shots"], _hm),
        _shrink(_away["shots_allowed"], _means["home_shots"], _am),
    )
    _aws = _blend(
        _shrink(_away["shots_for"], _means["away_shots"], _am),
        _shrink(_home["shots_allowed"], _means["away_shots"], _hm),
    )
    _hst = _blend(
        _shrink(_home["target_for"], _means["home_targets"], _hm),
        _shrink(_away["target_allowed"], _means["home_targets"], _am),
    )
    _awst = _blend(
        _shrink(_away["target_for"], _means["away_targets"], _am),
        _shrink(_home["target_allowed"], _means["away_targets"], _hm),
    )

    if _hs is None or _aws is None:
        return None

    global _HISTORY_SCOPE_IDS_V921
    _HISTORY_SCOPE_IDS_V921 = sorted(_league_ids)
    return (_hs, _aws, _hst, _awst)


def database_prediction(match: dict[str, Any], competition_key: str):
    global _HISTORY_SCOPE_USED_V921
    if str(competition_key or "").strip().lower() == "ligue-1":
        _result = _history_scope_prediction_v921(match, competition_key)
        if (
            isinstance(_result, (tuple, list))
            and len(_result) == 4
            and _result[0] is not None
            and _result[1] is not None
        ):
            _HISTORY_SCOPE_USED_V921 = True
            return tuple(_result)
    return _database_prediction_current_scope_v921(match, competition_key)



# ============================================================================
# ODDSHUNTER_FRANCIA_SHOTS_PROFILE_ONLY_V10_4_5
# Self-contained: NO depende de source_team_id/team_profile/league_shot_means.
# ============================================================================
_database_prediction_before_profile_v1045 = database_prediction
_write_json_before_profile_v1045 = write_json
_PROFILE_SCOPE_USED_V1045 = False
_PROFILE_SCOPE_HOME_IDS_V1045 = []
_PROFILE_SCOPE_AWAY_IDS_V1045 = []
_PROFILE_PRIMARY_MEANS_IDS_V1045 = []

def _profile_scope_prediction_v1045(match, competition_key):
    import math as _math
    import sqlite3 as _sqlite3
    from pathlib import Path as _Path

    if str(competition_key or "").strip().lower() != "ligue-1":
        return None

    def _source_id(side):
        for _key in (
            f"{side}_team_id",
            f"{side}_source_team_id",
            f"{side}_sofascore_id",
            f"{side}_team_source_id",
        ):
            try:
                _value = int(match.get(_key) or 0)
            except Exception:
                continue
            if _value > 0:
                return _value
        return None

    _home_sid = _source_id("home")
    _away_sid = _source_id("away")
    if _home_sid is None or _away_sid is None:
        return None

    _promoted = {1672, 1652}
    if _home_sid not in _promoted and _away_sid not in _promoted:
        return None

    _root = _Path(__file__).resolve().parent
    _db = _root / "data" / "oddshunter.db"
    _registry = _root / "data" / "competitions.json"
    if not _db.exists() or not _registry.exists():
        return None

    try:
        _registry_doc = json.loads(_registry.read_text(encoding="utf-8-sig"))
        _spec = next(
            _row for _row in (_registry_doc.get("competitions") or [])
            if isinstance(_row, dict)
            and str(_row.get("key") or "").strip().lower() == "ligue-1"
        )
    except Exception:
        return None

    def _pairs_to_ids(_con, _pairs):
        _ids = set()
        _sql = (
            "SELECT league_id FROM leagues "
            "WHERE source_tournament_id=? AND source_season_id=? "
            "ORDER BY league_id"
        )
        for _item in (_pairs or []):
            if not isinstance(_item, dict):
                continue
            try:
                _tid = int(_item.get("tournament_id"))
                _season = int(_item.get("season_id"))
            except Exception:
                continue
            for _row in _con.execute(_sql, (_tid, _season)).fetchall():
                try:
                    _lid = int(_row["league_id"])
                except Exception:
                    _lid = int(_row[0])
                _ids.add(_lid)
        return sorted(_ids)

    def _profile_pairs_for(_sid):
        _rows = []
        for _item in (_spec.get("profile_history_source_pairs") or []):
            if not isinstance(_item, dict):
                continue
            _teams = _item.get("team_sofascore_ids")
            if not isinstance(_teams, list):
                continue
            try:
                _teams = {int(_x) for _x in _teams}
            except Exception:
                continue
            if int(_sid) in _teams:
                _rows.append(_item)
        return _rows

    _kickoff = str(
        match.get("kickoff")
        or match.get("start_time")
        or match.get("date")
        or ""
    ).strip()
    if not _kickoff:
        return None

    def _num(_value):
        try:
            _value = float(_value)
        except Exception:
            return None
        return _value if _math.isfinite(_value) else None

    def _weighted(_rows, _field, _venue):
        _valid = [_r for _r in _rows if _num(_r[_field]) is not None]
        _venue_rows = [
            _r for _r in _valid
            if str(_r["venue"] or "").upper() == _venue
        ]
        _selected = (_venue_rows if len(_venue_rows) >= 3 else _valid)[:15]
        _total = 0.0
        _weights = 0.0
        for _index, _row in enumerate(_selected):
            _value = _num(_row[_field])
            if _value is None:
                continue
            _weight = 1.6363636363636365 if _index < 5 else 1.0
            _total += _value * _weight
            _weights += _weight
        return _total / _weights if _weights > 0 else None

    def _sample_size(_rows, _venue):
        _valid = [_r for _r in _rows if _num(_r["shots"]) is not None]
        _venue_rows = [
            _r for _r in _valid
            if str(_r["venue"] or "").upper() == _venue
        ]
        _selected = _venue_rows if len(_venue_rows) >= 3 else _valid
        return min(15, len(_selected))

    def _profile(_rows, _venue):
        return {
            "shots_for": _weighted(_rows, "shots", _venue),
            "shots_allowed": _weighted(_rows, "opponent_shots", _venue),
            "target_for": _weighted(_rows, "shots_on_target", _venue),
            "target_allowed": _weighted(_rows, "opponent_sot", _venue),
            "matches": _sample_size(_rows, _venue),
        }

    def _shrink(_value, _baseline, _matches):
        if _baseline is None:
            return _value
        if _value is None:
            return _baseline
        _w = max(0.0, float(_matches)) / (max(0.0, float(_matches)) + 5.0)
        return _w * _value + (1.0 - _w) * _baseline

    def _blend(_a, _b):
        if _a is not None and _b is not None and _a >= 0 and _b >= 0:
            return _math.sqrt(max(_a, 0.0) * max(_b, 0.0))
        return _a if _a is not None else _b

    _con = _sqlite3.connect(_db)
    _con.row_factory = _sqlite3.Row
    try:
        _primary_ids = _pairs_to_ids(_con, _spec.get("history_source_pairs"))
        if not _primary_ids:
            return None

        _home_ids = (
            _pairs_to_ids(_con, _profile_pairs_for(_home_sid))
            if _home_sid in _promoted
            else list(_primary_ids)
        )
        _away_ids = (
            _pairs_to_ids(_con, _profile_pairs_for(_away_sid))
            if _away_sid in _promoted
            else list(_primary_ids)
        )
        if not _home_ids or not _away_ids:
            return None

        def _internal_ids(_sid):
            return [
                int(_row["team_id"])
                for _row in _con.execute(
                    "SELECT team_id FROM teams "
                    "WHERE sofascore_id=? ORDER BY team_id DESC",
                    (_sid,),
                ).fetchall()
            ]

        def _history(_sid, _scope_ids):
            _team_ids = _internal_ids(_sid)
            if not _team_ids or not _scope_ids:
                return []
            _p_team = ",".join("?" for _ in _team_ids)
            _p_scope = ",".join("?" for _ in _scope_ids)
            _params = [*_team_ids, *_scope_ids, _kickoff]
            return _con.execute(
                f"""
                SELECT
                    s.venue,
                    s.shots,
                    s.shots_on_target,
                    opp.shots AS opponent_shots,
                    opp.shots_on_target AS opponent_sot,
                    m.kickoff
                FROM team_match_stats AS s
                INNER JOIN matches AS m
                    ON m.match_id=s.match_id
                INNER JOIN team_match_stats AS opp
                    ON opp.match_id=s.match_id
                   AND opp.team_id<>s.team_id
                WHERE s.team_id IN ({_p_team})
                  AND m.league_id IN ({_p_scope})
                  AND UPPER(COALESCE(m.status,'')) IN ('FT','FINISHED')
                  AND m.kickoff < ?
                ORDER BY m.kickoff DESC, m.match_id DESC
                LIMIT 40
                """,
                _params,
            ).fetchall()

        _home_rows = _history(_home_sid, _home_ids)
        _away_rows = _history(_away_sid, _away_ids)
        _home = _profile(_home_rows, "HOME")
        _away = _profile(_away_rows, "AWAY")

        _p_primary = ",".join("?" for _ in _primary_ids)
        _mean_row = _con.execute(
            f"""
            SELECT
                AVG(hs.shots) AS home_shots,
                AVG(aws.shots) AS away_shots,
                AVG(hs.shots_on_target) AS home_targets,
                AVG(aws.shots_on_target) AS away_targets
            FROM matches AS m
            INNER JOIN team_match_stats AS hs
                ON hs.match_id=m.match_id
               AND UPPER(hs.venue)='HOME'
            INNER JOIN team_match_stats AS aws
                ON aws.match_id=m.match_id
               AND UPPER(aws.venue)='AWAY'
            WHERE m.league_id IN ({_p_primary})
              AND UPPER(COALESCE(m.status,'')) IN ('FT','FINISHED')
              AND m.kickoff < ?
            """,
            [*_primary_ids, _kickoff],
        ).fetchone()

        _means = {
            "home_shots": _num(_mean_row["home_shots"]),
            "away_shots": _num(_mean_row["away_shots"]),
            "home_targets": _num(_mean_row["home_targets"]),
            "away_targets": _num(_mean_row["away_targets"]),
        }
    finally:
        _con.close()

    _hm = int(_home.get("matches") or 0)
    _am = int(_away.get("matches") or 0)

    _hs = _blend(
        _shrink(_home["shots_for"], _means["home_shots"], _hm),
        _shrink(_away["shots_allowed"], _means["home_shots"], _am),
    )
    _aws = _blend(
        _shrink(_away["shots_for"], _means["away_shots"], _am),
        _shrink(_home["shots_allowed"], _means["away_shots"], _hm),
    )
    _hst = _blend(
        _shrink(_home["target_for"], _means["home_targets"], _hm),
        _shrink(_away["target_allowed"], _means["home_targets"], _am),
    )
    _awst = _blend(
        _shrink(_away["target_for"], _means["away_targets"], _am),
        _shrink(_home["target_allowed"], _means["away_targets"], _hm),
    )

    if any(_x is None for _x in (_hs, _aws, _hst, _awst)):
        return None

    global _PROFILE_SCOPE_HOME_IDS_V1045
    global _PROFILE_SCOPE_AWAY_IDS_V1045
    global _PROFILE_PRIMARY_MEANS_IDS_V1045
    _PROFILE_SCOPE_HOME_IDS_V1045 = sorted(_home_ids)
    _PROFILE_SCOPE_AWAY_IDS_V1045 = sorted(_away_ids)
    _PROFILE_PRIMARY_MEANS_IDS_V1045 = sorted(_primary_ids)

    return (_hs, _aws, _hst, _awst)

def database_prediction(match, competition_key):
    global _PROFILE_SCOPE_USED_V1045
    if str(competition_key or "").strip().lower() == "ligue-1":
        _result = _profile_scope_prediction_v1045(match, competition_key)
        if (
            isinstance(_result, (tuple, list))
            and len(_result) == 4
            and all(_x is not None for _x in _result)
        ):
            _PROFILE_SCOPE_USED_V1045 = True
            return tuple(_result)
    return _database_prediction_before_profile_v1045(match, competition_key)

def write_json(path, data):
    if (
        globals().get("_PROFILE_SCOPE_USED_V1045")
        and isinstance(data, dict)
        and isinstance(data.get("model"), dict)
    ):
        data = dict(data)
        data["model"] = dict(data["model"])
        data["model"]["source"] = "sqlite_profile_history_scope_bayesian"
        data["model"]["scope"] = "profile_history_source_pairs_mixed"
    return _write_json_before_profile_v1045(path, data)
# ============================================================================
# FIN ODDSHUNTER_FRANCIA_SHOTS_PROFILE_ONLY_V10_4_5
# ============================================================================








# =============================================================================
# ODDSHUNTER_PREMIER_SHOTS_RUNTIME_SCOPE_V1
#
# Premier:
# - equipos normales -> Premier 25/26 + Premier 26/27;
# - ascendidos -> Championship 25/26 profile_history_source_pairs;
# - medias de liga -> scope primario Premier;
# - remates y SOT usan los pesos vigentes de shots_engine.py.
#
# No entrenamiento. No escritura SQLite.
# =============================================================================

_oh_database_prediction_before_premier_shots_v1 = database_prediction
_oh_write_json_before_premier_shots_v1 = write_json

_PREMIER_SHOTS_SCOPE_USED_V1 = False
_PREMIER_SHOTS_HOME_IDS_V1 = []
_PREMIER_SHOTS_AWAY_IDS_V1 = []
_PREMIER_SHOTS_MEANS_IDS_V1 = []


def _oh_premier_shots_source_id_v1(
    match,
    side,
):
    _keys = [
        f"{side}_team_id",
        f"{side}_sofascore_id",
        f"{side}TeamId",
    ]

    for _key in _keys:
        _value = match.get(_key)

        try:
            _value = int(_value)
        except Exception:
            continue

        if _value > 0:
            return _value

    for _key in (
        side,
        f"{side}_team",
        f"{side}Team",
    ):
        _node = match.get(_key)

        if not isinstance(
            _node,
            dict,
        ):
            continue

        for _id_key in (
            "id",
            "team_id",
            "sofascore_id",
        ):
            try:
                _value = int(
                    _node.get(
                        _id_key
                    )
                )
            except Exception:
                continue

            if _value > 0:
                return _value

    return None


def _oh_premier_pair_ids_v1(
    _conn,
    _pairs,
):
    _ids = set()

    for _pair in (
        _pairs
        or []
    ):
        if not isinstance(
            _pair,
            dict,
        ):
            continue

        try:
            _tid = int(
                _pair.get(
                    "tournament_id",
                    _pair.get(
                        "source_tournament_id"
                    ),
                )
            )

            _season = int(
                _pair.get(
                    "season_id",
                    _pair.get(
                        "source_season_id"
                    ),
                )
            )

        except Exception:
            continue

        _rows = _conn.execute(
            """
            SELECT league_id
            FROM leagues
            WHERE source_tournament_id = ?
              AND source_season_id = ?
            ORDER BY league_id
            """,
            (
                _tid,
                _season,
            ),
        ).fetchall()

        for _row in _rows:
            try:
                _value = int(
                    _row["league_id"]
                )
            except Exception:
                try:
                    _value = int(
                        _row[0]
                    )
                except Exception:
                    continue

            _ids.add(
                _value
            )

    return sorted(
        _ids
    )


def _oh_premier_spec_v1():
    import json as _json
    from pathlib import Path as _Path

    _path = (
        _Path(__file__).resolve().parent
        / "data"
        / "competitions.json"
    )

    try:
        _doc = _json.loads(
            _path.read_text(
                encoding="utf-8-sig"
            )
        )
    except Exception:
        return None

    for _item in (
        _doc.get(
            "competitions"
        )
        or []
    ):
        if (
            isinstance(
                _item,
                dict,
            )
            and str(
                _item.get("key")
                or ""
            ).strip().lower()
            == "premier-league"
        ):
            return _item

    return None


def _oh_premier_profile_pairs_v1(
    _spec,
    _sid,
):
    _rows = []

    for _item in (
        _spec.get(
            "profile_history_source_pairs"
        )
        or []
    ):
        if not isinstance(
            _item,
            dict,
        ):
            continue

        try:
            _teams = {
                int(_x)
                for _x in (
                    _item.get(
                        "team_sofascore_ids"
                    )
                    or []
                )
            }
        except Exception:
            continue

        if int(
            _sid
        ) in _teams:
            _rows.append(
                _item
            )

    return _rows


def _oh_premier_shots_prediction_v1(
    match,
    competition_key,
):
    import sqlite3 as _sqlite3
    from pathlib import Path as _Path

    from shots_engine import (
        DEFAULT_RECENT_WEIGHT_SHOTS as _RW_SHOTS,
        DEFAULT_RECENT_WEIGHT_SOT as _RW_SOT,
        team_profile_sqlite as _team_profile,
        league_shot_means_before as _league_means,
        shrink_to_baseline as _shrink,
        blend_attack_allowed as _blend,
    )

    if (
        str(
            competition_key
            or ""
        ).strip().lower()
        != "premier-league"
    ):
        return None

    _home_sid = (
        _oh_premier_shots_source_id_v1(
            match,
            "home",
        )
    )

    _away_sid = (
        _oh_premier_shots_source_id_v1(
            match,
            "away",
        )
    )

    if (
        _home_sid is None
        or _away_sid is None
    ):
        return None

    _spec = (
        _oh_premier_spec_v1()
    )

    if not isinstance(
        _spec,
        dict,
    ):
        return None

    _root = (
        _Path(__file__).resolve().parent
    )

    _db = (
        _root
        / "data"
        / "oddshunter.db"
    )

    if not _db.exists():
        return None

    _con = _sqlite3.connect(
        _db
    )

    _con.row_factory = (
        _sqlite3.Row
    )

    try:
        _primary_pairs = list(
            _spec.get(
                "history_source_pairs"
            )
            or []
        )

        # Garantiza que la temporada actual también
        # forma parte del scope primario.
        try:
            _primary_pairs.append(
                {
                    "tournament_id": int(
                        _spec.get(
                            "source_competition_id"
                        )
                        or _spec.get(
                            "tournament_id"
                        )
                    ),
                    "season_id": int(
                        _spec.get(
                            "season_id"
                        )
                    ),
                }
            )
        except Exception:
            pass

        _primary_ids = (
            _oh_premier_pair_ids_v1(
                _con,
                _primary_pairs,
            )
        )

        if not _primary_ids:
            return None

        _promoted = set()

        for _item in (
            _spec.get(
                "profile_history_source_pairs"
            )
            or []
        ):
            if not isinstance(
                _item,
                dict,
            ):
                continue

            for _value in (
                _item.get(
                    "team_sofascore_ids"
                )
                or []
            ):
                try:
                    _promoted.add(
                        int(_value)
                    )
                except Exception:
                    pass

        if (
            _home_sid
            in _promoted
        ):
            _home_ids = (
                _oh_premier_pair_ids_v1(
                    _con,
                    _oh_premier_profile_pairs_v1(
                        _spec,
                        _home_sid,
                    ),
                )
            )
        else:
            _home_ids = list(
                _primary_ids
            )

        if (
            _away_sid
            in _promoted
        ):
            _away_ids = (
                _oh_premier_pair_ids_v1(
                    _con,
                    _oh_premier_profile_pairs_v1(
                        _spec,
                        _away_sid,
                    ),
                )
            )
        else:
            _away_ids = list(
                _primary_ids
            )

        if (
            not _home_ids
            or not _away_ids
        ):
            return None

        _kickoff = (
            str(
                match.get(
                    "kickoff"
                )
                or ""
            )
            or None
        )

        _home = _team_profile(
            _con,
            int(
                _home_sid
            ),
            "HOME",
            list(
                _home_ids
            ),
            _kickoff,
            float(
                _RW_SHOTS
            ),
            float(
                _RW_SOT
            ),
        )

        _away = _team_profile(
            _con,
            int(
                _away_sid
            ),
            "AWAY",
            list(
                _away_ids
            ),
            _kickoff,
            float(
                _RW_SHOTS
            ),
            float(
                _RW_SOT
            ),
        )

        # La media de contracción permanece Premier;
        # Championship solo alimenta el perfil del ascendido.
        _means = _league_means(
            _con,
            list(
                _primary_ids
            ),
            _kickoff,
        )

    finally:
        _con.close()

    _hm = int(
        _home.get(
            "matches"
        )
        or 0
    )

    _am = int(
        _away.get(
            "matches"
        )
        or 0
    )

    _hs = _blend(
        _shrink(
            _home.get(
                "shots_for"
            ),
            _means.get(
                "home_shots"
            ),
            _hm,
        ),
        _shrink(
            _away.get(
                "shots_allowed"
            ),
            _means.get(
                "home_shots"
            ),
            _am,
        ),
    )

    _aws = _blend(
        _shrink(
            _away.get(
                "shots_for"
            ),
            _means.get(
                "away_shots"
            ),
            _am,
        ),
        _shrink(
            _home.get(
                "shots_allowed"
            ),
            _means.get(
                "away_shots"
            ),
            _hm,
        ),
    )

    _hst = _blend(
        _shrink(
            _home.get(
                "target_for"
            ),
            _means.get(
                "home_targets"
            ),
            _hm,
        ),
        _shrink(
            _away.get(
                "target_allowed"
            ),
            _means.get(
                "home_targets"
            ),
            _am,
        ),
    )

    _awst = _blend(
        _shrink(
            _away.get(
                "target_for"
            ),
            _means.get(
                "away_targets"
            ),
            _am,
        ),
        _shrink(
            _home.get(
                "target_allowed"
            ),
            _means.get(
                "away_targets"
            ),
            _hm,
        ),
    )

    if any(
        _x is None
        for _x in (
            _hs,
            _aws,
            _hst,
            _awst,
        )
    ):
        return None

    global _PREMIER_SHOTS_HOME_IDS_V1
    global _PREMIER_SHOTS_AWAY_IDS_V1
    global _PREMIER_SHOTS_MEANS_IDS_V1

    _PREMIER_SHOTS_HOME_IDS_V1 = sorted(
        _home_ids
    )

    _PREMIER_SHOTS_AWAY_IDS_V1 = sorted(
        _away_ids
    )

    _PREMIER_SHOTS_MEANS_IDS_V1 = sorted(
        _primary_ids
    )

    print(
        "[PREMIER_SHOTS_SCOPE] "
        f"home_sid={int(_home_sid)} "
        f"home_league_ids={sorted(_home_ids)} "
        f"away_sid={int(_away_sid)} "
        f"away_league_ids={sorted(_away_ids)} "
        f"means_league_ids={sorted(_primary_ids)}"
    )

    return (
        float(_hs),
        float(_aws),
        float(_hst),
        float(_awst),
    )


def database_prediction(
    match,
    competition_key,
):
    global _PREMIER_SHOTS_SCOPE_USED_V1

    if (
        str(
            competition_key
            or ""
        ).strip().lower()
        == "premier-league"
    ):
        _result = (
            _oh_premier_shots_prediction_v1(
                match,
                competition_key,
            )
        )

        if (
            isinstance(
                _result,
                (tuple, list),
            )
            and len(
                _result
            ) == 4
            and all(
                _x is not None
                for _x in _result
            )
        ):
            _PREMIER_SHOTS_SCOPE_USED_V1 = True
            return tuple(
                _result
            )

    return (
        _oh_database_prediction_before_premier_shots_v1(
            match,
            competition_key,
        )
    )


def write_json(
    path,
    data,
):
    if (
        globals().get(
            "_PREMIER_SHOTS_SCOPE_USED_V1"
        )
        and isinstance(
            data,
            dict,
        )
        and isinstance(
            data.get(
                "model"
            ),
            dict,
        )
    ):
        data = dict(
            data
        )

        data[
            "model"
        ] = dict(
            data[
                "model"
            ]
        )

        data[
            "model"
        ][
            "source"
        ] = (
            "sqlite_premier_registry_history_scope_bayesian"
        )

        data[
            "model"
        ][
            "scope"
        ] = (
            "premier_history_plus_promoted_profile"
        )

        data[
            "model"
        ][
            "history_scope"
        ] = {
            "home_league_ids": list(
                globals().get(
                    "_PREMIER_SHOTS_HOME_IDS_V1"
                )
                or []
            ),
            "away_league_ids": list(
                globals().get(
                    "_PREMIER_SHOTS_AWAY_IDS_V1"
                )
                or []
            ),
            "means_league_ids": list(
                globals().get(
                    "_PREMIER_SHOTS_MEANS_IDS_V1"
                )
                or []
            ),
        }

    return (
        _oh_write_json_before_premier_shots_v1(
            path,
            data,
        )
    )


# =============================================================================
# FIN ODDSHUNTER_PREMIER_SHOTS_RUNTIME_SCOPE_V1
# =============================================================================

def main() -> int:
    parser = argparse.ArgumentParser(description="Modelo local de remates esperados por equipo.")
    parser.add_argument("--key", required=True)
    parser.add_argument("--match-json", required=True)
    args = parser.parse_args()

    ratings_path = Path(args.match_json).resolve()
    ratings = read_json(ratings_path)
    match = ratings.get("upcoming_match") or ratings.get("match") or ratings.get("fixture")
    if not isinstance(match, dict):
        raise ValueError("ratings.json no contiene upcoming_match/match.")
    event_id = int(match.get("event_id") or match.get("id") or 0)
    if event_id <= 0:
        raise ValueError("No se encontró event_id en ratings.json.")

    bot10_context = ratings.get("bot10_context")
    bot10_markets = (
        bot10_context.get("markets")
        if isinstance(bot10_context, dict)
        else {}
    ) or {}
    context_shots = bot10_markets.get("shots") or {}
    context_targets = bot10_markets.get("shots_on_target") or {}
    shots_home = context_shots.get("home")
    shots_away = context_shots.get("away")
    target_home = context_targets.get("home")
    target_away = context_targets.get("away")
    if shots_home is not None and shots_away is not None:
        shots_home = float(shots_home)
        shots_away = float(shots_away)
        target_home = None if target_home is None else float(target_home)
        target_away = None if target_away is None else float(target_away)
        source = "bot10_separate_uefa_domestic_context"
    else:
        shots_home, shots_away, target_home, target_away = database_prediction(
            match,
            slugify(args.key),
        )
        source = ("sqlite_registry_history_scope_bayesian" if globals().get("_HISTORY_SCOPE_USED_V921") else "sqlite_current_competition_bayesian")

    if shots_home is None or shots_away is None:
        raise RuntimeError("No hay suficientes remates históricos para ambos equipos.")

    key = slugify(args.key)
    output = {
        "generated_at": utc_now(),
        "competition_key": key,
        "event_id": event_id,
        "upcoming_match": match,
        "model": {
            "name": "recent_venue_shots",
            "source": source,
            "core": "shots_engine.py",
            "window": 15,
            "recent_weight": DEFAULT_RECENT_WEIGHT_SHOTS,
            "shots_recent_share_at_15": recent_weight_to_share(
                DEFAULT_RECENT_WEIGHT_SHOTS
            ),
            "shots_recent_weight": DEFAULT_RECENT_WEIGHT_SHOTS,
            "sot_recent_share_at_15": recent_weight_to_share(
                DEFAULT_RECENT_WEIGHT_SOT
            ),
            "sot_recent_weight": DEFAULT_RECENT_WEIGHT_SOT,
            "sample_prior_matches": 5,
            "scope": ("registry_history_source_pairs" if globals().get("_HISTORY_SCOPE_USED_V921") else "same_competition_current_season"),
            "context": context_shots if source.startswith("bot10_") else None,
            "confidence": context_shots.get("confidence"),
            "fallback_level": (
                (context_shots.get("home_context") or {}).get("fallback_level")
                if source.startswith("bot10_")
                else None
            ),
        },
        "analysis": {
            "shots": {
                "home_team": {"name": match.get("home_team"), "expected_count": round(shots_home, 3)},
                "away_team": {"name": match.get("away_team"), "expected_count": round(shots_away, 3)},
                "expected_total": round(shots_home + shots_away, 3),
            },
            "shots_on_target": {
                "home_team": {"name": match.get("home_team"), "expected_count": None if target_home is None else round(target_home, 3)},
                "away_team": {"name": match.get("away_team"), "expected_count": None if target_away is None else round(target_away, 3)},
                "expected_total": None if target_home is None or target_away is None else round(target_home + target_away, 3),
            },
        },
    }
    destination = OUTPUT_ROOT / key / f"shots_{event_id}.json"
    write_json(destination, output)
    write_json(OUTPUT_ROOT / key / "ultimo_shots.json", output)

    print("=" * 76)
    print("ODDSHUNTER — MODELO DE REMATES")
    print("=" * 76)
    print(f"{match.get('home_team')} vs {match.get('away_team')}")
    print(f"Remates esperados: {shots_home:.2f} - {shots_away:.2f}")
    if target_home is not None and target_away is not None:
        print(f"Remates al arco esperados: {target_home:.2f} - {target_away:.2f}")
    print(f"Fuente: {source}")
    print(f"Resultado guardado en: {destination}")
    return 0




# ==============================================================================
# ODDSHUNTER_LALIGA_SHOTS_CURRENT_PLUS_PROFILE_V1
# ==============================================================================

_OH_LALIGA_SHOTS_ORIGINAL_DATABASE_PREDICTION_V1 = database_prediction
_OH_LALIGA_SHOTS_ORIGINAL_WRITE_JSON_V1 = write_json

_OH_LALIGA_SHOTS_SCOPE_USED_V1 = False
_OH_LALIGA_SHOTS_HISTORY_SCOPE_V1 = None


def _oh_laliga_shots_source_id_v1(
    _match,
    _side,
):
    try:
        import shots_engine as _engine

        _value = _engine.source_team_id(
            _match,
            _side,
        )

        if _value is not None:
            return int(_value)

    except Exception:
        pass

    for _key in (
        f"{_side}_team_id",
        f"{_side}_source_team_id",
        f"{_side}_sofascore_id",
        f"{_side}_team_source_id",
    ):

        try:
            _value = int(
                _match.get(
                    _key
                )
                or 0
            )
        except Exception:
            continue

        if _value > 0:
            return _value

    return None


def _oh_laliga_shots_prediction_v1(
    _match,
    _competition_key,
):
    import json as _json
    import sqlite3 as _sqlite3
    from pathlib import Path as _Path

    import shots_engine as _engine

    global _OH_LALIGA_SHOTS_HISTORY_SCOPE_V1

    if str(
        _competition_key
        or ""
    ).strip().lower() != "laliga":

        return None


    _home_sid = (
        _oh_laliga_shots_source_id_v1(
            _match,
            "home",
        )
    )

    _away_sid = (
        _oh_laliga_shots_source_id_v1(
            _match,
            "away",
        )
    )


    if (
        _home_sid is None
        or _away_sid is None
    ):
        return None


    _root = (
        _Path(__file__).resolve().parent
    )

    _db = (
        _root
        / "data"
        / "oddshunter.db"
    )

    _registry_path = (
        _root
        / "data"
        / "competitions.json"
    )


    if (
        not _db.exists()
        or not _registry_path.exists()
    ):
        return None


    try:
        _registry = _json.loads(
            _registry_path.read_text(
                encoding="utf-8-sig"
            )
        )
    except Exception:
        return None


    _spec = None

    for _item in (
        _registry.get(
            "competitions"
        )
        or []
    ):

        if not isinstance(
            _item,
            dict,
        ):
            continue

        if str(
            _item.get(
                "key"
            )
            or ""
        ).strip().lower() == "laliga":

            _spec = _item
            break


    if not isinstance(
        _spec,
        dict,
    ):
        return None


    _con = _sqlite3.connect(
        _db
    )

    _con.row_factory = (
        _sqlite3.Row
    )


    def _pairs_to_ids(
        _pairs,
    ):
        _ids = set()

        for _pair in (
            _pairs
            or []
        ):

            if not isinstance(
                _pair,
                dict,
            ):
                continue

            try:
                _tid = int(
                    _pair.get(
                        "tournament_id"
                    )
                    or 0
                )

                _season = int(
                    _pair.get(
                        "season_id"
                    )
                    or 0
                )

            except Exception:
                continue

            if (
                _tid <= 0
                or _season <= 0
            ):
                continue

            _rows = _con.execute(
                """
                SELECT league_id
                FROM leagues
                WHERE source_tournament_id=?
                  AND source_season_id=?
                ORDER BY league_id
                """,
                (
                    _tid,
                    _season,
                ),
            ).fetchall()

            for _row in _rows:

                try:
                    _lid = int(
                        _row[
                            "league_id"
                        ]
                    )

                except Exception:

                    try:
                        _lid = int(
                            _row[0]
                        )
                    except Exception:
                        continue

                _ids.add(
                    _lid
                )

        return sorted(
            _ids
        )


    def _profile_pairs_for(
        _sid,
    ):
        _rows = []

        for _pair in (
            _spec.get(
                "profile_history_source_pairs"
            )
            or []
        ):

            if not isinstance(
                _pair,
                dict,
            ):
                continue

            _teams = (
                _pair.get(
                    "team_sofascore_ids"
                )
            )

            if not isinstance(
                _teams,
                list,
            ):
                continue

            try:
                _teams = {
                    int(_value)
                    for _value in _teams
                }
            except Exception:
                continue

            if int(
                _sid
            ) in _teams:

                _rows.append(
                    _pair
                )

        return _rows


    try:

        _history_pairs = (
            _spec.get(
                "history_source_pairs"
            )
            or []
        )


        _primary_ids = (
            _pairs_to_ids(
                _history_pairs
            )
        )


        _current_pairs = [
            _pair
            for _pair in _history_pairs
            if isinstance(
                _pair,
                dict,
            )
            and str(
                _pair.get(
                    "role"
                )
                or ""
            ).strip().upper()
            == "CURRENT"
        ]


        if not _current_pairs:

            try:
                _tid = int(
                    _spec.get(
                        "source_competition_id"
                    )
                    or _spec.get(
                        "tournament_id"
                    )
                    or 0
                )

                _season = int(
                    _spec.get(
                        "season_id"
                    )
                    or 0
                )

            except Exception:
                _tid = 0
                _season = 0


            if (
                _tid > 0
                and _season > 0
            ):

                _current_pairs = [
                    {
                        "tournament_id":
                            _tid,

                        "season_id":
                            _season,

                        "role":
                            "CURRENT",
                    }
                ]


        _current_ids = (
            _pairs_to_ids(
                _current_pairs
            )
        )


        _home_profile_ids = (
            _pairs_to_ids(
                _profile_pairs_for(
                    _home_sid
                )
            )
        )


        _away_profile_ids = (
            _pairs_to_ids(
                _profile_pairs_for(
                    _away_sid
                )
            )
        )


        # Si ninguno es profile-only,
        # conservar el runtime original.
        if (
            not _home_profile_ids
            and not _away_profile_ids
        ):
            return None


        if not _primary_ids:
            return None


        if not _current_ids:
            return None


        _home_ids = (
            sorted(
                set(
                    _current_ids
                    + _home_profile_ids
                )
            )
            if _home_profile_ids
            else list(
                _primary_ids
            )
        )


        _away_ids = (
            sorted(
                set(
                    _current_ids
                    + _away_profile_ids
                )
            )
            if _away_profile_ids
            else list(
                _primary_ids
            )
        )


        _cutoff = (
            str(
                _match.get(
                    "kickoff"
                )
                or ""
            )
            or None
        )


        _shots_weight = (
            _engine.DEFAULT_RECENT_WEIGHT_SHOTS
        )

        _sot_weight = (
            _engine.DEFAULT_RECENT_WEIGHT_SOT
        )


        _home = (
            _engine.team_profile_sqlite(
                _con,
                int(
                    _home_sid
                ),
                "HOME",
                list(
                    _home_ids
                ),
                _cutoff,
                _shots_weight,
                _sot_weight,
            )
        )


        _away = (
            _engine.team_profile_sqlite(
                _con,
                int(
                    _away_sid
                ),
                "AWAY",
                list(
                    _away_ids
                ),
                _cutoff,
                _shots_weight,
                _sot_weight,
            )
        )


        # Las medias/prior siguen siendo
        # exclusivamente del scope primario
        # de LaLiga, nunca de LaLiga2.
        _means = (
            _engine.league_shot_means_before(
                _con,
                list(
                    _primary_ids
                ),
                _cutoff,
            )
        )


        _home_matches = int(
            _home.get(
                "matches"
            )
            or 0
        )

        _away_matches = int(
            _away.get(
                "matches"
            )
            or 0
        )


        _hs = (
            _engine.blend_attack_allowed(
                _engine.shrink_to_baseline(
                    _home[
                        "shots_for"
                    ],
                    _means.get(
                        "home_shots"
                    ),
                    _home_matches,
                ),
                _engine.shrink_to_baseline(
                    _away[
                        "shots_allowed"
                    ],
                    _means.get(
                        "home_shots"
                    ),
                    _away_matches,
                ),
            )
        )


        _aws = (
            _engine.blend_attack_allowed(
                _engine.shrink_to_baseline(
                    _away[
                        "shots_for"
                    ],
                    _means.get(
                        "away_shots"
                    ),
                    _away_matches,
                ),
                _engine.shrink_to_baseline(
                    _home[
                        "shots_allowed"
                    ],
                    _means.get(
                        "away_shots"
                    ),
                    _home_matches,
                ),
            )
        )


        _hst = (
            _engine.blend_attack_allowed(
                _engine.shrink_to_baseline(
                    _home[
                        "target_for"
                    ],
                    _means.get(
                        "home_targets"
                    ),
                    _home_matches,
                ),
                _engine.shrink_to_baseline(
                    _away[
                        "target_allowed"
                    ],
                    _means.get(
                        "home_targets"
                    ),
                    _away_matches,
                ),
            )
        )


        _awst = (
            _engine.blend_attack_allowed(
                _engine.shrink_to_baseline(
                    _away[
                        "target_for"
                    ],
                    _means.get(
                        "away_targets"
                    ),
                    _away_matches,
                ),
                _engine.shrink_to_baseline(
                    _home[
                        "target_allowed"
                    ],
                    _means.get(
                        "away_targets"
                    ),
                    _home_matches,
                ),
            )
        )


        _result = (
            _hs,
            _aws,
            _hst,
            _awst,
        )


        if any(
            _value is None
            for _value in _result
        ):
            return None


        _OH_LALIGA_SHOTS_HISTORY_SCOPE_V1 = {
            "home_sid":
                int(
                    _home_sid
                ),

            "home_league_ids":
                list(
                    _home_ids
                ),

            "home_matches":
                _home_matches,

            "away_sid":
                int(
                    _away_sid
                ),

            "away_league_ids":
                list(
                    _away_ids
                ),

            "away_matches":
                _away_matches,

            "means_league_ids":
                list(
                    _primary_ids
                ),

            "current_league_ids":
                list(
                    _current_ids
                ),

            "home_profile_league_ids":
                list(
                    _home_profile_ids
                ),

            "away_profile_league_ids":
                list(
                    _away_profile_ids
                ),
        }


        print(
            "[LALIGA_SHOTS_SCOPE] "
            f"home_sid={int(_home_sid)} "
            f"home_league_ids={list(_home_ids)} "
            f"away_sid={int(_away_sid)} "
            f"away_league_ids={list(_away_ids)} "
            f"means_league_ids={list(_primary_ids)}"
        )


        return tuple(
            float(_value)
            for _value in _result
        )


    finally:
        _con.close()


def database_prediction(
    match,
    competition_key,
):
    global _OH_LALIGA_SHOTS_SCOPE_USED_V1
    global _OH_LALIGA_SHOTS_HISTORY_SCOPE_V1

    _OH_LALIGA_SHOTS_SCOPE_USED_V1 = False
    _OH_LALIGA_SHOTS_HISTORY_SCOPE_V1 = None


    if str(
        competition_key
        or ""
    ).strip().lower() == "laliga":

        _result = (
            _oh_laliga_shots_prediction_v1(
                match,
                competition_key,
            )
        )


        if (
            isinstance(
                _result,
                (
                    tuple,
                    list,
                ),
            )
            and len(
                _result
            ) == 4
            and all(
                _value is not None
                for _value in _result
            )
        ):

            _OH_LALIGA_SHOTS_SCOPE_USED_V1 = True

            return tuple(
                _result
            )


    return (
        _OH_LALIGA_SHOTS_ORIGINAL_DATABASE_PREDICTION_V1(
            match,
            competition_key,
        )
    )


def write_json(
    path,
    data,
):
    if (
        _OH_LALIGA_SHOTS_SCOPE_USED_V1
        and isinstance(
            _OH_LALIGA_SHOTS_HISTORY_SCOPE_V1,
            dict,
        )
        and isinstance(
            data,
            dict,
        )
        and isinstance(
            data.get(
                "model"
            ),
            dict,
        )
    ):

        data = dict(
            data
        )

        data[
            "model"
        ] = dict(
            data[
                "model"
            ]
        )

        data[
            "model"
        ][
            "source"
        ] = (
            "sqlite_profile_history_scope_bayesian"
        )

        data[
            "model"
        ][
            "scope"
        ] = (
            "profile_history_source_pairs_mixed"
        )

        data[
            "model"
        ][
            "history_scope"
        ] = dict(
            _OH_LALIGA_SHOTS_HISTORY_SCOPE_V1
        )


    return (
        _OH_LALIGA_SHOTS_ORIGINAL_WRITE_JSON_V1(
            path,
            data,
        )
    )


# ==============================================================================
# FIN ODDSHUNTER_LALIGA_SHOTS_CURRENT_PLUS_PROFILE_V1
# ==============================================================================

if __name__ == "__main__":
    raise SystemExit(main())
