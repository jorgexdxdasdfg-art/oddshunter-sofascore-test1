from __future__ import annotations

import argparse
import json
import math
import re
import sqlite3
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

import numpy as np
from scipy.stats import nbinom, poisson

from trained_model_loader import (
    component_parameters,
    load_latest_model,
    model_metadata,
    numeric_parameter,
)


# ==============================================================================
# 1. RUTAS Y CONFIGURACIÓN
# ==============================================================================

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "oddshunter.db"
REGISTRY_PATH = DATA_DIR / "competitions.json"
DEFAULT_RATINGS_PATH = DATA_DIR / "ratings" / "ultimo_ratings.json"
HISTORY_DIR = DATA_DIR / "historiales"
OUTPUT_ROOT_DIR = DATA_DIR / "modelos" / "corners"

MATCHES_WINDOW = 15
RECENT_MATCHES = 5
RECENT_WEIGHT = 1.0769230769230769
OLD_WEIGHT = 1.0

MIN_RELEVANT_MATCHES = 3
MAX_TEAM_CORNERS = 20
MAX_TOTAL_CORNERS = 35

# Umbrales descriptivos del total de córners.
TOTAL_THRESHOLDS = tuple(range(6, 13))

OUTPUT_ROOT_DIR.mkdir(parents=True, exist_ok=True)


# ==============================================================================
# 2. UTILIDADES
# ==============================================================================

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def slugify(text: str) -> str:
    value = text.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-")


def read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"No se encontró:\n{path}")

    with path.open("r", encoding="utf-8") as file:
        data = json.load(file)

    if not isinstance(data, dict):
        raise ValueError(f"{path.name} no contiene un objeto JSON válido.")

    return data


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    path.write_text(
        json.dumps(
            data,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )


def numeric(value: Any) -> float | None:
    if value is None:
        return None

    try:
        result = float(value)
    except (TypeError, ValueError):
        return None

    if not math.isfinite(result):
        return None

    return result


def weighted_mean(
    rows: Iterable[dict[str, Any]],
    field: str,
) -> float | None:
    numerator = 0.0
    denominator = 0.0

    for row in rows:
        value = numeric(row.get(field))

        if value is None:
            continue

        weight = float(row["weight"])
        numerator += value * weight
        denominator += weight

    if denominator == 0:
        return None

    return numerator / denominator


def geometric_mean(
    first: float | None,
    second: float | None,
) -> float | None:
    if first is None or second is None:
        return None

    if first < 0 or second < 0:
        return None

    return math.sqrt(first * second)


def iso_from_timestamp(value: Any) -> str | None:
    try:
        timestamp = int(value)
    except (TypeError, ValueError):
        return None

    if timestamp <= 0:
        return None

    return datetime.fromtimestamp(
        timestamp,
        tz=timezone.utc,
    ).isoformat()


# ==============================================================================
# 3. COMPETICIÓN Y PRÓXIMO PARTIDO
# ==============================================================================

def load_registry() -> dict[str, Any]:
    registry = read_json(REGISTRY_PATH)

    if not isinstance(registry.get("competitions"), list):
        raise ValueError(
            "competitions.json no contiene una lista 'competitions'."
        )

    return registry


def find_competition(
    registry: dict[str, Any],
    key: str,
) -> dict[str, Any]:
    normalized = slugify(key)

    for competition in registry["competitions"]:
        current = slugify(str(competition.get("key", "")))

        if current == normalized:
            return competition

    raise ValueError(f"No existe la competición '{key}'.")


def latest_upcoming_match_file() -> Path:
    if DEFAULT_RATINGS_PATH.exists():
        return DEFAULT_RATINGS_PATH

    candidates = sorted(
        HISTORY_DIR.glob("proximo_partido_*.json"),
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )

    if candidates:
        return candidates[0]

    raise FileNotFoundError(
        "No se encontró ultimo_ratings.json ni un "
        "proximo_partido_*.json."
    )


def load_upcoming_match(path: Path) -> dict[str, Any]:
    data = read_json(path)

    event = data.get("upcoming_match")

    if not isinstance(event, dict):
        event = data.get("evento")

    if not isinstance(event, dict):
        raise ValueError(
            f"{path.name} no contiene 'upcoming_match' ni 'evento'."
        )

    required = (
        "event_id",
        "home_team_id",
        "home_team",
        "away_team_id",
        "away_team",
    )

    missing = [
        field
        for field in required
        if event.get(field) is None
    ]

    if missing:
        raise ValueError(
            "Faltan campos del próximo partido: "
            + ", ".join(missing)
        )

    normalized = dict(event)

    if not normalized.get("kickoff"):
        normalized["kickoff"] = iso_from_timestamp(
            normalized.get("start_timestamp")
        )

    return normalized


# ==============================================================================
# 4. SQLITE
# ==============================================================================

def get_connection() -> sqlite3.Connection:
    if not DB_PATH.exists():
        raise FileNotFoundError(
            f"No se encontró la base de datos:\n{DB_PATH}"
        )

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def validate_schema(conn: sqlite3.Connection) -> None:
    tables = {
        row["name"]
        for row in conn.execute(
            """
            SELECT name
            FROM sqlite_master
            WHERE type = 'table';
            """
        ).fetchall()
    }

    required = {
        "leagues",
        "teams",
        "matches",
        "team_match_stats",
    }

    missing = required - tables

    if missing:
        raise RuntimeError(
            "Faltan tablas: "
            + ", ".join(sorted(missing))
        )


def normalize_league_text(value: Any) -> str:
    text = str(value or "").strip().lower()
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return " ".join(text.split())


def resolve_league(
    conn: sqlite3.Connection,
    competition: dict[str, Any],
) -> dict[str, Any]:
    name = str(competition.get("name") or "").strip()
    season = str(competition.get("season_name") or "").strip()
    country = str(competition.get("country") or "").strip()

    rows = conn.execute(
        """
        SELECT
            league_id,
            name,
            country,
            season
        FROM leagues
        ORDER BY league_id DESC;
        """
    ).fetchall()

    if not rows:
        raise RuntimeError("La tabla leagues está vacía.")

    target_name = normalize_league_text(name)
    target_season = normalize_league_text(season)
    target_country = normalize_league_text(country)

    scored: list[tuple[float, sqlite3.Row]] = []

    for row in rows:
        row_name = normalize_league_text(row["name"])
        row_season = normalize_league_text(row["season"])
        row_country = normalize_league_text(row["country"])

        score = 0.0

        if target_name and row_name == target_name:
            score += 120.0
        elif target_name and (
            target_name in row_name
            or row_name in target_name
        ):
            score += 55.0

        if target_season and row_season == target_season:
            score += 120.0
        elif target_season and (
            target_season in row_season
            or row_season in target_season
        ):
            score += 55.0

        if target_country and row_country == target_country:
            score += 20.0

        for phase in ("apertura", "clausura"):
            target_has = (
                phase in target_name
                or phase in target_season
            )
            row_has = (
                phase in row_name
                or phase in row_season
            )

            if target_has and row_has:
                score += 80.0
            elif target_has and not row_has:
                score -= 40.0

        scored.append((score, row))

    scored.sort(
        key=lambda item: (
            item[0],
            int(item[1]["league_id"]),
        ),
        reverse=True,
    )

    best_score, row = scored[0]

    if best_score < 40.0:
        raise RuntimeError(
            f"No se encontró la competición '{name}' en SQLite."
        )

    return {
        "league_id": int(row["league_id"]),
        "name": str(row["name"]),
        "country": str(row["country"] or ""),
        "season": str(row["season"] or ""),
        "key": slugify(str(competition["key"])),
    }


def resolve_source_league_ids(
    conn: sqlite3.Connection,
    registry_competition: dict[str, Any],
    trained_model: dict[str, Any] | None,
    primary_league_id: int,
) -> list[int]:
    # Compatibilidad de alcance histórico.
    # El entrenador estándar actual guarda league_ids e history_source_pairs.
    # Modelos agrupados/legacy pueden guardar source_league_ids.
    # El fallback productivo no puede depender de que exista latest_model.json:
    # el alcance histórico autorizado vive en el registry y también debe
    # resolverse para una competición que aún no tiene modelo promovido.
    ids: list[int] = []

    def add_id(value: Any) -> None:
        try:
            league_id = int(value)
        except (TypeError, ValueError):
            return
        if league_id not in ids:
            ids.append(league_id)

    if isinstance(trained_model, dict):
        competition = trained_model.get("competition")

        if isinstance(competition, dict):
            raw_ids = competition.get("league_ids")
            if isinstance(raw_ids, (list, tuple, set)):
                for value in raw_ids:
                    add_id(value)

            raw_source_ids = competition.get("source_league_ids")
            if isinstance(raw_source_ids, (list, tuple, set)):
                for value in raw_source_ids:
                    add_id(value)

            history_pairs = competition.get("history_source_pairs")
            if isinstance(history_pairs, list):
                for item in history_pairs:
                    if isinstance(item, dict):
                        add_id(item.get("league_id"))

    def add_pair(tournament_id: Any, season_id: Any) -> None:
        try:
            tid = int(tournament_id)
            sid = int(season_id)
        except (TypeError, ValueError):
            return
        rows = conn.execute(
            """
            SELECT league_id
            FROM leagues
            WHERE source_tournament_id = ?
              AND source_season_id = ?
            ORDER BY league_id
            """,
            (tid, sid),
        ).fetchall()
        for row in rows:
            add_id(row["league_id"])

    # El registro es la fuente autoritativa del alcance histórico para todas
    # las competiciones. Limitarlo a Bundesliga/Premier dejaba a las ligas que
    # acababan de iniciar únicamente con su temporada actual (sin finalizados),
    # aunque sus temporadas anteriores ya estaban cargadas en SQLite.
    add_pair(
        registry_competition.get("source_competition_id"),
        registry_competition.get("season_id"),
    )
    for item in registry_competition.get("history_source_pairs") or []:
        if isinstance(item, dict):
            add_pair(item.get("tournament_id"), item.get("season_id"))

    add_id(primary_league_id)
    return sorted(ids)


def resolve_team(
    conn: sqlite3.Connection,
    sofascore_id: int,
    league_id: int,
) -> dict[str, Any]:
    row = conn.execute(
        """
        SELECT
            team_id,
            sofascore_id,
            name,
            league_id
        FROM teams
        WHERE
            sofascore_id = ?
            AND league_id = ?
        LIMIT 1;
        """,
        (sofascore_id, league_id),
    ).fetchone()

    if row is None:
        row = conn.execute(
            """
            SELECT
                team_id,
                sofascore_id,
                name,
                league_id
            FROM teams
            WHERE sofascore_id = ?
            ORDER BY team_id DESC
            LIMIT 1;
            """,
            (sofascore_id,),
        ).fetchone()

    if row is None:
        raise RuntimeError(
            f"No se encontró el equipo sofascore_id={sofascore_id}."
        )

    return dict(row)


def load_team_history(
    conn: sqlite3.Connection,
    league_ids: list[int],
    sofascore_id: int,
    before_kickoff: str | None,
    recent_weight: float,
    limit: int = MATCHES_WINDOW,
) -> list[dict[str, Any]]:
    if not league_ids:
        return []

    placeholders = ",".join("?" for _ in league_ids)

    filters = [
        f"m.league_id IN ({placeholders})",
        "analysed_team.sofascore_id = ?",
        "UPPER(COALESCE(m.status, '')) IN ('FT','FINISHED')",
        "s.corners_for IS NOT NULL",
        "s.corners_against IS NOT NULL",
    ]

    params: list[Any] = [
        *league_ids,
        sofascore_id,
    ]

    if before_kickoff:
        filters.append("m.kickoff < ?")
        params.append(before_kickoff)

    params.append(limit)

    rows = conn.execute(
        f"""
        SELECT
            s.match_id,
            s.team_id,
            s.venue,
            s.corners_for,
            s.corners_against,
            s.data_quality,
            m.sofascore_id AS event_id,
            m.kickoff,
            home.name AS home_team,
            away.name AS away_team,
            m.league_id AS source_league_id
        FROM team_match_stats AS s
        INNER JOIN teams AS analysed_team
            ON analysed_team.team_id = s.team_id
        INNER JOIN matches AS m
            ON m.match_id = s.match_id
        INNER JOIN teams AS home
            ON home.team_id = m.home_team_id
        INNER JOIN teams AS away
            ON away.team_id = m.away_team_id
        WHERE {" AND ".join(filters)}
        ORDER BY
            m.kickoff DESC,
            m.match_id DESC
        LIMIT ?;
        """,
        tuple(params),
    ).fetchall()

    history = [dict(row) for row in rows]

    for index, row in enumerate(history):
        row["recency_order"] = index + 1
        row["weight"] = (
            recent_weight
            if index < RECENT_MATCHES
            else OLD_WEIGHT
        )
        row["total_corners"] = (
            float(row["corners_for"])
            + float(row["corners_against"])
        )

    return history


def load_league_corner_means(
    conn: sqlite3.Connection,
    league_ids: list[int],
    before_kickoff: str | None,
) -> dict[str, float | None]:
    if not league_ids:
        return {"home": None, "away": None}

    placeholders = ",".join("?" for _ in league_ids)
    filters = [
        f"m.league_id IN ({placeholders})",
        "UPPER(COALESCE(m.status, '')) IN ('FT','FINISHED')",
        "home_stats.corners_for IS NOT NULL",
        "away_stats.corners_for IS NOT NULL",
    ]
    params: list[Any] = list(league_ids)

    if before_kickoff:
        filters.append("m.kickoff < ?")
        params.append(before_kickoff)

    row = conn.execute(
        f"""
        SELECT
            AVG(home_stats.corners_for) AS home_mean,
            AVG(away_stats.corners_for) AS away_mean
        FROM matches AS m
        INNER JOIN team_match_stats AS home_stats
            ON home_stats.match_id = m.match_id
            AND home_stats.venue = 'HOME'
        INNER JOIN team_match_stats AS away_stats
            ON away_stats.match_id = m.match_id
            AND away_stats.venue = 'AWAY'
        WHERE {" AND ".join(filters)};
        """,
        tuple(params),
    ).fetchone()

    return {
        "home": numeric(row["home_mean"]),
        "away": numeric(row["away_mean"]),
    }


def load_league_corner_totals(
    conn: sqlite3.Connection,
    league_ids: list[int],
    before_kickoff: str | None,
) -> list[float]:
    if not league_ids:
        return []

    placeholders = ",".join("?" for _ in league_ids)
    filters = [
        f"m.league_id IN ({placeholders})",
        "UPPER(COALESCE(m.status, '')) IN ('FT','FINISHED')",
        "home_stats.corners_for IS NOT NULL",
        "away_stats.corners_for IS NOT NULL",
    ]

    params: list[Any] = list(league_ids)

    if before_kickoff:
        filters.append("m.kickoff < ?")
        params.append(before_kickoff)

    rows = conn.execute(
        f"""
        SELECT
            (
                home_stats.corners_for
                + away_stats.corners_for
            ) AS total_corners
        FROM matches AS m
        INNER JOIN team_match_stats AS home_stats
            ON home_stats.match_id = m.match_id
            AND home_stats.venue = 'HOME'
        INNER JOIN team_match_stats AS away_stats
            ON away_stats.match_id = m.match_id
            AND away_stats.venue = 'AWAY'
        WHERE {" AND ".join(filters)}
        ORDER BY m.kickoff ASC;
        """,
        tuple(params),
    ).fetchall()

    return [
        float(row["total_corners"])
        for row in rows
        if row["total_corners"] is not None
    ]


# ==============================================================================
# 5. PERFILES DE CÓRNERS
# ==============================================================================

def blend_metric(
    relevant_value: float | None,
    overall_value: float | None,
    venue_mix: float,
) -> float | None:
    if relevant_value is None:
        return overall_value
    if overall_value is None:
        return relevant_value

    return (
        venue_mix * relevant_value
        + (1.0 - venue_mix) * overall_value
    )


def build_profile(
    history: list[dict[str, Any]],
    relevant_venue: str,
    venue_mix: float,
    learned: bool,
) -> dict[str, Any]:
    relevant_venue = relevant_venue.upper()
    relevant = [
        row
        for row in history
        if str(row.get("venue", "")).upper() == relevant_venue
    ]

    warnings: list[str] = []
    required_relevant_matches = (
        2 if learned else MIN_RELEVANT_MATCHES
    )
    overall_for = weighted_mean(history, "corners_for")
    overall_against = weighted_mean(history, "corners_against")
    overall_total = weighted_mean(history, "total_corners")

    relevant_for = weighted_mean(relevant, "corners_for")
    relevant_against = weighted_mean(relevant, "corners_against")
    relevant_total = weighted_mean(relevant, "total_corners")

    if learned and len(relevant) >= required_relevant_matches:
        corners_for = blend_metric(
            relevant_for,
            overall_for,
            venue_mix,
        )
        corners_against = blend_metric(
            relevant_against,
            overall_against,
            venue_mix,
        )
        total_corners = blend_metric(
            relevant_total,
            overall_total,
            venue_mix,
        )
        source = "LEARNED_HOME_AWAY_BLEND"
        selected = history
    elif len(relevant) >= required_relevant_matches:
        corners_for = relevant_for
        corners_against = relevant_against
        total_corners = relevant_total
        source = relevant_venue
        selected = relevant
    else:
        corners_for = overall_for
        corners_against = overall_against
        total_corners = overall_total
        source = "OVERALL_FALLBACK"
        selected = history
        warnings.append(
            f"Solo había {len(relevant)} partidos {relevant_venue}; "
            "se usó el perfil general de la ventana."
        )

    return {
        "source": source,
        "venue_mix": round(venue_mix, 6) if learned else None,
        "window_matches": len(history),
        "selected_matches": len(selected),
        "relevant_matches_available": len(relevant),
        "corners_for_weighted": (
            round(corners_for, 4)
            if corners_for is not None
            else None
        ),
        "corners_against_weighted": (
            round(corners_against, 4)
            if corners_against is not None
            else None
        ),
        "total_corners_weighted": (
            round(total_corners, 4)
            if total_corners is not None
            else None
        ),
        "warnings": warnings,
        "matches_used": [
            {
                "event_id": row.get("event_id"),
                "kickoff": row.get("kickoff"),
                "home_team": row.get("home_team"),
                "away_team": row.get("away_team"),
                "venue": row.get("venue"),
                "corners_for": row.get("corners_for"),
                "corners_against": row.get("corners_against"),
                "weight": row.get("weight"),
            }
            for row in selected
        ],
    }


def build_lambdas(
    home_profile: dict[str, Any],
    away_profile: dict[str, Any],
) -> tuple[float, float]:
    home_lambda = geometric_mean(
        numeric(home_profile["corners_for_weighted"]),
        numeric(away_profile["corners_against_weighted"]),
    )

    away_lambda = geometric_mean(
        numeric(away_profile["corners_for_weighted"]),
        numeric(home_profile["corners_against_weighted"]),
    )

    if home_lambda is None or away_lambda is None:
        raise RuntimeError(
            "No hay datos suficientes para calcular las medias "
            "esperadas de córners."
        )

    return home_lambda, away_lambda


# ==============================================================================
# 6. DISTRIBUCIONES
# ==============================================================================

def poisson_distribution(
    mean: float,
    max_value: int,
) -> dict[str, Any]:
    probabilities = poisson.pmf(
        np.arange(max_value + 1),
        mean,
    )

    tail = max(
        0.0,
        1.0 - float(probabilities.sum()),
    )

    return {
        "mean": round(mean, 6),
        "probabilities": {
            str(index): round(float(value), 8)
            for index, value in enumerate(probabilities)
        },
        f"{max_value + 1}+": round(tail, 8),
    }


def estimate_negative_binomial_dispersion(
    totals: list[float],
) -> dict[str, Any]:
    if len(totals) < 20:
        return {
            "available": False,
            "matches_used": len(totals),
            "reason": "Muestra insuficiente; se requieren al menos 20 partidos.",
        }

    mean = float(np.mean(totals))
    variance = float(np.var(totals, ddof=1))

    if variance <= mean:
        return {
            "available": False,
            "matches_used": len(totals),
            "league_mean": round(mean, 6),
            "league_variance": round(variance, 6),
            "reason": (
                "La varianza no supera la media; no se detectó "
                "sobredispersión suficiente."
            ),
        }

    size = (mean * mean) / (variance - mean)
    size = float(np.clip(size, 0.05, 10_000.0))

    return {
        "available": True,
        "matches_used": len(totals),
        "league_mean": round(mean, 6),
        "league_variance": round(variance, 6),
        "size": round(size, 6),
    }


def negative_binomial_distribution(
    mean: float,
    size: float,
    max_value: int,
) -> dict[str, Any]:
    probability = size / (size + mean)

    values = nbinom.pmf(
        np.arange(max_value + 1),
        size,
        probability,
    )

    tail = max(
        0.0,
        1.0 - float(values.sum()),
    )

    return {
        "mean": round(mean, 6),
        "size": round(size, 6),
        "probability_parameter": round(probability, 8),
        "probabilities": {
            str(index): round(float(value), 8)
            for index, value in enumerate(values)
        },
        f"{max_value + 1}+": round(tail, 8),
    }


def probability_at_least_poisson(
    mean: float,
    minimum: int,
) -> float:
    return float(poisson.sf(minimum - 1, mean))


def probability_at_least_nbinom(
    mean: float,
    size: float,
    minimum: int,
) -> float:
    probability = size / (size + mean)
    return float(
        nbinom.sf(
            minimum - 1,
            size,
            probability,
        )
    )


def build_thresholds(
    total_mean: float,
    dispersion: dict[str, Any],
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []

    size = (
        float(dispersion["size"])
        if dispersion.get("available")
        else None
    )

    for minimum in TOTAL_THRESHOLDS:
        item = {
            "minimum_total_corners": minimum,
            "poisson_probability": round(
                probability_at_least_poisson(
                    total_mean,
                    minimum,
                ),
                8,
            ),
            "negative_binomial_probability": None,
        }

        if size is not None:
            item["negative_binomial_probability"] = round(
                probability_at_least_nbinom(
                    total_mean,
                    size,
                    minimum,
                ),
                8,
            )

        result.append(item)

    return result


def most_likely_totals(
    total_mean: float,
    dispersion: dict[str, Any],
    limit: int = 8,
) -> dict[str, Any]:
    poisson_values = [
        (
            total,
            float(poisson.pmf(total, total_mean)),
        )
        for total in range(MAX_TOTAL_CORNERS + 1)
    ]

    poisson_values.sort(
        key=lambda item: item[1],
        reverse=True,
    )

    result: dict[str, Any] = {
        "poisson": [
            {
                "total_corners": total,
                "probability": round(probability, 8),
            }
            for total, probability in poisson_values[:limit]
        ],
        "negative_binomial": [],
    }

    if dispersion.get("available"):
        size = float(dispersion["size"])
        probability_parameter = size / (size + total_mean)

        nb_values = [
            (
                total,
                float(
                    nbinom.pmf(
                        total,
                        size,
                        probability_parameter,
                    )
                ),
            )
            for total in range(MAX_TOTAL_CORNERS + 1)
        ]

        nb_values.sort(
            key=lambda item: item[1],
            reverse=True,
        )

        result["negative_binomial"] = [
            {
                "total_corners": total,
                "probability": round(probability, 8),
            }
            for total, probability in nb_values[:limit]
        ]

    return result


# ==============================================================================
# 7. SALIDA
# ==============================================================================

def percentage(value: float | None) -> str:
    if value is None:
        return "N/D"

    return f"{value * 100:.2f}%"


def print_profile(
    title: str,
    profile: dict[str, Any],
) -> None:
    print()
    print(title)
    print("-" * 76)
    print(
        f"Fuente: {profile['source']} | "
        f"Partidos usados: {profile['selected_matches']} | "
        f"Ventana: {profile['window_matches']}"
    )
    print(
        "Córners a favor: "
        f"{profile['corners_for_weighted']}"
    )
    print(
        "Córners en contra: "
        f"{profile['corners_against_weighted']}"
    )
    print(
        "Total del partido: "
        f"{profile['total_corners_weighted']}"
    )

    for warning in profile["warnings"]:
        print(f"⚠️ {warning}")


def save_result(
    league: dict[str, Any],
    source_file: Path,
    upcoming: dict[str, Any],
    result: dict[str, Any],
    trained_metadata: dict[str, Any],
    learned_configuration: dict[str, Any],
) -> Path:
    output_dir = OUTPUT_ROOT_DIR / league["key"]
    output_dir.mkdir(parents=True, exist_ok=True)

    event_id = int(upcoming["event_id"])

    payload = {
        "generated_at": utc_now(),
        "source_match_file": str(source_file),
        "competition": league,
        "upcoming_match": upcoming,
        "trained_model": trained_metadata,
        "learned_configuration": learned_configuration,
        "configuration": {
            "matches_window": MATCHES_WINDOW,
            "recent_matches": RECENT_MATCHES,
            "recent_weight": learned_configuration["recent_weight"],
            "old_weight": OLD_WEIGHT,
            "minimum_relevant_matches": MIN_RELEVANT_MATCHES,
            "thresholds_are_descriptive": True,
        },
        "analysis": result,
        "academic_note": (
            "Modelo estadístico experimental para análisis deportivo. "
            "Sus resultados deben evaluarse mediante backtesting."
        ),
    }

    path = output_dir / f"corners_{event_id}.json"
    latest = output_dir / "ultimo_corners.json"

    write_json(path, payload)
    write_json(latest, payload)

    return path


# ==============================================================================
# 8. MAIN
# ==============================================================================


# ODDSHUNTER_J1_CARDS_CORNERS_CONTEXT_V28761
def _oh_j1_exact_league_ids_v2876(conn):
    ids = []
    for tournament_id, season_id in (
        (196, 96370),
        (196, 87931),
        (196, 69871),
        (402, 70418),
    ):
        row = conn.execute(
            "SELECT league_id FROM leagues "
            "WHERE source_tournament_id=? AND source_season_id=? "
            "ORDER BY league_id DESC LIMIT 1;",
            (tournament_id, season_id),
        ).fetchone()
        if row is None:
            raise RuntimeError(
                "J1 V2.8.7.6.1: falta contexto "
                f"{tournament_id}/{season_id} en SQLite."
            )
        ids.append(int(row[0]))
    result = list(dict.fromkeys(ids))
    if len(result) != 4:
        raise RuntimeError(f"J1 V2.8.7.6.1: contextos ambiguos: {result}")
    return result


def _oh_j1_team_history_v2876(
    conn,
    *,
    competition_key,
    source_league_ids,
    sofascore_id,
    before_kickoff,
    recent_weight,
    relevant_venue,
    market,
):
    competition_slug = slugify(str(competition_key))

    # Las competiciones que declaran profile_rule requieren una ventana real
    # por sede: los 15 HOME/AWAY se seleccionan antes de aplicar el límite.
    # Sin esta regla, se conserva exactamente el comportamiento histórico.
    if competition_slug != "j1-league":
        profile_rule = None
        try:
            configured = find_competition(load_registry(), competition_slug)
            candidate_rule = configured.get("profile_rule")
            if isinstance(candidate_rule, dict):
                profile_rule = candidate_rule
        except Exception:
            profile_rule = None

        venue_key = str(relevant_venue).strip().upper()
        limit_key = "home_matches" if venue_key == "HOME" else "away_matches"
        try:
            venue_limit = int((profile_rule or {}).get(limit_key) or 0)
        except (TypeError, ValueError):
            venue_limit = 0

        if venue_limit <= 0:
            return load_team_history(
                conn,
                league_ids=source_league_ids,
                sofascore_id=int(sofascore_id),
                before_kickoff=before_kickoff,
                recent_weight=recent_weight,
            )

        candidates = load_team_history(
            conn,
            league_ids=source_league_ids,
            sofascore_id=int(sofascore_id),
            before_kickoff=before_kickoff,
            recent_weight=recent_weight,
            limit=max(250, venue_limit * 6),
        )
        history = [
            dict(row)
            for row in candidates
            if str(row.get("venue") or "").upper() == venue_key
        ][:venue_limit]
        for index, row in enumerate(history):
            row["recency_order"] = index + 1
            row["weight"] = (
                float(recent_weight)
                if index < RECENT_MATCHES
                else float(OLD_WEIGHT)
            )
        return history

    league_ids = _oh_j1_exact_league_ids_v2876(conn)
    placeholders = ",".join("?" for _ in league_ids)
    filters = [
        f"m.league_id IN ({placeholders})",
        "analysed_team.sofascore_id = ?",
        "UPPER(COALESCE(m.status, '')) IN ('FT','FINISHED')",
        "UPPER(COALESCE(s.venue, '')) = ?",
    ]
    params = [*league_ids, int(sofascore_id), str(relevant_venue).upper()]

    if before_kickoff:
        filters.append("m.kickoff < ?")
        params.append(str(before_kickoff))
        try:
            reference = datetime.fromisoformat(
                str(before_kickoff).replace("Z", "+00:00")
            )
        except Exception as exc:
            raise RuntimeError(
                "J1 V2.8.7.6.1: kickoff inválido para ventana 365 días."
            ) from exc
        filters.append("m.kickoff >= ?")
        params.append((reference - timedelta(days=365)).isoformat())

    if market == "cards":
        filters.append("s.yellow_cards IS NOT NULL")
        metric_columns = "s.yellow_cards, s.red_cards, s.fouls,"
    elif market == "corners":
        filters.append("s.corners_for IS NOT NULL")
        filters.append("s.corners_against IS NOT NULL")
        metric_columns = "s.corners_for, s.corners_against,"
    else:
        raise RuntimeError(f"J1 V2.8.7.6.1: mercado inválido: {market}")

    params.append(15)
    rows = conn.execute(
        f"SELECT s.match_id, s.team_id, s.venue, {metric_columns} "
        "s.data_quality, m.sofascore_id AS event_id, m.kickoff, "
        "home.name AS home_team, away.name AS away_team, "
        "m.league_id AS source_league_id "
        "FROM team_match_stats AS s "
        "INNER JOIN teams AS analysed_team ON analysed_team.team_id=s.team_id "
        "INNER JOIN matches AS m ON m.match_id=s.match_id "
        "INNER JOIN teams AS home ON home.team_id=m.home_team_id "
        "INNER JOIN teams AS away ON away.team_id=m.away_team_id "
        f"WHERE {' AND '.join(filters)} "
        "ORDER BY m.kickoff DESC, m.match_id DESC LIMIT ?;",
        tuple(params),
    ).fetchall()

    history = [dict(row) for row in rows]
    for index, row in enumerate(history):
        row["recency_order"] = index + 1
        row["weight"] = (
            float(recent_weight) if index < RECENT_MATCHES else float(OLD_WEIGHT)
        )
        if market == "corners":
            row["total_corners"] = (
                float(row["corners_for"]) + float(row["corners_against"])
            )
    return history

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Modelo multiliga de distribución de córners "
            "para análisis académico."
        )
    )

    parser.add_argument(
        "--key",
        required=True,
        help="Clave de competición, por ejemplo: mls",
    )

    parser.add_argument(
        "--match-json",
        help=(
            "Archivo de próximo partido. Por defecto usa "
            "data/ratings/ultimo_ratings.json."
        ),
    )

    return parser


def main() -> None:
    args = build_parser().parse_args()

    try:
        registry = load_registry()
        competition = find_competition(
            registry,
            args.key,
        )
        competition_key = slugify(str(competition["key"]))

        trained_model, trained_path = load_latest_model(
            competition_key
        )
        trained_component = component_parameters(
            trained_model,
            "corners",
        )
        trained_metadata = model_metadata(
            trained_model,
            trained_path,
            "corners",
        )

        parameters = (
            trained_component.get("parameters", {})
            if trained_component
            else {}
        )
        recent_weight = numeric_parameter(
            parameters,
            "recent_weight",
            RECENT_WEIGHT,
            minimum=1.0769230769230769,
            maximum=1.0769230769230769,
        )
        venue_mix = numeric_parameter(
            parameters,
            "venue_mix",
            1.0,
            minimum=0.0,
            maximum=1.0,
        )
        shrinkage = numeric_parameter(
            parameters,
            "league_shrinkage",
            0.0,
            minimum=0.0,
            maximum=0.70,
        )
        selected_family = (
            str(trained_component.get("family"))
            if trained_component
            else "empirical"
        )
        learned_nb_size = (
            numeric(trained_component.get("size"))
            if trained_component
            else None
        )

        learned_configuration = {
            "available": bool(trained_component),
            "recent_weight": recent_weight,
            "venue_mix": venue_mix,
            "league_shrinkage": shrinkage,
            "selected_family": selected_family,
            "negative_binomial_size": learned_nb_size,
        }

        source_file = (
            Path(args.match_json)
            if args.match_json
            else latest_upcoming_match_file()
        )

        if not source_file.is_absolute():
            source_file = BASE_DIR / source_file

        ratings_document = read_json(source_file)
        bot10_projection = (
            ((ratings_document.get("bot10_context") or {}).get("markets") or {}).get(
                "corners"
            )
            if isinstance(ratings_document.get("bot10_context"), dict)
            else None
        )
        upcoming = load_upcoming_match(source_file)
        conn = get_connection()

        try:
            validate_schema(conn)
            league = resolve_league(conn, competition)
            source_league_ids = resolve_source_league_ids(
                conn,
                competition,
                trained_model,
                int(league["league_id"]),
            )
            league["source_league_ids"] = source_league_ids

            home_team = resolve_team(
                conn,
                sofascore_id=int(upcoming["home_team_id"]),
                league_id=league["league_id"],
            )
            away_team = resolve_team(
                conn,
                sofascore_id=int(upcoming["away_team_id"]),
                league_id=league["league_id"],
            )

            before_kickoff = (
                str(upcoming.get("kickoff"))
                if upcoming.get("kickoff")
                else None
            )

            home_history = _oh_j1_team_history_v2876(
                conn,
                competition_key=competition_key,
                source_league_ids=source_league_ids,
                sofascore_id=int(upcoming["home_team_id"]),
                before_kickoff=before_kickoff,
                recent_weight=recent_weight,
                relevant_venue="HOME",
                market="corners",
            )
            away_history = _oh_j1_team_history_v2876(
                conn,
                competition_key=competition_key,
                source_league_ids=source_league_ids,
                sofascore_id=int(upcoming["away_team_id"]),
                before_kickoff=before_kickoff,
                recent_weight=recent_weight,
                relevant_venue="AWAY",
                market="corners",
            )

            home_profile = build_profile(
                home_history,
                "HOME",
                venue_mix=venue_mix,
                learned=bool(trained_component),
            )
            away_profile = build_profile(
                away_history,
                "AWAY",
                venue_mix=venue_mix,
                learned=bool(trained_component),
            )
            if not home_history:
                home_profile["warnings"].append(
                    "Sin historial individual de córners; se usará la media "
                    "de la competición y temporada actuales."
                )
            if not away_history:
                away_profile["warnings"].append(
                    "Sin historial individual de córners; se usará la media "
                    "de la competición y temporada actuales."
                )

            league_means = load_league_corner_means(
                conn,
                league_ids=source_league_ids,
                before_kickoff=before_kickoff,
            )

            try:
                lambda_home, lambda_away = build_lambdas(
                    home_profile,
                    away_profile,
                )
            except RuntimeError:
                if (
                    league_means["home"] is None
                    or league_means["away"] is None
                ):
                    raise
                lambda_home = float(league_means["home"])
                lambda_away = float(league_means["away"])
                home_profile["warnings"].append(
                    "Sin muestra individual suficiente; se usó la media "
                    "de la competición y temporada actuales."
                )
                away_profile["warnings"].append(
                    "Sin muestra individual suficiente; se usó la media "
                    "de la competición y temporada actuales."
                )

            paired_sample = min(
                int(home_profile.get("selected_matches") or 0),
                int(away_profile.get("selected_matches") or 0),
            )
            context_used = False
            # BOT 10.1 mantiene la mezcla UEFA/doméstica activa de forma
            # continua hasta completar 15 partidos UEFA válidos. El propio
            # contexto reduce progresivamente el peso doméstico; no existe
            # una compuerta brusca al llegar a tres encuentros.
            if isinstance(bot10_projection, dict):
                context_home = numeric(bot10_projection.get("home"))
                context_away = numeric(bot10_projection.get("away"))
                if context_home is not None and context_away is not None:
                    lambda_home = context_home
                    lambda_away = context_away
                    context_used = True
                    home_profile["warnings"].append(
                        "Contexto UEFA/doméstico normalizado con mezcla "
                        "continua por evidencia BOT 10.1."
                    )
                    away_profile["warnings"].append(
                        "Contexto UEFA/doméstico normalizado con mezcla "
                        "continua por evidencia BOT 10.1."
                    )
            sample_shrinkage = min(
                0.90,
                5.0 / (5.0 + max(0, paired_sample)),
            )
            effective_shrinkage = max(
                shrinkage if trained_component else 0.0,
                sample_shrinkage,
            )
            if not context_used and league_means["home"] is not None:
                lambda_home = (
                    (1.0 - effective_shrinkage) * lambda_home
                    + effective_shrinkage * float(league_means["home"])
                )
            if not context_used and league_means["away"] is not None:
                lambda_away = (
                    (1.0 - effective_shrinkage) * lambda_away
                    + effective_shrinkage * float(league_means["away"])
                )

            lambda_home = max(0.01, lambda_home)
            lambda_away = max(0.01, lambda_away)
            total_mean = lambda_home + lambda_away

            league_totals = load_league_corner_totals(
                conn,
                league_ids=source_league_ids,
                before_kickoff=before_kickoff,
            )

        finally:
            conn.close()

        empirical_dispersion = estimate_negative_binomial_dispersion(
            league_totals
        )

        if (
            selected_family == "negative_binomial"
            and learned_nb_size is not None
        ):
            dispersion = {
                "available": True,
                "source": "trained_model",
                "selected_family": selected_family,
                "size": round(learned_nb_size, 6),
                "matches_used": trained_model.get("data", {}).get(
                    "train_samples"
                ) if trained_model else None,
                "empirical_diagnostic": empirical_dispersion,
            }
        elif selected_family == "poisson":
            dispersion = {
                "available": False,
                "source": "trained_model",
                "selected_family": "poisson",
                "reason": (
                    "Poisson obtuvo mejor validación temporal que "
                    "la binomial negativa."
                ),
                "empirical_diagnostic": empirical_dispersion,
            }
        else:
            dispersion = empirical_dispersion
            dispersion["source"] = "empirical_fallback"

        poisson_total = poisson_distribution(
            total_mean,
            MAX_TOTAL_CORNERS,
        )
        negative_binomial_total = None

        if dispersion.get("available"):
            negative_binomial_total = negative_binomial_distribution(
                mean=total_mean,
                size=float(dispersion["size"]),
                max_value=MAX_TOTAL_CORNERS,
            )

        result = {
            "trained_model": trained_metadata,
            "selected_family": selected_family,
            "home_team": {
                "team": home_team,
                "profile": home_profile,
                "expected_corners": round(lambda_home, 6),
                "poisson_distribution": poisson_distribution(
                    lambda_home,
                    MAX_TEAM_CORNERS,
                ),
            },
            "away_team": {
                "team": away_team,
                "profile": away_profile,
                "expected_corners": round(lambda_away, 6),
                "poisson_distribution": poisson_distribution(
                    lambda_away,
                    MAX_TEAM_CORNERS,
                ),
            },
            "expected_total_corners": round(total_mean, 6),
            "bot10_context": bot10_projection if context_used else None,
            "source": (
                "bot10_separate_uefa_domestic_context"
                if context_used
                else "same_competition_historical_fallback"
                if competition_key == "bundesliga" and not trained_component
                else "same_competition_trained_model"
            ),
            "confidence": (
                bot10_projection.get("confidence")
                if context_used and isinstance(bot10_projection, dict)
                else None
            ),
            "fallback_level": (
                (bot10_projection.get("home_context") or {}).get("fallback_level")
                if context_used and isinstance(bot10_projection, dict)
                else None
            ),
            "lambda_method": (
                "Parámetros aprendidos por liga cuando están disponibles; "
                "mezcla local/visitante, peso reciente y contracción a la media."
            ),
            "poisson_total_distribution": poisson_total,
            "negative_binomial_dispersion": dispersion,
            "negative_binomial_total_distribution": negative_binomial_total,
            "minimum_total_thresholds": build_thresholds(
                total_mean,
                dispersion,
            ),
            "most_likely_totals": most_likely_totals(
                total_mean,
                dispersion,
            ),
        }

        print("=" * 76)
        print("ODDSHUNTER — MODELO MULTILIGA DE CÓRNERS")
        print("=" * 76)
        print(f"Competición: {league['name']} {league['season']}")
        print(
            f"Partido: {upcoming['home_team']} vs "
            f"{upcoming['away_team']}"
        )
        print(
            "Modelo entrenado: "
            + (
                f"SÍ | versión {trained_metadata.get('version')}"
                if trained_metadata.get("available")
                else "NO | configuración predeterminada"
            )
        )
        print(
            f"Peso reciente={recent_weight:.2f} | "
            f"mezcla venue={venue_mix:.4f} | "
            f"shrinkage={shrinkage:.4f} | "
            f"familia={selected_family}"
        )

        print_profile(
            f"{home_team['name']} — perfil local",
            home_profile,
        )
        print_profile(
            f"{away_team['name']} — perfil visitante",
            away_profile,
        )

        print()
        print("DISTRIBUCIÓN DEL PARTIDO")
        print("-" * 76)
        print(
            f"Media esperada {home_team['name']}: "
            f"{lambda_home:.3f}"
        )
        print(
            f"Media esperada {away_team['name']}: "
            f"{lambda_away:.3f}"
        )
        print(f"Media total: {total_mean:.3f}")

        for threshold in result["minimum_total_thresholds"]:
            print(
                f"Total ≥ {threshold['minimum_total_corners']} | "
                f"Poisson: {percentage(threshold['poisson_probability'])} | "
                "Binomial negativa: "
                f"{percentage(threshold['negative_binomial_probability'])}"
            )

        output_path = save_result(
            league=league,
            source_file=source_file,
            upcoming=upcoming,
            result=result,
            trained_metadata=trained_metadata,
            learned_configuration=learned_configuration,
        )

        print()
        print("=" * 76)
        print("✅ MODELO DE CÓRNERS CALCULADO")
        print("=" * 76)
        print(f"Resultado guardado en:\n{output_path}")
        print(
            "\nCopia actualizada en:\n"
            f"{output_path.parent / 'ultimo_corners.json'}"
        )

    except KeyboardInterrupt:
        print("\n⚠️ Proceso interrumpido.")

    except Exception as exc:
        print()
        print(f"❌ Error: {type(exc).__name__}: {exc}")
        raise SystemExit(1)


# ==============================================================================
# ODDSHUNTER_PROFILE_HISTORY_SCOPE_GENERIC_V10_7_1
# Profile-only por equipo dirigido exclusivamente por competitions.json.
# Afecta SOLO al historial individual del equipo; las medias/prior de liga
# siguen usando el scope primario del modelo. No participa en entrenamiento.
# ==============================================================================
_OH_PROFILE_ORIGINAL_LOAD_TEAM_HISTORY_V1073 = load_team_history
_OH_LAST_PROFILE_SCOPE_V1073 = None

def _oh_cli_key_v1073():
    import sys as _sys
    _argv = list(_sys.argv)
    for _idx, _value in enumerate(_argv):
        if _value == "--key" and _idx + 1 < len(_argv):
            return str(_argv[_idx + 1]).strip()
        if str(_value).startswith("--key="):
            return str(_value).split("=", 1)[1].strip()
    return None

def _oh_registry_comp_v1073(_key):
    import json as _json
    from pathlib import Path as _Path
    if not _key:
        return None
    _root = _Path(__file__).resolve().parent
    _path = _root / "data" / "competitions.json"
    try:
        _doc = _json.loads(_path.read_text(encoding="utf-8-sig"))
    except Exception:
        return None
    for _row in (_doc.get("competitions") or []):
        if (
            isinstance(_row, dict)
            and str(_row.get("key") or "").strip().lower()
            == str(_key).strip().lower()
        ):
            return _row
    return None

def _oh_sid_from_bound_v1073(_conn, _bound):
    _sid = _bound.arguments.get("sofascore_id")
    try:
        if _sid is not None:
            return int(_sid)
    except Exception:
        pass
    _team_id = _bound.arguments.get("team_id")
    try:
        _team_id = int(_team_id)
    except Exception:
        return None
    try:
        _row = _conn.execute(
            "SELECT sofascore_id FROM teams WHERE team_id=? LIMIT 1",
            (_team_id,),
        ).fetchone()
    except Exception:
        return None
    if _row is None:
        return None
    try:
        _value = _row["sofascore_id"]
    except Exception:
        _value = _row[0]
    try:
        return int(_value) if _value is not None else None
    except Exception:
        return None

def _oh_pair_ids_v1073(_conn, _pairs):
    _ids = set()
    for _item in (_pairs or []):
        if not isinstance(_item, dict):
            continue
        try:
            _tid = int(_item.get("tournament_id"))
            _season = int(_item.get("season_id"))
        except Exception:
            continue
        try:
            _rows = _conn.execute(
                "SELECT league_id FROM leagues "
                "WHERE source_tournament_id=? AND source_season_id=? "
                "ORDER BY league_id",
                (_tid, _season),
            ).fetchall()
        except Exception:
            continue
        for _row in _rows:
            try:
                _lid = int(_row["league_id"])
            except Exception:
                try:
                    _lid = int(_row[0])
                except Exception:
                    continue
            _ids.add(_lid)
    return sorted(_ids)

def _oh_profile_scope_v1073(_conn, _key, _sid):
    _spec = _oh_registry_comp_v1073(_key)
    if not isinstance(_spec, dict) or _sid is None:
        return None
    _selected = []
    for _item in (_spec.get("profile_history_source_pairs") or []):
        if not isinstance(_item, dict):
            continue
        _teams = _item.get("team_sofascore_ids")
        if not isinstance(_teams, list):
            continue
        try:
            _allowed = {int(_x) for _x in _teams}
        except Exception:
            continue
        if int(_sid) in _allowed:
            _selected.append(_item)
    if not _selected:
        return None
    _ids = _oh_pair_ids_v1073(_conn, _selected)
    return _ids or None

def load_team_history(*_args, **_kwargs):
    # ODDSHUNTER_CURRENT_PLUS_PROFILE_SCOPE_V10_8_0
    # Para equipos con profile_history_source_pairs:
    #   CURRENT PRIMARY + PROFILE HISTORICO.
    # No altera equipos normales.
    # No altera medias/prior de liga.
    import inspect as _inspect

    global _OH_LAST_PROFILE_SCOPE_V1073

    _OH_LAST_PROFILE_SCOPE_V1073 = None

    _original = _OH_PROFILE_ORIGINAL_LOAD_TEAM_HISTORY_V1073
    _sig = _inspect.signature(_original)
    _bound = _sig.bind_partial(*_args, **_kwargs)

    _conn = (
        _bound.arguments.get("conn")
        or _bound.arguments.get("connection")
    )

    _key = _oh_cli_key_v1073()

    if _conn is not None and _key:
        _sid = _oh_sid_from_bound_v1073(
            _conn,
            _bound,
        )

        _profile_ids = _oh_profile_scope_v1073(
            _conn,
            _key,
            _sid,
        )

        if _profile_ids:
            _effective_ids = set()

            for _value in _profile_ids:
                try:
                    _effective_ids.add(
                        int(_value)
                    )
                except Exception:
                    pass

            # Añadir SOLO la temporada primaria CURRENT.
            # No añade temporadas top-flight antiguas al
            # perfil del ascendido.
            try:
                _registry = load_registry()
                _competition = find_competition(
                    _registry,
                    _key,
                )

                _tid = int(
                    _competition.get(
                        "source_competition_id"
                    )
                    or _competition.get(
                        "tournament_id"
                    )
                    or 0
                )

                _season = int(
                    _competition.get(
                        "season_id"
                    )
                    or 0
                )

                if _tid > 0 and _season > 0:
                    _rows = _conn.execute(
                        """
                        SELECT league_id
                        FROM leagues
                        WHERE source_tournament_id = ?
                          AND source_season_id = ?
                        ORDER BY league_id;
                        """,
                        (
                            _tid,
                            _season,
                        ),
                    ).fetchall()

                    for _row in _rows:
                        try:
                            _value = _row["league_id"]
                        except Exception:
                            _value = _row[0]

                        if _value is not None:
                            _effective_ids.add(
                                int(_value)
                            )

            except Exception:
                # El smoke posterior es el gate:
                # si CURRENT no entra, no se acepta.
                pass

            _effective_ids = sorted(
                _effective_ids
            )

            if "league_ids" in _sig.parameters:
                _bound.arguments[
                    "league_ids"
                ] = list(_effective_ids)

            elif "league_id" in _sig.parameters:
                _bound.arguments[
                    "league_id"
                ] = int(
                    _effective_ids[0]
                )

            else:
                return _original(
                    *_args,
                    **_kwargs,
                )

            _OH_LAST_PROFILE_SCOPE_V1073 = {
                "competition_key": _key,
                "sofascore_id": int(_sid),
                "league_ids": list(
                    _effective_ids
                ),
            }

            print(
                "[PROFILE_HISTORY_SCOPE] "
                f"key={_key} "
                f"sid={int(_sid)} "
                f"league_ids={list(_effective_ids)}"
            )

    return _original(
        *_bound.args,
        **_bound.kwargs,
    )
# ==============================================================================
# FIN ODDSHUNTER_PROFILE_HISTORY_SCOPE_GENERIC_V10_7_1
# ==============================================================================

# ============================================================================
# ODDSHUNTER_PROFILE_SCOPE_RUNTIME_FIX_V2_2
# Generic promoted-team profile bridge independent of CLI key.
# Registry-authoritative; only expands explicitly listed profile teams.
# ============================================================================
_OH_V22_PREVIOUS_LOAD_TEAM_HISTORY = load_team_history

def _oh_v22_pair_ids(_conn, _pairs):
    _ids = set()
    if not isinstance(_pairs, list):
        return []
    _sql = (
        "SELECT league_id FROM leagues "
        "WHERE source_tournament_id=? AND source_season_id=? "
        "ORDER BY league_id"
    )
    for _item in _pairs:
        if not isinstance(_item, dict):
            continue
        try:
            _tid = int(_item.get("tournament_id"))
            _season = int(_item.get("season_id"))
        except Exception:
            continue
        for _row in _conn.execute(_sql, (_tid, _season)).fetchall():
            try:
                _value = _row["league_id"]
            except Exception:
                _value = _row[0]
            if _value is not None:
                _ids.add(int(_value))
    return sorted(_ids)

def _oh_v22_expand_profile_scope(_conn, _incoming, _sid):
    import json as _json
    from pathlib import Path as _Path

    try:
        _sid = int(_sid)
        _incoming_set = {int(_x) for _x in (_incoming or [])}
    except Exception:
        return None

    if not _incoming_set:
        return None

    _allowed_keys = {
        "greece-stoiximan-super-league",
        "championship",
        "turkey-super-lig",
        "saudi-pro-league",
        "serie-a",
    }

    _registry = _Path(__file__).resolve().parent / "data" / "competitions.json"
    try:
        _doc = _json.loads(_registry.read_text(encoding="utf-8-sig"))
    except Exception:
        return None

    for _spec in (_doc.get("competitions") or []):
        if not isinstance(_spec, dict):
            continue
        _key = str(_spec.get("key") or "").strip()
        if _key not in _allowed_keys:
            continue

        _target_ids = set(_oh_v22_pair_ids(
            _conn,
            _spec.get("history_source_pairs") or [],
        ))
        if not _target_ids or not (_incoming_set & _target_ids):
            continue

        _selected = []
        for _item in (_spec.get("profile_history_source_pairs") or []):
            if not isinstance(_item, dict):
                continue
            try:
                _teams = {int(_x) for _x in (_item.get("team_sofascore_ids") or [])}
            except Exception:
                continue
            if _sid in _teams:
                _selected.append(_item)

        _profile_ids = set(_oh_v22_pair_ids(_conn, _selected))
        if not _profile_ids:
            continue

        _effective = sorted(_incoming_set | _profile_ids)
        return {
            "competition_key": _key,
            "sofascore_id": _sid,
            "profile_ids": sorted(_profile_ids),
            "league_ids": _effective,
        }

    return None

def load_team_history(*_args, **_kwargs):
    _args_list = list(_args)

    _conn = _kwargs.get("conn") or _kwargs.get("connection")
    if _conn is None and _args_list:
        _conn = _args_list[0]

    _league_ids = _kwargs.get("league_ids")
    if _league_ids is None and len(_args_list) > 1:
        _league_ids = _args_list[1]

    _sid = _kwargs.get("sofascore_id")
    if _sid is None and len(_args_list) > 2:
        _sid = _args_list[2]

    _expanded = None
    if _conn is not None and _league_ids is not None and _sid is not None:
        _expanded = _oh_v22_expand_profile_scope(
            _conn,
            _league_ids,
            _sid,
        )

    if _expanded:
        _effective = list(_expanded["league_ids"])
        if "league_ids" in _kwargs:
            _kwargs["league_ids"] = _effective
        elif len(_args_list) > 1:
            _args_list[1] = _effective
        else:
            _kwargs["league_ids"] = _effective

        print(
            "[PROFILE_HISTORY_SCOPE_V2_2] "
            f"key={_expanded['competition_key']} "
            f"sid={_expanded['sofascore_id']} "
            f"profile_ids={_expanded['profile_ids']} "
            f"league_ids={_effective}"
        )

    return _OH_V22_PREVIOUS_LOAD_TEAM_HISTORY(
        *_args_list,
        **_kwargs,
    )

if __name__ == "__main__":
    main()
