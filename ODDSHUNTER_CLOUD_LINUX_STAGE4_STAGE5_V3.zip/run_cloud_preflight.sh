#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
source .venv-cloud/bin/activate
export ODDSHUNTER_BROWSER_HEADLESS="${ODDSHUNTER_BROWSER_HEADLESS:-1}"
export ODDSHUNTER_CHROMIUM_SANDBOX="${ODDSHUNTER_CHROMIUM_SANDBOX:-0}"
python cloud_preflight.py --network
