from __future__ import annotations

import json
import os
import re
import tempfile
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from threading import RLock
from typing import Any


def _normalize(value: Any) -> str:
    raw = str(value or "").casefold()
    # Letras que NFKD no translitera por sí solo.
    raw = (
        raw.replace("ə", "a")
        .replace("ı", "i")
        .replace("ø", "o")
        .replace("ł", "l")
        .replace("đ", "d")
    )
    text = unicodedata.normalize("NFKD", raw)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return " ".join(text.split())


_CLUB_PREFIXES = {"fc", "fk", "sk", "sp", "kf", "gnk"}


def _identity_name(value: Any) -> str:
    """Normaliza nombres y omite prefijos/sufijos genéricos de club."""
    text = str(value or "").strip()
    text = re.sub(r"\s*\([^()]{2,24}\)\s*$", "", text).strip()
    tokens = _normalize(text).split()
    while tokens and tokens[0] in _CLUB_PREFIXES:
        tokens.pop(0)
    while tokens and tokens[-1] in _CLUB_PREFIXES:
        tokens.pop()
    return " ".join(tokens)


class TeamIdentityRegistry:
    """Registro JSON editable de alias de SofaScore/Flashscore.

    El registro nunca autoriza una URL de partido por sí solo. La URL final
    continúa exigiendo rival, fecha, orientación y competición en el cliente
    Flashscore. Solo evita repetir búsquedas ambiguas de la ficha del equipo.
    """

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self._lock = RLock()
        self._mtime_ns: int | None = None
        self._data: dict[str, Any] = {"schema_version": 1, "teams": []}
        self._alias_index: dict[str, str] = {}
        self._key_index: dict[str, dict[str, Any]] = {}
        self.reload(force=True)

    def _all_names(self, team: dict[str, Any]) -> list[str]:
        values: list[str] = []
        for field in (
            "canonical_name",
            "uefa_name",
            "name",
            "flashscore_display_name",
            "futbol24_profile_name",
        ):
            value = str(team.get(field) or "").strip()
            if value:
                values.append(value)
        for field in (
            "sofascore_names",
            "flashscore_names",
            "aliases",
            "normalized_aliases",
            "uefa_names",
            "sofascore_aliases",
            "flashscore_aliases",
            "futbol24_names",
            "futbol24_aliases",
        ):
            raw = team.get(field)
            if isinstance(raw, list):
                values.extend(
                    str(item).strip()
                    for item in raw
                    if str(item).strip()
                )
            elif isinstance(raw, str) and raw.strip():
                values.append(raw.strip())
        return list(dict.fromkeys(values))

    def _reindex(self) -> None:
        self._alias_index = {}
        self._key_index = {}
        for raw in self._data.get("teams", []):
            if not isinstance(raw, dict):
                continue
            key = str(raw.get("key") or "").strip()
            if not key:
                continue
            self._key_index[key] = raw
            for name in self._all_names(raw):
                normalized = _identity_name(name)
                if normalized and normalized not in self._alias_index:
                    self._alias_index[normalized] = key

    def reload(self, *, force: bool = False) -> None:
        with self._lock:
            try:
                stat = self.path.stat()
            except OSError:
                self._reindex()
                return
            if not force and self._mtime_ns == stat.st_mtime_ns:
                return
            try:
                data = json.loads(self.path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                return
            if not isinstance(data, dict) or not isinstance(data.get("teams"), list):
                return
            self._data = data
            self._mtime_ns = stat.st_mtime_ns
            self._reindex()

    def _maybe_reload(self) -> None:
        self.reload(force=False)

    def get(self, name: Any) -> dict[str, Any] | None:
        self._maybe_reload()
        key = self._alias_index.get(_identity_name(name))
        if not key:
            return None
        record = self._key_index.get(key)
        return dict(record) if isinstance(record, dict) else None

    def are_equivalent(self, left: Any, right: Any) -> bool:
        self._maybe_reload()
        left_key = self._alias_index.get(_identity_name(left))
        right_key = self._alias_index.get(_identity_name(right))
        return bool(left_key and right_key and left_key == right_key)

    def search_variants(self, name: Any) -> list[str]:
        record = self.get(name)
        if record is None:
            return []
        values: list[str] = []
        for field in ("flashscore_names", "flashscore_aliases"):
            variants = record.get(field)
            if isinstance(variants, list):
                values.extend(
                    str(item).strip()
                    for item in variants
                    if str(item).strip()
                )
            elif isinstance(variants, str) and variants.strip():
                values.append(variants.strip())
        return list(dict.fromkeys(values))

    def futbol24_variants(self, name: Any) -> list[str]:
        """Devuelve primero los nombres visibles verificados en Futbol24."""

        record = self.get(name)
        if record is None:
            return []
        values: list[str] = []
        for field in (
            "futbol24_names",
            "futbol24_aliases",
            "futbol24_profile_name",
        ):
            variants = record.get(field)
            if isinstance(variants, list):
                values.extend(
                    str(item).strip()
                    for item in variants
                    if str(item).strip()
                )
            elif isinstance(variants, str) and variants.strip():
                values.append(variants.strip())
        return list(dict.fromkeys(values))

    def country_hints(self, name: Any) -> set[str]:
        record = self.get(name)
        if record is None:
            return set()
        values: list[str] = []
        country = str(record.get("country") or "").strip()
        if country:
            values.append(country)
        aliases = record.get("country_aliases")
        if isinstance(aliases, list):
            values.extend(str(item).strip() for item in aliases if str(item).strip())
        return {_normalize(value) for value in values if _normalize(value)}

    def flashscore_profile(self, name: Any) -> dict[str, Any] | None:
        record = self.get(name)
        if record is None:
            return None
        url = str(record.get("flashscore_team_url") or "").strip()
        identifier = str(record.get("flashscore_team_id") or "").strip()
        if not url or not identifier:
            return None
        display = str(
            record.get("flashscore_display_name")
            or (record.get("flashscore_names") or [record.get("canonical_name")])[0]
            or record.get("canonical_name")
            or name
        ).strip()
        category = str(record.get("flashscore_category") or "").strip()
        slug = ""
        parts = [part for part in re.split(r"/+", url) if part]
        try:
            marker = parts.index("equipo")
            slug = parts[marker + 1]
        except (ValueError, IndexError):
            slug = re.sub(r"[^a-z0-9]+", "-", _normalize(display)).strip("-")
        return {
            "id": identifier,
            "name": display,
            "slug": slug,
            "url": url,
            "raw_href": url,
            "category": category,
            "source": "team_identity_registry",
        }

    def _atomic_write(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(self._data, ensure_ascii=False, indent=2) + "\n"
        fd, temp_name = tempfile.mkstemp(
            prefix=self.path.stem + "_",
            suffix=".tmp",
            dir=str(self.path.parent),
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_name, self.path)
        finally:
            try:
                Path(temp_name).unlink(missing_ok=True)
            except OSError:
                pass
        try:
            self._mtime_ns = self.path.stat().st_mtime_ns
        except OSError:
            self._mtime_ns = None

    def remember_flashscore_identity(
        self,
        expected_name: Any,
        *,
        display_name: Any,
        team_id: Any,
        team_url: Any,
        category: Any = "",
    ) -> bool:
        """Persiste la ficha solo después de que el cliente validó el partido."""
        display = str(display_name or "").strip()
        identifier = str(team_id or "").strip()
        url = str(team_url or "").strip()
        if not display or not identifier or not url:
            return False
        with self._lock:
            self._maybe_reload()
            normalized_expected = _identity_name(expected_name)
            key = self._alias_index.get(normalized_expected)
            record = self._key_index.get(key or "") if key else None
            if not isinstance(record, dict):
                key = re.sub(r"[^a-z0-9]+", "-", normalized_expected).strip("-")
                if not key:
                    return False
                record = {
                    "key": key,
                    "canonical_name": str(expected_name or display).strip(),
                    "uefa_name": str(expected_name or display).strip(),
                    "sofascore_names": [str(expected_name or display).strip()],
                    "flashscore_names": [],
                    "country": "",
                    "country_aliases": [],
                    "sport": "football",
                    "source": "auto_discovered_after_match_validation",
                }
                self._data.setdefault("teams", []).append(record)
            aliases = record.setdefault("flashscore_names", [])
            if isinstance(aliases, list) and display not in aliases:
                aliases.append(display)
            record["flashscore_team_id"] = identifier
            record["flashscore_team_url"] = url
            record["flashscore_display_name"] = display
            record["flashscore_category"] = str(category or "").strip()
            record["last_validated_at"] = datetime.now(timezone.utc).isoformat()
            self._data["updated_at"] = datetime.now(timezone.utc).isoformat()
            self._reindex()
            self._atomic_write()
            return True

    def validate(self) -> list[str]:
        self._maybe_reload()
        errors: list[str] = []
        seen_keys: set[str] = set()
        aliases: dict[str, str] = {}
        teams = self._data.get("teams")
        if not isinstance(teams, list):
            return ["La raíz no contiene una lista teams."]
        for index, record in enumerate(teams, start=1):
            if not isinstance(record, dict):
                errors.append(f"Entrada {index}: no es objeto JSON.")
                continue
            key = str(record.get("key") or "").strip()
            if not key:
                errors.append(f"Entrada {index}: falta key.")
                continue
            if key in seen_keys:
                errors.append(f"Key duplicada: {key}")
            seen_keys.add(key)
            canonical = str(record.get("canonical_name") or "").strip()
            if not canonical:
                errors.append(f"{key}: falta canonical_name.")
            if str(record.get("sport") or "").strip().casefold() != "football":
                errors.append(f"{key}: sport debe ser football.")
            for name in self._all_names(record):
                normalized = _identity_name(name)
                previous = aliases.get(normalized)
                if previous and previous != key:
                    errors.append(
                        f"Alias ambiguo '{name}' compartido por {previous} y {key}."
                    )
                else:
                    aliases[normalized] = key
        return errors


_REGISTRIES: dict[str, TeamIdentityRegistry] = {}
_REGISTRY_LOCK = RLock()


def get_default_team_identity_registry(project_root: str | Path) -> TeamIdentityRegistry:
    path = Path(project_root).resolve() / "data" / "team_identity_registry.json"
    key = str(path).casefold()
    with _REGISTRY_LOCK:
        registry = _REGISTRIES.get(key)
        if registry is None:
            registry = TeamIdentityRegistry(path)
            _REGISTRIES[key] = registry
        return registry
