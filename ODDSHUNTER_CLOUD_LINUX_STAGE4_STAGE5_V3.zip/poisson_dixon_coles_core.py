from __future__ import annotations

import argparse
import json
import math
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
from scipy.optimize import minimize_scalar
from scipy.stats import poisson

from trained_model_loader import (
    component_parameters,
    infer_competition_key,
    load_latest_model,
    model_metadata,
    numeric_parameter,
)


# ==============================================================================
# 1. RUTAS Y CONFIGURACIÓN
# ==============================================================================

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "oddshunter.db"
RATINGS_DIR = DATA_DIR / "ratings"
MODELS_DIR = DATA_DIR / "modelos"

DEFAULT_RATINGS_PATH = RATINGS_DIR / "ultimo_ratings.json"

# La matriz incluye resultados desde 0 hasta MAX_GOALS por equipo.
MAX_GOALS = 10

# Límites prudentes para la correlación Dixon-Coles.
RHO_MIN = -0.25
RHO_MAX = 0.25

# Evita parámetros Poisson nulos o extremos por errores de datos.
MIN_LAMBDA = 0.05
MAX_LAMBDA = 6.00

MODELS_DIR.mkdir(parents=True, exist_ok=True)


# ==============================================================================
# 2. UTILIDADES
# ==============================================================================

def leer_json(ruta: Path) -> dict[str, Any]:
    if not ruta.exists():
        raise FileNotFoundError(
            f"No se encontró el archivo:\n{ruta}"
        )

    with ruta.open("r", encoding="utf-8") as archivo:
        contenido = json.load(archivo)

    if not isinstance(contenido, dict):
        raise ValueError(
            f"El archivo {ruta.name} no contiene un objeto JSON válido."
        )

    return contenido


def valor_numerico(
    objeto: dict[str, Any],
    clave: str,
) -> float | None:
    valor = objeto.get(clave)

    if valor is None:
        return None

    try:
        numero = float(valor)
    except (TypeError, ValueError):
        return None

    if not math.isfinite(numero):
        return None

    return numero


def media_geometrica(
    valor_ataque: float | None,
    valor_defensa_rival: float | None,
) -> float | None:
    """
    Combina ataque propio y concesión rival sin porcentajes manuales.

    Ejemplo:
        lambda_local = sqrt(
            xG_local_a_favor * xG_visitante_en_contra
        )
    """

    if valor_ataque is None or valor_defensa_rival is None:
        return None

    if valor_ataque < 0 or valor_defensa_rival < 0:
        return None

    resultado = math.sqrt(
        max(valor_ataque, 0.0)
        * max(valor_defensa_rival, 0.0)
    )

    return float(
        np.clip(
            resultado,
            MIN_LAMBDA,
            MAX_LAMBDA,
        )
    )


def seleccionar_ruta_ratings(
    argumento: str | None,
) -> Path:
    if argumento:
        ruta = Path(argumento)

        if not ruta.is_absolute():
            ruta = BASE_DIR / ruta

        return ruta

    return DEFAULT_RATINGS_PATH


# ==============================================================================
# 3. DATOS DEL MODELO DESDE ratings.py
# ==============================================================================

def extraer_contexto(
    ratings: dict[str, Any],
) -> dict[str, Any]:
    encuentro = ratings.get("upcoming_match")
    local = ratings.get("home_team_analysis")
    visitante = ratings.get("away_team_analysis")

    if not isinstance(encuentro, dict):
        raise ValueError(
            "El JSON de ratings no contiene 'upcoming_match'."
        )

    if not isinstance(local, dict):
        raise ValueError(
            "El JSON de ratings no contiene 'home_team_analysis'."
        )

    if not isinstance(visitante, dict):
        raise ValueError(
            "El JSON de ratings no contiene 'away_team_analysis'."
        )

    local_relevant = (
        local.get("profiles", {})
        .get("relevant", {})
        .get("averages", {})
    )

    visitante_relevant = (
        visitante.get("profiles", {})
        .get("relevant", {})
        .get("averages", {})
    )

    local_overall = (
        local.get("profiles", {})
        .get("overall", {})
        .get("averages", {})
    )

    visitante_overall = (
        visitante.get("profiles", {})
        .get("overall", {})
        .get("averages", {})
    )

    if not isinstance(local_relevant, dict):
        raise ValueError(
            "No se encontraron los promedios relevantes del local."
        )

    if not isinstance(visitante_relevant, dict):
        raise ValueError(
            "No se encontraron los promedios relevantes del visitante."
        )

    return {
        "match": encuentro,
        "home_team": local.get("team", {}),
        "away_team": visitante.get("team", {}),
        "home_averages": local_relevant,
        "away_averages": visitante_relevant,
        "home_overall_averages": local_overall,
        "away_overall_averages": visitante_overall,
        "home_relevant_matches": (
            local.get("profiles", {})
            .get("relevant", {})
            .get("matches", 0)
        ),
        "away_relevant_matches": (
            visitante.get("profiles", {})
            .get("relevant", {})
            .get("matches", 0)
        ),
        "home_matches": (
            local.get("profiles", {})
            .get("relevant", {})
            .get("matches")
        ),
        "away_matches": (
            visitante.get("profiles", {})
            .get("relevant", {})
            .get("matches")
        ),
        "bot10_context": (
            ratings.get("bot10_context")
            if isinstance(ratings.get("bot10_context"), dict)
            else {}
        ),
    }


def mezclar_valores(
    relevant: dict[str, Any],
    overall: dict[str, Any],
    key: str,
    venue_mix: float,
) -> float | None:
    relevant_value = valor_numerico(relevant, key)
    overall_value = valor_numerico(overall, key)

    if relevant_value is None:
        return overall_value

    if overall_value is None:
        return relevant_value

    return (
        venue_mix * relevant_value
        + (1.0 - venue_mix) * overall_value
    )


def construir_parametros(
    contexto: dict[str, Any],
    learned_component: dict[str, Any] | None,
    league_means: dict[str, float],
) -> dict[str, dict[str, Any]]:
    """
    Conserva los modelos base y agrega MODELO_APRENDIDO cuando existe
    latest_model.json para la competición.
    """

    local = contexto["home_averages"]
    visitante = contexto["away_averages"]
    local_overall = contexto["home_overall_averages"]
    visitante_overall = contexto["away_overall_averages"]

    local_learned = (
        local
        if int(contexto.get("home_relevant_matches") or 0) >= 2
        else local_overall
    )
    visitante_learned = (
        visitante
        if int(contexto.get("away_relevant_matches") or 0) >= 2
        else visitante_overall
    )

    lambda_home_xg = media_geometrica(
        valor_numerico(local, "xg_for"),
        valor_numerico(visitante, "xg_against"),
    )

    lambda_away_xg = media_geometrica(
        valor_numerico(visitante, "xg_for"),
        valor_numerico(local, "xg_against"),
    )

    lambda_home_goals = media_geometrica(
        valor_numerico(local, "goals_for"),
        valor_numerico(visitante, "goals_against"),
    )

    lambda_away_goals = media_geometrica(
        valor_numerico(visitante, "goals_for"),
        valor_numerico(local, "goals_against"),
    )

    bot10_context = contexto.get("bot10_context")
    bot10_markets = (
        bot10_context.get("markets", {})
        if isinstance(bot10_context, dict)
        else {}
    )
    context_goals = bot10_markets.get("goals")
    context_xg = bot10_markets.get("xg")
    context_goals_used = False
    context_xg_used = False

    if isinstance(context_goals, dict):
        context_home = valor_numerico(context_goals, "home")
        context_away = valor_numerico(context_goals, "away")
        if context_home is not None and context_away is not None:
            lambda_home_goals = context_home
            lambda_away_goals = context_away
            context_goals_used = True

    if isinstance(context_xg, dict):
        context_home = valor_numerico(context_xg, "home")
        context_away = valor_numerico(context_xg, "away")
        if context_home is not None and context_away is not None:
            lambda_home_xg = context_home
            lambda_away_xg = context_away
            context_xg_used = True

    modelos: dict[str, dict[str, Any]] = {}

    if learned_component:
        parameters = learned_component.get("parameters", {})

        venue_mix = numeric_parameter(
            parameters,
            "venue_mix",
            0.70,
            minimum=0.0,
            maximum=1.0,
        )
        xg_weight = numeric_parameter(
            parameters,
            "xg_weight",
            0.65,
            minimum=0.0,
            maximum=1.0,
        )
        shrinkage = numeric_parameter(
            parameters,
            "league_shrinkage",
            0.20,
            minimum=0.0,
            maximum=0.70,
        )
        home_advantage = numeric_parameter(
            parameters,
            "home_advantage",
            1.08,
            minimum=0.85,
            maximum=1.30,
        )

        home_goals_for = mezclar_valores(
            local_learned,
            local_overall,
            "goals_for",
            venue_mix,
        )
        home_goals_against = mezclar_valores(
            local_learned,
            local_overall,
            "goals_against",
            venue_mix,
        )
        away_goals_for = mezclar_valores(
            visitante_learned,
            visitante_overall,
            "goals_for",
            venue_mix,
        )
        away_goals_against = mezclar_valores(
            visitante_learned,
            visitante_overall,
            "goals_against",
            venue_mix,
        )

        home_xg_for = mezclar_valores(
            local_learned,
            local_overall,
            "xg_for",
            venue_mix,
        )
        home_xg_against = mezclar_valores(
            local_learned,
            local_overall,
            "xg_against",
            venue_mix,
        )
        away_xg_for = mezclar_valores(
            visitante_learned,
            visitante_overall,
            "xg_for",
            venue_mix,
        )
        away_xg_against = mezclar_valores(
            visitante_learned,
            visitante_overall,
            "xg_against",
            venue_mix,
        )

        learned_goals_home = media_geometrica(
            home_goals_for,
            away_goals_against,
        )
        learned_goals_away = media_geometrica(
            away_goals_for,
            home_goals_against,
        )
        learned_xg_home = media_geometrica(
            home_xg_for,
            away_xg_against,
        )
        learned_xg_away = media_geometrica(
            away_xg_for,
            home_xg_against,
        )

        if context_goals_used:
            learned_goals_home = lambda_home_goals
            learned_goals_away = lambda_away_goals
        if context_xg_used:
            learned_xg_home = lambda_home_xg
            learned_xg_away = lambda_away_xg

        if learned_goals_home is None:
            learned_goals_home = league_means["home_goals"]
        if learned_goals_away is None:
            learned_goals_away = league_means["away_goals"]
        if learned_xg_home is None:
            learned_xg_home = learned_goals_home
        if learned_xg_away is None:
            learned_xg_away = learned_goals_away

        learned_home = (
            (1.0 - xg_weight) * learned_goals_home
            + xg_weight * learned_xg_home
        )
        learned_away = (
            (1.0 - xg_weight) * learned_goals_away
            + xg_weight * learned_xg_away
        )

        learned_home = (
            (1.0 - shrinkage) * learned_home
            + shrinkage * league_means["home_goals"]
        ) * home_advantage
        learned_away = (
            (1.0 - shrinkage) * learned_away
            + shrinkage * league_means["away_goals"]
        )

        modelos["MODELO_APRENDIDO"] = {
            "lambda_home": float(
                np.clip(learned_home, MIN_LAMBDA, MAX_LAMBDA)
            ),
            "lambda_away": float(
                np.clip(learned_away, MIN_LAMBDA, MAX_LAMBDA)
            ),
            "source": (
                "Parámetros aprendidos con validación temporal: mezcla "
                "local/visitante, peso de xG, contracción a la media "
                "de liga y ventaja local."
            ),
            "learned_parameters": {
                "venue_mix": venue_mix,
                "xg_weight": xg_weight,
                "league_shrinkage": shrinkage,
                "home_advantage": home_advantage,
            },
        }

    if (
        lambda_home_xg is not None
        and lambda_away_xg is not None
    ):
        modelos["MODELO_XG"] = {
            "lambda_home": lambda_home_xg,
            "lambda_away": lambda_away_xg,
            "source": (
                str(context_xg.get("source") or "contexto UEFA/doméstico")
                if context_xg_used and isinstance(context_xg, dict)
                else (
                    "Modelo base: media geométrica entre producción xG propia "
                    "y xG concedido por el rival."
                )
            ),
            "context": dict(context_xg) if context_xg_used else None,
        }

    if (
        lambda_home_goals is not None
        and lambda_away_goals is not None
    ):
        modelos["MODELO_GOLES"] = {
            "lambda_home": lambda_home_goals,
            "lambda_away": lambda_away_goals,
            "source": (
                str(context_goals.get("source") or "contexto UEFA/doméstico")
                if context_goals_used and isinstance(context_goals, dict)
                else (
                    "Modelo base: media geométrica entre goles propios "
                    "y goles concedidos por el rival."
                )
            ),
            "context": dict(context_goals) if context_goals_used else None,
        }

    if not modelos:
        raise RuntimeError(
            "No hay suficientes datos para construir ningún modelo."
        )

    return modelos


# ==============================================================================
# 4. AJUSTE DE RHO CON DATOS HISTÓRICOS
# ==============================================================================

def get_connection() -> sqlite3.Connection:
    if not DB_PATH.exists():
        raise FileNotFoundError(
            f"No se encontró la base de datos:\n{DB_PATH}"
        )

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def resolver_league_id(
    conn: sqlite3.Connection,
    contexto: dict[str, Any],
    competition_key: str | None,
    trained_model: dict[str, Any] | None,
) -> int:
    """Resuelve la liga aunque ratings antiguos no incluyan league_id."""

    candidates: list[Any] = [
        contexto.get("home_team", {}).get("league_id"),
        contexto.get("away_team", {}).get("league_id"),
        contexto.get("match", {}).get("league_id"),
    ]

    if isinstance(trained_model, dict):
        candidates.append(
            trained_model.get("competition", {}).get("league_id")
        )

    for candidate in candidates:
        try:
            if candidate is not None:
                return int(candidate)
        except (TypeError, ValueError):
            continue

    match = contexto.get("match", {})
    sofascore_ids: list[int] = []

    for source in (
        contexto.get("home_team", {}),
        contexto.get("away_team", {}),
        match,
    ):
        if not isinstance(source, dict):
            continue

        fields = (
            ("sofascore_id",),
            ("home_team_id", "away_team_id")
            if source is match
            else (),
        )

        for field_group in fields:
            for field in field_group:
                try:
                    value = source.get(field)
                    if value is not None:
                        sofascore_ids.append(int(value))
                except (TypeError, ValueError):
                    continue

    sofascore_ids = list(dict.fromkeys(sofascore_ids))

    if sofascore_ids:
        placeholders = ",".join("?" for _ in sofascore_ids)
        row = conn.execute(
            f"""
            SELECT league_id, COUNT(*) AS coincidences
            FROM teams
            WHERE sofascore_id IN ({placeholders})
              AND league_id IS NOT NULL
            GROUP BY league_id
            ORDER BY coincidences DESC, league_id DESC
            LIMIT 1;
            """,
            tuple(sofascore_ids),
        ).fetchone()

        if row is not None and row["league_id"] is not None:
            return int(row["league_id"])

    internal_ids: list[int] = []

    for team_key in ("home_team", "away_team"):
        try:
            value = contexto.get(team_key, {}).get("team_id")
            if value is not None:
                internal_ids.append(int(value))
        except (TypeError, ValueError):
            continue

    internal_ids = list(dict.fromkeys(internal_ids))

    if internal_ids:
        placeholders = ",".join("?" for _ in internal_ids)
        row = conn.execute(
            f"""
            SELECT league_id, COUNT(*) AS coincidences
            FROM teams
            WHERE team_id IN ({placeholders})
              AND league_id IS NOT NULL
            GROUP BY league_id
            ORDER BY coincidences DESC, league_id DESC
            LIMIT 1;
            """,
            tuple(internal_ids),
        ).fetchone()

        if row is not None and row["league_id"] is not None:
            return int(row["league_id"])

    if competition_key:
        registry_path = DATA_DIR / "competitions.json"

        try:
            registry = leer_json(registry_path)
        except Exception:
            registry = {}

        competitions = registry.get("competitions", [])
        competition_name = None

        if isinstance(competitions, list):
            for item in competitions:
                if not isinstance(item, dict):
                    continue

                key = str(item.get("key") or "").strip().lower()

                if key == str(competition_key).strip().lower():
                    competition_name = str(item.get("name") or "").strip()
                    break

        if competition_name:
            row = conn.execute(
                """
                SELECT league_id
                FROM leagues
                WHERE LOWER(name) = LOWER(?)
                ORDER BY league_id DESC
                LIMIT 1;
                """,
                (competition_name,),
            ).fetchone()

            if row is not None and row["league_id"] is not None:
                return int(row["league_id"])

    raise RuntimeError(
        "No se pudo resolver league_id para el partido. "
        "Vuelve a generar ratings.py o revisa teams/leagues en SQLite."
    )


def cargar_medias_liga(
    conn: sqlite3.Connection,
    league_id: int | list[int] | tuple[int, ...] | set[int],
    before_kickoff: str | None,
) -> dict[str, float]:
    if isinstance(league_id, (list, tuple, set)):
        league_ids = sorted({int(value) for value in league_id})
    else:
        league_ids = [int(league_id)]
    if not league_ids:
        raise RuntimeError("No hay league_ids para calcular las medias de liga.")

    placeholders = ",".join("?" for _ in league_ids)
    filters = [
        f"m.league_id IN ({placeholders})",
        "m.status = 'FT'",
        "m.home_goals IS NOT NULL",
        "m.away_goals IS NOT NULL",
    ]
    params: list[Any] = list(league_ids)

    if before_kickoff:
        filters.append("m.kickoff < ?")
        params.append(before_kickoff)

    row = conn.execute(
        f"""
        SELECT
            AVG(m.home_goals) AS home_goals,
            AVG(m.away_goals) AS away_goals
        FROM matches AS m
        WHERE {" AND ".join(filters)};
        """,
        tuple(params),
    ).fetchone()

    home_goals = float(row["home_goals"] or 1.45)
    away_goals = float(row["away_goals"] or 1.15)
    return {
        "home_goals": home_goals,
        "away_goals": away_goals,
    }

def cargar_partidos_para_rho(
    conn: sqlite3.Connection,
) -> list[dict[str, Any]]:
    """
    Usa los partidos con resultado y xG para estimar un rho global.
    La estimación no conoce cuotas ni decisiones de apuestas.
    """

    filas = conn.execute(
        """
        SELECT
            m.match_id,
            m.sofascore_id AS event_id,
            m.home_goals,
            m.away_goals,
            home_stats.xg_for AS home_xg,
            away_stats.xg_for AS away_xg,
            home_stats.goals_for AS home_goals_stats,
            away_stats.goals_for AS away_goals_stats
        FROM matches AS m
        INNER JOIN team_match_stats AS home_stats
            ON home_stats.match_id = m.match_id
            AND home_stats.venue = 'HOME'
        INNER JOIN team_match_stats AS away_stats
            ON away_stats.match_id = m.match_id
            AND away_stats.venue = 'AWAY'
        WHERE
            m.status = 'FT'
            AND m.home_goals IS NOT NULL
            AND m.away_goals IS NOT NULL
        ORDER BY m.kickoff ASC;
        """
    ).fetchall()

    resultado: list[dict[str, Any]] = []

    for fila in filas:
        partido = dict(fila)

        home_lambda = partido.get("home_xg")
        away_lambda = partido.get("away_xg")
        fuente = "xG"

        if home_lambda is None or away_lambda is None:
            home_lambda = partido.get("home_goals_stats")
            away_lambda = partido.get("away_goals_stats")
            fuente = "goles observados"

        if home_lambda is None or away_lambda is None:
            continue

        try:
            home_lambda = float(home_lambda)
            away_lambda = float(away_lambda)
        except (TypeError, ValueError):
            continue

        if home_lambda <= 0 or away_lambda <= 0:
            continue

        partido["lambda_home"] = float(
            np.clip(home_lambda, MIN_LAMBDA, MAX_LAMBDA)
        )
        partido["lambda_away"] = float(
            np.clip(away_lambda, MIN_LAMBDA, MAX_LAMBDA)
        )
        partido["lambda_source"] = fuente

        resultado.append(partido)

    return resultado


def tau_dixon_coles(
    home_goals: int,
    away_goals: int,
    lambda_home: float,
    lambda_away: float,
    rho: float,
) -> float:
    """
    Corrección Dixon-Coles para resultados bajos.
    """

    if home_goals == 0 and away_goals == 0:
        return 1.0 - (
            lambda_home
            * lambda_away
            * rho
        )

    if home_goals == 0 and away_goals == 1:
        return 1.0 + (
            lambda_home
            * rho
        )

    if home_goals == 1 and away_goals == 0:
        return 1.0 + (
            lambda_away
            * rho
        )

    if home_goals == 1 and away_goals == 1:
        return 1.0 - rho

    return 1.0


def negative_log_likelihood_rho(
    rho: float,
    partidos: list[dict[str, Any]],
) -> float:
    total = 0.0

    for partido in partidos:
        goles_local = int(partido["home_goals"])
        goles_visitante = int(partido["away_goals"])
        lambda_local = float(partido["lambda_home"])
        lambda_visitante = float(partido["lambda_away"])

        tau = tau_dixon_coles(
            goles_local,
            goles_visitante,
            lambda_local,
            lambda_visitante,
            rho,
        )

        if tau <= 0 or not math.isfinite(tau):
            return 1e12

        probabilidad = (
            poisson.pmf(
                goles_local,
                lambda_local,
            )
            * poisson.pmf(
                goles_visitante,
                lambda_visitante,
            )
            * tau
        )

        if probabilidad <= 0 or not math.isfinite(probabilidad):
            return 1e12

        total -= math.log(probabilidad)

    return total


def estimar_rho(
    partidos: list[dict[str, Any]],
) -> dict[str, Any]:
    """
    Ajusta rho por máxima verosimilitud.
    Con pocos partidos, el resultado debe considerarse provisional.
    """

    if len(partidos) < 10:
        return {
            "rho": 0.0,
            "matches_used": len(partidos),
            "optimized": False,
            "message": (
                "Muestra insuficiente para ajustar rho; "
                "se utiliza rho=0.0."
            ),
        }

    resultado = minimize_scalar(
        negative_log_likelihood_rho,
        bounds=(RHO_MIN, RHO_MAX),
        args=(partidos,),
        method="bounded",
        options={
            "xatol": 1e-6,
            "maxiter": 500,
        },
    )

    if not resultado.success:
        return {
            "rho": 0.0,
            "matches_used": len(partidos),
            "optimized": False,
            "message": (
                "La optimización no convergió; "
                "se utiliza rho=0.0."
            ),
        }

    rho = float(
        np.clip(
            resultado.x,
            RHO_MIN,
            RHO_MAX,
        )
    )

    return {
        "rho": round(rho, 6),
        "matches_used": len(partidos),
        "optimized": True,
        "negative_log_likelihood": round(
            float(resultado.fun),
            6,
        ),
        "message": (
            "Rho estimado con los partidos disponibles "
            "en oddshunter.db."
        ),
    }


# ==============================================================================
# 5. MATRIZ POISSON + DIXON-COLES
# ==============================================================================

def crear_matriz(
    lambda_home: float,
    lambda_away: float,
    rho: float,
    max_goals: int = MAX_GOALS,
) -> np.ndarray:
    probabilidades_home = poisson.pmf(
        np.arange(max_goals + 1),
        lambda_home,
    )

    probabilidades_away = poisson.pmf(
        np.arange(max_goals + 1),
        lambda_away,
    )

    matriz = np.outer(
        probabilidades_home,
        probabilidades_away,
    )

    for home_goals in range(
        min(2, max_goals) + 1
    ):
        for away_goals in range(
            min(2, max_goals) + 1
        ):
            matriz[
                home_goals,
                away_goals,
            ] *= tau_dixon_coles(
                home_goals,
                away_goals,
                lambda_home,
                lambda_away,
                rho,
            )

    # La truncación en MAX_GOALS deja una cola mínima fuera.
    # Normalizar asegura una distribución final de suma 1.
    suma = float(matriz.sum())

    if suma <= 0 or not math.isfinite(suma):
        raise RuntimeError(
            "La matriz de probabilidades no es válida."
        )

    matriz /= suma
    return matriz


def probabilidades_resultado(
    matriz: np.ndarray,
) -> dict[str, float]:
    home_win = float(np.tril(matriz, k=-1).sum())
    draw = float(np.trace(matriz))
    away_win = float(np.triu(matriz, k=1).sum())

    return {
        "home_win": round(home_win, 6),
        "draw": round(draw, 6),
        "away_win": round(away_win, 6),
    }


def distribucion_total_goles(
    matriz: np.ndarray,
) -> dict[str, float]:
    """
    Distribución exacta del total de goles.
    El último grupo representa MAX_GOALS o más.
    """

    max_index = matriz.shape[0] - 1
    resultado: dict[str, float] = {}

    for total in range(0, max_index + 1):
        prob = 0.0

        for home_goals in range(
            matriz.shape[0]
        ):
            away_goals = total - home_goals

            if 0 <= away_goals < matriz.shape[1]:
                prob += float(
                    matriz[
                        home_goals,
                        away_goals,
                    ]
                )

        resultado[str(total)] = round(
            prob,
            6,
        )

    prob_registrada = sum(resultado.values())
    resultado[f"{max_index + 1}+"] = round(
        max(0.0, 1.0 - prob_registrada),
        6,
    )

    return resultado


def top_marcadores(
    matriz: np.ndarray,
    limite: int = 10,
) -> list[dict[str, Any]]:
    marcadores: list[dict[str, Any]] = []

    for home_goals in range(
        matriz.shape[0]
    ):
        for away_goals in range(
            matriz.shape[1]
        ):
            marcadores.append(
                {
                    "home_goals": home_goals,
                    "away_goals": away_goals,
                    "probability": float(
                        matriz[
                            home_goals,
                            away_goals,
                        ]
                    ),
                }
            )

    marcadores.sort(
        key=lambda item: item["probability"],
        reverse=True,
    )

    return [
        {
            **item,
            "probability": round(
                item["probability"],
                6,
            ),
        }
        for item in marcadores[:limite]
    ]


def analizar_modelo(
    nombre: str,
    parametros: dict[str, Any],
    rho: float,
) -> dict[str, Any]:
    lambda_home = float(
        parametros["lambda_home"]
    )

    lambda_away = float(
        parametros["lambda_away"]
    )

    matriz = crear_matriz(
        lambda_home=lambda_home,
        lambda_away=lambda_away,
        rho=rho,
    )

    return {
        "model_name": nombre,
        "source": parametros["source"],
        "lambda_home": round(
            lambda_home,
            4,
        ),
        "lambda_away": round(
            lambda_away,
            4,
        ),
        "expected_total_goals": round(
            lambda_home + lambda_away,
            4,
        ),
        "rho": round(rho, 6),
        "outcome_probabilities": (
            probabilidades_resultado(
                matriz
            )
        ),
        "top_scorelines": top_marcadores(
            matriz,
            limite=10,
        ),
        "total_goals_distribution": (
            distribucion_total_goles(
                matriz
            )
        ),
        "matrix_max_goals_per_team": MAX_GOALS,
    }


# ==============================================================================
# 6. SALIDA
# ==============================================================================

def porcentaje(probabilidad: float) -> str:
    return f"{probabilidad * 100:.2f}%"


def imprimir_modelo(
    resultado: dict[str, Any],
    home_name: str,
    away_name: str,
) -> None:
    print()
    print("=" * 74)
    print(resultado["model_name"])
    print("=" * 74)
    print(resultado["source"])
    print()
    print(
        f"Lambda {home_name}: "
        f"{resultado['lambda_home']:.3f}"
    )
    print(
        f"Lambda {away_name}: "
        f"{resultado['lambda_away']:.3f}"
    )
    print(
        "Goles esperados totales: "
        f"{resultado['expected_total_goals']:.3f}"
    )
    print(
        f"Rho Dixon-Coles: "
        f"{resultado['rho']:.4f}"
    )

    probs = resultado[
        "outcome_probabilities"
    ]

    print()
    print("PROBABILIDADES DEL RESULTADO")
    print("-" * 74)
    print(
        f"{home_name:<32}: "
        f"{porcentaje(probs['home_win'])}"
    )
    print(
        f"{'Empate':<32}: "
        f"{porcentaje(probs['draw'])}"
    )
    print(
        f"{away_name:<32}: "
        f"{porcentaje(probs['away_win'])}"
    )

    print()
    print("MARCADORES MÁS PROBABLES")
    print("-" * 74)

    for posicion, marcador in enumerate(
        resultado["top_scorelines"],
        start=1,
    ):
        print(
            f"{posicion:02d}. "
            f"{home_name} "
            f"{marcador['home_goals']} - "
            f"{marcador['away_goals']} "
            f"{away_name} | "
            f"{porcentaje(marcador['probability'])}"
        )


def guardar_resultado(
    ratings_path: Path,
    contexto: dict[str, Any],
    rho_info: dict[str, Any],
    modelos: dict[str, Any],
    trained_metadata: dict[str, Any],
) -> Path:
    event_id = int(
        contexto["match"]["event_id"]
    )

    salida = {
        "generated_at": datetime.now(
            timezone.utc
        ).isoformat(),
        "source_ratings_file": str(
            ratings_path
        ),
        "upcoming_match": contexto["match"],
        "trained_model": trained_metadata,
        "methodology": {
            "models_are_separate": True,
            "learned_model_available": trained_metadata.get("available", False),
            "no_manual_blend": not trained_metadata.get("available", False),
            "lambda_combination": (
                "Media geométrica entre producción propia "
                "y concesión del rival en la condición "
                "local/visitante relevante."
            ),
            "dixon_coles_rho": rho_info,
            "note": (
                "Este es un modelo estadístico experimental. "
                "Debe evaluarse con backtesting antes de "
                "considerarlo fiable."
            ),
        },
        "models": modelos,
    }

    ruta = (
        MODELS_DIR
        / f"poisson_dixon_coles_{event_id}.json"
    )

    ruta.write_text(
        json.dumps(
            salida,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    ultima = (
        MODELS_DIR
        / "ultimo_poisson_dixon_coles.json"
    )

    ultima.write_text(
        json.dumps(
            salida,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    return ruta


# ==============================================================================
# 7. EJECUCIÓN PRINCIPAL
# ==============================================================================

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Modelo Poisson + Dixon-Coles con parámetros entrenados por liga."
        )
    )
    parser.add_argument(
        "ratings_json",
        nargs="?",
        help="Archivo ratings_*.json.",
    )
    parser.add_argument(
        "--key",
        help="Clave de competición, por ejemplo: mls.",
    )
    return parser


def main() -> None:
    args = build_parser().parse_args()

    try:
        ratings_path = seleccionar_ruta_ratings(
            args.ratings_json
        )
        ratings = leer_json(ratings_path)
        contexto = extraer_contexto(ratings)

        competition_key = infer_competition_key(
            ratings,
            args.key,
        )
        trained_model = None
        trained_path = DATA_DIR / "trained_models" / "UNKNOWN" / "latest_model.json"
        learned_component = None

        if competition_key:
            trained_model, trained_path = load_latest_model(
                competition_key
            )
            learned_component = component_parameters(
                trained_model,
                "goals",
            )

        trained_metadata = model_metadata(
            trained_model,
            trained_path,
            "goals",
        )
        trained_metadata["competition_key"] = competition_key

        conn = get_connection()

        try:
            league_id = resolver_league_id(
                conn=conn,
                contexto=contexto,
                competition_key=competition_key,
                trained_model=trained_model,
            )
            trained_league_ids = (
                trained_model.get("competition", {}).get("league_ids")
                if isinstance(trained_model, dict)
                else None
            )
            league_scope = (
                [int(value) for value in trained_league_ids]
                if isinstance(trained_league_ids, list) and trained_league_ids
                else [league_id]
            )
            league_means = cargar_medias_liga(
                conn,
                league_id=league_scope,
                before_kickoff=str(
                    contexto["match"].get("kickoff") or ""
                ) or None,
            )

            if learned_component:
                learned_parameters = learned_component.get(
                    "parameters",
                    {},
                )
                rho = numeric_parameter(
                    learned_parameters,
                    "dixon_coles_rho",
                    0.0,
                    minimum=RHO_MIN,
                    maximum=RHO_MAX,
                )
                rho_info = {
                    "rho": round(rho, 6),
                    "matches_used": trained_model.get("data", {}).get(
                        "train_samples"
                    ) if trained_model else None,
                    "optimized": True,
                    "source": "trained_model",
                    "model_version": trained_model.get("version") if trained_model else None,
                    "message": (
                        "Rho cargado desde latest_model.json y validado "
                        "en el bloque temporal reservado."
                    ),
                }
            else:
                partidos_rho = cargar_partidos_para_rho(conn)
                rho_info = estimar_rho(partidos_rho)
                rho = float(rho_info["rho"])

        finally:
            conn.close()

        parametros = construir_parametros(
            contexto,
            learned_component,
            league_means,
        )

        resultados: dict[str, Any] = {}

        for nombre, modelo in parametros.items():
            resultados[nombre] = analizar_modelo(
                nombre=nombre,
                parametros=modelo,
                rho=rho,
            )

        home_name = str(contexto["match"]["home_team"])
        away_name = str(contexto["match"]["away_team"])

        print("=" * 74)
        print("ODDSHUNTER — POISSON + DIXON-COLES")
        print("=" * 74)
        print(f"{home_name} vs {away_name}")
        print(f"Ratings usados: {ratings_path.name}")
        print(
            "Modelo entrenado: "
            + (
                f"SÍ | versión {trained_metadata.get('version')}"
                if trained_metadata.get("available")
                else "NO | se usan modelos base"
            )
        )
        print(f"Rho utilizado: {rho:.6f}")

        for resultado in resultados.values():
            imprimir_modelo(
                resultado=resultado,
                home_name=home_name,
                away_name=away_name,
            )

        ruta_salida = guardar_resultado(
            ratings_path=ratings_path,
            contexto=contexto,
            rho_info=rho_info,
            modelos=resultados,
            trained_metadata=trained_metadata,
        )

        print()
        print("=" * 74)
        print("✅ MODELOS CALCULADOS")
        print("=" * 74)
        print(f"Resultado guardado en:\n{ruta_salida}")
        print(
            "\nCopia actualizada también en:\n"
            f"{MODELS_DIR / 'ultimo_poisson_dixon_coles.json'}"
        )

    except KeyboardInterrupt:
        print("\n⚠️ Proceso interrumpido.")

    except Exception as exc:
        print()
        print(f"❌ Error: {type(exc).__name__}: {exc}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
