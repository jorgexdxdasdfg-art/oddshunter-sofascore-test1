from __future__ import annotations

import copy
import json
import os
import sys
from collections import deque
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from PySide6.QtCore import (
    QProcess,
    QProcessEnvironment,
    QTimer,
    Qt,
    QUrl,
)
from PySide6.QtGui import (
    QAction,
    QDesktopServices,
    QFont,
    QIcon,
)
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QComboBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSplitter,
    QStatusBar,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QToolBar,
    QVBoxLayout,
    QWidget,
)

from qprocess_safety import configure_hidden_windows_process as _configure_hidden_windows_process

# ODDSHUNTER_J1_SUMMARY_HISTORY_COUNT_V4
def _oh_j1_records_total_v4(competition_key, fallback):
    # Todas las demás competiciones, incluida Liga Portugal, quedan igual.
    if str(competition_key or "") != "j1-league":
        return fallback

    try:
        import json as _json
        import sqlite3 as _sqlite3
        from datetime import datetime as _Datetime, timedelta as _Timedelta, timezone as _Timezone
        from pathlib import Path as _Path

        root = _Path(__file__).resolve().parent
        data = root / "data"
        base = data / "competitions"
        db = data / "oddshunter.db"

        def _load(path):
            try:
                payload = _json.loads(path.read_text(encoding="utf-8-sig"))
            except Exception:
                return []
            if isinstance(payload, list):
                return payload
            if isinstance(payload, dict):
                for key in ("matches", "events", "partidos", "items", "results", "teams"):
                    rows = payload.get(key)
                    if isinstance(rows, list):
                        return rows
            return []

        def _int(value):
            try:
                return int(value)
            except Exception:
                return None

        def _eid(row):
            if not isinstance(row, dict):
                return None
            for key in ("event_id", "sofascore_id", "id", "eventId"):
                value = _int(row.get(key))
                if value is not None:
                    return value
            nested = row.get("event")
            return _int(nested.get("id")) if isinstance(nested, dict) else None

        def _ts(row):
            if not isinstance(row, dict):
                return None
            for key in ("start_timestamp", "startTimestamp"):
                value = _int(row.get(key))
                if value is not None:
                    return value
            value = row.get("kickoff") or row.get("date")
            if value:
                try:
                    dt = _Datetime.fromisoformat(str(value).replace("Z", "+00:00"))
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=_Timezone.utc)
                    return int(dt.timestamp())
                except Exception:
                    pass
            return None

        # Próximos/actuales visibles de J1.
        finished = _load(base / "j1-league" / "matches_finished.json")
        upcoming = _load(base / "j1-league" / "matches_upcoming.json")
        current_source_ids = set()
        for row in _load(base / "j1-league" / "teams.json"):
            if not isinstance(row, dict):
                continue
            for key in ("team_id", "sofascore_team_id", "sofascore_id", "source_team_id", "id"):
                value = _int(row.get(key))
                if value is not None:
                    current_source_ids.add(value)
                    break
        ids = set()
        for row in finished + upcoming:
            value = _eid(row)
            if value is not None:
                ids.add(str(value))

        # Misma referencia/ventana doméstica que usa J1/MLS.
        stamps = [value for row in upcoming if (value := _ts(row)) is not None]
        reference = min(stamps) if stamps else int(_Datetime.now(_Timezone.utc).timestamp())
        cutoff_iso = _Datetime.fromtimestamp(reference, tz=_Timezone.utc) - _Timedelta(days=365)
        before_iso = _Datetime.fromtimestamp(reference, tz=_Timezone.utc)

        # Contar SOLO históricos realmente existentes en SQLite y pertenecientes
        # a las 4 temporadas J1/J2 usadas por el modelo, no todos los catálogos.
        if db.exists():
            con = _sqlite3.connect(db)
            try:
                league_ids = set()
                for tournament_id, season_id in (
                    (196, 96370),
                    (196, 87931),
                    (196, 69871),
                    (402, 70418),
                ):
                    for row in con.execute(
                        "SELECT league_id FROM leagues WHERE source_tournament_id=? AND source_season_id=?",
                        (tournament_id, season_id),
                    ).fetchall():
                        league_ids.add(int(row[0]))

                if league_ids and current_source_ids:
                    ph = ",".join("?" for _ in league_ids)
                    sph = ",".join("?" for _ in current_source_ids)
                    internal_ids = [
                        int(row[0])
                        for row in con.execute(
                            f"SELECT team_id FROM teams WHERE sofascore_id IN ({sph})",
                            list(sorted(current_source_ids)),
                        ).fetchall()
                    ]
                    if internal_ids:
                        tph = ",".join("?" for _ in internal_ids)
                        query = (
                            "SELECT DISTINCT CAST(sofascore_id AS TEXT) "
                            "FROM matches "
                            f"WHERE league_id IN ({ph}) "
                            "AND kickoff >= ? AND kickoff < ? "
                            f"AND (home_team_id IN ({tph}) OR away_team_id IN ({tph})) "
                            "AND sofascore_id IS NOT NULL"
                        )
                        params = [
                            *sorted(league_ids),
                            cutoff_iso.isoformat(), before_iso.isoformat(),
                            *internal_ids, *internal_ids,
                        ]
                        for row in con.execute(query, params).fetchall():
                            if row[0] not in (None, ""):
                                ids.add(str(row[0]))
            finally:
                con.close()

        if ids:
            return str(len(ids))
    except Exception:
        pass

    return fallback

# ODDSHUNTER_LIGA_PORTUGAL_SUMMARY_HISTORY_COUNT_V3
def _oh_liga_portugal_records_total_v3(competition_key, fallback):
    # Todas las demás competiciones quedan exactamente igual.
    if str(competition_key or "") != "liga-portugal":
        return fallback

    try:
        import json as _json
        from pathlib import Path as _Path

        root = _Path(__file__).resolve().parent
        base = root / "data" / "competitions"

        sources = (
            base / "liga-portugal" / "matches_finished.json",
            base / "liga-portugal" / "matches_upcoming.json",
            base / "domestic-context-238-77806" / "matches_finished.json",
            base / "liga-portugal2-history-77801" / "matches_finished.json",
        )

        ids = set()

        for path in sources:
            if not path.exists():
                continue

            try:
                payload = _json.loads(
                    path.read_text(encoding="utf-8-sig")
                )
            except Exception:
                continue

            if isinstance(payload, list):
                rows = payload
            elif isinstance(payload, dict):
                rows = []
                for list_key in (
                    "matches",
                    "events",
                    "partidos",
                    "items",
                    "results",
                ):
                    candidate = payload.get(list_key)
                    if isinstance(candidate, list):
                        rows = candidate
                        break
            else:
                rows = []

            for row in rows:
                if not isinstance(row, dict):
                    continue

                eid = None
                for id_key in (
                    "event_id",
                    "sofascore_id",
                    "id",
                    "eventId",
                ):
                    candidate = row.get(id_key)
                    if candidate not in (None, ""):
                        eid = candidate
                        break

                if eid is None:
                    nested = row.get("event")
                    if isinstance(nested, dict):
                        eid = nested.get("id")

                if eid not in (None, ""):
                    ids.add(str(eid))

        if ids:
            return str(len(ids))
    except Exception:
        pass

    return fallback

# ==============================================================================
# 1. RUTAS
# ==============================================================================

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"

REGISTRY_PATH = DATA_DIR / "competitions.json"
RATINGS_PATH = DATA_DIR / "ratings" / "ultimo_ratings.json"
GOALS_MODEL_PATH = (
    DATA_DIR
    / "modelos"
    / "ultimo_poisson_dixon_coles.json"
)

APP_TITLE = "OddsHunter"
APP_VERSION = "2.1 aprendizaje continuo"


# ==============================================================================
# 2. ETIQUETAS
# ==============================================================================

METRIC_LABELS = {
    "goals_for": "Goles a favor",
    "goals_against": "Goles en contra",
    "xg_for": "xG a favor",
    "xg_against": "xG en contra",
    "shots": "Remates",
    "shots_on_target": "Remates al arco",
    "corners_for": "Córners a favor",
    "corners_against": "Córners en contra",
    "yellow_cards": "Tarjetas amarillas",
    "red_cards": "Tarjetas rojas",
    "possession": "Posesión",
    "fouls": "Faltas",
    "offsides": "Offsides",
    "big_chances": "Grandes ocasiones",
}

MODEL_LABELS = {
    "MODELO_APRENDIDO": "Modelo aprendido",
    "MODELO_XG": "Modelo xG",
    "MODELO_GOLES": "Modelo goles",
}


# ==============================================================================
# 3. UTILIDADES DE DATOS
# ==============================================================================

# ODDSHUNTER_PERFORMANCE_V4_4_1
_READ_JSON_CACHE: dict[str, tuple[tuple[int, int], dict[str, Any]]] = {}
_READ_JSON_CACHE_LIMIT = 192


def read_json(path: Path) -> dict[str, Any] | None:
    try:
        stat = path.stat()
        signature = (int(stat.st_mtime_ns), int(stat.st_size))
    except OSError:
        return None

    key = str(path.resolve())
    cached = _READ_JSON_CACHE.get(key)
    if cached is not None and cached[0] == signature:
        return copy.deepcopy(cached[1])

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None

    if not isinstance(data, dict):
        return None

    _READ_JSON_CACHE[key] = (signature, data)
    while len(_READ_JSON_CACHE) > _READ_JSON_CACHE_LIMIT:
        try:
            _READ_JSON_CACHE.pop(next(iter(_READ_JSON_CACHE)))
        except (StopIteration, KeyError):
            break

    return copy.deepcopy(data)


def format_number(
    value: Any,
    decimals: int = 2,
    suffix: str = "",
) -> str:
    if value is None:
        return "N/D"

    if isinstance(value, bool):
        return "Sí" if value else "No"

    try:
        number = float(value)
    except (TypeError, ValueError):
        return str(value)

    return f"{number:.{decimals}f}{suffix}"


def format_probability(value: Any) -> str:
    if value is None:
        return "N/D"

    try:
        number = float(value)
    except (TypeError, ValueError):
        return str(value)

    return f"{number * 100:.2f}%"


def format_datetime(value: Any) -> str:
    if value is None:
        return "N/D"

    text = str(value)

    try:
        normalized = text.replace("Z", "+00:00")
        parsed = datetime.fromisoformat(normalized)

        if parsed.tzinfo is not None:
            parsed = parsed.astimezone()

        return parsed.strftime("%Y-%m-%d %H:%M")
    except ValueError:
        return text


def nested_get(
    data: dict[str, Any] | None,
    *keys: str,
    default: Any = None,
) -> Any:
    current: Any = data

    for key in keys:
        if not isinstance(current, dict):
            return default

        current = current.get(key)

    return default if current is None else current


def set_item(
    table: QTableWidget,
    row: int,
    column: int,
    value: Any,
    alignment: Qt.AlignmentFlag | None = None,
) -> None:
    item = QTableWidgetItem(
        "" if value is None else str(value)
    )

    if alignment is not None:
        item.setTextAlignment(alignment)

    table.setItem(row, column, item)


def configure_table(
    table: QTableWidget,
    headers: list[str],
) -> None:
    table.setColumnCount(len(headers))
    table.setHorizontalHeaderLabels(headers)
    table.setAlternatingRowColors(True)
    table.setEditTriggers(
        QAbstractItemView.EditTrigger.NoEditTriggers
    )
    table.setSelectionBehavior(
        QAbstractItemView.SelectionBehavior.SelectRows
    )
    table.setSelectionMode(
        QAbstractItemView.SelectionMode.SingleSelection
    )
    table.verticalHeader().setVisible(False)
    table.horizontalHeader().setSectionResizeMode(
        QHeaderView.ResizeMode.Stretch
    )


# ==============================================================================
# 4. REPOSITORIO LOCAL
# ==============================================================================

class DataRepository:
    def __init__(self, base_dir: Path) -> None:
        self.base_dir = base_dir
        self.data_dir = base_dir / "data"

    def registry(self) -> dict[str, Any]:
        return read_json(
            self.data_dir / "competitions.json"
        ) or {"competitions": []}

    def competitions(self) -> list[dict[str, Any]]:
        raw = self.registry().get("competitions", [])

        if not isinstance(raw, list):
            return []

        return [
            competition
            for competition in raw
            if isinstance(competition, dict)
        ]

    def upcoming_schedule(
        self,
        key: str,
    ) -> dict[str, Any]:
        return read_json(
            self.data_dir
            / "competitions"
            / key
            / "matches_upcoming.json"
        ) or {
            "total_upcoming_matches": 0,
            "matches": [],
        }

    def analysis_index(
        self,
        key: str,
    ) -> dict[str, Any]:
        return read_json(
            self.data_dir
            / "analisis"
            / key
            / "index.json"
        ) or {
            "matches": [],
            "full": 0,
            "partial": 0,
            "errors": 0,
        }

    def analysis_bundle(
        self,
        key: str,
        event_id: int,
    ) -> dict[str, Any] | None:
        # ODDSHUNTER_UI_EVENT_MARKET_HYDRATION_V2_2_7
        event_id = int(event_id)
        event_dir = self.data_dir / "analisis" / key / str(event_id)
        bundle = read_json(event_dir / "analysis.json")
        if not isinstance(bundle, dict):
            bundle = {}

        # analysis.json is a snapshot assembled when the full analysis ran.
        # A model can be trained/promoted later and goals.json regenerated
        # independently.  In that case the old snapshot still has the two
        # baseline models and used to be accepted as "valid", hiding the
        # newer MODELO_APRENDIDO from the UI.
        trained = self.trained_model(key)
        trained_goals = (
            trained.get("goals")
            if isinstance(trained, dict)
            else None
        )
        learned_goals_required = (
            isinstance(trained_goals, dict)
            and isinstance(trained_goals.get("parameters"), dict)
        )

        def _numbers(obj: Any, wanted: set[str]) -> list[float]:
            out: list[float] = []
            if isinstance(obj, dict):
                for k, v in obj.items():
                    if k in wanted and v is not None:
                        try:
                            out.append(float(v))
                        except (TypeError, ValueError):
                            pass
                    out.extend(_numbers(v, wanted))
            elif isinstance(obj, list):
                for v in obj:
                    out.extend(_numbers(v, wanted))
            return out

        def _valid(market: str, doc: Any) -> bool:
            if not isinstance(doc, dict):
                return False
            if market == "ratings":
                return (
                    isinstance(doc.get("home_team_analysis"), dict)
                    and isinstance(doc.get("away_team_analysis"), dict)
                )
            if market == "goals":
                models = doc.get("models")
                if isinstance(models, dict):
                    if learned_goals_required:
                        learned = models.get("MODELO_APRENDIDO")
                        if not (
                            isinstance(learned, dict)
                            and learned.get("lambda_home") is not None
                            and learned.get("lambda_away") is not None
                        ):
                            return False
                    for model in models.values():
                        if (
                            isinstance(model, dict)
                            and model.get("lambda_home") is not None
                            and model.get("lambda_away") is not None
                        ):
                            return True
                return False
            if market == "corners":
                analysis = doc.get("analysis")
                if not isinstance(analysis, dict):
                    return False
                home = analysis.get("home_team")
                away = analysis.get("away_team")
                return (
                    isinstance(home, dict)
                    and isinstance(away, dict)
                    and home.get("expected_corners") is not None
                    and away.get("expected_corners") is not None
                )
            if market == "cards":
                analysis = doc.get("analysis")
                if not isinstance(analysis, dict):
                    return False
                home = analysis.get("home_team")
                away = analysis.get("away_team")
                return (
                    isinstance(home, dict)
                    and isinstance(away, dict)
                    and home.get("expected_yellow_cards") is not None
                    and away.get("expected_yellow_cards") is not None
                )
            if market == "shots":
                return len(_numbers(
                    doc,
                    {
                        "expected_shots",
                        "home_expected_shots",
                        "away_expected_shots",
                        "shots_home",
                        "shots_away",
                    },
                )) >= 2
            if market == "elo":
                return len(_numbers(
                    doc,
                    {"home_elo", "away_elo", "elo_home", "elo_away"},
                )) >= 2
            return bool(doc)

        def _candidates(market: str) -> list[Path]:
            result: list[Path] = []
            model_dir = self.data_dir / "modelos" / market / key
            direct = [
                event_dir / f"{market}.json",
                event_dir / f"{market}_{event_id}.json",
                model_dir / f"{market}_{event_id}.json",
                model_dir / f"{event_id}.json",
            ]
            if market == "ratings":
                direct.insert(0, event_dir / "ratings.json")
            if market == "goals":
                direct.extend([
                    event_dir / "goals_model.json",
                    self.data_dir / "modelos" / "goals" / key / f"goals_{event_id}.json",
                ])

            for path in direct:
                if path not in result:
                    result.append(path)

            if model_dir.exists():
                for path in sorted(model_dir.glob(f"*{event_id}*.json")):
                    if path not in result:
                        result.append(path)
            return result

        hydrated: dict[str, str] = {}
        for market in ("ratings", "goals", "corners", "cards", "shots", "elo"):
            if _valid(market, bundle.get(market)):
                continue
            for path in _candidates(market):
                doc = read_json(path)
                if _valid(market, doc):
                    bundle[market] = doc
                    hydrated[market] = str(path)
                    break

        if hydrated:
            bundle["_ui_hydrated_event_markets_v2_2_7"] = hydrated

        return bundle or None

    def trained_model(
        self,
        key: str,
    ) -> dict[str, Any] | None:
        return read_json(
            self.data_dir
            / "trained_models"
            / key
            / "latest_model.json"
        )

    def ratings(self) -> dict[str, Any] | None:
        return read_json(RATINGS_PATH)

    def goals_model(self) -> dict[str, Any] | None:
        return read_json(GOALS_MODEL_PATH)

    def corners_model(
        self,
        key: str,
    ) -> dict[str, Any] | None:
        return read_json(
            self.data_dir
            / "modelos"
            / "corners"
            / key
            / "ultimo_corners.json"
        )

    def cards_model(
        self,
        key: str,
    ) -> dict[str, Any] | None:
        return read_json(
            self.data_dir
            / "modelos"
            / "cards"
            / key
            / "ultimo_cards.json"
        )

    def goals_backtesting(
        self,
        key: str,
    ) -> dict[str, Any] | None:
        candidates = [
            (
                self.data_dir
                / "backtesting"
                / key
                / "backtesting_walk_forward.json"
            ),
            (
                self.data_dir
                / "backtesting"
                / "backtesting_walk_forward.json"
            ),
        ]

        for path in candidates:
            data = read_json(path)

            if data is not None:
                return data

        return None

    def corners_backtesting(
        self,
        key: str,
    ) -> dict[str, Any] | None:
        return read_json(
            self.data_dir
            / "backtesting"
            / "corners"
            / key
            / "corners_backtesting_walk_forward.json"
        )

    def cards_backtesting(
        self,
        key: str,
    ) -> dict[str, Any] | None:
        return read_json(
            self.data_dir
            / "backtesting"
            / "cards"
            / key
            / "cards_backtesting_walk_forward.json"
        )

    def upcoming_match(
        self,
        *documents: dict[str, Any] | None,
    ) -> dict[str, Any] | None:
        for document in documents:
            if not isinstance(document, dict):
                continue

            for key in ("upcoming_match", "evento"):
                event = document.get(key)

                if isinstance(event, dict):
                    return event

        return None


# ==============================================================================
# 5. ELEMENTOS VISUALES
# ==============================================================================

class StatCard(QFrame):
    def __init__(
        self,
        title: str,
        value: str = "N/D",
        subtitle: str = "",
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)

        self.setObjectName("statCard")
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Fixed,
        )

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.setSpacing(4)

        self.title_label = QLabel(title)
        self.title_label.setObjectName("cardTitle")

        self.value_label = QLabel(value)
        self.value_label.setObjectName("cardValue")
        self.value_label.setWordWrap(True)

        self.subtitle_label = QLabel(subtitle)
        self.subtitle_label.setObjectName("cardSubtitle")
        self.subtitle_label.setWordWrap(True)

        layout.addWidget(self.title_label)
        layout.addWidget(self.value_label)
        layout.addWidget(self.subtitle_label)

    def set_content(
        self,
        value: str,
        subtitle: str = "",
    ) -> None:
        self.value_label.setText(value)
        self.subtitle_label.setText(subtitle)


@dataclass
class ProcessTask:
    title: str
    script: str
    arguments: list[str]
    stdin_text: str | None = None


# ==============================================================================
# 6. VENTANA PRINCIPAL
# ==============================================================================

class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()

        self.repository = DataRepository(BASE_DIR)
        self.process: QProcess | None = None
        self.process_queue: deque[ProcessTask] = deque()
        self.current_task: ProcessTask | None = None
        self.action_buttons: list[QPushButton] = []

        self.setWindowTitle(
            f"{APP_TITLE} — {APP_VERSION}"
        )
        self.resize(1500, 900)
        self.setMinimumSize(1120, 720)

        self._build_toolbar()
        self._build_ui()
        self._build_statusbar()
        self._apply_style()

        self.load_competitions()
        # refresh_all() ya recarga próximos; evitar una segunda carga idéntica
        # durante el arranque reduce I/O y consultas sin cambiar el resultado.
        self.refresh_all()

    # --------------------------------------------------------------------------
    # CONSTRUCCIÓN DE UI
    # --------------------------------------------------------------------------

    def _build_toolbar(self) -> None:
        toolbar = QToolBar("Principal")
        toolbar.setMovable(False)
        toolbar.setToolButtonStyle(
            Qt.ToolButtonStyle.ToolButtonTextBesideIcon
        )
        self.addToolBar(toolbar)

        refresh_action = QAction(
            "Actualizar vista",
            self,
        )
        refresh_action.triggered.connect(
            self.refresh_all
        )

        open_data_action = QAction(
            "Abrir carpeta data",
            self,
        )
        open_data_action.triggered.connect(
            self.open_data_folder
        )

        clear_console_action = QAction(
            "Limpiar consola",
            self,
        )
        clear_console_action.triggered.connect(
            lambda: self.console.clear()
        )

        toolbar.addAction(refresh_action)
        toolbar.addAction(open_data_action)
        toolbar.addSeparator()
        toolbar.addAction(clear_console_action)

    def _build_ui(self) -> None:
        central = QWidget()
        self.setCentralWidget(central)

        root_layout = QVBoxLayout(central)
        root_layout.setContentsMargins(12, 12, 12, 12)
        root_layout.setSpacing(10)

        root_layout.addWidget(
            self._build_header_panel()
        )

        splitter = QSplitter(
            Qt.Orientation.Horizontal
        )

        splitter.addWidget(
            self._build_actions_panel()
        )

        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.setMovable(False)

        self.tabs.addTab(
            self._build_summary_tab(),
            "Resumen",
        )
        self.tabs.addTab(
            self._build_upcoming_tab(),
            "Próximos",
        )
        self.tabs.addTab(
            self._build_statistics_tab(),
            "Estadísticas",
        )
        self.tabs.addTab(
            self._build_goals_tab(),
            "Goles",
        )
        self.tabs.addTab(
            self._build_corners_tab(),
            "Córners",
        )
        self.tabs.addTab(
            self._build_cards_tab(),
            "Tarjetas",
        )
        self.tabs.addTab(
            self._build_backtesting_tab(),
            "Backtesting",
        )
        self.tabs.addTab(
            self._build_console_tab(),
            "Consola",
        )

        splitter.addWidget(self.tabs)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([330, 1150])

        root_layout.addWidget(splitter, 1)

    def _build_header_panel(self) -> QWidget:
        panel = QFrame()
        panel.setObjectName("headerPanel")

        layout = QGridLayout(panel)
        layout.setContentsMargins(18, 14, 18, 14)
        layout.setHorizontalSpacing(14)
        layout.setVerticalSpacing(8)

        title = QLabel(APP_TITLE)
        title.setObjectName("mainTitle")

        subtitle = QLabel(
            "Panel local para estadísticas, modelos "
            "y validación histórica por competición"
        )
        subtitle.setObjectName("mainSubtitle")

        self.competition_combo = QComboBox()
        self.competition_combo.setMinimumWidth(360)
        self.competition_combo.currentIndexChanged.connect(
            self.on_competition_changed
        )

        self.upcoming_combo = QComboBox()
        self.upcoming_combo.setMinimumWidth(410)
        self.upcoming_combo.currentIndexChanged.connect(
            self.on_upcoming_selected
        )

        self.refresh_upcoming_button = QPushButton(
            "Actualizar próximos"
        )
        self.refresh_upcoming_button.clicked.connect(
            self.run_sync_upcoming_matches
        )

        self.url_input = QLineEdit()
        self.url_input.setPlaceholderText(
            "Pega aquí la URL del próximo partido de SofaScore"
        )

        self.browse_match_button = QPushButton(
            "Elegir JSON"
        )
        self.browse_match_button.clicked.connect(
            self.choose_match_json
        )

        layout.addWidget(title, 0, 0, 1, 2)
        layout.addWidget(subtitle, 1, 0, 2, 2)

        layout.addWidget(
            QLabel("Competición:"),
            0,
            2,
        )
        layout.addWidget(
            self.competition_combo,
            0,
            3,
        )

        layout.addWidget(
            QLabel("Partido detectado:"),
            1,
            2,
        )
        layout.addWidget(
            self.upcoming_combo,
            1,
            3,
        )
        layout.addWidget(
            self.refresh_upcoming_button,
            1,
            4,
        )

        layout.addWidget(
            QLabel("URL / JSON:"),
            2,
            2,
        )
        layout.addWidget(
            self.url_input,
            2,
            3,
        )
        layout.addWidget(
            self.browse_match_button,
            2,
            4,
        )

        layout.setColumnStretch(1, 1)
        layout.setColumnStretch(3, 2)

        return panel

    def _build_actions_panel(self) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setMinimumWidth(310)
        scroll.setMaximumWidth(390)

        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(10)

        match_group = QGroupBox(
            "Flujo del próximo partido"
        )
        match_layout = QVBoxLayout(match_group)

        self._add_action_button(
            match_layout,
            "1. Obtener historiales",
            self.run_history,
        )
        self._add_action_button(
            match_layout,
            "2. Importar historiales",
            self.run_history_import,
        )
        self._add_action_button(
            match_layout,
            "3. Calcular ratings",
            self.run_ratings,
        )
        self._add_action_button(
            match_layout,
            "4. Modelo de goles",
            self.run_goals_model,
        )
        self._add_action_button(
            match_layout,
            "5. Modelo de córners",
            self.run_corners_model,
        )
        self._add_action_button(
            match_layout,
            "6. Modelo de tarjetas",
            self.run_cards_model,
        )

        full_button = QPushButton(
            "Ejecutar análisis completo"
        )
        full_button.setObjectName("primaryButton")
        full_button.clicked.connect(
            self.run_complete_analysis
        )
        self.action_buttons.append(full_button)
        match_layout.addWidget(full_button)

        league_group = QGroupBox(
            "Base de la competición"
        )
        league_layout = QVBoxLayout(league_group)

        train_button = QPushButton(
            "Reentrenar modelo de la liga"
        )
        train_button.clicked.connect(
            self.run_train_models
        )
        self.action_buttons.append(train_button)
        league_layout.addWidget(train_button)

        analyze_all_button = QPushButton(
            "Analizar todos los próximos"
        )
        analyze_all_button.setObjectName("primaryButton")
        analyze_all_button.clicked.connect(
            self.run_analyze_upcoming_matches
        )
        self.action_buttons.append(analyze_all_button)
        league_layout.addWidget(analyze_all_button)

        self._add_action_button(
            league_layout,
            "Actualizar próximos y analizarlos",
            self.run_sync_upcoming_matches,
        )

        update_all_button = QPushButton(
            "Actualizar TODO y analizar"
        )
        update_all_button.setObjectName("primaryButton")
        update_all_button.clicked.connect(
            self.run_update_everything
        )
        self.action_buttons.append(update_all_button)
        league_layout.addWidget(update_all_button)

        self._add_action_button(
            league_layout,
            "Sincronizar calendario",
            self.run_sync_competition,
        )
        self._add_action_button(
            league_layout,
            "Importar estadísticas",
            self.run_import_competition,
        )

        backtesting_group = QGroupBox(
            "Validación histórica"
        )
        backtesting_layout = QVBoxLayout(
            backtesting_group
        )

        self._add_action_button(
            backtesting_layout,
            "Backtesting de goles",
            self.run_goals_backtesting,
        )
        self._add_action_button(
            backtesting_layout,
            "Backtesting de córners",
            self.run_corners_backtesting,
        )
        self._add_action_button(
            backtesting_layout,
            "Backtesting de tarjetas",
            self.run_cards_backtesting,
        )

        management_group = QGroupBox(
            "Gestión"
        )
        management_layout = QVBoxLayout(
            management_group
        )

        stop_button = QPushButton(
            "Detener proceso actual"
        )
        stop_button.setObjectName("dangerButton")
        stop_button.clicked.connect(
            self.stop_current_process
        )
        management_layout.addWidget(stop_button)

        open_output_button = QPushButton(
            "Abrir resultados"
        )
        open_output_button.clicked.connect(
            self.open_results_folder
        )
        management_layout.addWidget(
            open_output_button
        )

        layout.addWidget(match_group)
        layout.addWidget(league_group)
        layout.addWidget(backtesting_group)
        layout.addWidget(management_group)
        layout.addStretch(1)

        scroll.setWidget(content)
        return scroll

    def _add_action_button(
        self,
        layout: QVBoxLayout,
        text: str,
        callback: Any,
    ) -> QPushButton:
        button = QPushButton(text)
        button.clicked.connect(callback)
        self.action_buttons.append(button)
        layout.addWidget(button)
        return button

    def _build_summary_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        self.match_title = QLabel(
            "No hay próximo partido cargado"
        )
        self.match_title.setObjectName("matchTitle")
        self.match_title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        self.match_meta = QLabel("")
        self.match_meta.setObjectName("mutedLabel")
        self.match_meta.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        cards_layout = QGridLayout()

        self.summary_cards = {
            "competition": StatCard(
                "Competición"
            ),
            "records": StatCard(
                "Partidos en base"
            ),
            "goals": StatCard(
                "Goles esperados"
            ),
            "corners": StatCard(
                "Córners esperados"
            ),
            "cards": StatCard(
                "Amarillas esperadas"
            ),
            "validation": StatCard(
                "Backtesting"
            ),
        }

        positions = [
            ("competition", 0, 0),
            ("records", 0, 1),
            ("goals", 0, 2),
            ("corners", 1, 0),
            ("cards", 1, 1),
            ("validation", 1, 2),
        ]

        for key, row, column in positions:
            cards_layout.addWidget(
                self.summary_cards[key],
                row,
                column,
            )

        self.summary_notes = QPlainTextEdit()
        self.summary_notes.setReadOnly(True)
        self.summary_notes.setMaximumHeight(190)
        self.summary_notes.setPlaceholderText(
            "Aquí se muestran advertencias y disponibilidad "
            "de los archivos del proyecto."
        )

        layout.addWidget(self.match_title)
        layout.addWidget(self.match_meta)
        layout.addLayout(cards_layout)
        layout.addWidget(
            QLabel("Estado de archivos")
        )
        layout.addWidget(self.summary_notes)
        layout.addStretch(1)

        return page

    def _build_upcoming_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        title = QLabel(
            "Calendario próximo de la competición"
        )
        title.setObjectName("matchTitle")

        self.upcoming_info_label = QLabel(
            "Todavía no se ha sincronizado el calendario futuro."
        )
        self.upcoming_info_label.setObjectName("mutedLabel")

        self.upcoming_table = QTableWidget()
        configure_table(
            self.upcoming_table,
            [
                "Fecha local",
                "Local",
                "Visitante",
                "Ronda",
                "Análisis",
                "Evento",
            ],
        )
        self.upcoming_table.cellDoubleClicked.connect(
            self.select_upcoming_from_table
        )

        help_label = QLabel(
            "Haz doble clic en un partido para seleccionarlo. "
            "La URL se copiará arriba y luego puedes ejecutar "
            "el análisis completo."
        )
        help_label.setObjectName("mutedLabel")
        help_label.setWordWrap(True)

        layout.addWidget(title)
        layout.addWidget(self.upcoming_info_label)
        layout.addWidget(self.upcoming_table, 1)
        layout.addWidget(help_label)

        return page

    def _build_statistics_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        header_layout = QHBoxLayout()

        self.home_form_label = QLabel(
            "Forma local: N/D"
        )
        self.away_form_label = QLabel(
            "Forma visitante: N/D"
        )

        header_layout.addWidget(
            self.home_form_label
        )
        header_layout.addStretch(1)
        header_layout.addWidget(
            self.away_form_label
        )

        self.statistics_table = QTableWidget()
        configure_table(
            self.statistics_table,
            [
                "Métrica",
                "Local relevante",
                "Visitante relevante",
                "Local general",
                "Visitante general",
            ],
        )

        self.stats_source_label = QLabel("")
        self.stats_source_label.setObjectName(
            "mutedLabel"
        )

        layout.addLayout(header_layout)
        layout.addWidget(
            self.statistics_table,
            1,
        )
        layout.addWidget(
            self.stats_source_label
        )

        return page

    def _build_goals_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        self.goals_model_table = QTableWidget()
        configure_table(
            self.goals_model_table,
            [
                "Modelo",
                "Lambda local",
                "Lambda visitante",
                "Total esperado",
                "Local",
                "Empate",
                "Visitante",
            ],
        )

        self.scorelines_table = QTableWidget()
        configure_table(
            self.scorelines_table,
            [
                "Modelo",
                "Marcador",
                "Probabilidad",
            ],
        )

        self.goals_source_label = QLabel("")
        self.goals_source_label.setObjectName(
            "mutedLabel"
        )

        layout.addWidget(
            QLabel("Modelos Poisson + Dixon-Coles")
        )
        layout.addWidget(
            self.goals_model_table
        )
        layout.addWidget(
            QLabel("Marcadores más probables")
        )
        layout.addWidget(
            self.scorelines_table,
            1,
        )
        layout.addWidget(
            self.goals_source_label
        )

        return page

    def _build_corners_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        cards_layout = QGridLayout()

        self.corners_cards = {
            "home": StatCard("Media local"),
            "away": StatCard("Media visitante"),
            "total": StatCard("Media total"),
            "distribution": StatCard(
                "Distribución alternativa"
            ),
        }

        cards_layout.addWidget(
            self.corners_cards["home"],
            0,
            0,
        )
        cards_layout.addWidget(
            self.corners_cards["away"],
            0,
            1,
        )
        cards_layout.addWidget(
            self.corners_cards["total"],
            0,
            2,
        )
        cards_layout.addWidget(
            self.corners_cards["distribution"],
            0,
            3,
        )

        self.corners_thresholds_table = QTableWidget()
        configure_table(
            self.corners_thresholds_table,
            [
                "Total mínimo",
                "Poisson",
                "Binomial negativa",
            ],
        )

        self.corners_source_label = QLabel("")
        self.corners_source_label.setObjectName(
            "mutedLabel"
        )

        layout.addLayout(cards_layout)
        layout.addWidget(
            QLabel(
                "Distribución descriptiva del total de córners"
            )
        )
        layout.addWidget(
            self.corners_thresholds_table,
            1,
        )
        layout.addWidget(
            self.corners_source_label
        )

        return page

    def _build_cards_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        cards_layout = QGridLayout()

        self.cards_cards = {
            "home": StatCard(
                "Amarillas local"
            ),
            "away": StatCard(
                "Amarillas visitante"
            ),
            "total": StatCard(
                "Amarillas totales"
            ),
            "red": StatCard(
                "Rojas — experimental"
            ),
        }

        cards_layout.addWidget(
            self.cards_cards["home"],
            0,
            0,
        )
        cards_layout.addWidget(
            self.cards_cards["away"],
            0,
            1,
        )
        cards_layout.addWidget(
            self.cards_cards["total"],
            0,
            2,
        )
        cards_layout.addWidget(
            self.cards_cards["red"],
            0,
            3,
        )

        self.cards_thresholds_table = QTableWidget()
        configure_table(
            self.cards_thresholds_table,
            [
                "Umbral de amarillas",
                "Poisson",
                "Binomial negativa",
            ],
        )

        self.cards_source_label = QLabel("")
        self.cards_source_label.setObjectName(
            "mutedLabel"
        )

        layout.addLayout(cards_layout)
        layout.addWidget(
            QLabel(
                "Distribución descriptiva del total de amarillas"
            )
        )
        layout.addWidget(
            self.cards_thresholds_table,
            1,
        )
        layout.addWidget(
            self.cards_source_label
        )

        return page

    def _build_backtesting_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        self.backtesting_table = QTableWidget()
        configure_table(
            self.backtesting_table,
            [
                "Módulo",
                "Modelo",
                "Evaluados",
                "Omitidos",
                "Brier",
                "Log-Loss",
                "Precisión / MAE",
                "RMSE",
            ],
        )

        self.backtesting_notes = QPlainTextEdit()
        self.backtesting_notes.setReadOnly(True)
        self.backtesting_notes.setMaximumHeight(180)

        layout.addWidget(
            QLabel(
                "Resultados de validación walk-forward"
            )
        )
        layout.addWidget(
            self.backtesting_table,
            1,
        )
        layout.addWidget(
            self.backtesting_notes
        )

        return page

    def _build_console_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        self.console = QPlainTextEdit()
        self.console.setReadOnly(True)
        self.console.setLineWrapMode(
            QPlainTextEdit.LineWrapMode.NoWrap
        )
        self.console.setFont(
            QFont("Consolas", 10)
        )

        layout.addWidget(self.console)
        return page

    def _build_statusbar(self) -> None:
        status = QStatusBar()
        self.setStatusBar(status)

        self.status_label = QLabel(
            "Listo"
        )
        self.process_label = QLabel(
            "Sin procesos activos"
        )

        status.addWidget(
            self.status_label,
            1,
        )
        status.addPermanentWidget(
            self.process_label
        )

    def _apply_style(self) -> None:
        self.setStyleSheet(
            """
            QMainWindow {
                background: #11151c;
            }

            QWidget {
                color: #e9edf4;
                font-family: "Segoe UI";
                font-size: 10pt;
            }

            QFrame#headerPanel {
                background: #171d27;
                border: 1px solid #273143;
                border-radius: 12px;
            }

            QLabel#mainTitle {
                font-size: 22pt;
                font-weight: 700;
                color: #f7f9fc;
            }

            QLabel#mainSubtitle,
            QLabel#mutedLabel,
            QLabel#cardSubtitle {
                color: #9aa7ba;
            }

            QLabel#matchTitle {
                font-size: 20pt;
                font-weight: 700;
                padding: 12px;
            }

            QFrame#statCard {
                background: #171d27;
                border: 1px solid #273143;
                border-radius: 10px;
                min-height: 86px;
            }

            QLabel#cardTitle {
                color: #9aa7ba;
                font-size: 9pt;
            }

            QLabel#cardValue {
                color: #ffffff;
                font-size: 17pt;
                font-weight: 700;
            }

            QGroupBox {
                border: 1px solid #273143;
                border-radius: 8px;
                margin-top: 12px;
                padding-top: 10px;
                background: #151a23;
                font-weight: 600;
            }

            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 4px;
            }

            QPushButton {
                background: #242d3b;
                border: 1px solid #354157;
                border-radius: 7px;
                padding: 9px 12px;
                text-align: left;
            }

            QPushButton:hover {
                background: #2e3a4d;
            }

            QPushButton:disabled {
                color: #697385;
                background: #1a202b;
            }

            QPushButton#primaryButton {
                background: #1f6feb;
                border-color: #388bfd;
                font-weight: 700;
                text-align: center;
            }

            QPushButton#primaryButton:hover {
                background: #388bfd;
            }

            QPushButton#dangerButton {
                background: #6e2930;
                border-color: #9b3b45;
                text-align: center;
            }

            QLineEdit,
            QComboBox,
            QPlainTextEdit,
            QTableWidget {
                background: #0f131a;
                border: 1px solid #2b3547;
                border-radius: 6px;
                padding: 5px;
            }

            QComboBox {
                color: #f8fafc;
                min-height: 24px;
            }

            QComboBox:disabled {
                color: #697385;
                background: #1a202b;
            }

            QComboBox QAbstractItemView {
                background-color: #111827;
                color: #f8fafc;
                border: 1px solid #334155;
                outline: 0;
                selection-background-color: #2563eb;
                selection-color: #ffffff;
            }

            QComboBox QAbstractItemView::item {
                min-height: 30px;
                padding: 5px 10px;
                color: #f8fafc;
                background-color: #111827;
            }

            QComboBox QAbstractItemView::item:selected {
                background-color: #2563eb;
                color: #ffffff;
            }

            QComboBox QAbstractItemView::item:hover {
                background-color: #1e40af;
                color: #ffffff;
            }

            QTabWidget::pane {
                border: 1px solid #273143;
                border-radius: 8px;
                background: #131821;
            }

            QTabBar::tab {
                background: #1b222e;
                border: 1px solid #293446;
                padding: 9px 14px;
            }

            QTabBar::tab:selected {
                background: #253148;
                color: #ffffff;
            }

            QHeaderView::section {
                background: #202938;
                color: #e9edf4;
                border: 0;
                padding: 7px;
                font-weight: 600;
            }

            QTableWidget {
                gridline-color: #273143;
                alternate-background-color: #151b25;
            }

            QScrollBar:vertical {
                background: #11151c;
                width: 12px;
            }

            QScrollBar::handle:vertical {
                background: #36445a;
                border-radius: 5px;
                min-height: 30px;
            }

            QToolBar {
                background: #171d27;
                border-bottom: 1px solid #273143;
                spacing: 6px;
                padding: 5px;
            }

            QStatusBar {
                background: #171d27;
                border-top: 1px solid #273143;
            }
            """
        )

    # --------------------------------------------------------------------------
    # COMPETICIONES
    # --------------------------------------------------------------------------

    def load_competitions(self) -> None:
        selected_key = self.current_competition_key()

        self.competition_combo.blockSignals(True)
        self.competition_combo.clear()

        competitions = self.repository.competitions()

        for competition in competitions:
            active = competition.get(
                "active",
                True,
            )

            # Las competiciones históricas o finalizadas permanecen
            # disponibles para entrenamiento, pero no aparecen en
            # el selector principal de análisis.
            if not active:
                continue

            key = str(
                competition.get("key")
                or competition.get("name")
                or ""
            )
            name = str(
                competition.get("name")
                or key
            )
            season = str(
                competition.get("season_name")
                or ""
            )

            # LEAGUE_TITLES_V1
            league_titles = {
                "mls": "MLS — Estados Unidos",
                "ligapro": "LigaPro Serie A — Ecuador",
                "ligamx-apertura": "Liga MX — México",
                "chile-primera": "Primera División — Chile",
                "brasil-serie-a": "Brasileirão Série A — Brasil",
            }

            flag_files = {
                "mls": "us.png",
                "ligapro": "ec.png",
                "ligamx-apertura": "mx.png",
                "chile-primera": "cl.png",
                "brasil-serie-a": "br.png",
            }

            label = league_titles.get(key)

            if label is None:
                label = name

                if season:
                    label += f" — {season}"

            flag_name = flag_files.get(key)
            flag_path = (
                DATA_DIR / "ui" / "flags" / flag_name
                if flag_name
                else None
            )

            if flag_path is not None and flag_path.exists():
                self.competition_combo.addItem(
                    QIcon(str(flag_path)),
                    label,
                    key,
                )
            else:
                self.competition_combo.addItem(
                    label,
                    key,
                )

        if self.competition_combo.count() == 0:
            self.competition_combo.addItem(
                "Sin competiciones",
                "",
            )

        if selected_key:
            index = self.competition_combo.findData(
                selected_key
            )

            if index >= 0:
                self.competition_combo.setCurrentIndex(
                    index
                )

        self.competition_combo.blockSignals(False)

    def on_competition_changed(self) -> None:
        # refresh_all() ya llama load_upcoming_matches(); no duplicar trabajo.
        self.refresh_all()

    def load_upcoming_matches(self) -> None:
        if not hasattr(self, "upcoming_combo"):
            return

        key = self.current_competition_key()
        previous_event_id = None
        current = self.current_scheduled_match()

        if current:
            previous_event_id = current.get("event_id")

        schedule = (
            self.repository.upcoming_schedule(key)
            if key
            else {"matches": []}
        )

        matches = schedule.get("matches", [])

        if not isinstance(matches, list):
            matches = []

        self.upcoming_combo.blockSignals(True)
        self.upcoming_combo.clear()

        for match in matches:
            if not isinstance(match, dict):
                continue

            kickoff = format_datetime(
                match.get("kickoff")
                or match.get("start_timestamp")
            )
            home = match.get("home_team") or "Local"
            away = match.get("away_team") or "Visitante"

            self.upcoming_combo.addItem(
                f"{kickoff} | {home} vs {away}",
                match,
            )

        if self.upcoming_combo.count() == 0:
            self.upcoming_combo.addItem(
                "Sin próximos partidos sincronizados",
                None,
            )

        if previous_event_id is not None:
            for index in range(self.upcoming_combo.count()):
                item = self.upcoming_combo.itemData(index)

                if (
                    isinstance(item, dict)
                    and item.get("event_id") == previous_event_id
                ):
                    self.upcoming_combo.setCurrentIndex(index)
                    break

        self.upcoming_combo.blockSignals(False)
        self._refresh_upcoming_table(matches)

        selected = self.current_scheduled_match()

        if selected and selected.get("url"):
            self.url_input.setText(str(selected["url"]))

    def current_scheduled_match(self) -> dict[str, Any] | None:
        if not hasattr(self, "upcoming_combo"):
            return None

        value = self.upcoming_combo.currentData()
        return value if isinstance(value, dict) else None

    def on_upcoming_selected(self) -> None:
        match = self.current_scheduled_match()

        if match and match.get("url"):
            self.url_input.setText(str(match["url"]))

        self.refresh_all()

    def _refresh_upcoming_table(
        self,
        matches: list[dict[str, Any]],
    ) -> None:
        if not hasattr(self, "upcoming_table"):
            return

        key = self.current_competition_key()
        index_document = (
            self.repository.analysis_index(key)
            if key
            else {"matches": []}
        )

        status_by_event: dict[int, str] = {}

        for row in index_document.get("matches", []):
            if not isinstance(row, dict):
                continue

            try:
                event_id = int(row["event_id"])
            except (KeyError, TypeError, ValueError):
                continue

            status_by_event[event_id] = str(
                row.get("analysis_status")
                or row.get("status")
                or "PENDING"
            )

        self.upcoming_table.setRowCount(len(matches))

        for row, match in enumerate(matches):
            try:
                event_id = int(match.get("event_id") or 0)
            except (TypeError, ValueError):
                event_id = 0

            status = status_by_event.get(
                event_id,
                "PENDING",
            )

            status_label = {
                "FULL": "✅ Listo",
                "PARTIAL": "⚠️ Parcial",
                "ERROR": "❌ Error",
                "SKIPPED": "✅ Listo",
                "PENDING": "⏳ Pendiente",
            }.get(status, status)

            set_item(
                self.upcoming_table,
                row,
                0,
                format_datetime(
                    match.get("kickoff")
                    or match.get("start_timestamp")
                ),
            )
            set_item(
                self.upcoming_table,
                row,
                1,
                match.get("home_team"),
            )
            set_item(
                self.upcoming_table,
                row,
                2,
                match.get("away_team"),
            )
            set_item(
                self.upcoming_table,
                row,
                3,
                match.get("round") or "N/D",
                Qt.AlignmentFlag.AlignCenter,
            )
            set_item(
                self.upcoming_table,
                row,
                4,
                status_label,
                Qt.AlignmentFlag.AlignCenter,
            )
            set_item(
                self.upcoming_table,
                row,
                5,
                event_id,
                Qt.AlignmentFlag.AlignCenter,
            )

        full = int(index_document.get("full") or 0)
        partial = int(index_document.get("partial") or 0)
        errors = int(index_document.get("errors") or 0)

        self.upcoming_info_label.setText(
            f"Partidos próximos únicos: {len(matches)}  •  "
            f"Listos: {full}  •  "
            f"Parciales: {partial}  •  "
            f"Errores: {errors}"
        )

    def select_upcoming_from_table(
        self,
        row: int,
        _column: int,
    ) -> None:
        event_item = self.upcoming_table.item(row, 5)

        if event_item is None:
            return

        try:
            event_id = int(event_item.text())
        except ValueError:
            return

        for index in range(self.upcoming_combo.count()):
            match = self.upcoming_combo.itemData(index)

            if (
                isinstance(match, dict)
                and int(match.get("event_id") or 0) == event_id
            ):
                self.upcoming_combo.setCurrentIndex(index)
                self.tabs.setCurrentIndex(0)
                return

    def current_competition_key(self) -> str:
        if not hasattr(
            self,
            "competition_combo",
        ):
            return ""

        value = self.competition_combo.currentData()
        return str(value or "")

    def current_competition_name(self) -> str:
        return self.competition_combo.currentText()

    # --------------------------------------------------------------------------
    # REFRESCO DE DATOS
    # --------------------------------------------------------------------------

    def refresh_all(self) -> None:
        key = self.current_competition_key()

        self.load_upcoming_matches()

        selected_match = self.current_scheduled_match()
        bundle: dict[str, Any] | None = None

        if (
            key
            and isinstance(selected_match, dict)
            and selected_match.get("event_id") is not None
        ):
            bundle = self.repository.analysis_bundle(
                key,
                int(selected_match["event_id"]),
            )

        self.current_analysis_bundle = bundle

        if isinstance(bundle, dict):
            ratings = bundle.get("ratings")
            goals = bundle.get("goals")
            corners = bundle.get("corners")
            cards = bundle.get("cards")
        elif selected_match is not None:
            # Hay un partido seleccionado, pero aún no tiene análisis.
            # No mostramos resultados de otro evento por accidente.
            ratings = None
            goals = None
            corners = None
            cards = None
        else:
            ratings = self.repository.ratings()
            goals = self.repository.goals_model()
            corners = (
                self.repository.corners_model(key)
                if key
                else None
            )
            cards = (
                self.repository.cards_model(key)
                if key
                else None
            )

        goals_backtest = (
            self.repository.goals_backtesting(key)
            if key
            else None
        )
        corners_backtest = (
            self.repository.corners_backtesting(key)
            if key
            else None
        )
        cards_backtest = (
            self.repository.cards_backtesting(key)
            if key
            else None
        )

        model_upcoming = self.repository.upcoming_match(
            ratings,
            goals,
            corners,
            cards,
        )

        upcoming = (
            selected_match
            or model_upcoming
        )

        self._refresh_summary(
            key=key,
            upcoming=upcoming,
            ratings=ratings,
            goals=goals,
            corners=corners,
            cards=cards,
            goals_backtest=goals_backtest,
            corners_backtest=corners_backtest,
            cards_backtest=cards_backtest,
        )
        self._refresh_statistics(ratings)
        self._refresh_goals(goals)
        self._refresh_corners(corners)
        self._refresh_cards(cards)
        self._refresh_backtesting(
            goals_backtest,
            corners_backtest,
            cards_backtest,
        )

        self.status_label.setText(
            "Vista actualizada"
        )

    def _refresh_summary(
        self,
        key: str,
        upcoming: dict[str, Any] | None,
        ratings: dict[str, Any] | None,
        goals: dict[str, Any] | None,
        corners: dict[str, Any] | None,
        cards: dict[str, Any] | None,
        goals_backtest: dict[str, Any] | None,
        corners_backtest: dict[str, Any] | None,
        cards_backtest: dict[str, Any] | None,
    ) -> None:
        if upcoming:
            home = str(
                upcoming.get("home_team")
                or "Local"
            )
            away = str(
                upcoming.get("away_team")
                or "Visitante"
            )

            self.match_title.setText(
                f"{home}  vs  {away}"
            )

            kickoff = (
                upcoming.get("kickoff")
                or upcoming.get("fecha")
                or upcoming.get("start_timestamp")
            )

            event_id = upcoming.get("event_id")

            self.match_meta.setText(
                f"Evento: {event_id or 'N/D'}  •  "
                f"Fecha: {format_datetime(kickoff)}"
            )
        else:
            self.match_title.setText(
                "No hay próximo partido cargado"
            )
            self.match_meta.setText(
                "Ejecuta el flujo del próximo partido "
                "o selecciona un JSON."
            )

        competition_name = (
            self.current_competition_name()
            or key
            or "N/D"
        )

        self.summary_cards[
            "competition"
        ].set_content(
            competition_name,
            f"Clave interna: {key or 'N/D'}",
        )

        counts = (
            goals_backtest.get("counts", {})
            if isinstance(
                goals_backtest,
                dict,
            )
            else {}
        )

        finished = (
            counts.get(
                "finished_matches_in_database"
            )
            or counts.get(
                "finished_matches_with_corners"
            )
            or "N/D"
        )

        evaluated = counts.get(
            "evaluated_matches"
        )

        self.summary_cards[
            "records"
        ].set_content(
            _oh_j1_records_total_v4(key, _oh_liga_portugal_records_total_v3(key, str(finished))),
            (
                f"Evaluados: {evaluated}"
                if evaluated is not None
                else "Sin backtesting cargado"
            ),
        )

        goals_models = (
            goals.get("models", {})
            if isinstance(goals, dict)
            else {}
        )

        preferred_goals = (
            goals_models.get("MODELO_APRENDIDO")
            or goals_models.get("MODELO_XG")
            or goals_models.get("MODELO_GOLES")
            or {}
        )

        expected_goals = preferred_goals.get(
            "expected_total_goals"
        )

        self.summary_cards[
            "goals"
        ].set_content(
            format_number(expected_goals),
            (
                MODEL_LABELS.get(
                    preferred_goals.get(
                        "model_name",
                        "",
                    ),
                    preferred_goals.get(
                        "model_name",
                        "Sin modelo",
                    ),
                )
            ),
        )

        corners_total = nested_get(
            corners,
            "analysis",
            "expected_total_corners",
        )

        self.summary_cards[
            "corners"
        ].set_content(
            format_number(corners_total),
            (
                "Modelo cargado"
                if corners
                else "Sin archivo de córners"
            ),
        )

        yellow_total = nested_get(
            cards,
            "analysis",
            "expected_total_yellow_cards",
        )

        self.summary_cards[
            "cards"
        ].set_content(
            format_number(yellow_total),
            (
                "Modelo cargado"
                if cards
                else "Sin archivo de tarjetas"
            ),
        )

        bt_evaluated = nested_get(
            goals_backtest,
            "counts",
            "evaluated_matches",
        )

        self.summary_cards[
            "validation"
        ].set_content(
            (
                str(bt_evaluated)
                if bt_evaluated is not None
                else "N/D"
            ),
            "Partidos evaluados en goles",
        )

        availability: list[str] = []

        trained_model = (
            self.repository.trained_model(key)
            if key
            else None
        )

        if isinstance(trained_model, dict):
            promotion = trained_model.get("promotion", {})
            availability.append(
                "🧠 Modelo aprendido vigente: "
                f"v{trained_model.get('version', 'N/D')} | "
                "puntuación "
                f"{format_number(promotion.get('candidate_score'), 4)}"
            )
        else:
            availability.append(
                "❌ No existe latest_model.json para esta liga."
            )

        bundle = getattr(
            self,
            "current_analysis_bundle",
            None,
        )

        if isinstance(bundle, dict):
            bundle_status = str(
                bundle.get("status") or "N/D"
            )

            availability.append(
                f"📦 Análisis del evento seleccionado: {bundle_status}"
            )

            for error in bundle.get("errors", []):
                if isinstance(error, dict):
                    availability.append(
                        "⚠️ "
                        f"{error.get('component')}: "
                        f"{error.get('error')}"
                    )

        elif self.current_scheduled_match() is not None:
            availability.append(
                "⏳ Este partido todavía no está analizado. "
                "Pulsa Analizar todos los próximos."
            )

        selected_match = self.current_scheduled_match()
        model_match = self.repository.upcoming_match(
            ratings,
            goals,
            corners,
            cards,
        )

        if selected_match and model_match:
            selected_id = selected_match.get("event_id")
            model_id = model_match.get("event_id")

            if (
                selected_id is not None
                and model_id is not None
                and selected_id != model_id
            ):
                availability.append(
                    "⚠️ El partido seleccionado aún no ha sido analizado. "
                    f"Los modelos visibles corresponden al evento {model_id}. "
                    "Pulsa Ejecutar análisis completo."
                )

        availability.extend([
            (
                "✅ Ratings"
                if ratings
                else "❌ Ratings"
            ),
            (
                "✅ Modelo de goles"
                if goals
                else "❌ Modelo de goles"
            ),
            (
                "✅ Modelo de córners"
                if corners
                else "❌ Modelo de córners"
            ),
            (
                "✅ Modelo de tarjetas"
                if cards
                else "❌ Modelo de tarjetas"
            ),
            (
                "✅ Backtesting de goles"
                if goals_backtest
                else "❌ Backtesting de goles"
            ),
            (
                "✅ Backtesting de córners"
                if corners_backtest
                else "❌ Backtesting de córners"
            ),
            (
                "✅ Backtesting de tarjetas"
                if cards_backtest
                else "❌ Backtesting de tarjetas"
            ),
        ])

        self.summary_notes.setPlainText(
            "\n".join(availability)
        )

    def _refresh_statistics(
        self,
        ratings: dict[str, Any] | None,
    ) -> None:
        table = self.statistics_table
        table.setRowCount(0)

        if not ratings:
            self.home_form_label.setText(
                "Forma local: N/D"
            )
            self.away_form_label.setText(
                "Forma visitante: N/D"
            )
            self.stats_source_label.setText(
                f"No existe {RATINGS_PATH}"
            )
            return

        home_analysis = ratings.get(
            "home_team_analysis",
            {},
        )
        away_analysis = ratings.get(
            "away_team_analysis",
            {},
        )

        home_relevant = nested_get(
            home_analysis,
            "profiles",
            "relevant",
            default={},
        )
        away_relevant = nested_get(
            away_analysis,
            "profiles",
            "relevant",
            default={},
        )
        home_overall = nested_get(
            home_analysis,
            "profiles",
            "overall",
            default={},
        )
        away_overall = nested_get(
            away_analysis,
            "profiles",
            "overall",
            default={},
        )

        home_averages = (
            home_relevant.get("averages", {})
            if isinstance(
                home_relevant,
                dict,
            )
            else {}
        )
        away_averages = (
            away_relevant.get("averages", {})
            if isinstance(
                away_relevant,
                dict,
            )
            else {}
        )
        home_overall_averages = (
            home_overall.get("averages", {})
            if isinstance(
                home_overall,
                dict,
            )
            else {}
        )
        away_overall_averages = (
            away_overall.get("averages", {})
            if isinstance(
                away_overall,
                dict,
            )
            else {}
        )

        metrics = list(METRIC_LABELS)

        table.setRowCount(len(metrics))

        for row, metric in enumerate(metrics):
            set_item(
                table,
                row,
                0,
                METRIC_LABELS[metric],
            )
            set_item(
                table,
                row,
                1,
                format_number(
                    home_averages.get(metric)
                ),
                Qt.AlignmentFlag.AlignCenter,
            )
            set_item(
                table,
                row,
                2,
                format_number(
                    away_averages.get(metric)
                ),
                Qt.AlignmentFlag.AlignCenter,
            )
            set_item(
                table,
                row,
                3,
                format_number(
                    home_overall_averages.get(
                        metric
                    )
                ),
                Qt.AlignmentFlag.AlignCenter,
            )
            set_item(
                table,
                row,
                4,
                format_number(
                    away_overall_averages.get(
                        metric
                    )
                ),
                Qt.AlignmentFlag.AlignCenter,
            )

        home_form = home_relevant.get(
            "form",
            {},
        )
        away_form = away_relevant.get(
            "form",
            {},
        )

        self.home_form_label.setText(
            self._form_text(
                "Local",
                home_form,
            )
        )
        self.away_form_label.setText(
            self._form_text(
                "Visitante",
                away_form,
            )
        )

        source = ratings.get(
            "source_file",
            "",
        )
        self.stats_source_label.setText(
            f"Fuente: {source or RATINGS_PATH}"
        )

    def _form_text(
        self,
        label: str,
        form: dict[str, Any],
    ) -> str:
        if not isinstance(form, dict):
            return f"Forma {label.lower()}: N/D"

        return (
            f"{label}: "
            f"{form.get('wins', 0)}G "
            f"{form.get('draws', 0)}E "
            f"{form.get('losses', 0)}P  •  "
            f"Puntos ponderados: "
            f"{format_number(form.get('weighted_points_per_match'))}"
        )

    def _refresh_goals(
        self,
        goals: dict[str, Any] | None,
    ) -> None:
        self.goals_model_table.setRowCount(0)
        self.scorelines_table.setRowCount(0)

        if not goals:
            self.goals_source_label.setText(
                f"No existe {GOALS_MODEL_PATH}"
            )
            return

        models = goals.get("models", {})

        if not isinstance(models, dict):
            models = {}

        self.goals_model_table.setRowCount(
            len(models)
        )

        scoreline_rows: list[
            tuple[str, dict[str, Any]]
        ] = []

        for row, (model_key, model) in enumerate(
            models.items()
        ):
            if not isinstance(model, dict):
                continue

            probabilities = model.get(
                "outcome_probabilities",
                {},
            )

            set_item(
                self.goals_model_table,
                row,
                0,
                MODEL_LABELS.get(
                    model_key,
                    model_key,
                ),
            )
            set_item(
                self.goals_model_table,
                row,
                1,
                format_number(
                    model.get("lambda_home"),
                    3,
                ),
            )
            set_item(
                self.goals_model_table,
                row,
                2,
                format_number(
                    model.get("lambda_away"),
                    3,
                ),
            )
            set_item(
                self.goals_model_table,
                row,
                3,
                format_number(
                    model.get(
                        "expected_total_goals"
                    ),
                    3,
                ),
            )
            set_item(
                self.goals_model_table,
                row,
                4,
                format_probability(
                    probabilities.get("home_win")
                ),
            )
            set_item(
                self.goals_model_table,
                row,
                5,
                format_probability(
                    probabilities.get("draw")
                ),
            )
            set_item(
                self.goals_model_table,
                row,
                6,
                format_probability(
                    probabilities.get("away_win")
                ),
            )

            for scoreline in model.get(
                "top_scorelines",
                [],
            )[:7]:
                if isinstance(scoreline, dict):
                    scoreline_rows.append(
                        (
                            MODEL_LABELS.get(
                                model_key,
                                model_key,
                            ),
                            scoreline,
                        )
                    )

        self.scorelines_table.setRowCount(
            len(scoreline_rows)
        )

        for row, (
            model_label,
            scoreline,
        ) in enumerate(scoreline_rows):
            set_item(
                self.scorelines_table,
                row,
                0,
                model_label,
            )
            set_item(
                self.scorelines_table,
                row,
                1,
                (
                    f"{scoreline.get('home_goals', 0)}"
                    f" - "
                    f"{scoreline.get('away_goals', 0)}"
                ),
                Qt.AlignmentFlag.AlignCenter,
            )
            set_item(
                self.scorelines_table,
                row,
                2,
                format_probability(
                    scoreline.get("probability")
                ),
                Qt.AlignmentFlag.AlignCenter,
            )

        source = goals.get(
            "source_ratings_file",
            "",
        )
        self.goals_source_label.setText(
            f"Fuente: {source or GOALS_MODEL_PATH}"
        )

    def _refresh_corners(
        self,
        corners: dict[str, Any] | None,
    ) -> None:
        self.corners_thresholds_table.setRowCount(
            0
        )

        if not corners:
            for card in self.corners_cards.values():
                card.set_content("N/D")

            self.corners_source_label.setText(
                "No hay modelo de córners para "
                "la competición seleccionada."
            )
            return

        analysis = corners.get(
            "analysis",
            {},
        )

        home = analysis.get("home_team", {})
        away = analysis.get("away_team", {})

        self.corners_cards["home"].set_content(
            format_number(
                home.get("expected_corners"),
                3,
            ),
            nested_get(
                home,
                "team",
                "name",
                default="Local",
            ),
        )
        self.corners_cards["away"].set_content(
            format_number(
                away.get("expected_corners"),
                3,
            ),
            nested_get(
                away,
                "team",
                "name",
                default="Visitante",
            ),
        )
        self.corners_cards["total"].set_content(
            format_number(
                analysis.get(
                    "expected_total_corners"
                ),
                3,
            ),
            "Suma de medias esperadas",
        )

        dispersion = analysis.get(
            "negative_binomial_dispersion",
            {},
        )
        nb_available = (
            isinstance(dispersion, dict)
            and dispersion.get("available")
        )

        self.corners_cards[
            "distribution"
        ].set_content(
            (
                "Disponible"
                if nb_available
                else "No disponible"
            ),
            "Binomial negativa",
        )

        thresholds = analysis.get(
            "minimum_total_thresholds",
            [],
        )

        if not isinstance(thresholds, list):
            thresholds = []

        self.corners_thresholds_table.setRowCount(
            len(thresholds)
        )

        for row, threshold in enumerate(
            thresholds
        ):
            minimum = threshold.get(
                "minimum_total_corners"
            )

            set_item(
                self.corners_thresholds_table,
                row,
                0,
                f"Total ≥ {minimum}",
            )
            set_item(
                self.corners_thresholds_table,
                row,
                1,
                format_probability(
                    threshold.get(
                        "poisson_probability"
                    )
                ),
            )
            set_item(
                self.corners_thresholds_table,
                row,
                2,
                format_probability(
                    threshold.get(
                        "negative_binomial_probability"
                    )
                ),
            )

        self.corners_source_label.setText(
            "Fuente: "
            f"{corners.get('source_match_file', 'N/D')}"
        )

    def _refresh_cards(
        self,
        cards: dict[str, Any] | None,
    ) -> None:
        self.cards_thresholds_table.setRowCount(0)

        if not cards:
            for card in self.cards_cards.values():
                card.set_content("N/D")

            self.cards_source_label.setText(
                "No hay modelo de tarjetas para "
                "la competición seleccionada."
            )
            return

        analysis = cards.get(
            "analysis",
            {},
        )

        home = analysis.get("home_team", {})
        away = analysis.get("away_team", {})

        self.cards_cards["home"].set_content(
            format_number(
                home.get(
                    "expected_yellow_cards"
                ),
                3,
            ),
            nested_get(
                home,
                "team",
                "name",
                default="Local",
            ),
        )
        self.cards_cards["away"].set_content(
            format_number(
                away.get(
                    "expected_yellow_cards"
                ),
                3,
            ),
            nested_get(
                away,
                "team",
                "name",
                default="Visitante",
            ),
        )
        self.cards_cards["total"].set_content(
            format_number(
                analysis.get(
                    "expected_total_yellow_cards"
                ),
                3,
            ),
            "Total de amarillas",
        )

        red_analysis = analysis.get(
            "red_cards_analysis",
            {},
        )

        red_total = red_analysis.get(
            "expected_total_red_cards"
        )
        red_probability = red_analysis.get(
            "probability_at_least_one_red"
        )

        self.cards_cards["red"].set_content(
            format_number(
                red_total,
                3,
            ),
            (
                "Al menos una: "
                f"{format_probability(red_probability)}"
            ),
        )

        thresholds = analysis.get(
            "yellow_thresholds",
            [],
        )

        if not isinstance(thresholds, list):
            thresholds = []

        self.cards_thresholds_table.setRowCount(
            len(thresholds)
        )

        for row, threshold in enumerate(
            thresholds
        ):
            line = threshold.get(
                "line_equivalent"
            )
            minimum = threshold.get(
                "minimum_total_yellow_cards"
            )

            set_item(
                self.cards_thresholds_table,
                row,
                0,
                (
                    f"Total ≥ {minimum} "
                    f"(umbral {line})"
                ),
            )
            set_item(
                self.cards_thresholds_table,
                row,
                1,
                format_probability(
                    threshold.get(
                        "poisson_probability"
                    )
                ),
            )
            set_item(
                self.cards_thresholds_table,
                row,
                2,
                format_probability(
                    threshold.get(
                        "negative_binomial_probability"
                    )
                ),
            )

        self.cards_source_label.setText(
            "Fuente: "
            f"{cards.get('source_match_file', 'N/D')}"
        )

    def _refresh_backtesting(
        self,
        goals_backtest: dict[str, Any] | None,
        corners_backtest: dict[str, Any] | None,
        cards_backtest: dict[str, Any] | None,
    ) -> None:
        rows: list[list[str]] = []
        notes: list[str] = []

        key = self.current_competition_key()
        trained = (
            self.repository.trained_model(key)
            if key
            else None
        )

        if isinstance(trained, dict):
            goals_validation = nested_get(
                trained,
                "goals",
                "validation_metrics",
                default={},
            )
            rows.append(
                [
                    "Goles",
                    "🧠 Aprendido v"
                    f"{trained.get('version', 'N/D')}",
                    str(goals_validation.get("samples", "N/D")),
                    "0",
                    format_number(
                        goals_validation.get("brier_score"),
                        4,
                    ),
                    format_number(
                        goals_validation.get("log_loss"),
                        4,
                    ),
                    format_probability(
                        goals_validation.get("accuracy")
                    ),
                    "N/D",
                ]
            )

            for module_name, section_name in (
                ("Córners", "corners"),
                ("Tarjetas", "cards"),
            ):
                section = trained.get(section_name, {})
                family = str(
                    section.get("selected_family")
                    or "poisson"
                )
                family_section = section.get(family, {})
                validation = family_section.get(
                    "validation_metrics",
                    {},
                )
                rows.append(
                    [
                        module_name,
                        "🧠 "
                        + (
                            "Binomial negativa"
                            if family == "negative_binomial"
                            else "Poisson"
                        ),
                        str(validation.get("samples", "N/D")),
                        "0",
                        format_number(
                            validation.get("mean_threshold_brier"),
                            4,
                        ),
                        format_number(
                            validation.get("exact_total_log_loss"),
                            4,
                        ),
                        "MAE "
                        + format_number(
                            validation.get("mae"),
                            4,
                        ),
                        format_number(
                            validation.get("rmse"),
                            4,
                        ),
                    ]
                )

            notes.append(
                "Las filas 🧠 corresponden al bloque temporal "
                "reservado de latest_model.json."
            )

        if goals_backtest:
            counts = goals_backtest.get(
                "counts",
                {},
            )
            summaries = goals_backtest.get(
                "model_summary",
                {},
            )

            for model_key, summary in summaries.items():
                if not isinstance(summary, dict):
                    continue

                rows.append(
                    [
                        "Goles",
                        MODEL_LABELS.get(
                            model_key,
                            model_key,
                        ),
                        str(
                            summary.get(
                                "predictions",
                                counts.get(
                                    "evaluated_matches",
                                    "N/D",
                                ),
                            )
                        ),
                        str(
                            counts.get(
                                "skipped_matches",
                                "N/D",
                            )
                        ),
                        format_number(
                            summary.get(
                                "brier_score"
                            ),
                            4,
                        ),
                        format_number(
                            summary.get("log_loss"),
                            4,
                        ),
                        format_probability(
                            summary.get("accuracy")
                        ),
                        "N/D",
                    ]
                )
        else:
            notes.append(
                "No se encontró el backtesting de goles."
            )

        if corners_backtest:
            counts = corners_backtest.get(
                "counts",
                {},
            )
            summary = corners_backtest.get(
                "summary",
                {},
            )

            for model_name, model_key in (
                ("Poisson", "poisson"),
                (
                    "Binomial negativa",
                    "negative_binomial",
                ),
            ):
                model_summary = summary.get(
                    model_key,
                    {},
                )

                rows.append(
                    [
                        "Córners",
                        model_name,
                        str(
                            model_summary.get(
                                "predictions",
                                counts.get(
                                    "evaluated_matches",
                                    "N/D",
                                ),
                            )
                        ),
                        str(
                            counts.get(
                                "skipped_matches",
                                "N/D",
                            )
                        ),
                        format_number(
                            model_summary.get(
                                "mean_threshold_brier"
                            ),
                            4,
                        ),
                        format_number(
                            model_summary.get(
                                "exact_total_log_loss"
                            ),
                            4,
                        ),
                        (
                            "MAE "
                            + format_number(
                                summary.get(
                                    "mae_total"
                                ),
                                4,
                            )
                        ),
                        format_number(
                            summary.get("rmse_total"),
                            4,
                        ),
                    ]
                )
        else:
            notes.append(
                "No se encontró el backtesting de córners."
            )

        if cards_backtest:
            counts = cards_backtest.get(
                "counts",
                {},
            )
            summary = cards_backtest.get(
                "summary",
                {},
            )

            for model_name, model_key in (
                ("Poisson", "poisson"),
                (
                    "Binomial negativa",
                    "negative_binomial",
                ),
            ):
                model_summary = summary.get(
                    model_key,
                    {},
                )

                rows.append(
                    [
                        "Tarjetas",
                        model_name,
                        str(
                            model_summary.get(
                                "predictions",
                                counts.get(
                                    "evaluated_matches",
                                    "N/D",
                                ),
                            )
                        ),
                        str(
                            counts.get(
                                "skipped_matches",
                                "N/D",
                            )
                        ),
                        format_number(
                            model_summary.get(
                                "mean_threshold_brier"
                            ),
                            4,
                        ),
                        format_number(
                            model_summary.get(
                                "exact_total_log_loss"
                            ),
                            4,
                        ),
                        (
                            "MAE "
                            + format_number(
                                summary.get(
                                    "mae_total"
                                ),
                                4,
                            )
                        ),
                        format_number(
                            summary.get("rmse_total"),
                            4,
                        ),
                    ]
                )
        else:
            notes.append(
                "No se encontró el backtesting de tarjetas."
            )

        self.backtesting_table.setRowCount(
            len(rows)
        )

        for row_index, row_values in enumerate(rows):
            for column, value in enumerate(
                row_values
            ):
                set_item(
                    self.backtesting_table,
                    row_index,
                    column,
                    value,
                )

        if not notes:
            notes.append(
                "Todos los reportes de backtesting "
                "están disponibles."
            )

        notes.append(
            "Los valores más bajos de Brier, Log-Loss, "
            "MAE y RMSE indican menor error."
        )

        self.backtesting_notes.setPlainText(
            "\n".join(notes)
        )

    # --------------------------------------------------------------------------
    # ARCHIVOS Y CARPETAS
    # --------------------------------------------------------------------------

    def choose_match_json(self) -> None:
        filename, _ = QFileDialog.getOpenFileName(
            self,
            "Seleccionar JSON del próximo partido",
            str(DATA_DIR),
            "Archivos JSON (*.json)",
        )

        if not filename:
            return

        path = Path(filename)
        data = read_json(path)

        if not data:
            QMessageBox.warning(
                self,
                "Archivo inválido",
                "No se pudo leer el JSON seleccionado.",
            )
            return

        event = self.repository.upcoming_match(
            data
        )

        if not event:
            QMessageBox.warning(
                self,
                "JSON sin partido",
                "El archivo no contiene upcoming_match "
                "ni evento.",
            )
            return

        self.url_input.setText(
            str(path)
        )
        self.status_label.setText(
            f"JSON seleccionado: {path.name}"
        )

    def open_data_folder(self) -> None:
        DATA_DIR.mkdir(
            parents=True,
            exist_ok=True,
        )
        QDesktopServices.openUrl(
            QUrl.fromLocalFile(str(DATA_DIR))
        )

    def open_results_folder(self) -> None:
        key = self.current_competition_key()
        selected = self.current_scheduled_match()

        path = DATA_DIR / "analisis"

        if key:
            path = path / key

        if (
            isinstance(selected, dict)
            and selected.get("event_id") is not None
        ):
            candidate = path / str(
                int(selected["event_id"])
            )

            if candidate.exists():
                path = candidate

        path.mkdir(
            parents=True,
            exist_ok=True,
        )

        QDesktopServices.openUrl(
            QUrl.fromLocalFile(str(path))
        )

    # --------------------------------------------------------------------------
    # EJECUCIÓN DE PROCESOS
    # --------------------------------------------------------------------------

    def _task(
        self,
        title: str,
        script: str,
        arguments: list[str] | None = None,
        stdin_text: str | None = None,
    ) -> ProcessTask:
        return ProcessTask(
            title=title,
            script=script,
            arguments=arguments or [],
            stdin_text=stdin_text,
        )

    def run_tasks(
        self,
        tasks: list[ProcessTask],
    ) -> None:
        if self.process is not None:
            QMessageBox.information(
                self,
                "Proceso activo",
                "Ya hay un proceso ejecutándose.",
            )
            return

        valid_tasks: list[ProcessTask] = []

        for task in tasks:
            script_path = BASE_DIR / task.script

            if not script_path.exists():
                QMessageBox.warning(
                    self,
                    "Archivo faltante",
                    f"No se encontró:\n{script_path}",
                )
                return

            valid_tasks.append(task)

        self.process_queue = deque(valid_tasks)
        self._set_action_buttons_enabled(False)
        self.tabs.setCurrentWidget(
            self.console.parentWidget()
        )
        self._start_next_task()

    def _start_next_task(self) -> None:
        if not self.process_queue:
            self.current_task = None
            self.process = None
            self._set_action_buttons_enabled(True)
            self.process_label.setText(
                "Sin procesos activos"
            )
            self.status_label.setText(
                "Flujo terminado"
            )
            self.append_console(
                "\n✅ Flujo completado.\n"
            )
            self.refresh_all()
            return

        task = self.process_queue.popleft()
        self.current_task = task

        process = QProcess(self)
        _configure_hidden_windows_process(process)
        self.process = process

        process.setWorkingDirectory(
            str(BASE_DIR)
        )
        process.setProcessChannelMode(
            QProcess.ProcessChannelMode.MergedChannels
        )

        environment = (
            QProcessEnvironment.systemEnvironment()
        )
        environment.insert(
            "PYTHONIOENCODING",
            "utf-8",
        )
        environment.insert(
            "PYTHONUTF8",
            "1",
        )
        process.setProcessEnvironment(environment)

        process.readyReadStandardOutput.connect(
            self._read_process_output
        )
        process.started.connect(
            self._process_started
        )
        process.finished.connect(
            self._process_finished
        )
        process.errorOccurred.connect(
            self._process_error
        )

        script_path = BASE_DIR / task.script
        arguments = [
            "-u",
            str(script_path),
            *task.arguments,
        ]

        self.append_console(
            "\n"
            + "=" * 84
            + f"\n▶ {task.title}\n"
            + f"$ {sys.executable} "
            + " ".join(arguments)
            + "\n"
            + "=" * 84
            + "\n"
        )

        self.process_label.setText(
            task.title
        )
        self.status_label.setText(
            "Ejecutando"
        )

        process.start(
            sys.executable,
            arguments,
        )

    def _process_started(self) -> None:
        if (
            self.process is None
            or self.current_task is None
        ):
            return

        stdin_text = self.current_task.stdin_text

        if stdin_text is not None:
            QTimer.singleShot(
                900,
                lambda: self._send_process_input(
                    stdin_text
                ),
            )

    def _send_process_input(
        self,
        text: str,
    ) -> None:
        if self.process is None:
            return

        payload = (
            text.rstrip("\r\n") + "\n"
        ).encode("utf-8")

        self.process.write(payload)
        self.process.closeWriteChannel()

        self.append_console(
            "[Entrada enviada automáticamente]\n"
        )

    def _read_process_output(self) -> None:
        if self.process is None:
            return

        raw = bytes(
            self.process.readAllStandardOutput()
        )

        if not raw:
            return

        text = raw.decode(
            "utf-8",
            errors="replace",
        )

        self.append_console(text)

    def _process_finished(
        self,
        exit_code: int,
        _exit_status: QProcess.ExitStatus,
    ) -> None:
        self._read_process_output()

        title = (
            self.current_task.title
            if self.current_task
            else "Proceso"
        )

        self.append_console(
            f"\n[Fin: {title} | código {exit_code}]\n"
        )

        if exit_code != 0:
            self.append_console(
                "⚠️ El proceso terminó con un código "
                "distinto de cero. Se detiene la cola.\n"
            )
            self.process_queue.clear()

        if self.process is not None:
            self.process.deleteLater()

        self.process = None
        self.current_task = None

        self.refresh_all()

        QTimer.singleShot(
            350,
            self._start_next_task,
        )

    def _process_error(
        self,
        error: QProcess.ProcessError,
    ) -> None:
        self.append_console(
            f"\n❌ Error de QProcess: {error}\n"
        )

    def stop_current_process(self) -> None:
        self.process_queue.clear()

        if self.process is None:
            self.append_console(
                "\nNo hay un proceso activo.\n"
            )
            return

        self.append_console(
            "\n⚠️ Se solicitó detener el proceso.\n"
        )

        self.process.terminate()

        if not self.process.waitForFinished(3000):
            self.process.kill()

    def append_console(
        self,
        text: str,
    ) -> None:
        cursor = self.console.textCursor()
        cursor.movePosition(
            cursor.MoveOperation.End
        )
        cursor.insertText(text)
        self.console.setTextCursor(cursor)
        self.console.ensureCursorVisible()

    def _set_action_buttons_enabled(
        self,
        enabled: bool,
    ) -> None:
        for button in self.action_buttons:
            button.setEnabled(enabled)

        self.browse_match_button.setEnabled(
            enabled
        )
        self.refresh_upcoming_button.setEnabled(
            enabled
        )

    # --------------------------------------------------------------------------
    # ACCIONES DEL PRÓXIMO PARTIDO
    # --------------------------------------------------------------------------

    def run_history(self) -> None:
        url = self.url_input.text().strip()

        if not url.startswith(
            ("http://", "https://")
        ):
            QMessageBox.warning(
                self,
                "URL requerida",
                "Pega una URL válida del próximo partido.",
            )
            return

        self.run_tasks(
            [
                self._task(
                    "Obtener historiales del próximo partido",
                    "historial_sofascore.py",
                    stdin_text=url,
                )
            ]
        )

    def run_history_import(self) -> None:
        self.run_tasks(
            [
                self._task(
                    "Importar historiales a SQLite",
                    "importar_historiales_sqlite.py",
                )
            ]
        )

    def run_ratings(self) -> None:
        key = self._required_key()

        if not key:
            return

        self.run_tasks(
            [
                self._task(
                    "Calcular ratings ponderados",
                    "ratings.py",
                    ["--key", key],
                )
            ]
        )

    def run_goals_model(self) -> None:
        key = self._required_key()

        if not key:
            return

        self.run_tasks(
            [
                self._task(
                    "Calcular modelo de goles",
                    "poisson_dixon_coles.py",
                    ["--key", key],
                )
            ]
        )

    def run_corners_model(self) -> None:
        key = self._required_key()

        if not key:
            return

        self.run_tasks(
            [
                self._task(
                    "Calcular modelo de córners",
                    "corners_model.py",
                    ["--key", key],
                )
            ]
        )

    def run_cards_model(self) -> None:
        key = self._required_key()

        if not key:
            return

        self.run_tasks(
            [
                self._task(
                    "Calcular modelo de tarjetas",
                    "cards_model.py",
                    ["--key", key],
                )
            ]
        )

    def run_complete_analysis(self) -> None:
        key = self._required_key()

        if not key:
            return

        selected = self.current_scheduled_match()

        if (
            isinstance(selected, dict)
            and selected.get("event_id") is not None
        ):
            event_id = int(selected["event_id"])

            self.run_tasks(
                [
                    self._task(
                        "Analizar partido seleccionado",
                        "analyze_upcoming_matches.py",
                        [
                            "--key",
                            key,
                            "--event-id",
                            str(event_id),
                            "--force",
                        ],
                    )
                ]
            )
            return

        url = self.url_input.text().strip()

        if not url.startswith(
            ("http://", "https://")
        ):
            QMessageBox.warning(
                self,
                "Partido requerido",
                "Selecciona un partido detectado o pega una URL válida.",
            )
            return

        # Compatibilidad con el flujo manual anterior.
        self.run_tasks(
            [
                self._task(
                    "1/6 Obtener historiales",
                    "historial_sofascore.py",
                    stdin_text=url,
                ),
                self._task(
                    "2/6 Importar historiales",
                    "importar_historiales_sqlite.py",
                ),
                self._task(
                    "3/6 Calcular ratings",
                    "ratings.py",
                    ["--key", key],
                ),
                self._task(
                    "4/6 Modelo de goles",
                    "poisson_dixon_coles.py",
                    ["--key", key],
                ),
                self._task(
                    "5/6 Modelo de córners",
                    "corners_model.py",
                    ["--key", key],
                ),
                self._task(
                    "6/6 Modelo de tarjetas",
                    "cards_model.py",
                    ["--key", key],
                ),
            ]
        )

    # --------------------------------------------------------------------------
    # ACCIONES DE COMPETICIÓN
    # --------------------------------------------------------------------------

    def run_train_models(self) -> None:
        key = self._required_key()

        if not key:
            return

        self.run_tasks(
            [
                self._task(
                    "Reentrenar modelo de la liga",
                    "train_models.py",
                    ["--key", key],
                ),
                self._task(
                    "Recalcular próximos con el modelo vigente",
                    "analyze_upcoming_matches.py",
                    ["--key", key],
                ),
            ]
        )

    def run_analyze_upcoming_matches(self) -> None:
        key = self._required_key()

        if not key:
            return

        self.run_tasks(
            [
                self._task(
                    "Analizar todos los próximos partidos",
                    "analyze_upcoming_matches.py",
                    ["--key", key],
                )
            ]
        )

    def run_sync_upcoming_matches(self) -> None:
        key = self._required_key()

        if not key:
            return

        self.run_tasks(
            [
                self._task(
                    "1/2 Actualizar próximos partidos",
                    "sync_upcoming_matches.py",
                    ["--key", key, "--per-team", "3"],
                ),
                self._task(
                    "2/2 Analizar próximos partidos",
                    "analyze_upcoming_matches.py",
                    ["--key", key],
                ),
            ]
        )

    def run_update_everything(self) -> None:
        key = self._required_key()

        if not key:
            return

        self.run_tasks(
            [
                self._task(
                    "1/5 Sincronizar competición",
                    "sync_competition.py",
                    ["--key", key],
                ),
                self._task(
                    "2/5 Importar nuevas estadísticas",
                    "import_competition_stats.py",
                    ["--key", key],
                ),
                self._task(
                    "3/5 Reentrenar parámetros",
                    "train_models.py",
                    ["--key", key],
                ),
                self._task(
                    "4/5 Actualizar próximos partidos",
                    "sync_upcoming_matches.py",
                    ["--key", key, "--per-team", "3"],
                ),
                self._task(
                    "5/5 Analizar todos con el modelo vigente",
                    "analyze_upcoming_matches.py",
                    ["--key", key],
                ),
            ]
        )

    def run_sync_competition(self) -> None:
        key = self._required_key()

        if not key:
            return

        self.run_tasks(
            [
                self._task(
                    "Sincronizar competición",
                    "sync_competition.py",
                    ["--key", key],
                )
            ]
        )

    def run_import_competition(self) -> None:
        key = self._required_key()

        if not key:
            return

        self.run_tasks(
            [
                self._task(
                    "Importar estadísticas de competición",
                    "import_competition_stats.py",
                    ["--key", key],
                )
            ]
        )

    # --------------------------------------------------------------------------
    # ACCIONES DE BACKTESTING
    # --------------------------------------------------------------------------

    def run_goals_backtesting(self) -> None:
        key = self._required_key()

        if not key:
            return

        self.run_tasks(
            [
                self._task(
                    "Backtesting de goles",
                    "backtesting.py",
                    ["--key", key],
                )
            ]
        )

    def run_corners_backtesting(self) -> None:
        key = self._required_key()

        if not key:
            return

        self.run_tasks(
            [
                self._task(
                    "Backtesting de córners",
                    "corners_backtesting.py",
                    ["--key", key],
                )
            ]
        )

    def run_cards_backtesting(self) -> None:
        key = self._required_key()

        if not key:
            return

        self.run_tasks(
            [
                self._task(
                    "Backtesting de tarjetas",
                    "cards_backtesting.py",
                    ["--key", key],
                )
            ]
        )

    def _required_key(self) -> str:
        key = self.current_competition_key()

        if not key:
            QMessageBox.warning(
                self,
                "Competición requerida",
                "Selecciona una competición válida.",
            )
            return ""

        return key

    # --------------------------------------------------------------------------
    # CIERRE
    # --------------------------------------------------------------------------

    def closeEvent(self, event: Any) -> None:
        if self.process is None:
            event.accept()
            return

        answer = QMessageBox.question(
            self,
            "Proceso activo",
            "Hay un proceso ejecutándose. "
            "¿Deseas cerrarlo y salir?",
            QMessageBox.StandardButton.Yes
            | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )

        if answer == QMessageBox.StandardButton.Yes:
            self.stop_current_process()
            event.accept()
        else:
            event.ignore()


# ==============================================================================
# 7. MAIN
# ==============================================================================

def main() -> int:
    os.environ.setdefault(
        "PYTHONUTF8",
        "1",
    )

    app = QApplication(sys.argv)
    app.setApplicationName(APP_TITLE)
    app.setOrganizationName("Proyecto académico")

    window = MainWindow()
    window.show()

    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())

# ==============================================================================
# ODDSHUNTER_GLOBAL_FINAL_INTEGRATION_V1_3_2_CORE
# UI catalog + exact schedule fallback + SQLite read-only context bridge.
# Does not alter automation registry active flags and never writes SQLite.
# ==============================================================================
try:
    import json as _oh_g13_json
    from global_match_context import build_global_context as _oh_g13_build_context
    _OH_G13_ORIG_COMPETITIONS=DataRepository.competitions
    _OH_G13_ORIG_ANALYSIS=DataRepository.analysis_bundle
    _OH_G13_ORIG_UPCOMING=DataRepository.upcoming_schedule
    _OH_G13_TITLES={'mls': 'MLS — Estados Unidos', 'ligapro': 'LigaPro Serie A — Ecuador', 'ligamx-apertura': 'Liga MX — México', 'chile-primera': 'Primera División — Chile', 'brasil-serie-a': 'Brasileirão Série A — Brasil', 'uefa-champions-league': 'Champions League — Europa', 'uefa-conference-league': 'Conference League — Europa', 'conmebol-sudamericana': 'Sudamericana — CONMEBOL', 'copa-colombia': 'Copa Colombia', 'bundesliga': 'Bundesliga — Alemania', 'premier-league': 'Premier League — Inglaterra', 'uefa-europa-league': 'Europa League — Europa', 'leagues-cup': 'Leagues Cup', 'liga-portugal': 'Liga Portugal — Portugal', 'j1-league': 'J1 League — Japón', 'serie-a': 'Serie A — Italia', 'laliga': 'LaLiga — España', 'eredivisie': 'Eredivisie — Países Bajos', 'saudi-pro-league': 'Saudi Pro League — Arabia Saudita', 'besta-deild': 'Besta deild — Islandia', 'ligue-1': 'Ligue 1 — Francia', 'turkey-super-lig': 'Süper Lig — Turquía', 'belgium-pro-league': 'Pro League — Bélgica', 'championship': 'Championship — Inglaterra', 'usa-usl-championship': 'USL Championship — Estados Unidos', 'canada-canadian-premier-league': 'Canadian Premier League — Canadá', 'greece-stoiximan-super-league': 'Stoiximan Super League — Grecia', 'liga-betplay-colombia': 'Liga BetPlay — Colombia'}

    def _oh_g13_registry_rows(self):
        try:
            raw=self.registry().get("competitions",[])
            return raw if isinstance(raw,list) else []
        except Exception:
            return []

    def _oh_g13_competitions(self):
        # Original DataRepository.competitions may filter inactive entries.
        # Build the UI catalog from RAW registry rows, while overlaying any richer
        # object already returned by the original method.
        original=_OH_G13_ORIG_COMPETITIONS(self)
        original_by_key={
            str(r.get("key") or ""):dict(r)
            for r in original
            if isinstance(r,dict) and r.get("key")
        }
        raw=_oh_g13_registry_rows(self)
        out=[]
        seen=set()
        for row in raw:
            if not isinstance(row,dict):
                continue
            key=str(row.get("key") or "")
            if not key or key in seen:
                continue
            ui_only=bool(row.get("ui_only_catalog",False))
            normal_visible=(
                row.get("active",True) is True
                and row.get("visible_in_ui",True) is not False
                and not bool(row.get("context_only",False))
            )
            if not (normal_visible or ui_only):
                continue
            x=dict(row)
            if key in original_by_key:
                x.update(original_by_key[key])
            if ui_only:
                # UI-copy only. Registry active/context flags remain untouched.
                x["active"]=True
                x["visible_in_ui"]=True
                x["context_only"]=False
            if key in _OH_G13_TITLES:
                x["name"]=_OH_G13_TITLES[key]
            out.append(x)
            seen.add(key)
        return out

    def _oh_g13_upcoming(self,key):
        current=_OH_G13_ORIG_UPCOMING(self,key)
        if isinstance(current,dict) and isinstance(current.get("matches"),list) and current.get("matches"):
            return current
        reg=next((r for r in _oh_g13_registry_rows(self) if isinstance(r,dict) and str(r.get("key") or "")==str(key)),{})
        candidates=[]
        sk=str(reg.get("schedule_source_key") or "").strip()
        if sk:candidates.append(sk)
        tid=reg.get("source_competition_id");sid=reg.get("season_id")
        for r in _oh_g13_registry_rows(self):
            if not isinstance(r,dict):continue
            if str(r.get("source_competition_id"))==str(tid) and str(r.get("season_id"))==str(sid):
                k=str(r.get("key") or "").strip()
                if k and k!=str(key) and k not in candidates:candidates.append(k)
        for k in candidates:
            p=self.data_dir/"competitions"/k/"matches_upcoming.json"
            try:
                d=_oh_g13_json.loads(p.read_text(encoding="utf-8-sig"))
            except Exception:
                continue
            rows=d if isinstance(d,list) else d.get("matches",[]) if isinstance(d,dict) else []
            if isinstance(rows,list) and rows:
                if isinstance(d,dict):
                    d=dict(d);d["schedule_source_key"]=k;return d
                return {"matches":rows,"total_upcoming_matches":len(rows),"schedule_source_key":k}
        return current or {"total_upcoming_matches":0,"matches":[]}

    def _oh_g13_analysis(self,key,event_id):
        bundle=_OH_G13_ORIG_ANALYSIS(self,key,event_id)
        bundle=dict(bundle) if isinstance(bundle,dict) else {}
        try:
            bundle["global_context"]=_oh_g13_build_context(self.base_dir,str(key),int(event_id),bundle=bundle)
        except Exception as exc:
            bundle["global_context"]={"version":"GLOBAL_CONTEXT_V1_3_2","status":"ERROR","competition_key":str(key),"event_id":int(event_id),"error":f"{type(exc).__name__}: {exc}"}
        return bundle

    DataRepository.competitions=_oh_g13_competitions
    DataRepository.upcoming_schedule=_oh_g13_upcoming
    DataRepository.analysis_bundle=_oh_g13_analysis
except Exception:
    pass

