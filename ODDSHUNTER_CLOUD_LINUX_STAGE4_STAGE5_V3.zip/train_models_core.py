from __future__ import annotations

import argparse
import json
import math
import re
import shutil
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable

import numpy as np
from scipy.optimize import minimize
from scipy.special import gammaln
from scipy.stats import nbinom, poisson

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "oddshunter.db"
REGISTRY_PATH = DATA_DIR / "competitions.json"
OUTPUT_ROOT = DATA_DIR / "trained_models"

MATCH_WINDOW = 15
RECENT_MATCHES = 5
MIN_PRIOR_MATCHES = 3

ODDSHUNTER_SUDAMERICANA_ALL_RECENT_CONTEXT_V1 = True
ODDSHUNTER_SUDAMERICANA_15_PLUS_TARGET_V1 = True
ODDSHUNTER_SUDAMERICANA_TARGET_EXTRA_EFFECTIVE_V2 = True

MIN_VENUE_MATCHES = 2
DEFAULT_HOLDOUT = 0.25
MAX_GOALS = 8
EPSILON = 1e-12

GOAL_STARTS = (
    np.array([1.1746031746031746, 0.70, 0.65, 0.20, 1.08, -0.05]),
    np.array([1.1746031746031746, 0.50, 0.50, 0.10, 1.05, 0.00]),
    np.array([1.1746031746031746, 0.85, 0.80, 0.30, 1.12, -0.10]),
)
COUNT_STARTS_BY_TARGET = {
    "corners": (
        np.array([1.0769230769230769, 0.70, 0.20]),
        np.array([1.0769230769230769, 0.50, 0.10]),
        np.array([1.0769230769230769, 0.85, 0.35]),
    ),
    "cards": (
        np.array([1.0, 0.70, 0.20]),
        np.array([1.0, 0.50, 0.10]),
        np.array([1.0, 0.85, 0.35]),
    ),
}
NB_SIZE_STARTS = (2.0, 5.0, 12.0)
GOAL_BOUNDS = (
    (1.1746031746031746, 1.1746031746031746),
    (0.0, 1.0),
    (0.0, 1.0),
    (0.0, 0.70),
    (0.85, 1.30),
    (-0.20, 0.20),
)
COUNT_BOUNDS_BY_TARGET = {
    "corners": (
        (1.0769230769230769, 1.0769230769230769),
        (0.0, 1.0),
        (0.0, 0.70),
    ),
    "cards": (
        (1.0, 1.0),
        (0.0, 1.0),
        (0.0, 0.70),
    ),
}

BUNDESLIGA_INTERNAL_FOLD_TRAIN_SIZES = (80, 104, 131, 157)
BUNDESLIGA_REGULARIZATION_GRID = (0.0, 0.001, 0.01, 0.1, 1.0)
BUNDESLIGA_GOAL_PARAMETER_NAMES = (
    "recent_weight",
    "venue_mix",
    "xg_weight",
    "league_shrinkage",
    "home_advantage",
    "dixon_coles_rho",
)
BUNDESLIGA_COUNT_PARAMETER_NAMES = (
    "recent_weight",
    "venue_mix",
    "league_shrinkage",
)

OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)


@dataclass(frozen=True)
class TeamRecord:
    venue: str
    goals_for: float | None
    goals_against: float | None
    xg_for: float | None
    xg_against: float | None
    corners_for: float | None
    corners_against: float | None
    yellow_cards: float | None


@dataclass(frozen=True)
class TrainingSample:
    match_id: int
    event_id: int | None
    kickoff: str
    home_team_id: int
    away_team_id: int
    home_team: str
    away_team: str
    home_goals: int
    away_goals: int
    home_corners: int | None
    away_corners: int | None
    home_yellow: int | None
    away_yellow: int | None
    home_history: tuple[TeamRecord, ...]
    away_history: tuple[TeamRecord, ...]
    home_venue_history: tuple[TeamRecord, ...]
    away_venue_history: tuple[TeamRecord, ...]
    league_home_goals: float
    league_away_goals: float
    league_home_corners: float | None
    league_away_corners: float | None
    league_home_yellow: float | None
    league_away_yellow: float | None


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def slugify(text: str) -> str:
    value = text.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-")


def read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"No se encontró:\n{path}")
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"{path.name} no contiene un objeto JSON.")
    return data


def read_json_optional(path: Path) -> dict[str, Any] | None:
    try:
        return read_json(path)
    except Exception:
        return None


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def finite_float(value: Any) -> float | None:
    if value is None:
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(maximum, value))


def mean_or_none(values: Iterable[float | None]) -> float | None:
    clean = [float(v) for v in values if v is not None and math.isfinite(float(v))]
    return float(np.mean(clean)) if clean else None


def geometric_mean(first: float | None, second: float | None) -> float | None:
    if first is None or second is None or first < 0 or second < 0:
        return None
    return math.sqrt(first * second)


def outcome_index(home_goals: int, away_goals: int) -> int:
    if home_goals > away_goals:
        return 0
    if home_goals == away_goals:
        return 1
    return 2


def poisson_nll(observed: int, mean: float) -> float:
    safe_mean = max(float(mean), EPSILON)
    return safe_mean - observed * math.log(safe_mean) + float(gammaln(observed + 1))


def nb_nll(observed: int, mean: float, size: float) -> float:
    safe_mean = max(float(mean), EPSILON)
    safe_size = max(float(size), 0.05)
    probability = safe_size / (safe_size + safe_mean)
    value = float(nbinom.logpmf(observed, safe_size, probability))
    return -value if math.isfinite(value) else 1e6


def brier_multiclass(probabilities: np.ndarray, observed_index: int) -> float:
    target = np.zeros(3, dtype=float)
    target[observed_index] = 1.0
    return float(np.sum((probabilities - target) ** 2))


def binary_brier(probability: float, observed: bool) -> float:
    target = 1.0 if observed else 0.0
    return (float(probability) - target) ** 2


def load_registry() -> dict[str, Any]:
    registry = read_json(REGISTRY_PATH)
    if not isinstance(registry.get("competitions"), list):
        raise ValueError("competitions.json no contiene una lista 'competitions'.")
    return registry


def find_competition(registry: dict[str, Any], key: str) -> dict[str, Any]:
    normalized = slugify(key)
    for competition in registry["competitions"]:
        if slugify(str(competition.get("key", ""))) == normalized:
            return competition
    raise ValueError(f"No existe la competición '{key}'.")


def get_connection() -> sqlite3.Connection:
    if not DB_PATH.exists():
        raise FileNotFoundError(f"No se encontró la base de datos:\n{DB_PATH}")
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def _history_source_pairs(
    competition: dict[str, Any],
) -> list[tuple[int, int]]:
    pairs: list[tuple[int, int]] = []

    for item in competition.get("history_source_pairs") or []:
        if isinstance(item, dict):
            tournament_id = item.get("tournament_id")
            season_id = item.get("season_id")
        elif isinstance(item, (list, tuple)) and len(item) >= 2:
            tournament_id, season_id = item[0], item[1]
        else:
            continue

        try:
            pair = (int(tournament_id), int(season_id))
        except (TypeError, ValueError):
            continue

        if pair not in pairs:
            pairs.append(pair)

    return pairs


def resolve_league(connection: sqlite3.Connection, competition: dict[str, Any]) -> dict[str, Any]:
    name = str(competition.get("name") or "").strip()
    season = str(competition.get("season_name") or "").strip()
    tournament_id = competition.get("source_competition_id")
    source_season_id = competition.get("season_id")
    rows: list[sqlite3.Row] = []

    try:
        if tournament_id is not None and source_season_id is not None:
            rows = connection.execute(
                """
                SELECT league_id, name, country, season
                FROM leagues
                WHERE source_tournament_id = ?
                  AND source_season_id = ?
                ORDER BY league_id DESC;
                """,
                (int(tournament_id), int(source_season_id)),
            ).fetchall()
    except (TypeError, ValueError):
        rows = []

    if not rows:
        names = [
            str(value).strip()
            for value in (
                competition.get("name"),
                competition.get("source_name"),
                *(competition.get("aliases") or []),
            )
            if str(value or "").strip()
        ]
        placeholders = ",".join("?" for _ in names)
        if names:
            rows = connection.execute(
                f"""
                SELECT league_id, name, country, season
                FROM leagues
                WHERE LOWER(name) IN ({placeholders})
                ORDER BY league_id DESC;
                """,
                tuple(value.lower() for value in names),
            ).fetchall()

    if not rows:
        raise RuntimeError(f"No se encontró la competición '{name}' en SQLite.")
    if season:
        exact = [row for row in rows if str(row["season"] or "") == season]
        if exact:
            rows = exact
    row = rows[0]
    primary_league_id = int(row["league_id"])
    league_ids: set[int] = {primary_league_id}
    resolved_pairs: list[dict[str, int]] = []

    for tournament_id, season_id in _history_source_pairs(competition):
        pair_rows = connection.execute(
            """
            SELECT league_id
            FROM leagues
            WHERE source_tournament_id = ?
              AND source_season_id = ?
            ORDER BY league_id;
            """,
            (tournament_id, season_id),
        ).fetchall()
        pair_league_ids = [
            int(pair_row["league_id"])
            for pair_row in pair_rows
            if pair_row["league_id"] is not None
        ]
        league_ids.update(pair_league_ids)
        resolved_pairs.extend(
            {
                "tournament_id": tournament_id,
                "season_id": season_id,
                "league_id": league_id,
            }
            for league_id in pair_league_ids
        )

    return {
        "league_id": primary_league_id,
        "league_ids": sorted(league_ids),
        "name": str(row["name"]),
        "country": str(row["country"] or ""),
        "season": str(row["season"] or ""),
        "key": slugify(str(competition["key"])),
        "history_source_pairs": resolved_pairs,
        "training_scope": (
            "registry_history_source_pairs"
            if resolved_pairs
            else "primary_league"
        ),
    }


def load_match_rows(
    connection: sqlite3.Connection,
    league_ids: Iterable[int],
) -> list[dict[str, Any]]:
    resolved_ids = sorted({int(value) for value in league_ids})
    if not resolved_ids:
        return []

    placeholders = ",".join("?" for _ in resolved_ids)
    rows = connection.execute(
        f"""
        SELECT
            m.match_id,
            m.sofascore_id AS event_id,
            m.kickoff,
            m.league_id,
            m.home_team_id,
            m.away_team_id,
            home.sofascore_id AS home_sofascore_id,
            away.sofascore_id AS away_sofascore_id,
            home.name AS home_team,
            away.name AS away_team,
            m.home_goals,
            m.away_goals,
            hs.goals_for AS home_goals_for,
            hs.goals_against AS home_goals_against,
            hs.xg_for AS home_xg_for,
            hs.xg_against AS home_xg_against,
            hs.corners_for AS home_corners_for,
            hs.corners_against AS home_corners_against,
            hs.yellow_cards AS home_yellow_cards,
            aws.goals_for AS away_goals_for,
            aws.goals_against AS away_goals_against,
            aws.xg_for AS away_xg_for,
            aws.xg_against AS away_xg_against,
            aws.corners_for AS away_corners_for,
            aws.corners_against AS away_corners_against,
            aws.yellow_cards AS away_yellow_cards
        FROM matches AS m
        INNER JOIN teams AS home ON home.team_id = m.home_team_id
        INNER JOIN teams AS away ON away.team_id = m.away_team_id
        INNER JOIN team_match_stats AS hs
            ON hs.match_id = m.match_id AND hs.venue = 'HOME'
        INNER JOIN team_match_stats AS aws
            ON aws.match_id = m.match_id AND aws.venue = 'AWAY'
        WHERE
            m.league_id IN ({placeholders})
            -- Importers use both the compact SofaScore code and the
            -- normalized textual status.  Restricting this query to FT made
            -- complete historical leagues (notably Canada) look empty.
            AND LOWER(TRIM(m.status)) IN ('ft', 'finished')
            AND m.home_goals IS NOT NULL
            AND m.away_goals IS NOT NULL
        ORDER BY m.kickoff ASC, m.match_id ASC;
        """,
        tuple(resolved_ids),
    ).fetchall()
    return [dict(row) for row in rows]

def average_or_default(values: list[float], default: float) -> float:
    return float(np.mean(values)) if values else float(default)



def _training_team_identity(
    row: dict[str, Any],
    side: str,
) -> tuple[str, int]:
    team_id = int(row[f"{side}_team_id"])
    sofascore_id = row.get(f"{side}_sofascore_id")

    if sofascore_id is not None:
        return (
            "sofascore",
            int(sofascore_id),
        )

    return (
        "internal",
        team_id,
    )


def _training_kickoff_timestamp(value: Any) -> float:
    import datetime as _dt

    text = str(value or "").strip().replace(
        "Z",
        "+00:00",
    )

    if not text:
        raise ValueError(
            "Kickoff vac?o en entrenamiento."
        )

    dt = _dt.datetime.fromisoformat(text)

    if dt.tzinfo is None:
        dt = dt.replace(
            tzinfo=_dt.timezone.utc
        )

    return float(dt.timestamp())


def _training_team_records(
    row: dict[str, Any],
) -> tuple[TeamRecord, TeamRecord]:
    home_record = TeamRecord(
        venue="HOME",
        goals_for=finite_float(
            row["home_goals_for"]
        ),
        goals_against=finite_float(
            row["home_goals_against"]
        ),
        xg_for=finite_float(
            row["home_xg_for"]
        ),
        xg_against=finite_float(
            row["home_xg_against"]
        ),
        corners_for=finite_float(
            row["home_corners_for"]
        ),
        corners_against=finite_float(
            row["home_corners_against"]
        ),
        yellow_cards=finite_float(
            row["home_yellow_cards"]
        ),
    )

    away_record = TeamRecord(
        venue="AWAY",
        goals_for=finite_float(
            row["away_goals_for"]
        ),
        goals_against=finite_float(
            row["away_goals_against"]
        ),
        xg_for=finite_float(
            row["away_xg_for"]
        ),
        xg_against=finite_float(
            row["away_xg_against"]
        ),
        corners_for=finite_float(
            row["away_corners_for"]
        ),
        corners_against=finite_float(
            row["away_corners_against"]
        ),
        yellow_cards=finite_float(
            row["away_yellow_cards"]
        ),
    )

    return home_record, away_record


def resolve_domestic_context_league_ids(
    connection: sqlite3.Connection,
    registry: dict[str, Any],
    competition: dict[str, Any],
    excluded_league_ids: Iterable[int],
) -> list[int]:
    # ODDSHUNTER_SUDAMERICANA_ALL_RECENT_CONTEXT_V1
    # Sudamericana usa el historial normal del equipo en todas
    # las competiciones FT válidas que ya existen en SQLite.
    # El filtrado posterior conserva solo equipos TARGET.
    if str(competition.get('key') or '').strip().lower() == 'conmebol-sudamericana':
        excluded = {
            int(value)
            for value in excluded_league_ids
        }

        rows = connection.execute(
            """
            SELECT DISTINCT
                m.league_id
            FROM matches AS m
            WHERE m.status = 'FT'
              AND m.home_goals IS NOT NULL
              AND m.away_goals IS NOT NULL
            ORDER BY m.league_id ASC;
            """
        ).fetchall()

        return [
            int(row[0])
            for row in rows
            if int(row[0]) not in excluded
        ]

    mode = str(
        competition.get("training_context_mode")
        or ""
    ).strip().lower()

    if mode != "domestic_plus_primary":
        return []

    excluded = {
        int(value)
        for value in excluded_league_ids
    }

    international_labels = {
        "EUROPE",
        "SOUTH AMERICA",
        "WORLD",
        "INTERNATIONAL",
        "GLOBAL",
    }

    target_tournament_id = competition.get(
        "source_competition_id"
    )

    try:
        target_tournament_id = int(
            target_tournament_id
        )
    except (TypeError, ValueError):
        target_tournament_id = None

    domestic_tournaments: set[int] = set()
    domestic_pairs: set[tuple[int, int]] = set()

    for item in registry.get("competitions") or []:
        country = str(
            item.get("country") or ""
        ).strip().upper()

        if (
            not country
            or country in international_labels
        ):
            continue

        tournament_id = item.get(
            "source_competition_id"
        )

        season_id = item.get(
            "season_id"
        )

        try:
            tournament_id = int(
                tournament_id
            )
        except (TypeError, ValueError):
            continue

        if (
            target_tournament_id is not None
            and tournament_id
            == target_tournament_id
        ):
            continue

        domestic_tournaments.add(
            tournament_id
        )

        try:
            season_id = int(
                season_id
            )
        except (TypeError, ValueError):
            season_id = None

        if season_id is not None:
            domestic_pairs.add(
                (
                    tournament_id,
                    season_id,
                )
            )

    league_rows = connection.execute(
        """
        SELECT *
        FROM leagues
        ORDER BY league_id;
        """
    ).fetchall()

    resolved: list[int] = []

    for raw in league_rows:
        row = dict(raw)

        league_id = int(
            row["league_id"]
        )

        if league_id in excluded:
            continue

        tournament_id = row.get(
            "source_tournament_id"
        )

        season_id = row.get(
            "source_season_id"
        )

        try:
            tournament_id = int(
                tournament_id
            )
        except (TypeError, ValueError):
            tournament_id = None

        try:
            season_id = int(
                season_id
            )
        except (TypeError, ValueError):
            season_id = None

        family = str(
            row.get("competition_family")
            or ""
        ).strip().upper()

        role = str(
            row.get("context_role")
            or ""
        ).strip().upper()

        is_domestic = (
            family == "DOMESTIC"
            or "DOMESTIC" in role
            or (
                tournament_id is not None
                and tournament_id
                in domestic_tournaments
            )
            or (
                tournament_id is not None
                and season_id is not None
                and (
                    tournament_id,
                    season_id,
                )
                in domestic_pairs
            )
        )

        if not is_domestic:
            continue

        if (
            target_tournament_id is not None
            and tournament_id
            == target_tournament_id
        ):
            continue

        resolved.append(
            league_id
        )

    return sorted(
        set(resolved)
    )



# =============================================================================
# ODDSHUNTER_CHAMPIONS_HISTORICAL_ROUTING_V3
# =============================================================================

ODDSHUNTER_CHAMPIONS_HISTORICAL_ROUTING_V3 = True

_CHAMPIONS_HISTORICAL_SCOPE_PATH = (
    DATA_DIR
    / "maintenance"
    / "CHAMPIONS_TRAINING_SCOPE_2024_25_2025_26.json"
)


def _champions_historical_scope_ids():
    payload = json.loads(
        _CHAMPIONS_HISTORICAL_SCOPE_PATH.read_text(
            encoding="utf-8-sig"
        )
    )

    target_ids = [
        int(value)
        for value in (
            payload.get("target_event_ids")
            or []
        )
    ]

    family_ids = [
        int(value)
        for value in (
            payload.get("uefa_context_event_ids")
            or []
        )
    ]

    if (
        len(target_ids) != 378
        or len(set(target_ids)) != 378
    ):
        raise RuntimeError(
            "Champions TARGET histórico != 378 exactos."
        )

    if (
        len(family_ids) != 182
        or len(set(family_ids)) != 182
    ):
        raise RuntimeError(
            "Champions family histórico != 182 exactos."
        )

    if set(target_ids) & set(family_ids):
        raise RuntimeError(
            "Overlap TARGET / Champions family."
        )

    return target_ids, family_ids


def _load_champions_historical_training_rows(
    connection: sqlite3.Connection,
    league: dict[str, Any],
):
    target_ids, family_ids = (
        _champions_historical_scope_ids()
    )

    target_set = set(target_ids)
    family_set = set(family_ids)

    raw_league_ids = connection.execute(
        """
        SELECT DISTINCT
            m.league_id

        FROM matches AS m

        INNER JOIN leagues AS l
          ON l.league_id = m.league_id

        WHERE
            m.status = 'FT'

            AND m.home_goals IS NOT NULL
            AND m.away_goals IS NOT NULL

            AND m.league_id IS NOT NULL

            AND LOWER(
                COALESCE(l.name, '')
            ) NOT LIKE '%friendly%'

            AND LOWER(
                COALESCE(l.name, '')
            ) NOT LIKE '%amistoso%'

        ORDER BY m.league_id;
        """
    ).fetchall()

    league_ids = [
        int(row[0])
        for row in raw_league_ids
    ]

    all_rows = load_match_rows(
        connection,
        league_ids,
    )

    by_event = {}

    for row in all_rows:

        if row.get("event_id") is None:
            continue

        event_id = int(
            row["event_id"]
        )

        previous = by_event.get(
            event_id
        )

        if (
            previous is not None
            and
            int(previous["match_id"])
            !=
            int(row["match_id"])
        ):
            raise RuntimeError(
                f"event_id duplicado SQLite: {event_id}"
            )

        by_event[
            event_id
        ] = row


    missing_target = sorted(
        target_set
        -
        set(by_event)
    )

    missing_family = sorted(
        family_set
        -
        set(by_event)
    )


    if missing_target:
        raise RuntimeError(
            "TARGET históricos faltantes: "
            + repr(
                missing_target[:20]
            )
        )

    if missing_family:
        raise RuntimeError(
            "Champions-family faltantes: "
            + repr(
                missing_family[:20]
            )
        )


    target_rows = [
        dict(
            by_event[event_id]
        )
        for event_id in target_ids
    ]


    target_rows.sort(
        key=lambda row: (
            _training_kickoff_timestamp(
                row["kickoff"]
            ),
            int(
                row["match_id"]
            ),
        )
    )


    target_identities = set()

    for row in target_rows:

        target_identities.add(
            _training_team_identity(
                row,
                "home",
            )
        )

        target_identities.add(
            _training_team_identity(
                row,
                "away",
            )
        )


    expected_relevant_family = set()

    for event_id in family_set:

        row = by_event[
            event_id
        ]

        home_identity = (
            _training_team_identity(
                row,
                "home",
            )
        )

        away_identity = (
            _training_team_identity(
                row,
                "away",
            )
        )

        if (
            home_identity
            in target_identities

            or

            away_identity
            in target_identities
        ):
            expected_relevant_family.add(
                event_id
            )


    context_rows = []

    seen = set()

    actual_relevant_family = set()


    for source_row in all_rows:

        event_id = (
            int(
                source_row["event_id"]
            )
            if source_row.get("event_id")
            is not None
            else None
        )


        if (
            event_id is not None
            and
            event_id in target_set
        ):
            continue


        home_identity = (
            _training_team_identity(
                source_row,
                "home",
            )
        )

        away_identity = (
            _training_team_identity(
                source_row,
                "away",
            )
        )


        if (
            home_identity
            not in target_identities

            and

            away_identity
            not in target_identities
        ):
            continue


        unique_key = (
            (
                "event",
                event_id,
            )

            if event_id is not None

            else

            (
                "match",
                int(
                    source_row["match_id"]
                ),
            )
        )


        if unique_key in seen:
            continue


        seen.add(
            unique_key
        )


        row = dict(
            source_row
        )


        if (
            event_id is not None
            and
            event_id in family_set
        ):

            row[
                "_training_source_kind"
            ] = "target_family"

            actual_relevant_family.add(
                event_id
            )

        else:

            row[
                "_training_source_kind"
            ] = "context"


        context_rows.append(
            row
        )


    context_rows.sort(
        key=lambda row: (
            _training_kickoff_timestamp(
                row["kickoff"]
            ),
            int(
                row["match_id"]
            ),
        )
    )


    if (
        actual_relevant_family
        !=
        expected_relevant_family
    ):
        raise RuntimeError(
            "Champions-family relevante incompleta."
        )


    league[
        "training_scope"
    ] = "champions_historical_sidecar_v3"

    league[
        "context_matches"
    ] = len(
        context_rows
    )

    league[
        "champions_family_context"
    ] = len(
        actual_relevant_family
    )

    league[
        "historical_target_matches"
    ] = len(
        target_rows
    )


    return (
        target_rows,
        context_rows,
    )


def _load_profile_history_context_rows(
    connection: sqlite3.Connection,
    competition: dict[str, Any],
) -> list[dict[str, Any]]:
    """Carga contexto por equipo sin convertirlo en TARGET de la competición."""
    league_to_team_ids: dict[int, set[int]] = {}

    for item in competition.get("profile_history_source_pairs") or []:
        if not isinstance(item, dict):
            continue
        try:
            tournament_id = int(item.get("tournament_id"))
            season_id = int(item.get("season_id"))
        except (TypeError, ValueError):
            continue

        allowed_team_ids: set[int] = set()
        for value in item.get("team_sofascore_ids") or []:
            try:
                allowed_team_ids.add(int(value))
            except (TypeError, ValueError):
                continue
        if not allowed_team_ids:
            continue

        league_rows = connection.execute(
            """
            SELECT league_id
            FROM leagues
            WHERE source_tournament_id = ?
              AND source_season_id = ?
            ORDER BY league_id;
            """,
            (tournament_id, season_id),
        ).fetchall()
        for row in league_rows:
            league_to_team_ids.setdefault(int(row["league_id"]), set()).update(
                allowed_team_ids
            )

    if not league_to_team_ids:
        return []

    raw_rows = load_match_rows(connection, league_to_team_ids)
    context_rows: list[dict[str, Any]] = []
    seen: set[tuple[str, int]] = set()

    for raw in raw_rows:
        allowed = league_to_team_ids.get(int(raw["league_id"]), set())
        participating = {
            int(value)
            for value in (
                raw.get("home_sofascore_id"),
                raw.get("away_sofascore_id"),
            )
            if value is not None and int(value) in allowed
        }
        if not participating:
            continue

        unique_key = (
            ("event", int(raw["event_id"]))
            if raw.get("event_id") is not None
            else ("match", int(raw["match_id"]))
        )
        if unique_key in seen:
            continue
        seen.add(unique_key)

        row = dict(raw)
        row["_training_source_kind"] = "profile_context"
        row["_training_allowed_sofascore_ids"] = sorted(participating)
        context_rows.append(row)

    return context_rows


def load_training_rows(
    connection: sqlite3.Connection,
    registry: dict[str, Any],
    competition: dict[str, Any],
    league: dict[str, Any],
) -> tuple[
    list[dict[str, Any]],
    list[dict[str, Any]],
]:
    if (
        str(
            competition.get("key")
            or ""
        ).strip().lower()
        ==
        "uefa-champions-league"
    ):
        return (
            _load_champions_historical_training_rows(
                connection,
                league,
            )
        )

    # TARGET:
    # ?nicamente la competici?n que se est? entrenando.
    # history_source_pairs de la MISMA competici?n tambi?n
    # pueden formar muestras objetivo leg?timas.
    target_rows = load_match_rows(
        connection,
        league["league_ids"],
    )

    profile_context_rows = _load_profile_history_context_rows(
        connection,
        competition,
    )

    mode = str(
        competition.get("training_context_mode")
        or ""
    ).strip().lower()

    if mode != "domestic_plus_primary":
        if profile_context_rows:
            league["training_scope"] = (
                "target_competition_plus_profile_context"
            )
            league["context_league_ids"] = sorted(
                {int(row["league_id"]) for row in profile_context_rows}
            )
            league["context_matches"] = len(profile_context_rows)
        return target_rows, profile_context_rows

    context_league_ids = (
        resolve_domestic_context_league_ids(
            connection=connection,
            registry=registry,
            competition=competition,
            excluded_league_ids=league[
                "league_ids"
            ],
        )
    )

    if not context_league_ids:
        return target_rows, profile_context_rows

    # Solo interesan contextos de equipos que realmente
    # participan en las muestras TARGET.
    target_identities: set[
        tuple[str, int]
    ] = set()

    for row in target_rows:
        target_identities.add(
            _training_team_identity(
                row,
                "home",
            )
        )

        target_identities.add(
            _training_team_identity(
                row,
                "away",
            )
        )

    raw_context_rows = load_match_rows(
        connection,
        context_league_ids,
    )

    context_rows: list[dict[str, Any]] = list(profile_context_rows)

    seen: set[tuple[str, int]] = {
        (
            ("event", int(row["event_id"]))
            if row.get("event_id") is not None
            else ("match", int(row["match_id"]))
        )
        for row in context_rows
    }

    for row in raw_context_rows:
        home_identity = (
            _training_team_identity(
                row,
                "home",
            )
        )

        away_identity = (
            _training_team_identity(
                row,
                "away",
            )
        )

        if (
            home_identity
            not in target_identities
            and away_identity
            not in target_identities
        ):
            continue

        if row.get("event_id") is not None:
            unique_key = (
                "event",
                int(row["event_id"]),
            )
        else:
            unique_key = (
                "match",
                int(row["match_id"]),
            )

        if unique_key in seen:
            continue

        seen.add(
            unique_key
        )

        context_rows.append(
            row
        )

    context_rows.sort(
        key=lambda row: (
            _training_kickoff_timestamp(
                row["kickoff"]
            ),
            int(row["match_id"]),
        )
    )

    relevant_context_leagues = sorted(
        {
            int(row["league_id"])
            for row in context_rows
        }
    )

    league[
        "training_scope"
    ] = "target_competition_plus_domestic_context"

    league[
        "context_league_ids"
    ] = relevant_context_leagues

    league[
        "context_matches"
    ] = len(context_rows)

    return target_rows, context_rows


def build_samples_with_context(
    target_rows: list[dict[str, Any]],
    context_rows: list[dict[str, Any]],
    context_lookback_days: int = 365,
    include_target_extras: bool = False,
) -> list[TrainingSample]:
    lookback_seconds = (
        max(
            1,
            int(context_lookback_days),
        )
        * 86400.0
    )

    # Cada historial conserva su procedencia.
    #
    # target:
    #   partido de la propia competici?n.
    #
    # context:
    #   partido dom?stico.
    #
    # Los contextos dom?sticos tienen ventana temporal.
    # Los TARGET previos mantienen el comportamiento
    # hist?rico de la competici?n.
    histories: dict[
        tuple[str, int],
        list[
            tuple[
                float,
                int,
                str,
                TeamRecord,
            ]
        ],
    ] = {}

    def add_history_row(
        row: dict[str, Any],
        source_kind: str,
    ) -> None:
        kickoff_ts = (
            _training_kickoff_timestamp(
                row["kickoff"]
            )
        )

        match_id = int(
            row["match_id"]
        )

        home_identity = (
            _training_team_identity(
                row,
                "home",
            )
        )

        away_identity = (
            _training_team_identity(
                row,
                "away",
            )
        )

        (
            home_record,
            away_record,
        ) = _training_team_records(
            row
        )

        allowed_source_ids = row.get(
            "_training_allowed_sofascore_ids"
        )
        allowed = (
            {int(value) for value in allowed_source_ids}
            if allowed_source_ids is not None
            else None
        )

        home_source_id = row.get("home_sofascore_id")
        away_source_id = row.get("away_sofascore_id")

        if allowed is None or (
            home_source_id is not None
            and int(home_source_id) in allowed
        ):
            histories.setdefault(home_identity, []).append(
                (kickoff_ts, match_id, source_kind, home_record)
            )

        if allowed is None or (
            away_source_id is not None
            and int(away_source_id) in allowed
        ):
            histories.setdefault(away_identity, []).append(
                (kickoff_ts, match_id, source_kind, away_record)
            )

    for row in context_rows:
        add_history_row(
            row,
            str(
                row.get(
                    "_training_source_kind"
                )
                or "context"
            ),
        )

    for row in target_rows:
        add_history_row(
            row,
            "target",
        )

    for entries in histories.values():
        entries.sort(
            key=lambda item: (
                item[0],
                item[1],
            )
        )

    ordered_targets = sorted(
        target_rows,
        key=lambda row: (
            _training_kickoff_timestamp(
                row["kickoff"]
            ),
            int(row["match_id"]),
        ),
    )

    samples: list[
        TrainingSample
    ] = []

    grouped_targets: list[list[dict[str, Any]]] = []
    for row in ordered_targets:
        if (
            not grouped_targets
            or _training_kickoff_timestamp(
                grouped_targets[-1][0]["kickoff"]
            )
            != _training_kickoff_timestamp(row["kickoff"])
        ):
            grouped_targets.append([])
        grouped_targets[-1].append(row)

    # Los grupos fijan una frontera común. Todos los historiales y medias
    # aplican cutoff estricto, de modo que ningún miembro ve resultados
    # de otro partido con el mismo kickoff.
    grouped_order = (
        row
        for kickoff_group in grouped_targets
        for row in kickoff_group
    )
    for row in grouped_order:
        cutoff = (
            _training_kickoff_timestamp(
                row["kickoff"]
            )
        )

        context_floor = (
            cutoff
            - lookback_seconds
        )

        home_team_id = int(
            row["home_team_id"]
        )

        away_team_id = int(
            row["away_team_id"]
        )

        home_identity = (
            _training_team_identity(
                row,
                "home",
            )
        )

        away_identity = (
            _training_team_identity(
                row,
                "away",
            )
        )

        def history_before(
            identity: tuple[str, int],
            venue: str | None = None,
        ) -> tuple[TeamRecord, ...]:
            # ODDSHUNTER_SUDAMERICANA_15_PLUS_TARGET_V1
            # BASE = últimos 15 partidos normales previos.
            # EXTRA = TARGET Sudamericana previo que quedó fuera de esos 15.
            # Un TARGET ya incluido en BASE no se duplica.
            entries: list[tuple[float, int, str, TeamRecord]] = []

            for (
                kickoff_ts,
                match_id,
                source_kind,
                record,
            ) in histories.get(identity, []):
                if kickoff_ts >= cutoff:
                    continue
                if source_kind not in {"target", "target_family"}:
                    if kickoff_ts < context_floor:
                        continue
                if venue is not None and record.venue != venue:
                    continue

                entries.append(
                    (
                        kickoff_ts,
                        match_id,
                        source_kind,
                        record,
                    )
                )

            entries.sort(
                key=lambda item: (
                    item[0],
                    item[1],
                )
            )

            base_entries = entries[-MATCH_WINDOW:]

            base_match_ids = {
                item[1]
                for item in base_entries
            }

            target_extra = (
                [
                    item
                    for item in entries
                    if item[2] in {"target", "target_family"}
                    and item[1] not in base_match_ids
                ]
                if include_target_extras
                else []
            )

            combined = (
                target_extra
                + base_entries
            )

            combined.sort(
                key=lambda item: (
                    item[0],
                    item[1],
                )
            )

            return tuple(
                item[3]
                for item in combined
            )

        home_history = (
            history_before(
                home_identity
            )
        )

        away_history = (
            history_before(
                away_identity
            )
        )

        home_venue_history = history_before(
            home_identity,
            "HOME",
        )
        away_venue_history = history_before(
            away_identity,
            "AWAY",
        )

        if (
            len(home_history)
            < MIN_PRIOR_MATCHES
            or len(away_history)
            < MIN_PRIOR_MATCHES
        ):
            continue

        # Las medias "de liga" se calculan ?NICAMENTE
        # con partidos TARGET anteriores.
        #
        # Las dom?sticas jam?s contaminan estas medias.
        prior_target_rows = [
            prior
            for prior in ordered_targets
            if (
                _training_kickoff_timestamp(
                    prior["kickoff"]
                )
                < cutoff
            )
        ]

        prior_home_goals = [
            float(prior["home_goals"])
            for prior in prior_target_rows
            if prior["home_goals"]
            is not None
        ]

        prior_away_goals = [
            float(prior["away_goals"])
            for prior in prior_target_rows
            if prior["away_goals"]
            is not None
        ]

        prior_home_corners = [
            float(
                prior[
                    "home_corners_for"
                ]
            )
            for prior in prior_target_rows
            if prior[
                "home_corners_for"
            ]
            is not None
        ]

        prior_away_corners = [
            float(
                prior[
                    "away_corners_for"
                ]
            )
            for prior in prior_target_rows
            if prior[
                "away_corners_for"
            ]
            is not None
        ]

        prior_home_yellow = [
            float(
                prior[
                    "home_yellow_cards"
                ]
            )
            for prior in prior_target_rows
            if prior[
                "home_yellow_cards"
            ]
            is not None
        ]

        prior_away_yellow = [
            float(
                prior[
                    "away_yellow_cards"
                ]
            )
            for prior in prior_target_rows
            if prior[
                "away_yellow_cards"
            ]
            is not None
        ]

        samples.append(
            TrainingSample(
                match_id=int(
                    row["match_id"]
                ),
                event_id=(
                    int(
                        row["event_id"]
                    )
                    if row[
                        "event_id"
                    ]
                    is not None
                    else None
                ),
                kickoff=str(
                    row["kickoff"]
                ),
                home_team_id=home_team_id,
                away_team_id=away_team_id,
                home_team=str(
                    row["home_team"]
                ),
                away_team=str(
                    row["away_team"]
                ),
                home_goals=int(
                    row["home_goals"]
                ),
                away_goals=int(
                    row["away_goals"]
                ),
                home_corners=(
                    int(
                        row[
                            "home_corners_for"
                        ]
                    )
                    if row[
                        "home_corners_for"
                    ]
                    is not None
                    else None
                ),
                away_corners=(
                    int(
                        row[
                            "away_corners_for"
                        ]
                    )
                    if row[
                        "away_corners_for"
                    ]
                    is not None
                    else None
                ),
                home_yellow=(
                    int(
                        row[
                            "home_yellow_cards"
                        ]
                    )
                    if row[
                        "home_yellow_cards"
                    ]
                    is not None
                    else None
                ),
                away_yellow=(
                    int(
                        row[
                            "away_yellow_cards"
                        ]
                    )
                    if row[
                        "away_yellow_cards"
                    ]
                    is not None
                    else None
                ),
                home_history=home_history,
                away_history=away_history,
                home_venue_history=home_venue_history,
                away_venue_history=away_venue_history,
                league_home_goals=(
                    average_or_default(
                        prior_home_goals,
                        1.45,
                    )
                ),
                league_away_goals=(
                    average_or_default(
                        prior_away_goals,
                        1.15,
                    )
                ),
                league_home_corners=(
                    mean_or_none(
                        prior_home_corners
                    )
                ),
                league_away_corners=(
                    mean_or_none(
                        prior_away_corners
                    )
                ),
                league_home_yellow=(
                    mean_or_none(
                        prior_home_yellow
                    )
                ),
                league_away_yellow=(
                    mean_or_none(
                        prior_away_yellow
                    )
                ),
            )
        )

    return samples


def build_training_samples(
    target_rows: list[dict[str, Any]],
    context_rows: list[dict[str, Any]],
    competition: dict[str, Any],
) -> list[TrainingSample]:
    lookback_days = competition.get(
        "training_context_lookback_days",
        competition.get("history_lookback_days", 365),
    )

    try:
        lookback_days = int(
            lookback_days
        )
    except (TypeError, ValueError):
        lookback_days = 365

    return build_samples_with_context(
        target_rows=target_rows,
        context_rows=context_rows,
        context_lookback_days=lookback_days,
        include_target_extras=(
            str(competition.get("key") or "").strip().lower()
            == "conmebol-sudamericana"
        ),
    )

def build_samples(rows: list[dict[str, Any]]) -> list[TrainingSample]:
    return build_samples_with_context(
        target_rows=rows,
        context_rows=[],
        context_lookback_days=365,
        include_target_extras=False,
    )


def weighted_profile(
    history: tuple[TeamRecord, ...],
    field: str,
    recent_weight: float,
    required_venue: str | None,
) -> float | None:
    # El historial recibido ya fue curado al construir la muestra.
    #
    # Flujo normal:
    #   build_samples() entrega como maximo MATCH_WINDOW.
    #
    # Sudamericana:
    #   build_samples_with_context() entrega:
    #   - BASE: ultimos 15 partidos normales previos
    #   - EXTRA: Sudamericana TARGET previo fuera del BASE
    #   - sin duplicar partidos ya incluidos en BASE
    #
    # No recortar de nuevo a MATCH_WINDOW porque eliminaria
    # precisamente el contexto TARGET adicional.
    rows = list(history)
    if required_venue is not None:
        venue_rows = [row for row in rows if row.venue == required_venue]
        if len(venue_rows) >= MIN_VENUE_MATCHES:
            rows = venue_rows
    numerator = 0.0
    denominator = 0.0
    for reverse_index, row in enumerate(reversed(rows)):
        value = finite_float(getattr(row, field))
        if value is None:
            continue
        weight = recent_weight if reverse_index < RECENT_MATCHES else 1.0
        numerator += value * weight
        denominator += weight
    return numerator / denominator if denominator else None


def blended_profile(
    general_history: tuple[TeamRecord, ...],
    venue_history: tuple[TeamRecord, ...],
    field: str,
    recent_weight: float,
    venue_mix: float,
) -> float | None:
    overall = weighted_profile(general_history, field, recent_weight, None)
    venue_value = weighted_profile(venue_history, field, recent_weight, None)
    if overall is None:
        return venue_value
    if venue_value is None:
        return overall
    return venue_mix * venue_value + (1.0 - venue_mix) * overall


def dixon_coles_matrix(lambda_home: float, lambda_away: float, rho: float) -> np.ndarray:
    home_values = poisson.pmf(np.arange(MAX_GOALS + 1), lambda_home)
    away_values = poisson.pmf(np.arange(MAX_GOALS + 1), lambda_away)
    matrix = np.outer(home_values, away_values)
    corrections = {
        (0, 0): 1.0 - lambda_home * lambda_away * rho,
        (0, 1): 1.0 + lambda_home * rho,
        (1, 0): 1.0 + lambda_away * rho,
        (1, 1): 1.0 - rho,
    }
    for (home_goals, away_goals), factor in corrections.items():
        matrix[home_goals, away_goals] *= max(factor, EPSILON)
    total = float(matrix.sum())
    if total <= 0 or not math.isfinite(total):
        return np.full((MAX_GOALS + 1, MAX_GOALS + 1), 1.0 / ((MAX_GOALS + 1) ** 2))
    return matrix / total


def goal_prediction(sample: TrainingSample, parameters: np.ndarray) -> tuple[float, float, np.ndarray]:
    recent_weight, venue_mix, xg_weight, shrinkage, home_advantage, rho = parameters
    home_gf = blended_profile(sample.home_history, sample.home_venue_history, "goals_for", recent_weight, venue_mix)
    home_ga = blended_profile(sample.home_history, sample.home_venue_history, "goals_against", recent_weight, venue_mix)
    away_gf = blended_profile(sample.away_history, sample.away_venue_history, "goals_for", recent_weight, venue_mix)
    away_ga = blended_profile(sample.away_history, sample.away_venue_history, "goals_against", recent_weight, venue_mix)
    home_xgf = blended_profile(sample.home_history, sample.home_venue_history, "xg_for", recent_weight, venue_mix)
    home_xga = blended_profile(sample.home_history, sample.home_venue_history, "xg_against", recent_weight, venue_mix)
    away_xgf = blended_profile(sample.away_history, sample.away_venue_history, "xg_for", recent_weight, venue_mix)
    away_xga = blended_profile(sample.away_history, sample.away_venue_history, "xg_against", recent_weight, venue_mix)

    goals_home = geometric_mean(home_gf, away_ga) or sample.league_home_goals
    goals_away = geometric_mean(away_gf, home_ga) or sample.league_away_goals
    xg_home = geometric_mean(home_xgf, away_xga) or goals_home
    xg_away = geometric_mean(away_xgf, home_xga) or goals_away

    lambda_home = (1.0 - xg_weight) * goals_home + xg_weight * xg_home
    lambda_away = (1.0 - xg_weight) * goals_away + xg_weight * xg_away
    lambda_home = (1.0 - shrinkage) * lambda_home + shrinkage * sample.league_home_goals
    lambda_away = (1.0 - shrinkage) * lambda_away + shrinkage * sample.league_away_goals
    lambda_home *= home_advantage
    lambda_home = clamp(lambda_home, 0.05, 6.0)
    lambda_away = clamp(lambda_away, 0.05, 6.0)

    matrix = dixon_coles_matrix(lambda_home, lambda_away, rho)
    probabilities = np.array(
        [
            float(np.tril(matrix, -1).sum()),
            float(np.trace(matrix)),
            float(np.triu(matrix, 1).sum()),
        ],
        dtype=float,
    )
    probabilities /= probabilities.sum()
    return lambda_home, lambda_away, probabilities


def goals_objective(parameters: np.ndarray, samples: list[TrainingSample]) -> float:
    losses: list[float] = []
    for sample in samples:
        lambda_home, lambda_away, probabilities = goal_prediction(sample, parameters)
        observed = outcome_index(sample.home_goals, sample.away_goals)
        outcome_loss = -math.log(max(float(probabilities[observed]), EPSILON))
        count_loss = 0.5 * (
            poisson_nll(sample.home_goals, lambda_home)
            + poisson_nll(sample.away_goals, lambda_away)
        )
        losses.append(outcome_loss + 0.20 * count_loss)
    return float(np.mean(losses)) if losses else 1e6


def evaluate_goals(parameters: np.ndarray, samples: list[TrainingSample]) -> dict[str, Any]:
    briers: list[float] = []
    log_losses: list[float] = []
    accuracies: list[float] = []
    count_nlls: list[float] = []
    for sample in samples:
        lambda_home, lambda_away, probabilities = goal_prediction(sample, parameters)
        observed = outcome_index(sample.home_goals, sample.away_goals)
        briers.append(brier_multiclass(probabilities, observed))
        log_losses.append(-math.log(max(float(probabilities[observed]), EPSILON)))
        accuracies.append(1.0 if int(np.argmax(probabilities)) == observed else 0.0)
        count_nlls.append(
            0.5 * (
                poisson_nll(sample.home_goals, lambda_home)
                + poisson_nll(sample.away_goals, lambda_away)
            )
        )
    return {
        "samples": len(samples),
        "brier_score": round(float(np.mean(briers)), 8),
        "log_loss": round(float(np.mean(log_losses)), 8),
        "accuracy": round(float(np.mean(accuracies)), 8),
        "mean_goal_count_nll": round(float(np.mean(count_nlls)), 8),
    }


def count_prediction(sample: TrainingSample, parameters: np.ndarray, target: str) -> tuple[float, float]:
    recent_weight, venue_mix, shrinkage = parameters
    if target == "corners":
        home_for = blended_profile(sample.home_history, sample.home_venue_history, "corners_for", recent_weight, venue_mix)
        home_against = blended_profile(sample.home_history, sample.home_venue_history, "corners_against", recent_weight, venue_mix)
        away_for = blended_profile(sample.away_history, sample.away_venue_history, "corners_for", recent_weight, venue_mix)
        away_against = blended_profile(sample.away_history, sample.away_venue_history, "corners_against", recent_weight, venue_mix)
        home_mean = geometric_mean(home_for, away_against)
        away_mean = geometric_mean(away_for, home_against)
        league_home = sample.league_home_corners
        league_away = sample.league_away_corners
    elif target == "cards":
        home_mean = blended_profile(sample.home_history, sample.home_venue_history, "yellow_cards", recent_weight, venue_mix)
        away_mean = blended_profile(sample.away_history, sample.away_venue_history, "yellow_cards", recent_weight, venue_mix)
        league_home = sample.league_home_yellow
        league_away = sample.league_away_yellow
    else:
        raise ValueError(target)

    home_mean = home_mean if home_mean is not None else league_home
    away_mean = away_mean if away_mean is not None else league_away
    if home_mean is None or away_mean is None:
        raise RuntimeError(f"No hay suficiente historial para {target}.")
    home_mean = (1.0 - shrinkage) * home_mean + shrinkage * float(league_home or home_mean)
    away_mean = (1.0 - shrinkage) * away_mean + shrinkage * float(league_away or away_mean)
    return clamp(home_mean, 0.01, 20.0), clamp(away_mean, 0.01, 20.0)


def observed_total(sample: TrainingSample, target: str) -> int | None:
    if target == "corners":
        if sample.home_corners is None or sample.away_corners is None:
            return None
        return sample.home_corners + sample.away_corners
    if target == "cards":
        if sample.home_yellow is None or sample.away_yellow is None:
            return None
        return sample.home_yellow + sample.away_yellow
    raise ValueError(target)


def filtered_samples(samples: list[TrainingSample], target: str) -> list[TrainingSample]:
    return [sample for sample in samples if observed_total(sample, target) is not None]


def poisson_count_objective(parameters: np.ndarray, samples: list[TrainingSample], target: str) -> float:
    losses: list[float] = []
    for sample in samples:
        actual = observed_total(sample, target)
        if actual is None:
            continue
        home_mean, away_mean = count_prediction(sample, parameters, target)
        losses.append(poisson_nll(actual, home_mean + away_mean))
    return float(np.mean(losses)) if losses else 1e6


def nb_count_objective(parameters_with_log_size: np.ndarray, samples: list[TrainingSample], target: str) -> float:
    parameters = parameters_with_log_size[:3]
    size = math.exp(float(parameters_with_log_size[3]))
    losses: list[float] = []
    for sample in samples:
        actual = observed_total(sample, target)
        if actual is None:
            continue
        home_mean, away_mean = count_prediction(sample, parameters, target)
        losses.append(nb_nll(actual, home_mean + away_mean, size))
    return float(np.mean(losses)) if losses else 1e6


def count_thresholds(target: str) -> tuple[int, ...]:
    if target == "corners":
        return tuple(range(6, 13))
    if target == "cards":
        return (1, 2, 3, 4)
    raise ValueError(target)


def evaluate_count_model(
    parameters: np.ndarray,
    samples: list[TrainingSample],
    target: str,
    family: str,
    size: float | None,
) -> dict[str, Any]:
    absolute_errors: list[float] = []
    squared_errors: list[float] = []
    log_losses: list[float] = []
    threshold_briers: list[float] = []
    for sample in samples:
        actual = observed_total(sample, target)
        if actual is None:
            continue
        home_mean, away_mean = count_prediction(sample, parameters, target)
        total_mean = home_mean + away_mean
        absolute_errors.append(abs(total_mean - actual))
        squared_errors.append((total_mean - actual) ** 2)
        if family == "poisson":
            exact_probability = float(poisson.pmf(actual, total_mean))
        else:
            if size is None:
                raise ValueError("Falta size para binomial negativa.")
            probability_parameter = size / (size + total_mean)
            exact_probability = float(nbinom.pmf(actual, size, probability_parameter))
        log_losses.append(-math.log(max(exact_probability, EPSILON)))
        for minimum in count_thresholds(target):
            observed = actual >= minimum
            if family == "poisson":
                probability = float(poisson.sf(minimum - 1, total_mean))
            else:
                assert size is not None
                probability_parameter = size / (size + total_mean)
                probability = float(nbinom.sf(minimum - 1, size, probability_parameter))
            threshold_briers.append(binary_brier(probability, observed))
    return {
        "samples": len(absolute_errors),
        "mae": round(float(np.mean(absolute_errors)), 8),
        "rmse": round(math.sqrt(float(np.mean(squared_errors))), 8),
        "exact_total_log_loss": round(float(np.mean(log_losses)), 8),
        "mean_threshold_brier": round(float(np.mean(threshold_briers)), 8),
    }


def optimize_with_starts(
    objective: Callable[[np.ndarray], float],
    starts: Iterable[np.ndarray],
    bounds: tuple[tuple[float, float], ...],
) -> tuple[np.ndarray, float, list[dict[str, Any]]]:
    best_parameters: np.ndarray | None = None
    best_value = math.inf
    attempts: list[dict[str, Any]] = []
    for start in starts:
        result = minimize(
            objective,
            x0=np.array(start, dtype=float),
            method="L-BFGS-B",
            bounds=bounds,
            options={"maxiter": 180, "ftol": 1e-9, "maxls": 30},
        )
        value = float(result.fun)
        attempts.append(
            {
                "success": bool(result.success),
                "objective": round(value, 10),
                "message": str(result.message),
                "iterations": int(result.nit),
            }
        )
        if math.isfinite(value) and value < best_value:
            best_value = value
            best_parameters = np.array(result.x, dtype=float)
    if best_parameters is None:
        raise RuntimeError("La optimización no produjo parámetros válidos.")
    return best_parameters, best_value, attempts


def _bounds_with_fixed_values(
    bounds: tuple[tuple[float, float], ...],
    names: tuple[str, ...],
    fixed_values: dict[str, float],
) -> tuple[tuple[float, float], ...]:
    return tuple(
        (float(fixed_values[name]), float(fixed_values[name]))
        if name in fixed_values
        else bound
        for name, bound in zip(names, bounds)
    )


def _starts_inside_bounds(
    starts: Iterable[np.ndarray],
    bounds: tuple[tuple[float, float], ...],
) -> tuple[np.ndarray, ...]:
    adjusted: list[np.ndarray] = []
    for start in starts:
        values = np.array(start, dtype=float)
        for index, (lower, upper) in enumerate(bounds):
            values[index] = min(max(values[index], lower), upper)
        adjusted.append(values)
    return tuple(adjusted)


def _bundesliga_goal_bounds() -> tuple[tuple[float, float], ...]:
    return _bounds_with_fixed_values(
        GOAL_BOUNDS,
        BUNDESLIGA_GOAL_PARAMETER_NAMES,
        {
            "venue_mix": 0.0,
            "league_shrinkage": 0.0,
        },
    )


def _bundesliga_count_bounds(
    target: str,
) -> tuple[tuple[float, float], ...]:
    return _bounds_with_fixed_values(
        COUNT_BOUNDS_BY_TARGET[target],
        BUNDESLIGA_COUNT_PARAMETER_NAMES,
        {"venue_mix": 0.0},
    )


def _bundesliga_goal_penalty(parameters: np.ndarray) -> float:
    home_advantage = float(parameters[4])
    rho = float(parameters[5])
    return (
        ((home_advantage - 1.0) / 0.30) ** 2
        + (rho / 0.20) ** 2
    )


def _bundesliga_count_penalty(parameters: np.ndarray) -> float:
    shrinkage = float(parameters[2])
    return (shrinkage / 0.70) ** 2


def _bundesliga_goal_objective(
    parameters: np.ndarray,
    samples: list[TrainingSample],
    regularization_strength: float,
) -> float:
    return (
        goals_objective(parameters, samples)
        + float(regularization_strength)
        * _bundesliga_goal_penalty(parameters)
    )


def _bundesliga_count_objective(
    parameters_with_log_size: np.ndarray,
    samples: list[TrainingSample],
    target: str,
    regularization_strength: float,
) -> float:
    return (
        nb_count_objective(parameters_with_log_size, samples, target)
        + float(regularization_strength)
        * _bundesliga_count_penalty(parameters_with_log_size[:3])
    )


def _bundesliga_internal_folds(
    train_samples: list[TrainingSample],
) -> list[tuple[list[TrainingSample], list[TrainingSample]]]:
    sample_count = len(train_samples)
    if sample_count < 100:
        raise RuntimeError(
            "Bundesliga V0002 requiere al menos 100 muestras TRAIN y "
            f"se recibieron {sample_count}."
        )

    # Los tamaños originales (80, 104, 131, 157 sobre 182) definen la
    # proporción temporal de los cuatro folds. Se escalan al historial
    # disponible para que el aprendizaje continuo no se rompa cuando entran
    # nuevos partidos. Cada frontera se mueve al kickoff group-safe más
    # cercano y se reserva un mínimo de diez muestras por bloque.
    desired_starts = tuple(
        int(round(sample_count * value / 182.0))
        for value in BUNDESLIGA_INTERNAL_FOLD_TRAIN_SIZES
    )
    safe_candidates = [
        index
        for index in range(40, sample_count)
        if _training_kickoff_timestamp(train_samples[index - 1].kickoff)
        < _training_kickoff_timestamp(train_samples[index].kickoff)
    ]
    starts_list: list[int] = []
    for position, desired in enumerate(desired_starts):
        remaining_boundaries = len(desired_starts) - position - 1
        lower = (starts_list[-1] + 10) if starts_list else 40
        upper = sample_count - 10 * (remaining_boundaries + 1)
        eligible = [
            index
            for index in safe_candidates
            if lower <= index <= upper
        ]
        if not eligible:
            raise RuntimeError(
                "No existen cuatro fronteras temporales group-safe para "
                f"{sample_count} muestras Bundesliga."
            )
        starts_list.append(
            min(eligible, key=lambda index: (abs(index - desired), index))
        )

    starts = tuple(starts_list)
    ends = starts[1:] + (sample_count,)
    folds: list[tuple[list[TrainingSample], list[TrainingSample]]] = []

    for start, end in zip(starts, ends):
        if not 0 < start < end <= len(train_samples):
            raise RuntimeError(
                f"Fold interno inválido: start={start}, end={end}."
            )
        left_kickoff = _training_kickoff_timestamp(
            train_samples[start - 1].kickoff
        )
        right_kickoff = _training_kickoff_timestamp(
            train_samples[start].kickoff
        )
        if left_kickoff >= right_kickoff:
            raise RuntimeError(
                "La frontera interna no es group-safe por kickoff: "
                f"index={start}."
            )
        folds.append((train_samples[:start], train_samples[start:end]))

    return folds


def _weighted_fold_metric(
    metrics: list[dict[str, Any]],
    key: str,
) -> float:
    total = sum(int(metric["samples"]) for metric in metrics)
    if total <= 0:
        raise RuntimeError("Los folds internos no contienen muestras evaluables.")
    return float(
        sum(
            float(metric[key]) * int(metric["samples"])
            for metric in metrics
        )
        / total
    )


def _fit_goals_for_bounds(
    samples: list[TrainingSample],
    bounds: tuple[tuple[float, float], ...],
    regularization_strength: float,
) -> np.ndarray:
    starts = _starts_inside_bounds(GOAL_STARTS, bounds)
    parameters, _, _ = optimize_with_starts(
        objective=lambda values: _bundesliga_goal_objective(
            values,
            samples,
            regularization_strength,
        ),
        starts=starts,
        bounds=bounds,
    )
    return parameters


def _fit_nb_count_for_bounds(
    target: str,
    samples: list[TrainingSample],
    bounds: tuple[tuple[float, float], ...],
    regularization_strength: float,
) -> tuple[np.ndarray, float]:
    available = filtered_samples(samples, target)
    count_starts = _starts_inside_bounds(
        COUNT_STARTS_BY_TARGET[target],
        bounds,
    )
    nb_starts = tuple(
        np.concatenate([start, np.array([math.log(size)])])
        for start in count_starts
        for size in NB_SIZE_STARTS
    )
    full_bounds = bounds + ((math.log(0.05), math.log(200.0)),)
    parameters, _, _ = optimize_with_starts(
        objective=lambda values: _bundesliga_count_objective(
            values,
            available,
            target,
            regularization_strength,
        ),
        starts=nb_starts,
        bounds=full_bounds,
    )
    return parameters[:3], math.exp(float(parameters[3]))


def _goal_cv_score(
    folds: list[tuple[list[TrainingSample], list[TrainingSample]]],
    bounds: tuple[tuple[float, float], ...],
    regularization_strength: float,
) -> dict[str, Any]:
    fold_metrics: list[dict[str, Any]] = []
    fold_parameters: list[dict[str, float]] = []
    for fold_train, fold_validation in folds:
        parameters = _fit_goals_for_bounds(
            fold_train,
            bounds,
            regularization_strength,
        )
        fold_metrics.append(evaluate_goals(parameters, fold_validation))
        fold_parameters.append(
            {
                name: round(float(value), 8)
                for name, value in zip(
                    BUNDESLIGA_GOAL_PARAMETER_NAMES,
                    parameters,
                )
            }
        )
    return {
        "log_loss": round(_weighted_fold_metric(fold_metrics, "log_loss"), 8),
        "brier_score": round(
            _weighted_fold_metric(fold_metrics, "brier_score"),
            8,
        ),
        "accuracy": round(_weighted_fold_metric(fold_metrics, "accuracy"), 8),
        "mean_goal_count_nll": round(
            _weighted_fold_metric(fold_metrics, "mean_goal_count_nll"),
            8,
        ),
        "fold_metrics": fold_metrics,
        "fold_parameters": fold_parameters,
    }


def _count_cv_score(
    target: str,
    folds: list[tuple[list[TrainingSample], list[TrainingSample]]],
    bounds: tuple[tuple[float, float], ...],
    regularization_strength: float,
) -> dict[str, Any]:
    fold_metrics: list[dict[str, Any]] = []
    fold_parameters: list[dict[str, Any]] = []
    for fold_train, fold_validation in folds:
        parameters, size = _fit_nb_count_for_bounds(
            target,
            fold_train,
            bounds,
            regularization_strength,
        )
        fold_metrics.append(
            evaluate_count_model(
                parameters,
                filtered_samples(fold_validation, target),
                target,
                family="negative_binomial",
                size=size,
            )
        )
        fold_parameters.append(
            {
                "parameters": {
                    name: round(float(value), 8)
                    for name, value in zip(
                        BUNDESLIGA_COUNT_PARAMETER_NAMES,
                        parameters,
                    )
                },
                "size": round(size, 8),
            }
        )
    return {
        "exact_total_log_loss": round(
            _weighted_fold_metric(fold_metrics, "exact_total_log_loss"),
            8,
        ),
        "mae": round(_weighted_fold_metric(fold_metrics, "mae"), 8),
        "rmse": round(_weighted_fold_metric(fold_metrics, "rmse"), 8),
        "fold_metrics": fold_metrics,
        "fold_parameters": fold_parameters,
    }


def select_bundesliga_regularization(
    train_samples: list[TrainingSample],
) -> dict[str, Any]:
    folds = _bundesliga_internal_folds(train_samples)
    fold_summary = [
        {
            "train_samples": len(fold_train),
            "validation_samples": len(fold_validation),
            "last_train_kickoff": fold_train[-1].kickoff,
            "first_validation_kickoff": fold_validation[0].kickoff,
            "last_validation_kickoff": fold_validation[-1].kickoff,
        }
        for fold_train, fold_validation in folds
    ]

    print("   CV interna: calculando referencia V0001 (goles)...", flush=True)
    v1_goals = _goal_cv_score(folds, GOAL_BOUNDS, 0.0)
    goal_scores: list[dict[str, Any]] = []
    goal_bounds = _bundesliga_goal_bounds()
    for strength in BUNDESLIGA_REGULARIZATION_GRID:
        print(
            f"   CV interna goles V0002: lambda={strength:g}",
            flush=True,
        )
        score = _goal_cv_score(folds, goal_bounds, strength)
        score["strength"] = strength
        goal_scores.append(score)
    selected_goal = min(
        goal_scores,
        key=lambda item: (
            float(item["log_loss"]),
            float(item["brier_score"]),
            float(item["strength"]),
        ),
    )

    count_results: dict[str, Any] = {}
    for target in ("corners", "cards"):
        print(
            f"   CV interna: calculando referencia V0001 ({target})...",
            flush=True,
        )
        try:
            v1_score = _count_cv_score(
                target,
                folds,
                COUNT_BOUNDS_BY_TARGET[target],
                0.0,
            )
            scores: list[dict[str, Any]] = []
            bounds = _bundesliga_count_bounds(target)
            for strength in BUNDESLIGA_REGULARIZATION_GRID:
                print(
                    f"   CV interna {target} V0002: lambda={strength:g}",
                    flush=True,
                )
                score = _count_cv_score(target, folds, bounds, strength)
                score["strength"] = strength
                scores.append(score)
            selected = min(
                scores,
                key=lambda item: (
                    float(item["exact_total_log_loss"]),
                    float(item["mae"]),
                    float(item["strength"]),
                ),
            )
            count_results[target] = {
                "v0001_reference": v1_score,
                "grid": scores,
                "selected_strength": float(selected["strength"]),
                "selected_score": selected,
                "selection_status": "completed",
            }
        except RuntimeError as exc:
            # Algunos históricos antiguos no publican córners o tarjetas en
            # todos los folds. La CV auxiliar no debe impedir entrenar goles
            # ni el mercado con cobertura completa. Lambda=0 conserva el
            # comportamiento sin regularización y la omisión queda auditada.
            count_results[target] = {
                "v0001_reference": None,
                "grid": [],
                "selected_strength": 0.0,
                "selected_score": None,
                "selection_status": "skipped_insufficient_fold_history",
                "reason": str(exc),
            }
            print(
                f"   [WARN] CV interna {target} omitida: {exc} "
                "Se usara lambda=0.",
                flush=True,
            )

    return {
        "method": "four_fold_expanding_group_safe_train_only",
        "selection_uses_external_validation": False,
        "regularization_grid": list(BUNDESLIGA_REGULARIZATION_GRID),
        "folds": fold_summary,
        "goals": {
            "v0001_reference": v1_goals,
            "grid": goal_scores,
            "selected_strength": float(selected_goal["strength"]),
            "selected_score": selected_goal,
        },
        **count_results,
    }


def train_goals(
    train_samples: list[TrainingSample],
    validation_samples: list[TrainingSample],
    bounds: tuple[tuple[float, float], ...] = GOAL_BOUNDS,
    regularization_strength: float = 0.0,
    regularization_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    starts = _starts_inside_bounds(GOAL_STARTS, bounds)
    parameters, objective_value, attempts = optimize_with_starts(
        objective=lambda params: _bundesliga_goal_objective(
            params,
            train_samples,
            regularization_strength,
        ),
        starts=starts,
        bounds=bounds,
    )
    names = BUNDESLIGA_GOAL_PARAMETER_NAMES
    return {
        "parameters": {name: round(float(value), 8) for name, value in zip(names, parameters)},
        "training_objective": round(
            goals_objective(parameters, train_samples),
            8,
        ),
        "regularized_training_objective": round(objective_value, 8),
        "training_metrics": evaluate_goals(parameters, train_samples),
        "validation_metrics": evaluate_goals(parameters, validation_samples),
        "optimizer_attempts": attempts,
        "bounds": {
            name: [float(lower), float(upper)]
            for name, (lower, upper) in zip(names, bounds)
        },
        "regularization": {
            "strength": float(regularization_strength),
            "penalty": "normalized_l2_home_advantage_to_1_and_rho_to_0",
            **(regularization_metadata or {}),
        },
    }


def train_count_target(
    target: str,
    train_samples: list[TrainingSample],
    validation_samples: list[TrainingSample],
    count_bounds_override: tuple[tuple[float, float], ...] | None = None,
    regularization_strength: float = 0.0,
    selected_family_override: str | None = None,
    regularization_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    train_available = filtered_samples(train_samples, target)
    validation_available = filtered_samples(validation_samples, target)
    if len(train_available) < 20 or len(validation_available) < 10:
        raise RuntimeError(
            f"Muestra insuficiente para entrenar {target}: "
            f"train={len(train_available)}, validation={len(validation_available)}."
        )

    if target not in COUNT_STARTS_BY_TARGET or target not in COUNT_BOUNDS_BY_TARGET:
        raise ValueError(f"Target de conteo no soportado: {target}")

    count_bounds = (
        count_bounds_override
        if count_bounds_override is not None
        else COUNT_BOUNDS_BY_TARGET[target]
    )
    count_starts = _starts_inside_bounds(
        COUNT_STARTS_BY_TARGET[target],
        count_bounds,
    )

    poisson_parameters, poisson_objective, poisson_attempts = optimize_with_starts(
        objective=lambda params: (
            poisson_count_objective(params, train_available, target)
            + float(regularization_strength)
            * _bundesliga_count_penalty(params)
        ),
        starts=count_starts,
        bounds=count_bounds,
    )
    nb_starts = tuple(
        np.concatenate([start, np.array([math.log(size)])])
        for start in count_starts
        for size in NB_SIZE_STARTS
    )
    nb_parameters_full, nb_objective, nb_attempts = optimize_with_starts(
        objective=lambda params: _bundesliga_count_objective(
            params,
            train_available,
            target,
            regularization_strength,
        ),
        starts=nb_starts,
        bounds=count_bounds + ((math.log(0.05), math.log(200.0)),),
    )
    nb_parameters = nb_parameters_full[:3]
    nb_size = math.exp(float(nb_parameters_full[3]))
    poisson_validation = evaluate_count_model(
        poisson_parameters,
        validation_available,
        target,
        family="poisson",
        size=None,
    )
    nb_validation = evaluate_count_model(
        nb_parameters,
        validation_available,
        target,
        family="negative_binomial",
        size=nb_size,
    )
    if selected_family_override is not None:
        if selected_family_override not in {"poisson", "negative_binomial"}:
            raise ValueError(
                f"Familia forzada no soportada: {selected_family_override}"
            )
        selected_family = selected_family_override
    else:
        selected_family = (
            "negative_binomial"
            if nb_validation["exact_total_log_loss"] < poisson_validation["exact_total_log_loss"]
            else "poisson"
        )
    parameter_names = BUNDESLIGA_COUNT_PARAMETER_NAMES
    regularization = {
        "strength": float(regularization_strength),
        "penalty": "normalized_l2_league_shrinkage_to_0",
        **(regularization_metadata or {}),
    }
    serialized_bounds = {
        name: [float(lower), float(upper)]
        for name, (lower, upper) in zip(parameter_names, count_bounds)
    }
    return {
        "selected_family": selected_family,
        "poisson": {
            "parameters": {
                name: round(float(value), 8)
                for name, value in zip(parameter_names, poisson_parameters)
            },
            "training_objective": round(
                poisson_count_objective(
                    poisson_parameters,
                    train_available,
                    target,
                ),
                8,
            ),
            "regularized_training_objective": round(poisson_objective, 8),
            "training_metrics": evaluate_count_model(
                poisson_parameters,
                train_available,
                target,
                family="poisson",
                size=None,
            ),
            "validation_metrics": poisson_validation,
            "optimizer_attempts": poisson_attempts,
            "bounds": serialized_bounds,
            "regularization": regularization,
        },
        "negative_binomial": {
            "parameters": {
                name: round(float(value), 8)
                for name, value in zip(parameter_names, nb_parameters)
            },
            "size": round(nb_size, 8),
            "training_objective": round(
                nb_count_objective(
                    np.concatenate(
                        [
                            nb_parameters,
                            np.array([math.log(nb_size)]),
                        ]
                    ),
                    train_available,
                    target,
                ),
                8,
            ),
            "regularized_training_objective": round(nb_objective, 8),
            "training_metrics": evaluate_count_model(
                nb_parameters,
                train_available,
                target,
                family="negative_binomial",
                size=nb_size,
            ),
            "validation_metrics": nb_validation,
            "optimizer_attempts": nb_attempts,
            "bounds": {
                **serialized_bounds,
                "size": [0.05, 200.0],
            },
            "regularization": regularization,
        },
        "available_samples": {
            "train": len(train_available),
            "validation": len(validation_available),
        },
    }


def count_target_training_ready(
    target: str,
    train_samples: list[TrainingSample],
    validation_samples: list[TrainingSample],
) -> bool:
    """Comprueba cobertura real antes de iniciar una optimización de conteo."""

    train_available = filtered_samples(train_samples, target)
    validation_available = filtered_samples(validation_samples, target)
    if len(train_available) < 20 or len(validation_available) < 10:
        return False
    probe = np.array(COUNT_STARTS_BY_TARGET[target][0], dtype=float)
    try:
        for sample in (*train_available, *validation_available):
            count_prediction(sample, probe, target)
    except (RuntimeError, TypeError, ValueError):
        return False
    return True


def promotion_score(
    model: dict[str, Any],
    components: Iterable[str] | None = None,
) -> float:
    selected = set(
        components
        if components is not None
        else (
            name
            for name in ("goals", "corners", "cards")
            if name in model
        )
    )
    goals_log_loss = float(model["goals"]["validation_metrics"]["log_loss"])
    score = goals_log_loss
    for target in ("corners", "cards"):
        if target not in selected:
            continue
        family = model[target]["selected_family"]
        score += float(
            model[target][family]["validation_metrics"]["exact_total_log_loss"]
        )
    return score


def next_version(output_dir: Path) -> int:
    versions: list[int] = []
    for path in output_dir.glob("model_v*.json"):
        match = re.fullmatch(r"model_v(\d+)\.json", path.name)
        if match:
            versions.append(int(match.group(1)))
    return max(versions, default=0) + 1


def promote_candidate(
    output_dir: Path,
    candidate: dict[str, Any],
    force_promote: bool,
    no_promote: bool = False,
) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    latest_path = output_dir / "latest_model.json"
    previous = read_json_optional(latest_path)
    candidate_components = tuple(
        name
        for name in ("goals", "corners", "cards")
        if name in candidate
    )
    candidate_score = promotion_score(candidate, candidate_components)
    previous_score = (
        promotion_score(previous, candidate_components)
        if isinstance(previous, dict)
        and all(key in previous for key in candidate_components)
        else None
    )
    improved = previous_score is None or candidate_score < previous_score - 0.001
    promoted = False if no_promote else (force_promote or improved)
    version = next_version(output_dir)
    version_path = output_dir / f"model_v{version:04d}.json"
    candidate["version"] = version
    candidate["promotion"] = {
        "candidate_score": round(candidate_score, 8),
        "previous_score": round(previous_score, 8) if previous_score is not None else None,
        "improved": improved,
        "force_promote": force_promote,
        "no_promote": no_promote,
        "promoted": promoted,
    }
    write_json(version_path, candidate)
    write_json(output_dir / "last_candidate.json", candidate)
    if promoted:
        shutil.copy2(version_path, latest_path)
    return {
        "version": version,
        "version_path": str(version_path),
        "latest_path": str(latest_path),
        "candidate_score": round(candidate_score, 8),
        "previous_score": round(previous_score, 8) if previous_score is not None else None,
        "promoted": promoted,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Entrena parámetros por liga con separación temporal, "
            "validación y control de versiones."
        )
    )
    parser.add_argument("--key", required=True, help="Clave de competición, por ejemplo: mls")
    parser.add_argument(
        "--holdout",
        type=float,
        default=DEFAULT_HOLDOUT,
        help="Proporción cronológica reservada para validación.",
    )
    parser.add_argument(
        "--force-promote",
        action="store_true",
        help="Promueve el candidato aunque no mejore al modelo actual.",
    )
    parser.add_argument(
        "--no-promote",
        action="store_true",
        help="Genera y valida el candidato sin reemplazar latest_model.json.",
    )
    parser.add_argument(
        "--goals-only",
        action="store_true",
        help=(
            "Entrena y promueve únicamente goles cuando la liga no tiene "
            "cobertura histórica suficiente para otros mercados."
        ),
    )
    return parser



def _group_safe_split_index(
    samples: list[TrainingSample],
    holdout: float,
) -> int:
    desired = int(
        round(
            len(samples)
            * (1.0 - holdout)
        )
    )

    lower = 40
    upper = (
        len(samples)
        - 25
    )

    if upper < lower:
        raise RuntimeError(
            "Muestras insuficientes para split."
        )

    candidates = []

    for index in range(
        lower,
        upper + 1,
    ):

        left = (
            _training_kickoff_timestamp(
                samples[
                    index - 1
                ].kickoff
            )
        )

        right = (
            _training_kickoff_timestamp(
                samples[
                    index
                ].kickoff
            )
        )

        if left < right:
            candidates.append(
                index
            )

    if not candidates:
        raise RuntimeError(
            "No existe frontera temporal group-safe."
        )

    return min(
        candidates,
        key=lambda value: (
            abs(
                value
                -
                desired
            ),
            value,
        ),
    )


def main() -> None:
    args = build_parser().parse_args()
    try:
        holdout = float(args.holdout)
        if not 0.15 <= holdout <= 0.40:
            raise ValueError("--holdout debe estar entre 0.15 y 0.40.")

        registry = load_registry()
        competition = find_competition(registry, args.key)
        connection = get_connection()
        try:
            league = resolve_league(connection, competition)
            rows, context_rows = load_training_rows(
                connection=connection,
                registry=registry,
                competition=competition,
                league=league,
            )
        finally:
            connection.close()

        samples = build_training_samples(
            target_rows=rows,
            context_rows=context_rows,
            competition=competition,
        )
        if len(samples) < 80:
            raise RuntimeError(
                "Se requieren al menos 80 muestras walk-forward "
                f"y solo se obtuvieron {len(samples)}."
            )

        split_index = _group_safe_split_index(
            samples,
            holdout,
        )

        train_samples = samples[:split_index]
        validation_samples = samples[split_index:]
        missing_count_targets = [
            target
            for target in ("corners", "cards")
            if not count_target_training_ready(
                target,
                train_samples,
                validation_samples,
            )
        ]
        goals_only_training = bool(
            args.goals_only or missing_count_targets
        )

        print("=" * 86)
        print("ODDSHUNTER — ENTRENAMIENTO CONTINUO POR LIGA")
        print("=" * 86)
        print(f"Competición: {league['name']} {league['season']}")
        print(f"Partidos TARGET finalizados cargados: {len(rows)}")
        print(f"Partidos de contexto dom?stico: {len(context_rows)}")
        print(f"Muestras walk-forward: {len(samples)}")
        print(f"Entrenamiento: {len(train_samples)}")
        print(f"Validación temporal: {len(validation_samples)}")
        print(
            "La validación contiene únicamente los partidos más recientes "
            "y no participa en el ajuste."
        )
        if missing_count_targets and not args.goals_only:
            print(
                "Cobertura insuficiente para "
                + ", ".join(missing_count_targets)
                + "; se promoverá el modelo aprendido de goles y los "
                "otros mercados conservarán sus fallbacks independientes."
            )

        bundesliga_v0002 = league["key"] == "bundesliga"
        regularization_cv: dict[str, Any] | None = None
        if bundesliga_v0002:
            print(
                "\n[0/3] Seleccionando regularización con cuatro folds "
                "temporales internos del TRAIN...",
                flush=True,
            )
            regularization_cv = select_bundesliga_regularization(
                train_samples
            )
            print(
                "   Lambda goles: "
                f"{regularization_cv['goals']['selected_strength']:g}"
            )
            print(
                "   Lambda córners: "
                f"{regularization_cv['corners']['selected_strength']:g}"
            )
            print(
                "   Lambda tarjetas: "
                f"{regularization_cv['cards']['selected_strength']:g}"
            )

        print("\n[1/3] Entrenando modelo de goles...")
        goals = train_goals(
            train_samples,
            validation_samples,
            bounds=(
                _bundesliga_goal_bounds()
                if bundesliga_v0002
                else GOAL_BOUNDS
            ),
            regularization_strength=(
                float(regularization_cv["goals"]["selected_strength"])
                if regularization_cv is not None
                else 0.0
            ),
            regularization_metadata=(
                {
                    "selected_by": regularization_cv["method"],
                    "selection_uses_external_validation": False,
                }
                if regularization_cv is not None
                else None
            ),
        )
        print(f"   ✅ Log-Loss validación: {goals['validation_metrics']['log_loss']:.4f}")
        print(f"   ✅ Brier validación: {goals['validation_metrics']['brier_score']:.4f}")

        if goals_only_training:
            candidate = {
                "generated_at": utc_now(),
                "model_type": "continuous_learning_parameters",
                "competition": league,
                "data": {
                    "database": str(DB_PATH),
                    "finished_matches": len(rows),
                    "context_matches": len(context_rows),
                    "walk_forward_samples": len(samples),
                    "train_samples": len(train_samples),
                    "validation_samples": len(validation_samples),
                    "holdout_ratio": holdout,
                    "first_train_kickoff": train_samples[0].kickoff,
                    "last_train_kickoff": train_samples[-1].kickoff,
                    "first_validation_kickoff": validation_samples[0].kickoff,
                    "last_validation_kickoff": validation_samples[-1].kickoff,
                },
                "goals": goals,
                "internal_cross_validation": regularization_cv,
                "notes": [
                    "Todos los perfiles usan únicamente partidos anteriores.",
                    "El componente de goles se validó en el bloque temporal más reciente.",
                    "Paquete parcial intencional: otros mercados conservan sus fallbacks independientes.",
                    (
                        "Fallback automático por cobertura insuficiente: "
                        + ", ".join(missing_count_targets)
                        if missing_count_targets
                        else "Entrenamiento parcial solicitado por --goals-only."
                    ),
                    "La base SQLite no se modifica.",
                ],
            }
            output_dir = OUTPUT_ROOT / league["key"]
            promotion = promote_candidate(
                output_dir=output_dir,
                candidate=candidate,
                force_promote=bool(args.force_promote),
                no_promote=bool(args.no_promote),
            )
            print("\n" + "=" * 86)
            print("RESULTADO DEL ENTRENAMIENTO DE GOLES")
            print("=" * 86)
            print(f"Versión creada: v{promotion['version']:04d}")
            print(f"Puntuación candidata: {promotion['candidate_score']:.4f}")
            print(f"Promovido como modelo vigente: {'SÍ' if promotion['promoted'] else 'NO'}")
            print(f"\nModelo vigente:\n{promotion['latest_path']}")
            print("=" * 86)
            print("✅ ENTRENAMIENTO DE GOLES TERMINADO")
            return

        print("\n[2/3] Entrenando modelo de córners...")
        corners = train_count_target(
            "corners",
            train_samples,
            validation_samples,
            count_bounds_override=(
                _bundesliga_count_bounds("corners")
                if bundesliga_v0002
                else None
            ),
            regularization_strength=(
                float(regularization_cv["corners"]["selected_strength"])
                if regularization_cv is not None
                else 0.0
            ),
            selected_family_override=(
                "negative_binomial"
                if bundesliga_v0002
                else None
            ),
            regularization_metadata=(
                {
                    "selected_by": regularization_cv["method"],
                    "selection_uses_external_validation": False,
                }
                if regularization_cv is not None
                else None
            ),
        )
        print(f"   ✅ Familia seleccionada: {corners['selected_family']}")

        print("\n[3/3] Entrenando modelo de tarjetas...")
        cards = train_count_target(
            "cards",
            train_samples,
            validation_samples,
            count_bounds_override=(
                _bundesliga_count_bounds("cards")
                if bundesliga_v0002
                else None
            ),
            regularization_strength=(
                float(regularization_cv["cards"]["selected_strength"])
                if regularization_cv is not None
                else 0.0
            ),
            selected_family_override=(
                "negative_binomial"
                if bundesliga_v0002
                else None
            ),
            regularization_metadata=(
                {
                    "selected_by": regularization_cv["method"],
                    "selection_uses_external_validation": False,
                }
                if regularization_cv is not None
                else None
            ),
        )
        print(f"   ✅ Familia seleccionada: {cards['selected_family']}")

        candidate = {
            "generated_at": utc_now(),
            "model_type": "continuous_learning_parameters",
            "competition": league,
            "data": {
                "database": str(DB_PATH),
                "finished_matches": len(rows),
                "context_matches": len(context_rows),
                "walk_forward_samples": len(samples),
                "train_samples": len(train_samples),
                "validation_samples": len(validation_samples),
                "holdout_ratio": holdout,
                "first_train_kickoff": train_samples[0].kickoff,
                "last_train_kickoff": train_samples[-1].kickoff,
                "first_validation_kickoff": validation_samples[0].kickoff,
                "last_validation_kickoff": validation_samples[-1].kickoff,
            },
            "goals": goals,
            "corners": corners,
            "cards": cards,
            "internal_cross_validation": regularization_cv,
            "notes": [
                "Todos los perfiles usan únicamente partidos anteriores.",
                "Los parámetros se ajustan en entrenamiento y se evalúan en el bloque temporal más reciente.",
                "La base SQLite no se modifica.",
                "Un candidato solo reemplaza al modelo vigente cuando mejora la validación, salvo --force-promote.",
                "Bundesliga V0002 selecciona la regularización exclusivamente dentro de TRAIN mediante cuatro folds temporales group-safe.",
            ],
        }

        output_dir = OUTPUT_ROOT / league["key"]
        promotion = promote_candidate(
            output_dir=output_dir,
            candidate=candidate,
            force_promote=bool(args.force_promote),
            no_promote=bool(args.no_promote),
        )

        print("\n" + "=" * 86)
        print("RESULTADO DEL ENTRENAMIENTO")
        print("=" * 86)
        print(f"Versión creada: v{promotion['version']:04d}")
        print(f"Puntuación candidata: {promotion['candidate_score']:.4f}")
        print(
            "Puntuación anterior: "
            + (
                f"{promotion['previous_score']:.4f}"
                if promotion["previous_score"] is not None
                else "N/D"
            )
        )
        print(f"Promovido como modelo vigente: {'SÍ' if promotion['promoted'] else 'NO'}")
        print(f"\nVersión:\n{promotion['version_path']}")
        print(f"\nModelo vigente:\n{promotion['latest_path']}")
        print("=" * 86)
        print("✅ ENTRENAMIENTO TERMINADO")

    except KeyboardInterrupt:
        print("\n⚠️ Entrenamiento interrumpido.")
        raise SystemExit(130)
    except Exception as exc:
        print(f"\n❌ Error: {type(exc).__name__}: {exc}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
