from __future__ import annotations

import os
from typing import Any, Callable

ErrorCallback = Callable[[str, BaseException], None]


def _notify(
    callback: ErrorCallback | None,
    operation: str,
    exc: BaseException,
) -> None:
    if callback is None:
        return
    try:
        callback(operation, exc)
    except Exception:
        # El callback de registro nunca debe propagar un segundo fallo.
        return


def is_qobject_valid(obj: Any) -> bool:
    if obj is None:
        return False
    try:
        import shiboken6

        return bool(shiboken6.isValid(obj))
    except Exception:
        try:
            obj.objectName()
            return True
        except RuntimeError:
            return False
        except Exception:
            return False


def safe_process_state(
    process: Any,
    on_error: ErrorCallback | None = None,
) -> Any:
    if not is_qobject_valid(process):
        return None
    try:
        return process.state()
    except RuntimeError as exc:
        _notify(on_error, "state", exc)
        return None
    except Exception as exc:
        _notify(on_error, "state", exc)
        return None


def safe_process_state_name(
    process: Any,
    on_error: ErrorCallback | None = None,
) -> str:
    state = safe_process_state(process, on_error)
    if state is None:
        return "INVALID"
    try:
        return str(getattr(state, "name", state))
    except Exception:
        return "UNKNOWN"


def safe_read_process_output(
    process: Any,
    on_error: ErrorCallback | None = None,
) -> bytes:
    if not is_qobject_valid(process):
        return b""
    try:
        return bytes(process.readAllStandardOutput())
    except RuntimeError as exc:
        _notify(on_error, "read_stdout", exc)
        return b""
    except Exception as exc:
        _notify(on_error, "read_stdout", exc)
        return b""


def safe_read_process_error(
    process: Any,
    on_error: ErrorCallback | None = None,
) -> bytes:
    if not is_qobject_valid(process):
        return b""
    try:
        return bytes(process.readAllStandardError())
    except RuntimeError as exc:
        _notify(on_error, "read_stderr", exc)
        return b""
    except Exception as exc:
        _notify(on_error, "read_stderr", exc)
        return b""


def safe_process_exit_code(
    process: Any,
    default: int | None = -1,
    on_error: ErrorCallback | None = None,
) -> int | None:
    if not is_qobject_valid(process):
        return default
    try:
        return int(process.exitCode())
    except RuntimeError as exc:
        _notify(on_error, "exit_code", exc)
        return default
    except Exception as exc:
        _notify(on_error, "exit_code", exc)
        return default


def safe_disconnect_process_signals(
    process: Any,
    on_error: ErrorCallback | None = None,
) -> bool:
    if not is_qobject_valid(process):
        return False
    disconnected = False
    for signal_name in (
        "readyReadStandardOutput",
        "readyReadStandardError",
        "started",
        "finished",
        "errorOccurred",
        "destroyed",
    ):
        try:
            signal = getattr(process, signal_name, None)
            if signal is None:
                continue
            signal.disconnect()
            disconnected = True
        except (RuntimeError, TypeError):
            # TypeError significa normalmente que no había conexión.
            continue
        except Exception as exc:
            _notify(
                on_error,
                f"disconnect:{signal_name}",
                exc,
            )
    return disconnected


def safe_delete_later(
    process: Any,
    on_error: ErrorCallback | None = None,
) -> bool:
    if not is_qobject_valid(process):
        return False
    try:
        if bool(
            process.property(
                "oddshunter_delete_later_scheduled"
            )
        ):
            return False
        process.setProperty(
            "oddshunter_delete_later_scheduled",
            True,
        )
        process.deleteLater()
        return True
    except RuntimeError as exc:
        _notify(on_error, "deleteLater", exc)
        return False
    except Exception as exc:
        _notify(on_error, "deleteLater", exc)
        return False


def safe_terminate_process(
    process: Any,
    timeout_ms: int = 1500,
    on_error: ErrorCallback | None = None,
) -> bool:
    if not is_qobject_valid(process):
        return False
    try:
        process.terminate()
        if not process.waitForFinished(int(timeout_ms)):
            process.kill()
            process.waitForFinished(1000)
        return True
    except RuntimeError as exc:
        _notify(on_error, "terminate", exc)
        return False
    except Exception as exc:
        _notify(on_error, "terminate", exc)
        return False

# ODDSHUNTER_PERFORMANCE_V4_4_1
_WINDOWS_CREATE_NO_WINDOW = 0x08000000


def configure_hidden_windows_process(
    process: Any,
    on_error: ErrorCallback | None = None,
) -> bool:
    """Oculta la consola del proceso hijo sin cambiar stdout/stderr ni argumentos."""
    if os.name != "nt" or not is_qobject_valid(process):
        return False

    setter = getattr(process, "setCreateProcessArgumentsModifier", None)
    if not callable(setter):
        return False

    def modifier(arguments: Any) -> None:
        try:
            arguments.flags = int(arguments.flags) | _WINDOWS_CREATE_NO_WINDOW
        except Exception:
            try:
                arguments.flags |= _WINDOWS_CREATE_NO_WINDOW
            except Exception:
                return

    try:
        setter(modifier)
        try:
            setattr(process, "_oddshunter_create_process_modifier", modifier)
        except Exception:
            pass
        return True
    except Exception as exc:
        _notify(on_error, "create_process_modifier", exc)
        return False

