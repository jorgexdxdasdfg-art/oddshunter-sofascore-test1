from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from bot10_context_model import build_component_document


def configure_console_encoding() -> None:
    """Evita que símbolos informativos detengan el proceso en Windows."""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except (OSError, ValueError):
                pass


configure_console_encoding()


# ==============================================================================
# 1. RUTAS
# ==============================================================================

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
REGISTRY_PATH = DATA_DIR / "competitions.json"
COMPETITIONS_DIR = DATA_DIR / "competitions"
ANALYSIS_ROOT_DIR = DATA_DIR / "analisis"
DB_PATH = DATA_DIR / "oddshunter.db"
TRAINED_MODELS_DIR = DATA_DIR / "trained_models"

RATINGS_SCRIPT = BASE_DIR / "ratings.py"
GOALS_SCRIPT = BASE_DIR / "poisson_dixon_coles.py"
CORNERS_SCRIPT = BASE_DIR / "corners_model.py"
CARDS_SCRIPT = BASE_DIR / "cards_model.py"
SHOTS_SCRIPT = BASE_DIR / "shots_model.py"

RATINGS_DIR = DATA_DIR / "ratings"
GOALS_DIR = DATA_DIR / "modelos"
CORNERS_ROOT_DIR = DATA_DIR / "modelos" / "corners"
CARDS_ROOT_DIR = DATA_DIR / "modelos" / "cards"
SHOTS_ROOT_DIR = DATA_DIR / "modelos" / "shots"

REQUIRED_SCRIPTS = (
    RATINGS_SCRIPT,
    GOALS_SCRIPT,
    CORNERS_SCRIPT,
    CARDS_SCRIPT,
    SHOTS_SCRIPT,
)

ANALYSIS_ROOT_DIR.mkdir(parents=True, exist_ok=True)


# ==============================================================================
# 2. UTILIDADES
# ==============================================================================

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def now_timestamp() -> int:
    return int(datetime.now(timezone.utc).timestamp())


def match_start_timestamp(match: dict[str, Any]) -> int | None:
    value = match.get("start_timestamp")
    try:
        return int(value)
    except (TypeError, ValueError):
        pass

    kickoff = str(match.get("kickoff") or "").strip()
    if not kickoff:
        return None

    try:
        parsed = datetime.fromisoformat(kickoff.replace("Z", "+00:00"))
    except ValueError:
        return None

    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)

    return int(parsed.astimezone(timezone.utc).timestamp())


def match_has_started(match: dict[str, Any]) -> bool:
    timestamp = match_start_timestamp(match)
    return timestamp is not None and timestamp <= now_timestamp()


def slugify(text: str) -> str:
    import re

    value = text.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-")


def read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"No existe:\n{path}")

    data = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(data, dict):
        raise ValueError(f"{path.name} no contiene un objeto JSON válido.")

    return data


def read_json_optional(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None

    return data if isinstance(data, dict) else None


def write_json(path: Path, data: Any) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def copy_json(source: Path, destination: Path) -> dict[str, Any]:
    data = read_json(source)
    write_json(destination, data)
    return data


def event_id_from_document(document: dict[str, Any]) -> int | None:
    for key in ("upcoming_match", "evento"):
        event = document.get(key)

        if not isinstance(event, dict):
            continue

        value = event.get("event_id")

        try:
            return int(value)
        except (TypeError, ValueError):
            continue

    return None


def validate_event_document(
    path: Path,
    expected_event_id: int,
) -> dict[str, Any]:
    document = read_json(path)
    actual_event_id = event_id_from_document(document)

    if actual_event_id != expected_event_id:
        raise RuntimeError(
            f"{path.name} pertenece al evento {actual_event_id}, "
            f"pero se esperaba {expected_event_id}."
        )

    return document


def file_signature(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {
            "exists": False,
            "size": None,
            "mtime_ns": None,
        }

    stat = path.stat()

    return {
        "exists": True,
        "size": stat.st_size,
        "mtime_ns": stat.st_mtime_ns,
    }



def _hash_payload(payload: Any) -> str:
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        default=str,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _table_exists(
    connection: sqlite3.Connection,
    table_name: str,
) -> bool:
    row = connection.execute(
        """
        SELECT 1
        FROM sqlite_master
        WHERE type = 'table' AND name = ?
        LIMIT 1
        """,
        (table_name,),
    ).fetchone()
    return row is not None


def team_data_signature(
    sofascore_team_id: Any,
) -> dict[str, Any]:
    try:
        source_team_id = int(sofascore_team_id)
    except (TypeError, ValueError):
        return {
            "team_id": sofascore_team_id,
            "exists": False,
            "signature": "invalid-team-id",
        }

    if not DB_PATH.exists():
        return {
            "team_id": source_team_id,
            "exists": False,
            "signature": "database-missing",
        }

    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row

    try:
        team_rows = connection.execute(
            """
            SELECT team_id, sofascore_id, name, league_id
            FROM teams
            WHERE sofascore_id = ?
            ORDER BY team_id
            """,
            (source_team_id,),
        ).fetchall()

        internal_ids = [
            int(row["team_id"])
            for row in team_rows
        ]

        if not internal_ids:
            return {
                "team_id": source_team_id,
                "exists": False,
                "signature": "team-not-imported",
            }

        placeholders = ",".join("?" for _ in internal_ids)

        history_rows = connection.execute(
            f"""
            SELECT
                s.stat_id,
                s.match_id,
                s.team_id,
                s.venue,
                s.goals_for,
                s.goals_against,
                s.xg_for,
                s.xg_against,
                s.shots,
                s.shots_on_target,
                s.corners_for,
                s.corners_against,
                s.yellow_cards,
                s.red_cards,
                s.possession,
                s.fouls,
                s.offsides,
                s.big_chances,
                s.data_quality,
                m.sofascore_id AS event_id,
                m.kickoff,
                m.status,
                m.home_team_id,
                m.away_team_id
            FROM team_match_stats AS s
            INNER JOIN matches AS m
              ON m.match_id = s.match_id
            WHERE s.team_id IN ({placeholders})
              AND m.status = 'FT'
            ORDER BY m.kickoff DESC, m.match_id DESC
            LIMIT 30
            """,
            tuple(internal_ids),
        ).fetchall()

        elo_rows: list[dict[str, Any]] = []

        if _table_exists(connection, "elo_ratings"):
            elo_rows = [
                dict(row)
                for row in connection.execute(
                    f"""
                    SELECT
                        league_id,
                        season_id,
                        team_id,
                        elo_inicial,
                        elo_actual,
                        partidos_jugados,
                        ultimo_partido_id,
                        ultimo_partido_timestamp,
                        updated_at
                    FROM elo_ratings
                    WHERE team_id IN ({placeholders})
                    ORDER BY updated_at DESC, season_id DESC
                    """,
                    tuple(internal_ids),
                ).fetchall()
            ]

        payload = {
            "source_team_id": source_team_id,
            "teams": [dict(row) for row in team_rows],
            "history": [dict(row) for row in history_rows],
            "elo": elo_rows,
        }

        return {
            "team_id": source_team_id,
            "exists": True,
            "history_rows": len(history_rows),
            "signature": _hash_payload(payload),
        }

    finally:
        connection.close()


def active_model_signature(
    competition_key: str,
) -> dict[str, Any]:
    latest_path = (
        TRAINED_MODELS_DIR
        / competition_key
        / "latest_model.json"
    )
    document = read_json_optional(latest_path) or {}

    return {
        "file": file_signature(latest_path),
        "version": document.get("version"),
        "generated_at": document.get("generated_at"),
        "promotion": document.get("promotion"),
    }




def build_fingerprint(
    competition_key: str,
    schedule_generated_at: str | None,
    match: dict[str, Any],
) -> str:
    del schedule_generated_at

    payload = {
        "fingerprint_version": 3,
        "competition_key": competition_key,
        "match": {
            "event_id": match.get("event_id"),
            "start_timestamp": match.get("start_timestamp"),
            "kickoff": match.get("kickoff"),
            "home_team_id": match.get("home_team_id"),
            "away_team_id": match.get("away_team_id"),
            "round": match.get("round"),
            "venue": match.get("venue"),
        },
        # Ya no se usa la fecha general de modificación de SQLite.
        # Cada análisis depende únicamente de los dos equipos involucrados.
        "team_states": {
            "home": team_data_signature(
                match.get("home_team_id")
            ),
            "away": team_data_signature(
                match.get("away_team_id")
            ),
        },
        "active_model": active_model_signature(
            competition_key
        ),
        "modules": {
            script.name: file_signature(script)
            for script in REQUIRED_SCRIPTS
        },
    }

    return _hash_payload(payload)



# ==============================================================================
# 3. REGISTRO Y CALENDARIO
# ==============================================================================

def load_registry() -> dict[str, Any]:
    registry = read_json(REGISTRY_PATH)

    if not isinstance(registry.get("competitions"), list):
        raise ValueError(
            "competitions.json no contiene una lista 'competitions'."
        )

    return registry


def find_competition(
    registry: dict[str, Any],
    key: str,
) -> dict[str, Any]:
    normalized = slugify(key)

    for competition in registry["competitions"]:
        current = slugify(str(competition.get("key", "")))

        if current == normalized:
            return competition

    raise ValueError(f"No existe la competición '{key}'.")


def load_upcoming_schedule(
    competition_key: str,
) -> tuple[dict[str, Any], Path]:
    path = (
        COMPETITIONS_DIR
        / competition_key
        / "matches_upcoming.json"
    )

    schedule = read_json(path)
    matches = schedule.get("matches")

    if not isinstance(matches, list):
        raise ValueError(
            f"{path.name} no contiene una lista 'matches'."
        )

    unique: dict[int, dict[str, Any]] = {}

    for match in matches:
        if not isinstance(match, dict):
            continue

        try:
            event_id = int(match["event_id"])
        except (KeyError, TypeError, ValueError):
            continue

        normalized = dict(match)
        normalized["event_id"] = event_id
        unique[event_id] = normalized

    schedule["matches"] = sorted(
        unique.values(),
        key=lambda item: (
            int(item.get("start_timestamp") or 0),
            int(item["event_id"]),
        ),
    )

    return schedule, path


# ==============================================================================
# 4. EJECUCIÓN DE MÓDULOS
# ==============================================================================

class ModuleExecutionError(RuntimeError):
    def __init__(self, message: str, return_code: int) -> None:
        super().__init__(message)
        self.return_code = int(return_code)


def run_module(
    title: str,
    command: list[str],
    log_path: Path,
) -> int:
    environment = os.environ.copy()
    environment["PYTHONUTF8"] = "1"
    environment["PYTHONIOENCODING"] = "utf-8"

    print(f"   ▶ {title}")
    print("     $ " + " ".join(command))

    log_path.parent.mkdir(parents=True, exist_ok=True)

    with log_path.open(
        "w",
        encoding="utf-8",
        errors="replace",
    ) as log_file:
        process = subprocess.Popen(
            command,
            cwd=BASE_DIR,
            env=environment,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
        )

        assert process.stdout is not None

        for line in process.stdout:
            log_file.write(line)
            log_file.flush()

            visible = line.rstrip()

            if visible:
                print(f"     {visible}")

        return_code = process.wait()

    if return_code != 0:
        raise ModuleExecutionError(
            f"{title} terminó con código {return_code}. "
            f"Revisa {log_path}",
            return_code,
        )
    return int(return_code)


def module_paths(
    competition_key: str,
    event_id: int,
) -> dict[str, Path]:
    return {
        "ratings_source": (
            RATINGS_DIR
            / f"ratings_{event_id}.json"
        ),
        "goals_source": (
            GOALS_DIR
            / f"poisson_dixon_coles_{event_id}.json"
        ),
        "corners_source": (
            CORNERS_ROOT_DIR
            / competition_key
            / f"corners_{event_id}.json"
        ),
        "cards_source": (
            CARDS_ROOT_DIR
            / competition_key
            / f"cards_{event_id}.json"
        ),
        "shots_source": (
            SHOTS_ROOT_DIR
            / competition_key
            / f"shots_{event_id}.json"
        ),
    }


def destination_paths(event_dir: Path) -> dict[str, Path]:
    return {
        "ratings": event_dir / "ratings.json",
        "goals": event_dir / "goals.json",
        "corners": event_dir / "corners.json",
        "cards": event_dir / "cards.json",
        "shots": event_dir / "shots.json",
    }


def valid_component(
    path: Path,
    event_id: int,
) -> bool:
    try:
        validate_event_document(path, event_id)
        return True
    except Exception:
        return False


def ratings_history_coverage(
    document: dict[str, Any] | None,
    minimum_matches: int = 3,
) -> dict[str, Any]:
    """Mide si ambos equipos tienen base mínima para una predicción propia."""
    minimum = max(1, int(minimum_matches))
    teams: dict[str, dict[str, Any]] = {}

    for side, field in (
        ("home", "home_team_analysis"),
        ("away", "away_team_analysis"),
    ):
        analysis = document.get(field) if isinstance(document, dict) else None
        analysis = analysis if isinstance(analysis, dict) else {}
        profiles = analysis.get("profiles")
        profiles = profiles if isinstance(profiles, dict) else {}
        overall = profiles.get("overall")
        overall = overall if isinstance(overall, dict) else {}
        raw_matches = overall.get("matches")
        if raw_matches is None:
            used = analysis.get("matches_used")
            raw_matches = len(used) if isinstance(used, list) else 0
        try:
            matches = max(0, int(raw_matches))
        except (TypeError, ValueError):
            matches = 0
        team = analysis.get("team")
        team = team if isinstance(team, dict) else {}
        teams[side] = {
            "team": team.get("name"),
            "matches": matches,
            "minimum_matches": minimum,
            "sufficient": matches >= minimum,
        }

    insufficient = [
        side for side, item in teams.items() if not item["sufficient"]
    ]
    return {
        "checked": True,
        "minimum_matches": minimum,
        "sufficient": not insufficient,
        "fallback_required": bool(insufficient),
        "insufficient_sides": insufficient,
        "teams": teams,
    }


def analyze_match(
    competition: dict[str, Any],
    match: dict[str, Any],
    schedule_generated_at: str | None,
    force: bool,
) -> dict[str, Any]:
    competition_key = slugify(str(competition["key"]))
    event_id = int(match["event_id"])

    event_dir = (
        ANALYSIS_ROOT_DIR
        / competition_key
        / str(event_id)
    )
    event_dir.mkdir(parents=True, exist_ok=True)

    input_path = event_dir / "input_match.json"
    bundle_path = event_dir / "analysis.json"
    status_path = event_dir / "status.json"
    logs_dir = event_dir / "logs"

    fingerprint = build_fingerprint(
        competition_key=competition_key,
        schedule_generated_at=schedule_generated_at,
        match=match,
    )

    previous_bundle = read_json_optional(bundle_path)

    # Una predicción es provisional mientras no empiece el partido.
    # Al llegar el kickoff se congela y nunca se reescribe con datos
    # posteriores al inicio.
    if match_has_started(match):
        files = destination_paths(event_dir)
        previous_status = (
            str(previous_bundle.get("status") or "")
            if isinstance(previous_bundle, dict)
            else ""
        )

        if previous_bundle is not None:
            print("   🔒 Predicción congelada: el partido ya comenzó.")
            return {
                "event_id": event_id,
                "kickoff": match.get("kickoff"),
                "home_team": match.get("home_team"),
                "away_team": match.get("away_team"),
                "status": "FROZEN",
                "analysis_status": previous_status or "PARTIAL",
                "path": str(bundle_path),
                "generated_at": previous_bundle.get("generated_at"),
                "errors": [],
            }

        print(
            "   ⚠️ El partido ya comenzó y no existe una predicción "
            "prepartido. No se inventará una después del inicio."
        )
        return {
            "event_id": event_id,
            "kickoff": match.get("kickoff"),
            "home_team": match.get("home_team"),
            "away_team": match.get("away_team"),
            "status": "MISSED",
            "analysis_status": "MISSED",
            "path": None,
            "generated_at": utc_now(),
            "errors": [
                {
                    "component": "prediction",
                    "error": "No existía predicción antes del kickoff.",
                }
            ],
        }

    if (
        not force
        and isinstance(previous_bundle, dict)
        and previous_bundle.get("fingerprint") == fingerprint
        and previous_bundle.get("status") in {
            "FULL",
            "PARTIAL_WITH_FALLBACK",
        }
    ):
        files = destination_paths(event_dir)

        if all(
            valid_component(path, event_id)
            for path in files.values()
        ):
            previous_coverage = ratings_history_coverage(
                read_json_optional(files["ratings"])
            )
            false_full = (
                previous_bundle.get("status") == "FULL"
                and not previous_coverage["sufficient"]
            )

            if false_full:
                print(
                    "   🔄 El análisis anterior figuraba FULL sin "
                    "historial suficiente; se reclasificará con fallback."
                )
            else:
                print("   ⏭️ Ya estaba analizado y continúa vigente.")

                return {
                    "event_id": event_id,
                    "kickoff": match.get("kickoff"),
                    "home_team": match.get("home_team"),
                    "away_team": match.get("away_team"),
                    "status": "SKIPPED",
                    "analysis_status": str(
                        previous_bundle.get("status") or "FULL"
                    ),
                    "path": str(bundle_path),
                    "generated_at": previous_bundle.get(
                        "generated_at"
                    ),
                    "errors": [],
                }

    input_document = {
        "generated_at": utc_now(),
        "competition_key": competition_key,
        "evento": match,
        "upcoming_match": match,
    }
    write_json(input_path, input_document)

    sources = module_paths(
        competition_key,
        event_id,
    )
    destinations = destination_paths(event_dir)

    components: dict[str, dict[str, Any] | None] = {
        "ratings": None,
        "goals": None,
        "corners": None,
        "cards": None,
        "shots": None,
    }

    errors: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []
    data_coverage: dict[str, Any] = {
        "checked": False,
        "sufficient": False,
    }
    module_exit_codes: dict[str, int | None] = {
        "ratings": None,
        "goals": None,
        "corners": None,
        "cards": None,
        "shots": None,
    }
    failed_modules: list[str] = []
    fallback_modules: list[str] = []
    successful_modules: list[str] = []

    status_document = {
        "event_id": event_id,
        "competition_key": competition_key,
        "started_at": utc_now(),
        "fingerprint": fingerprint,
        "steps": {},
    }
    write_json(status_path, status_document)

    # --------------------------------------------------------------------------
    # RATINGS
    # --------------------------------------------------------------------------
    try:
        sources["ratings_source"].unlink(missing_ok=True)

        module_exit_codes["ratings"] = run_module(
            title="Ratings ponderados",
            command=[sys.executable, '-u', str(RATINGS_SCRIPT), str(input_path), '--key', competition_key],
            log_path=logs_dir / "ratings.log",
        )

        validate_event_document(
            sources["ratings_source"],
            event_id,
        )

        components["ratings"] = copy_json(
            sources["ratings_source"],
            destinations["ratings"],
        )

        data_coverage = ratings_history_coverage(
            components["ratings"]
        )
        status_document["data_coverage"] = data_coverage

        if not data_coverage["sufficient"]:
            fallback_modules.append("ratings_history")
            warnings.append(
                {
                    "component": "ratings",
                    "code": "INSUFFICIENT_TEAM_HISTORY",
                    "message": (
                        "Uno o ambos equipos no alcanzan el historial "
                        "mínimo; los modelos disponibles siguen activos "
                        "y el análisis queda marcado con fallback."
                    ),
                    "coverage": data_coverage,
                }
            )

        status_document["steps"]["ratings"] = "OK"
        successful_modules.append("ratings")

    except Exception as exc:
        message = f"{type(exc).__name__}: {exc}"
        module_exit_codes["ratings"] = int(
            getattr(exc, "return_code", 1)
        )
        failed_modules.append("ratings")
        errors.append(
            {
                "component": "ratings",
                "error": message,
            }
        )
        status_document["steps"]["ratings"] = message

    write_json(status_path, status_document)

    # Sin ratings no se pueden ejecutar los demás modelos.
    if components["ratings"] is None:
        status = "ERROR"
        unrecovered_modules = list(failed_modules or ["ratings"])

    else:
        # ----------------------------------------------------------------------
        # GOLES
        # ----------------------------------------------------------------------
        try:
            sources["goals_source"].unlink(missing_ok=True)

            module_exit_codes["goals"] = run_module(
                title="Poisson + Dixon-Coles",
                command=[
                    sys.executable,
                    "-u",
                    str(GOALS_SCRIPT),
                    str(destinations["ratings"]),
                    "--key",
                    competition_key,
                ],
                log_path=logs_dir / "goals.log",
            )

            validate_event_document(
                sources["goals_source"],
                event_id,
            )

            components["goals"] = copy_json(
                sources["goals_source"],
                destinations["goals"],
            )

            status_document["steps"]["goals"] = "OK"
            successful_modules.append("goals")

        except Exception as exc:
            message = f"{type(exc).__name__}: {exc}"
            module_exit_codes["goals"] = int(
                getattr(exc, "return_code", 1)
            )
            failed_modules.append("goals")
            errors.append(
                {
                    "component": "goals",
                    "error": message,
                }
            )
            status_document["steps"]["goals"] = message

        write_json(status_path, status_document)

        # ----------------------------------------------------------------------
        # CÓRNERS
        # ----------------------------------------------------------------------
        try:
            sources["corners_source"].unlink(missing_ok=True)

            module_exit_codes["corners"] = run_module(
                title="Modelo de córners",
                command=[
                    sys.executable,
                    "-u",
                    str(CORNERS_SCRIPT),
                    "--key",
                    competition_key,
                    "--match-json",
                    str(destinations["ratings"]),
                ],
                log_path=logs_dir / "corners.log",
            )

            validate_event_document(
                sources["corners_source"],
                event_id,
            )

            components["corners"] = copy_json(
                sources["corners_source"],
                destinations["corners"],
            )
            status_document["steps"]["corners"] = "OK"
            successful_modules.append("corners")

        except Exception as exc:
            module_exit_codes["corners"] = int(
                getattr(exc, "return_code", 1)
            )
            failed_modules.append("corners")
            context_document = build_component_document(
                "corners",
                components["ratings"],
                competition,
            )
            if context_document is not None:
                write_json(destinations["corners"], context_document)
                components["corners"] = context_document
                status_document["steps"]["corners"] = "OK_BOT10_CONTEXT_FALLBACK"
                fallback_modules.append("corners")
                errors.append(
                    {
                        "component": "corners",
                        "error": f"{type(exc).__name__}: {exc}",
                        "recovered_by_fallback": True,
                    }
                )
            else:
                message = f"{type(exc).__name__}: {exc}"
                errors.append(
                    {
                        "component": "corners",
                        "error": message,
                    }
                )
                status_document["steps"]["corners"] = message

        write_json(status_path, status_document)

        # ----------------------------------------------------------------------
        # TARJETAS
        # ----------------------------------------------------------------------
        try:
            sources["cards_source"].unlink(missing_ok=True)

            module_exit_codes["cards"] = run_module(
                title="Modelo de tarjetas",
                command=[
                    sys.executable,
                    "-u",
                    str(CARDS_SCRIPT),
                    "--key",
                    competition_key,
                    "--match-json",
                    str(destinations["ratings"]),
                ],
                log_path=logs_dir / "cards.log",
            )

            validate_event_document(
                sources["cards_source"],
                event_id,
            )

            components["cards"] = copy_json(
                sources["cards_source"],
                destinations["cards"],
            )
            status_document["steps"]["cards"] = "OK"
            successful_modules.append("cards")

        except Exception as exc:
            module_exit_codes["cards"] = int(
                getattr(exc, "return_code", 1)
            )
            failed_modules.append("cards")
            context_document = build_component_document(
                "cards",
                components["ratings"],
                competition,
            )
            if context_document is not None:
                write_json(destinations["cards"], context_document)
                components["cards"] = context_document
                status_document["steps"]["cards"] = "OK_BOT10_CONTEXT_FALLBACK"
                fallback_modules.append("cards")
                errors.append(
                    {
                        "component": "cards",
                        "error": f"{type(exc).__name__}: {exc}",
                        "recovered_by_fallback": True,
                    }
                )
            else:
                message = f"{type(exc).__name__}: {exc}"
                errors.append(
                    {
                        "component": "cards",
                        "error": message,
                    }
                )
                status_document["steps"]["cards"] = message

        write_json(status_path, status_document)

        # ----------------------------------------------------------------------
        # REMATES Y REMATES A PUERTA
        # ----------------------------------------------------------------------
        try:
            sources["shots_source"].unlink(missing_ok=True)

            module_exit_codes["shots"] = run_module(
                title="Modelo de remates",
                command=[
                    sys.executable,
                    "-u",
                    str(SHOTS_SCRIPT),
                    "--key",
                    competition_key,
                    "--match-json",
                    str(destinations["ratings"]),
                ],
                log_path=logs_dir / "shots.log",
            )

            validate_event_document(
                sources["shots_source"],
                event_id,
            )

            components["shots"] = copy_json(
                sources["shots_source"],
                destinations["shots"],
            )
            status_document["steps"]["shots"] = "OK"
            successful_modules.append("shots")

        except Exception as exc:
            module_exit_codes["shots"] = int(
                getattr(exc, "return_code", 1)
            )
            failed_modules.append("shots")
            context_document = build_component_document(
                "shots",
                components["ratings"],
                competition,
            )
            if context_document is not None:
                write_json(destinations["shots"], context_document)
                components["shots"] = context_document
                status_document["steps"]["shots"] = "OK_BOT10_CONTEXT_FALLBACK"
                fallback_modules.append("shots")
                errors.append(
                    {
                        "component": "shots",
                        "error": f"{type(exc).__name__}: {exc}",
                        "recovered_by_fallback": True,
                    }
                )
            else:
                message = f"{type(exc).__name__}: {exc}"
                errors.append(
                    {
                        "component": "shots",
                        "error": message,
                    }
                )
                status_document["steps"]["shots"] = message

        write_json(status_path, status_document)

        available = sum(
            value is not None
            for value in components.values()
        )
        unrecovered_modules = [
            module
            for module in failed_modules
            if module not in fallback_modules
        ]
        if unrecovered_modules:
            status = "PARTIAL_MODULE_ERROR"
        elif fallback_modules:
            status = "PARTIAL_WITH_FALLBACK"
        elif available == 5 and len(successful_modules) == 5:
            status = "FULL"
        else:
            status = "ERROR"

    bundle = {
        "generated_at": utc_now(),
        "fingerprint": fingerprint,
        "status": status,
        "competition": {
            "key": competition_key,
            "name": competition.get("name"),
            "country": competition.get("country"),
            "season_name": competition.get("season_name"),
            "season_id": competition.get("season_id"),
        },
        "upcoming_match": match,
        "files": {
            key: str(path)
            for key, path in destinations.items()
        },
        "ratings": components["ratings"],
        "goals": components["goals"],
        "corners": components["corners"],
        "cards": components["cards"],
        "shots": components["shots"],
        "errors": errors,
        "warnings": warnings,
        "data_coverage": data_coverage,
        "ratings_exit_code": module_exit_codes["ratings"],
        "goals_exit_code": module_exit_codes["goals"],
        "corners_exit_code": module_exit_codes["corners"],
        "cards_exit_code": module_exit_codes["cards"],
        "shots_exit_code": module_exit_codes["shots"],
        "module_exit_codes": module_exit_codes,
        "failed_modules": sorted(set(failed_modules)),
        "fallback_modules": sorted(set(fallback_modules)),
        "successful_modules": sorted(set(successful_modules)),
        "unrecovered_modules": sorted(set(unrecovered_modules)),
        "analysis_run_status": status,
    }
    write_json(bundle_path, bundle)

    status_document["finished_at"] = utc_now()
    status_document["status"] = status
    status_document["errors"] = errors
    status_document["warnings"] = warnings
    status_document["data_coverage"] = data_coverage
    status_document["module_exit_codes"] = module_exit_codes
    status_document["failed_modules"] = sorted(set(failed_modules))
    status_document["fallback_modules"] = sorted(set(fallback_modules))
    status_document["successful_modules"] = sorted(set(successful_modules))
    status_document["unrecovered_modules"] = sorted(set(unrecovered_modules))
    write_json(status_path, status_document)

    return {
        "event_id": event_id,
        "kickoff": match.get("kickoff"),
        "home_team": match.get("home_team"),
        "away_team": match.get("away_team"),
        "status": status,
        "analysis_status": status,
        "path": str(bundle_path),
        "generated_at": bundle["generated_at"],
        "errors": errors,
        "ratings_exit_code": module_exit_codes["ratings"],
        "goals_exit_code": module_exit_codes["goals"],
        "corners_exit_code": module_exit_codes["corners"],
        "cards_exit_code": module_exit_codes["cards"],
        "shots_exit_code": module_exit_codes["shots"],
        "failed_modules": sorted(set(failed_modules)),
        "fallback_modules": sorted(set(fallback_modules)),
        "successful_modules": sorted(set(successful_modules)),
    }


def repair_missing_match(
    competition: dict[str, Any],
    match: dict[str, Any],
    schedule_generated_at: str | None,
) -> dict[str, Any]:
    """Repara solo córners/tarjetas ausentes y conserva módulos válidos."""
    competition_key = slugify(str(competition["key"]))
    event_id = int(match["event_id"])
    event_dir = ANALYSIS_ROOT_DIR / competition_key / str(event_id)
    bundle_path = event_dir / "analysis.json"
    status_path = event_dir / "status.json"
    input_path = event_dir / "input_match.json"
    logs_dir = event_dir / "logs"

    if match_has_started(match):
        raise RuntimeError(
            "El partido ya comenzó; el PREPARTIDO no se puede reparar."
        )
    if not input_path.is_file():
        raise FileNotFoundError(
            f"No existe el PREPARTIDO de entrada para {event_id}."
        )

    destinations = destination_paths(event_dir)
    sources = module_paths(competition_key, event_id)
    components: dict[str, dict[str, Any] | None] = {}
    for name, path in destinations.items():
        components[name] = (
            validate_event_document(path, event_id)
            if valid_component(path, event_id)
            else None
        )
        if name in {"corners", "cards"} and components[name] is not None:
            analysis = components[name].get("analysis")
            if isinstance(analysis, dict):
                trained = analysis.get("trained_model")
                source = str(analysis.get("source") or "")
                if (
                    isinstance(trained, dict)
                    and trained.get("available") is False
                    and source == "same_competition_trained_model"
                ):
                    components[name] = None

    preserved = [
        name for name, document in components.items() if document is not None
    ]
    print("   Preservados: " + ", ".join(sorted(preserved)))

    errors: list[dict[str, Any]] = []
    repaired: list[str] = []
    exit_codes: dict[str, int | None] = {
        name: (0 if document is not None else None)
        for name, document in components.items()
    }

    if components.get("ratings") is None:
        errors.append(
            {
                "component": "ratings",
                "error": "ratings.json válido es obligatorio para reparar mercados.",
            }
        )
    else:
        repair_commands = {
            "corners": [
                sys.executable,
                "-u",
                str(CORNERS_SCRIPT),
                "--key",
                competition_key,
                "--match-json",
                str(destinations["ratings"]),
            ],
            "cards": [
                sys.executable,
                "-u",
                str(CARDS_SCRIPT),
                "--key",
                competition_key,
                "--match-json",
                str(destinations["ratings"]),
            ],
        }
        titles = {
            "corners": "Reparación de córners",
            "cards": "Reparación de tarjetas",
        }
        for name in ("corners", "cards"):
            if components.get(name) is not None:
                continue
            try:
                sources[f"{name}_source"].unlink(missing_ok=True)
                exit_codes[name] = run_module(
                    title=titles[name],
                    command=repair_commands[name],
                    log_path=logs_dir / f"{name}.log",
                )
                validate_event_document(
                    sources[f"{name}_source"],
                    event_id,
                )
                components[name] = copy_json(
                    sources[f"{name}_source"],
                    destinations[name],
                )
                repaired.append(name)
            except Exception as exc:
                exit_codes[name] = int(getattr(exc, "return_code", 1))
                errors.append(
                    {
                        "component": name,
                        "error": f"{type(exc).__name__}: {exc}",
                    }
                )

    missing = [
        name for name, document in components.items() if document is None
    ]
    status = "FULL" if not missing else "PARTIAL_MODULE_ERROR"
    now = utc_now()
    fingerprint = build_fingerprint(
        competition_key=competition_key,
        schedule_generated_at=schedule_generated_at,
        match=match,
    )

    previous_bundle = read_json_optional(bundle_path) or {}
    bundle = dict(previous_bundle)
    bundle.update(
        {
            "generated_at": now,
            "fingerprint": fingerprint,
            "status": status,
            "competition": {
                "key": competition_key,
                "name": competition.get("name"),
                "country": competition.get("country"),
                "season_name": competition.get("season_name"),
                "season_id": competition.get("season_id"),
            },
            "upcoming_match": match,
            "files": {
                key: str(path) for key, path in destinations.items()
            },
            **components,
            "errors": errors,
            "module_exit_codes": exit_codes,
            "ratings_exit_code": exit_codes["ratings"],
            "goals_exit_code": exit_codes["goals"],
            "corners_exit_code": exit_codes["corners"],
            "cards_exit_code": exit_codes["cards"],
            "shots_exit_code": exit_codes["shots"],
            "failed_modules": sorted(missing),
            "fallback_modules": [],
            "successful_modules": sorted(
                name
                for name, document in components.items()
                if document is not None
            ),
            "unrecovered_modules": sorted(missing),
            "analysis_run_status": status,
            "repair": {
                "mode": "MISSING_ONLY",
                "repaired_modules": sorted(repaired),
                "preserved_modules": sorted(preserved),
            },
        }
    )
    write_json(bundle_path, bundle)

    previous_status = read_json_optional(status_path) or {}
    steps = dict(previous_status.get("steps") or {})
    for name in preserved:
        steps[name] = "PRESERVED_VALID"
    for name in repaired:
        steps[name] = "OK_REPAIRED"
    status_document = dict(previous_status)
    status_document.update(
        {
            "event_id": event_id,
            "competition_key": competition_key,
            "fingerprint": fingerprint,
            "repair_started_at": now,
            "finished_at": utc_now(),
            "status": status,
            "steps": steps,
            "errors": errors,
            "module_exit_codes": exit_codes,
            "failed_modules": sorted(missing),
            "fallback_modules": [],
            "successful_modules": bundle["successful_modules"],
            "unrecovered_modules": sorted(missing),
            "repair": bundle["repair"],
        }
    )
    write_json(status_path, status_document)

    return {
        "event_id": event_id,
        "kickoff": match.get("kickoff"),
        "home_team": match.get("home_team"),
        "away_team": match.get("away_team"),
        "status": status,
        "analysis_status": status,
        "path": str(bundle_path),
        "generated_at": bundle["generated_at"],
        "errors": errors,
        "repaired_modules": sorted(repaired),
        "preserved_modules": sorted(preserved),
    }


# ==============================================================================
# 5. ÍNDICE Y ARCHIVOS "ÚLTIMO"
# ==============================================================================

def save_index(
    competition: dict[str, Any],
    schedule: dict[str, Any],
    results: list[dict[str, Any]],
) -> Path:
    competition_key = slugify(str(competition["key"]))
    output_dir = ANALYSIS_ROOT_DIR / competition_key
    output_dir.mkdir(parents=True, exist_ok=True)

    previous = read_json_optional(
        output_dir / "index.json"
    ) or {}

    previous_rows = {
        int(row["event_id"]): row
        for row in previous.get("matches", [])
        if isinstance(row, dict)
        and row.get("event_id") is not None
    }

    for result in results:
        previous_rows[int(result["event_id"])] = result

    schedule_ids = {
        int(match["event_id"])
        for match in schedule.get("matches", [])
        if isinstance(match, dict)
        and match.get("event_id") is not None
    }

    ordered = sorted(
        (
            row
            for event_id, row in previous_rows.items()
            if event_id in schedule_ids
        ),
        key=lambda row: (
            str(row.get("kickoff") or ""),
            int(row.get("event_id") or 0),
        ),
    )

    path = output_dir / "index.json"

    write_json(
        path,
        {
            "generated_at": utc_now(),
            "competition_key": competition_key,
            "competition_name": competition.get("name"),
            "schedule_generated_at": schedule.get("generated_at"),
            "total_upcoming_matches": len(
                schedule.get("matches", [])
            ),
            "full": sum(
                1
                for row in ordered
                if row.get("analysis_status") == "FULL"
            ),
            "partial_with_fallback": sum(
                1
                for row in ordered
                if row.get("analysis_status") == "PARTIAL_WITH_FALLBACK"
            ),
            "partial_module_error": sum(
                1
                for row in ordered
                if row.get("analysis_status") == "PARTIAL_MODULE_ERROR"
            ),
            "partial": sum(
                1
                for row in ordered
                if row.get("analysis_status") in {
                    "PARTIAL_WITH_FALLBACK",
                    "PARTIAL_MODULE_ERROR",
                }
            ),
            "errors": sum(
                1
                for row in ordered
                if row.get("analysis_status") == "ERROR"
            ),
            "missed": sum(
                1
                for row in ordered
                if row.get("analysis_status") == "MISSED"
            ),
            "matches": ordered,
        },
    )

    return path


def copy_as_latest(
    competition_key: str,
    result: dict[str, Any],
) -> None:
    if result.get("analysis_status") not in {
        "FULL",
        "PARTIAL_WITH_FALLBACK",
    }:
        return

    event_id = int(result["event_id"])
    event_dir = (
        ANALYSIS_ROOT_DIR
        / competition_key
        / str(event_id)
    )

    mapping = {
        event_dir / "ratings.json": (
            RATINGS_DIR / "ultimo_ratings.json"
        ),
        event_dir / "goals.json": (
            GOALS_DIR
            / "ultimo_poisson_dixon_coles.json"
        ),
        event_dir / "corners.json": (
            CORNERS_ROOT_DIR
            / competition_key
            / "ultimo_corners.json"
        ),
        event_dir / "cards.json": (
            CARDS_ROOT_DIR
            / competition_key
            / "ultimo_cards.json"
        ),
        event_dir / "shots.json": (
            SHOTS_ROOT_DIR
            / competition_key
            / "ultimo_shots.json"
        ),
    }

    for source, destination in mapping.items():
        if not source.exists():
            continue

        destination.parent.mkdir(
            parents=True,
            exist_ok=True,
        )
        shutil.copy2(source, destination)


# ==============================================================================
# 6. CLI
# ==============================================================================

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Calcula automáticamente ratings, goles, córners, "
            "tarjetas y remates para todos los próximos partidos."
        )
    )

    parser.add_argument(
        "--key",
        required=True,
        help="Clave de competición, por ejemplo: mls",
    )

    parser.add_argument(
        "--event-id",
        type=int,
        action="append",
        help=(
            "Analiza solo un evento. Puede repetirse varias veces."
        ),
    )

    parser.add_argument(
        "--limit",
        type=int,
        help="Procesa únicamente los primeros N partidos.",
    )

    parser.add_argument(
        "--force",
        action="store_true",
        help="Recalcula aunque el análisis vigente ya exista.",
    )

    parser.add_argument(
        "--no-set-latest",
        action="store_true",
        help=(
            "No actualiza los archivos ultimo_*.json al finalizar."
        ),
    )

    parser.add_argument(
        "--repair-missing-only",
        action="store_true",
        help=(
            "Conserva módulos válidos y repara únicamente córners/tarjetas "
            "ausentes en PREPARTIDO futuros."
        ),
    )

    return parser


def main() -> None:
    args = build_parser().parse_args()

    try:
        for script in REQUIRED_SCRIPTS:
            if not script.exists():
                raise FileNotFoundError(
                    f"No se encontró el módulo requerido:\n{script}"
                )

        if not DB_PATH.exists():
            raise FileNotFoundError(
                f"No se encontró la base de datos:\n{DB_PATH}"
            )

        registry = load_registry()
        competition = find_competition(
            registry,
            args.key,
        )
        competition_key = slugify(
            str(competition["key"])
        )

        schedule, schedule_path = load_upcoming_schedule(
            competition_key
        )

        matches = list(schedule["matches"])

        if args.event_id:
            selected_ids = set(args.event_id)
            matches = [
                match
                for match in matches
                if int(match["event_id"]) in selected_ids
            ]

        if args.limit is not None:
            matches = matches[:max(0, int(args.limit))]

        if not matches:
            raise RuntimeError(
                "No hay próximos partidos seleccionados para analizar."
            )

        print("=" * 86)
        print("ODDSHUNTER — ANÁLISIS AUTOMÁTICO DE PRÓXIMOS PARTIDOS")
        print("=" * 86)
        print(
            f"Competición: {competition.get('name')} "
            f"{competition.get('season_name') or ''}".strip()
        )
        print(f"Calendario: {schedule_path}")
        print(f"Partidos seleccionados: {len(matches)}")
        print(
            "Módulos por partido: ratings → goles → córners → tarjetas → remates"
        )
        print()

        results: list[dict[str, Any]] = []

        for index, match in enumerate(matches, start=1):
            event_id = int(match["event_id"])
            home = match.get("home_team") or "Local"
            away = match.get("away_team") or "Visitante"

            print("-" * 86)
            print(
                f"[{index:02d}/{len(matches):02d}] "
                f"{home} vs {away} | event_id={event_id}"
            )

            try:
                if args.repair_missing_only:
                    result = repair_missing_match(
                        competition=competition,
                        match=match,
                        schedule_generated_at=schedule.get("generated_at"),
                    )
                else:
                    result = analyze_match(
                        competition=competition,
                        match=match,
                        schedule_generated_at=schedule.get(
                            "generated_at"
                        ),
                        force=bool(args.force),
                    )

            except Exception as exc:
                result = {
                    "event_id": event_id,
                    "kickoff": match.get("kickoff"),
                    "home_team": home,
                    "away_team": away,
                    "status": "ERROR",
                    "analysis_status": "ERROR",
                    "path": None,
                    "generated_at": utc_now(),
                    "errors": [
                        {
                            "component": "orchestrator",
                            "error": (
                                f"{type(exc).__name__}: {exc}"
                            ),
                        }
                    ],
                }

                print(
                    f"   ❌ {type(exc).__name__}: {exc}"
                )

            results.append(result)

            print(
                f"   Resultado: "
                f"{result.get('analysis_status')}"
            )

            save_index(
                competition=competition,
                schedule=schedule,
                results=results,
            )

        index_path = save_index(
            competition=competition,
            schedule=schedule,
            results=results,
        )

        successful = [
            result
            for result in results
            if result.get("analysis_status") in {
                "FULL",
                "PARTIAL_WITH_FALLBACK",
            }
        ]

        if successful and not args.no_set_latest:
            first = sorted(
                successful,
                key=lambda row: (
                    str(row.get("kickoff") or ""),
                    int(row.get("event_id") or 0),
                ),
            )[0]

            copy_as_latest(
                competition_key,
                first,
            )

        print()
        print("=" * 86)
        print("RESUMEN FINAL")
        print("=" * 86)
        print(f"Seleccionados: {len(results)}")
        print(
            "Completos: "
            f"{sum(1 for row in results if row.get('analysis_status') == 'FULL')}"
        )
        print(
            "Parciales con fallback: "
            f"{sum(1 for row in results if row.get('analysis_status') == 'PARTIAL_WITH_FALLBACK')}"
        )
        print(
            "Parciales con error: "
            f"{sum(1 for row in results if row.get('analysis_status') == 'PARTIAL_MODULE_ERROR')}"
        )
        print(
            "Errores: "
            f"{sum(1 for row in results if row.get('analysis_status') == 'ERROR')}"
        )
        print(
            "Vigentes omitidos: "
            f"{sum(1 for row in results if row.get('status') == 'SKIPPED')}"
        )
        print(f"\nÍndice:\n{index_path}")
        print(
            f"\nAnálisis por partido:\n"
            f"{ANALYSIS_ROOT_DIR / competition_key}"
        )
        print("=" * 86)
        print("✅ ANÁLISIS AUTOMÁTICO TERMINADO")

    except KeyboardInterrupt:
        print(
            "\n⚠️ Proceso interrumpido. "
            "Los partidos terminados permanecen guardados."
        )

    except Exception as exc:
        print(
            f"\n❌ Error: {type(exc).__name__}: {exc}"
        )
        raise SystemExit(1)


if __name__ == "__main__":
    main()
