from __future__ import annotations

import math
from datetime import datetime, timezone
from typing import Any


WINDOW = 15
RECENT = 5
DOMESTIC_RATIO_MIN = 0.35
DOMESTIC_RATIO_MAX = 2.50

MARKET_FIELDS: dict[str, tuple[str, ...]] = {
    "goals": ("goals_for", "goals_against"),
    "xg": ("xg_for", "xg_against"),
    "shots": ("shots", "shots_on_target"),
    "corners": ("corners_for", "corners_against"),
    "cards": ("yellow_cards", "red_cards"),
    "general": ("possession", "fouls", "offsides", "big_chances"),
}

FIELD_MARKET = {
    field: market
    for market, fields in MARKET_FIELDS.items()
    for field in fields
}

CONFIDENCE_ORDER = {"LOW": 0, "MEDIUM": 1, "HIGH": 2}


def number(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def _count(profile: dict[str, Any], field: str) -> int:
    values = profile.get("available_values")
    if isinstance(values, dict):
        try:
            return max(0, min(WINDOW, int(values.get(field) or 0)))
        except (TypeError, ValueError):
            pass
    market = FIELD_MARKET[field]
    windows = profile.get("matches_by_market")
    if isinstance(windows, dict):
        try:
            return max(0, min(WINDOW, int(windows.get(market) or 0)))
        except (TypeError, ValueError):
            return 0
    return 0


def venue_adjusted_metric(
    specific: dict[str, Any],
    overall: dict[str, Any],
    field: str,
) -> tuple[float | None, int, dict[str, Any]]:
    """Contrae local/visitante hacia el perfil general de la misma fuente.

    Un Ãºnico partido como local no debe ocultar catorce observaciones
    domÃ©sticas reales. Tampoco se cuentan dos veces: el conteo de evidencia es
    el mÃ¡ximo disponible y el valor de sede se contrae jerÃ¡rquicamente.
    """

    specific_value = number((specific.get("averages") or {}).get(field))
    overall_value = number((overall.get("averages") or {}).get(field))
    specific_count = _count(specific, field)
    overall_count = _count(overall, field)
    if specific_value is None:
        value = overall_value
        venue_weight = 0.0
    elif overall_value is None or specific is overall:
        value = specific_value
        venue_weight = 1.0
    else:
        venue_weight = specific_count / (specific_count + 3.0)
        value = (
            specific_value * venue_weight
            + overall_value * (1.0 - venue_weight)
        )
    return value, max(specific_count, overall_count), {
        "venue_specific_matches": specific_count,
        "general_matches": overall_count,
        "venue_specific_weight": round(venue_weight, 6),
        "uses_general_shrinkage": (
            specific is not overall and overall_value is not None
        ),
    }


def _confidence(european_count: int, domestic_count: int) -> str:
    total = min(WINDOW, european_count + domestic_count)
    if european_count >= 10 or (european_count >= 7 and total >= 15):
        return "HIGH"
    if total >= 8 or european_count >= 4:
        return "MEDIUM"
    return "LOW"


def evidence_weights(
    european_count: int,
    domestic_count: int,
    prior_available: bool,
) -> dict[str, float]:
    """Pesos por evidencia; nunca usa una mezcla fija 70/30.

    El apoyo doméstico cae de forma continua cuando crece la cobertura UEFA.
    Los coeficientes son parámetros de la versión evidence_v1 y quedan
    expuestos en el JSON para poder calibrarlos mediante backtesting.
    """

    eu_coverage = max(0.0, min(1.0, european_count / WINDOW))
    domestic_coverage = max(0.0, min(1.0, domestic_count / WINDOW))
    european_score = (eu_coverage ** 0.85) * 1.35
    # El contexto doméstico se reduce de forma continua y solo llega a
    # cero cuando ya existen 15 observaciones UEFA válidas del mercado.
    # Nunca se apaga bruscamente al alcanzar tres partidos.
    domestic_decay = max(0.0, 1.0 - eu_coverage)
    domestic_score = (domestic_coverage ** 0.85) * domestic_decay
    prior_score = (
        0.35 * (1.0 - eu_coverage) * (1.0 - domestic_coverage)
        if prior_available
        else 0.0
    )
    total = european_score + domestic_score + prior_score
    if total <= 0.0:
        return {"uefa": 0.0, "domestic": 0.0, "prior": 0.0}
    return {
        "uefa": european_score / total,
        "domestic": domestic_score / total,
        "prior": prior_score / total,
    }


def blend_metric(
    european_value: Any,
    domestic_value: Any,
    prior_value: Any,
    european_count: int,
    domestic_count: int,
    domestic_baseline: Any = None,
    target_baseline: Any = None,
) -> tuple[float | None, dict[str, Any]]:
    eu = number(european_value)
    domestic_raw = number(domestic_value)
    domestic_mean = number(domestic_baseline)
    target_mean = number(target_baseline)
    domestic = domestic_raw
    normalization_ratio: float | None = None
    if (
        domestic_raw is not None
        and domestic_mean is not None
        and target_mean is not None
        and domestic_mean > 0.0
        and target_mean >= 0.0
    ):
        normalization_ratio = max(
            DOMESTIC_RATIO_MIN,
            min(DOMESTIC_RATIO_MAX, domestic_raw / domestic_mean),
        )
        domestic = target_mean * normalization_ratio
    prior = number(prior_value)
    weights = evidence_weights(
        european_count if eu is not None else 0,
        domestic_count if domestic is not None else 0,
        prior is not None,
    )
    values = {"uefa": eu, "domestic": domestic, "prior": prior}
    numerator = 0.0
    denominator = 0.0
    for source, value in values.items():
        if value is None:
            continue
        weight = float(weights[source])
        numerator += value * weight
        denominator += weight
    result = numerator / denominator if denominator > 0 else None

    if eu is not None and domestic is not None:
        source = "uefa_domestic_bayesian"
    elif eu is not None:
        source = "uefa_profile"
    elif domestic is not None:
        source = "domestic_profile_bayesian"
    elif prior is not None:
        source = "competition_prior"
    else:
        source = "unavailable"
    effective_uefa = min(WINDOW, max(0, european_count))
    effective_domestic = min(WINDOW, max(0.0, domestic_count * 0.75))
    fallback_level = (
        "A" if european_count >= 10
        else "B" if european_count >= 5
        else "C" if domestic_count > 0
        else "D" if prior is not None
        else "E"
    )
    return (
        None if result is None else round(result, 4),
        {
            "source": source,
            "method_version": "evidence_v2_league_normalized",
            "uefa_real_matches": european_count,
            "domestic_real_matches": domestic_count,
            "uefa_valid_matches": european_count,
            "domestic_valid_matches": domestic_count,
            "uefa_effective_sample": round(effective_uefa, 2),
            "domestic_effective_sample": round(effective_domestic, 2),
            "effective_sample": round(
                min(WINDOW, effective_uefa + effective_domestic),
                2,
            ),
            "confidence": _confidence(european_count, domestic_count),
            "weights": {key: round(value, 6) for key, value in weights.items()},
            "uefa_weight": round(weights["uefa"], 6),
            "domestic_weight": round(weights["domestic"], 6),
            "prior_weight": round(weights["prior"], 6),
            "fallback_level": fallback_level,
            "domestic_raw_value": domestic_raw,
            "domestic_league_mean": domestic_mean,
            "target_uefa_mean": target_mean,
            "domestic_normalized_value": domestic,
            "domestic_normalization_ratio": (
                None
                if normalization_ratio is None
                else round(normalization_ratio, 6)
            ),
            "domestic_normalized": normalization_ratio is not None,
        },
    )


def _empty_profile(venue: str) -> dict[str, Any]:
    return {
        "venue": venue,
        "matches": 0,
        "total_weight": 0.0,
        "form": {},
        "averages": {field: None for field in FIELD_MARKET},
        "available_values": {field: 0 for field in FIELD_MARKET},
        "matches_by_market": {market: 0 for market in MARKET_FIELDS},
        "market_provenance": {},
        "market_context": {},
        "confidence_by_market": {},
    }


def build_model_profiles(
    european_profiles: dict[str, Any] | None,
    domestic_profiles: dict[str, Any] | None,
    priors: dict[str, Any],
    domestic_priors: dict[str, Any] | None = None,
) -> dict[str, Any]:
    european_profiles = european_profiles or {}
    domestic_profiles = domestic_profiles or {}
    domestic_priors = domestic_priors or {}
    result: dict[str, Any] = {}
    eu_overall = european_profiles.get("overall")
    eu_overall = (
        eu_overall if isinstance(eu_overall, dict) else _empty_profile("OVERALL")
    )
    domestic_overall = domestic_profiles.get("overall")
    domestic_overall = (
        domestic_overall
        if isinstance(domestic_overall, dict)
        else _empty_profile("OVERALL")
    )
    for venue in ("overall", "home", "away", "relevant"):
        eu = european_profiles.get(venue)
        domestic = domestic_profiles.get(venue)
        eu = eu if isinstance(eu, dict) else _empty_profile(venue.upper())
        domestic = (
            domestic if isinstance(domestic, dict) else _empty_profile(venue.upper())
        )
        profile = _empty_profile(str(eu.get("venue") or venue).upper())
        profile["form"] = eu.get("form") or domestic.get("form") or {}
        for field, market in FIELD_MARKET.items():
            eu_value, eu_count, eu_venue = venue_adjusted_metric(
                eu,
                eu_overall,
                field,
            )
            domestic_value, domestic_count, domestic_venue = venue_adjusted_metric(
                domestic,
                domestic_overall,
                field,
            )
            value, provenance = blend_metric(
                eu_value,
                domestic_value,
                priors.get(field),
                eu_count,
                domestic_count,
                domestic_priors.get(field),
                priors.get(field),
            )
            provenance["uefa_venue_profile"] = eu_venue
            provenance["domestic_venue_profile"] = domestic_venue
            profile["averages"][field] = value
            profile["available_values"][field] = min(
                WINDOW, eu_count + domestic_count
            )
            profile["market_provenance"].setdefault(market, {})[field] = provenance
        for market, fields in MARKET_FIELDS.items():
            counts = [profile["available_values"][field] for field in fields]
            profile["matches_by_market"][market] = min(counts) if counts else 0
            confidences = [
                profile["market_provenance"][market][field]["confidence"]
                for field in fields
            ]
            profile["confidence_by_market"][market] = min(
                confidences,
                key=lambda value: CONFIDENCE_ORDER.get(value, 0),
            )
            principal = fields[0] if fields else None
            principal_provenance = (
                profile["market_provenance"][market][principal]
                if principal is not None
                else {}
            )
            profile["market_context"][market] = {
                "market": market,
                "uefa_valid_matches": principal_provenance.get(
                    "uefa_valid_matches", 0
                ),
                "domestic_valid_matches": principal_provenance.get(
                    "domestic_valid_matches", 0
                ),
                "uefa_effective_sample": principal_provenance.get(
                    "uefa_effective_sample", 0.0
                ),
                "domestic_effective_sample": principal_provenance.get(
                    "domestic_effective_sample", 0.0
                ),
                "effective_sample": principal_provenance.get(
                    "effective_sample", 0.0
                ),
                "uefa_weight": principal_provenance.get("uefa_weight", 0.0),
                "domestic_weight": principal_provenance.get(
                    "domestic_weight", 0.0
                ),
                "prior_weight": principal_provenance.get("prior_weight", 0.0),
                "expected_value": (
                    profile["averages"].get(principal)
                    if principal is not None
                    else None
                ),
                "source": principal_provenance.get("source", "unavailable"),
                "confidence": profile["confidence_by_market"][market],
                "fallback_level": principal_provenance.get("fallback_level", "E"),
                "method_version": "bot10_1_evidence_v2",
            }
        profile["matches"] = max(profile["matches_by_market"].values(), default=0)
        profile["total_weight"] = float(profile["matches"])
        result[venue] = profile
    return result


def _geo(first: Any, second: Any) -> float | None:
    left = number(first)
    right = number(second)
    if left is not None and right is not None and left >= 0 and right >= 0:
        return math.sqrt(left * right)
    return left if left is not None else right


def _lower_confidence(first: str, second: str) -> str:
    return min(
        (first or "LOW", second or "LOW"),
        key=lambda value: CONFIDENCE_ORDER.get(value, 0),
    )


def build_match_context(
    home_analysis: dict[str, Any],
    away_analysis: dict[str, Any],
    home_elo: float | None = None,
    away_elo: float | None = None,
) -> dict[str, Any]:
    home = (home_analysis.get("model_profiles") or {}).get("relevant") or {}
    away = (away_analysis.get("model_profiles") or {}).get("relevant") or {}
    home_avg = home.get("averages") or {}
    away_avg = away.get("averages") or {}
    home_conf = home.get("confidence_by_market") or {}
    away_conf = away.get("confidence_by_market") or {}
    home_market_context = home.get("market_context") or {}
    away_market_context = away.get("market_context") or {}

    elo_delta = 0.0
    if home_elo is not None and away_elo is not None:
        elo_delta = max(-160.0, min(160.0, float(home_elo) - float(away_elo)))
    home_elo_factor = 10.0 ** (elo_delta / 1600.0)
    away_elo_factor = 1.0 / home_elo_factor

    mapping = {
        "goals": ("goals_for", "goals_against"),
        "xg": ("xg_for", "xg_against"),
        "corners": ("corners_for", "corners_against"),
    }
    markets: dict[str, Any] = {}
    for market, (attack, allowed) in mapping.items():
        home_value = _geo(home_avg.get(attack), away_avg.get(allowed))
        away_value = _geo(away_avg.get(attack), home_avg.get(allowed))
        if home_value is not None:
            home_value *= home_elo_factor
        if away_value is not None:
            away_value *= away_elo_factor
        confidence = _lower_confidence(
            str(home_conf.get(market) or "LOW"),
            str(away_conf.get(market) or "LOW"),
        )
        markets[market] = {
            "home": None if home_value is None else round(home_value, 4),
            "away": None if away_value is None else round(away_value, 4),
            "total": (
                None
                if home_value is None or away_value is None
                else round(home_value + away_value, 4)
            ),
            "confidence": confidence,
            "source": "separate_uefa_domestic_profiles_elo",
            "method_version": "bot10_1_evidence_v2",
            "home_context": home_market_context.get(market),
            "away_context": away_market_context.get(market),
        }

    for market, field in (("cards", "yellow_cards"), ("shots", "shots")):
        home_value = number(home_avg.get(field))
        away_value = number(away_avg.get(field))
        if home_value is not None:
            home_value *= home_elo_factor ** 0.25
        if away_value is not None:
            away_value *= away_elo_factor ** 0.25
        markets[market] = {
            "home": None if home_value is None else round(home_value, 4),
            "away": None if away_value is None else round(away_value, 4),
            "total": (
                None
                if home_value is None or away_value is None
                else round(home_value + away_value, 4)
            ),
            "confidence": _lower_confidence(
                str(home_conf.get(market) or "LOW"),
                str(away_conf.get(market) or "LOW"),
            ),
            "source": "separate_uefa_domestic_profiles_elo",
            "method_version": "bot10_1_evidence_v2",
            "home_context": home_market_context.get(market),
            "away_context": away_market_context.get(market),
        }

    target_home = number(home_avg.get("shots_on_target"))
    target_away = number(away_avg.get("shots_on_target"))
    markets["shots_on_target"] = {
        "home": target_home,
        "away": target_away,
        "total": (
            target_home + target_away
            if target_home is not None and target_away is not None
            else None
        ),
        "confidence": markets["shots"]["confidence"],
        "source": markets["shots"]["source"],
        "method_version": "bot10_1_evidence_v2",
    }
    return {
        "enabled": True,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "policy": (
            "UEFA and domestic profiles remain separate; domestic values are "
            "league-normalized before the continuous evidence blend"
        ),
        "weights_are_dynamic": True,
        "fixed_percentage_blend": False,
        "elo": {"home": home_elo, "away": away_elo, "delta": elo_delta},
        "markets": markets,
    }


def poisson_distribution(mean: float, maximum: int) -> list[dict[str, Any]]:
    probability = math.exp(-mean)
    values = [{"count": 0, "probability": round(probability, 8)}]
    for count in range(1, maximum + 1):
        probability *= mean / count
        values.append({"count": count, "probability": round(probability, 8)})
    return values


def thresholds(mean: float, lines: tuple[float, ...]) -> list[dict[str, Any]]:
    distribution = poisson_distribution(mean, max(40, int(max(lines)) + 15))
    return [
        {
            "line": line,
            "minimum_count": int(math.floor(line)) + 1,
            "probability": round(
                sum(
                    row["probability"]
                    for row in distribution
                    if row["count"] >= int(math.floor(line)) + 1
                ),
                8,
            ),
        }
        for line in lines
    ]


def build_component_document(
    market: str,
    ratings: dict[str, Any],
    competition: dict[str, Any],
) -> dict[str, Any] | None:
    context = ratings.get("bot10_context")
    if not isinstance(context, dict) or not context.get("enabled"):
        return None
    projection = (context.get("markets") or {}).get(market)
    if not isinstance(projection, dict):
        return None
    home = number(projection.get("home"))
    away = number(projection.get("away"))
    if home is None or away is None:
        return None
    match = ratings.get("upcoming_match") or {}
    common = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "competition": competition,
        "upcoming_match": match,
        "context_model": context,
        "source": projection.get("source"),
        "confidence": projection.get("confidence"),
        "method_version": projection.get("method_version"),
    }
    if market == "corners":
        total = home + away
        common["analysis"] = {
            "selected_family": "poisson_context_fallback",
            "home_team": {
                "team": {"name": match.get("home_team")},
                "expected_corners": round(home, 6),
                "confidence": projection.get("confidence"),
            },
            "away_team": {
                "team": {"name": match.get("away_team")},
                "expected_corners": round(away, 6),
                "confidence": projection.get("confidence"),
            },
            "expected_total_corners": round(total, 6),
            "minimum_total_thresholds": thresholds(
                total, (5.5, 6.5, 7.5, 8.5, 9.5, 10.5, 11.5)
            ),
            "lambda_method": "BOT 10: UEFA + domestic separated evidence blend",
        }
    elif market == "cards":
        total = home + away
        common["analysis"] = {
            "selected_family": "poisson_context_fallback",
            "home_team": {
                "team": {"name": match.get("home_team")},
                "expected_yellow_cards": round(home, 6),
                "confidence": projection.get("confidence"),
            },
            "away_team": {
                "team": {"name": match.get("away_team")},
                "expected_yellow_cards": round(away, 6),
                "confidence": projection.get("confidence"),
            },
            "expected_total_yellow_cards": round(total, 6),
            "yellow_thresholds": thresholds(total, (0.5, 1.5, 2.5, 3.5, 4.5, 5.5)),
            "red_cards_analysis": {"available": False},
            "yellow_lambda_method": "BOT 10: UEFA + domestic separated evidence blend",
        }
    elif market == "shots":
        total = home + away
        target = (context.get("markets") or {}).get("shots_on_target") or {}
        target_home = number(target.get("home"))
        target_away = number(target.get("away"))
        common["analysis"] = {
            "shots": {
                "selected_family": "poisson_context_fallback",
                "home_team": {
                    "name": match.get("home_team"),
                    "expected_count": round(home, 6),
                    "thresholds": thresholds(home, (5.5, 7.5, 9.5, 11.5, 13.5, 15.5)),
                },
                "away_team": {
                    "name": match.get("away_team"),
                    "expected_count": round(away, 6),
                    "thresholds": thresholds(away, (5.5, 7.5, 9.5, 11.5, 13.5, 15.5)),
                },
                "expected_total": round(total, 6),
                "confidence": projection.get("confidence"),
            },
            "shots_on_target": {
                "home_team": {"name": match.get("home_team"), "expected_count": target_home},
                "away_team": {"name": match.get("away_team"), "expected_count": target_away},
                "expected_total": (
                    target_home + target_away
                    if target_home is not None and target_away is not None
                    else None
                ),
            },
        }
    else:
        return None
    return common
