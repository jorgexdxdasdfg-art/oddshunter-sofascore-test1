from __future__ import annotations

CLOUD_SOURCE_POLICY_VERSION = "1.0"

SOFASCORE_ENABLED = False

STATUS_SCORE_ORDER = ("futbol24",)
TEAM_METRIC_ORDER = ("futbol24", "flashscore")
XG_ORDER = ("futbol24", "flashscore")

# Ausencias reales se conservan como None/N/D. Nunca se convierten a cero.
NULL_IS_ZERO = False
