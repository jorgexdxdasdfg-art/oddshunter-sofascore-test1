#!/usr/bin/env bash
set -euo pipefail

BUNDLE_ROOT=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --bundle-root)
      BUNDLE_ROOT="${2:-}"
      shift 2
      ;;
    *)
      echo "Argumento desconocido: $1" >&2
      exit 2
      ;;
  esac
done

if [[ -z "$BUNDLE_ROOT" ]]; then
  echo "Falta --bundle-root" >&2
  exit 2
fi
BUNDLE_ROOT="$(cd "$BUNDLE_ROOT" && pwd)"

if [[ "$(id -u)" -ne 0 ]]; then
  echo "STAGE8_INSTALL_REQUIRES_ROOT=YES" >&2
  exit 1
fi

V4_ZIP="$BUNDLE_ROOT/ODDSHUNTER_CLOUD_LINUX_STAGE4_STAGE5_V4.zip"
S6_ZIP="$BUNDLE_ROOT/ODDSHUNTER_CLOUD_STAGE6_PUBLISHER_V1_2.zip"
S7_STATE="$BUNDLE_ROOT/ODDSHUNTER_CLOUD_WORKING_STATE_STAGE7.zip"
ENV_IN="$BUNDLE_ROOT/oddshunter.env"
PW_BUNDLE="$BUNDLE_ROOT/PLAYWRIGHT_BROWSERS_STAGE8.tar.gz"
PW_VERSION_FILE="$BUNDLE_ROOT/PLAYWRIGHT_VERSION_STAGE8.txt"
PW_SHA_FILE="$BUNDLE_ROOT/PLAYWRIGHT_BROWSERS_STAGE8.sha256"
PKG_DIR="$(cd "$(dirname "$0")" && pwd)"

EXPECTED_V4="A230D5947A2B02A74505DB72D4E01BE303B990B3DFDD2339BB80F69B70F56C95"
EXPECTED_S6="9F60DDF611EC85D052C0F7AEB46B7F9C7E18134630141A35B8F2BE900DD2933C"
EXPECTED_S7="64546C16BA9676CE0243D2560EEE3193272451D6246D7712BD58CAF886C8CA26"
EXPECTED_S7_DB="809E93FBF664F8CD86B6C21D9D0AC0E47BBE134BBBD0CE1A2FB6AF8981E1171F"
EXPECTED_PLAYWRIGHT_VERSION="1.62.0"

for f in "$V4_ZIP" "$S6_ZIP" "$S7_STATE" "$ENV_IN" "$PW_BUNDLE" "$PW_VERSION_FILE" "$PW_SHA_FILE"; do
  test -f "$f" || { echo "Falta archivo requerido: $f" >&2; exit 1; }
done

sha_upper() { sha256sum "$1" | awk '{print toupper($1)}'; }

[[ "$(sha_upper "$V4_ZIP")" == "$EXPECTED_V4" ]] || { echo "V4_SHA_MISMATCH" >&2; exit 1; }
[[ "$(sha_upper "$S6_ZIP")" == "$EXPECTED_S6" ]] || { echo "STAGE6_SHA_MISMATCH" >&2; exit 1; }
[[ "$(sha_upper "$S7_STATE")" == "$EXPECTED_S7" ]] || { echo "STAGE7_STATE_SHA_MISMATCH" >&2; exit 1; }

PW_VERSION="$(tr -d '\r\n[:space:]' < "$PW_VERSION_FILE")"
[[ "$PW_VERSION" == "$EXPECTED_PLAYWRIGHT_VERSION" ]] || {
  echo "PLAYWRIGHT_VERSION_MISMATCH expected=$EXPECTED_PLAYWRIGHT_VERSION actual=$PW_VERSION" >&2
  exit 1
}
PW_EXPECTED_SHA="$(awk 'NR==1 {print toupper($1)}' "$PW_SHA_FILE")"
[[ "$PW_EXPECTED_SHA" =~ ^[0-9A-F]{64}$ ]] || {
  echo "PLAYWRIGHT_BUNDLE_SHA_FILE_INVALID" >&2
  exit 1
}
[[ "$(sha_upper "$PW_BUNDLE")" == "$PW_EXPECTED_SHA" ]] || {
  echo "PLAYWRIGHT_BUNDLE_SHA_MISMATCH" >&2
  exit 1
}
echo "STAGE8_PLAYWRIGHT_BUNDLE_HASH_GATE=PASS"
echo "STAGE8_SOURCE_HASH_GATE=PASS"

source /etc/os-release
[[ "${ID:-}" == "ubuntu" ]] || { echo "STAGE8_OS_NOT_UBUNTU=${ID:-unknown}" >&2; exit 1; }
[[ "${VERSION_ID:-}" == "24.04" ]] || { echo "STAGE8_UBUNTU_VERSION_REQUIRED=24.04 ACTUAL=${VERSION_ID:-unknown}" >&2; exit 1; }
[[ "$(uname -m)" == "x86_64" ]] || { echo "STAGE8_ARCH_REQUIRED=x86_64 ACTUAL=$(uname -m)" >&2; exit 1; }

CPU="$(nproc)"
MEM_KB="$(awk '/MemTotal/ {print $2}' /proc/meminfo)"
DISK_KB="$(df -Pk /opt 2>/dev/null | awk 'NR==2 {print $4}' || true)"
if [[ -z "$DISK_KB" ]]; then
  DISK_KB="$(df -Pk / | awk 'NR==2 {print $4}')"
fi
[[ "$CPU" -ge 2 ]] || { echo "STAGE8_CPU_MIN=2 ACTUAL=$CPU" >&2; exit 1; }
[[ "$MEM_KB" -ge 3500000 ]] || { echo "STAGE8_RAM_MIN_KB=3500000 ACTUAL=$MEM_KB" >&2; exit 1; }
[[ "$DISK_KB" -ge 12000000 ]] || { echo "STAGE8_FREE_DISK_MIN_KB=12000000 ACTUAL=$DISK_KB" >&2; exit 1; }
echo "STAGE8_VPS_CAPACITY_GATE=PASS"

export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y --no-install-recommends \
  ca-certificates curl unzip sqlite3 python3 python3-venv python3-pip

if ! id oddshunter >/dev/null 2>&1; then
  useradd --system --home-dir /var/lib/oddshunter --create-home --shell /usr/sbin/nologin oddshunter
fi

install -d -m 0755 /opt/oddshunter /opt/oddshunter/releases
install -d -o oddshunter -g oddshunter -m 0750 /var/lib/oddshunter
install -d -o oddshunter -g oddshunter -m 0750 /var/lib/oddshunter/artifacts
install -d -o oddshunter -g oddshunter -m 0750 /var/log/oddshunter
install -d -m 0700 /etc/oddshunter

# Validate secrets without printing them.
set -a
# shellcheck disable=SC1090
source "$ENV_IN"
set +a
[[ -n "${TURSO_DATABASE_URL:-}" ]] || { echo "TURSO_DATABASE_URL_EMPTY" >&2; exit 1; }
[[ -n "${TURSO_AUTH_TOKEN:-}" ]] || { echo "TURSO_AUTH_TOKEN_EMPTY" >&2; exit 1; }
install -m 0600 -o root -g root "$ENV_IN" /etc/oddshunter/oddshunter.env
echo "STAGE8_SECRET_FILE_GATE=PASS"

TMP_STATE="$(mktemp -d)"
trap 'rm -rf "$TMP_STATE"' EXIT
unzip -q "$S7_STATE" -d "$TMP_STATE"

test -f "$TMP_STATE/data/oddshunter.db"
test -f "$TMP_STATE/CLOUD_WORKING_STATE_MANIFEST.json"

python3 - "$TMP_STATE" "$EXPECTED_S7_DB" <<'PY'
import hashlib, json, sqlite3, sys
from pathlib import Path
root = Path(sys.argv[1])
expected = sys.argv[2]
db = root / "data" / "oddshunter.db"
h = hashlib.sha256(db.read_bytes()).hexdigest().upper()
if h != expected:
    raise RuntimeError(f"Stage7 DB SHA inesperado: {h}")
m = json.loads((root / "CLOUD_WORKING_STATE_MANIFEST.json").read_text(encoding="utf-8-sig"))
if m.get("source_stage") != "Stage7":
    raise RuntimeError("Working state no proviene de Stage7")
if m.get("stage7_pass") is not True:
    raise RuntimeError("Working state Stage7 no está PASS")
if str(m.get("working_copy_sha") or "").upper() != h:
    raise RuntimeError("Manifest working_copy_sha != DB SHA")
uri = f"file:{db.as_posix()}?mode=ro"
con = sqlite3.connect(uri, uri=True)
try:
    qc = con.execute("PRAGMA quick_check;").fetchone()[0]
    fk = con.execute("PRAGMA foreign_key_check;").fetchall()
finally:
    con.close()
if qc != "ok" or fk:
    raise RuntimeError(f"Stage7 SQLite no sano: quick={qc}, fk={len(fk)}")
print("STAGE8_STAGE7_STATE_CONTENT_GATE=PASS")
PY

if [[ ! -f /var/lib/oddshunter/data/oddshunter.db ]]; then
  cp -a "$TMP_STATE/data" /var/lib/oddshunter/data
  cp -a "$TMP_STATE/CLOUD_WORKING_STATE_MANIFEST.json" \
    /var/lib/oddshunter/CLOUD_WORKING_STATE_MANIFEST_STAGE7.json
  chown -R oddshunter:oddshunter /var/lib/oddshunter/data
  chown oddshunter:oddshunter /var/lib/oddshunter/CLOUD_WORKING_STATE_MANIFEST_STAGE7.json
  INSTALL_MODE="INITIALIZED_FROM_STAGE7"
else
  python3 - <<'PY'
import sqlite3
from pathlib import Path
db = Path("/var/lib/oddshunter/data/oddshunter.db")
uri = f"file:{db.as_posix()}?mode=ro"
con = sqlite3.connect(uri, uri=True)
try:
    qc = con.execute("PRAGMA quick_check;").fetchone()[0]
    fk = con.execute("PRAGMA foreign_key_check;").fetchall()
finally:
    con.close()
if qc != "ok" or fk:
    raise RuntimeError(f"Persistent SQLite no sano: quick={qc}, fk={len(fk)}")
print("STAGE8_EXISTING_STATE_HEALTH_GATE=PASS")
PY
  INSTALL_MODE="UPDATE_PRESERVE_EXISTING_STATE"
fi
echo "STAGE8_INSTALL_MODE=$INSTALL_MODE"

# Import the exact Playwright-managed Chromium exported by GitHub Actions.
# The OVH VPS cannot download this browser directly from cdn.playwright.dev
# (HTTP 403 "service is not available in your location").
rm -rf /opt/oddshunter/ms-playwright
tar -xzf "$PW_BUNDLE" -C /opt/oddshunter
test -d /opt/oddshunter/ms-playwright
find /opt/oddshunter/ms-playwright -maxdepth 3 -type f -name 'chrome' -o -name 'headless_shell' | head -n 1 | grep -q .
chmod -R a+rX /opt/oddshunter/ms-playwright
echo "STAGE8_PLAYWRIGHT_BROWSER_IMPORT=PASS"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
RELEASE="/opt/oddshunter/releases/$STAMP"
mkdir -p "$RELEASE"

unzip -q "$V4_ZIP" -d "$RELEASE"
unzip -q -o "$S6_ZIP" -d "$RELEASE"
cp -a "$PKG_DIR/stage8_daemon.py" "$RELEASE/"
cp -a "$PKG_DIR/stage8_health.py" "$RELEASE/"
cp -a "$PKG_DIR/STAGE8_MANIFEST.json" "$RELEASE/"
cp -a "$PKG_DIR/README_CLOUD_STAGE8.md" "$RELEASE/"

rm -rf "$RELEASE/data" "$RELEASE/artifacts"
ln -s /var/lib/oddshunter/data "$RELEASE/data"
ln -s /var/lib/oddshunter/artifacts "$RELEASE/artifacts"

chmod +x "$RELEASE/install_cloud_linux.sh" "$RELEASE/run_cloud_preflight.sh"

# Pin exactly the Playwright version that produced the exported browser bundle.
python3 - "$RELEASE/requirements-cloud.txt" "$EXPECTED_PLAYWRIGHT_VERSION" <<'PY'
import re
import sys
from pathlib import Path

path = Path(sys.argv[1])
version = sys.argv[2]
text = path.read_text(encoding="utf-8")
lines = text.splitlines()
out = []
replaced = 0
for line in lines:
    if re.match(r"^\s*playwright\b", line, flags=re.I):
        out.append(f"playwright=={version}")
        replaced += 1
    else:
        out.append(line)
if replaced != 1:
    raise RuntimeError(f"Expected exactly one playwright requirement, got {replaced}")
path.write_text("\n".join(out) + "\n", encoding="utf-8")
print("STAGE8_PLAYWRIGHT_REQUIREMENT_PIN=PASS")
PY

# V4 originally downloads Chromium from Playwright CDN. On this VPS that CDN
# returns a location 403, so install only OS dependencies; browser bytes are
# already present in /opt/oddshunter/ms-playwright.
python3 - "$RELEASE/install_cloud_linux.sh" <<'PY'
import sys
from pathlib import Path

path = Path(sys.argv[1])
text = path.read_text(encoding="utf-8")
old = "python -m playwright install --with-deps chromium"
new = "python -m playwright install-deps chromium"
if text.count(old) != 1:
    raise RuntimeError("Unexpected install_cloud_linux.sh browser install line")
path.write_text(text.replace(old, new, 1), encoding="utf-8")
print("STAGE8_PLAYWRIGHT_DOWNLOAD_BYPASS_PATCH=PASS")
PY

export PLAYWRIGHT_BROWSERS_PATH=/opt/oddshunter/ms-playwright
(
  cd "$RELEASE"
  ./install_cloud_linux.sh
)

ACTUAL_PLAYWRIGHT_VERSION="$("$RELEASE/.venv-cloud/bin/python" - <<'PY'
from importlib.metadata import version
print(version("playwright"))
PY
)"
[[ "$ACTUAL_PLAYWRIGHT_VERSION" == "$EXPECTED_PLAYWRIGHT_VERSION" ]] || {
  echo "PLAYWRIGHT_RUNTIME_VERSION_MISMATCH expected=$EXPECTED_PLAYWRIGHT_VERSION actual=$ACTUAL_PLAYWRIGHT_VERSION" >&2
  exit 1
}
echo "STAGE8_PLAYWRIGHT_VERSION_GATE=PASS"

python3 -m py_compile "$RELEASE/stage8_daemon.py" "$RELEASE/stage8_health.py" "$RELEASE/cloud_stage6_publish.py"
"$RELEASE/.venv-cloud/bin/python" "$RELEASE/stage8_daemon.py" --self-test
"$RELEASE/.venv-cloud/bin/python" "$RELEASE/stage8_health.py" --self-test

chmod -R a+rX "$RELEASE" /opt/oddshunter/ms-playwright

# Smoke test the exact browser as the service user before systemd can start.
runuser -u oddshunter -- env   HOME=/var/lib/oddshunter   PLAYWRIGHT_BROWSERS_PATH=/opt/oddshunter/ms-playwright   ODDSHUNTER_BROWSER_HEADLESS=1   ODDSHUNTER_CHROMIUM_SANDBOX=0   "$RELEASE/.venv-cloud/bin/python" - <<'PY'
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(
        headless=True,
        chromium_sandbox=False,
        args=["--no-sandbox"],
    )
    try:
        page = browser.new_page()
        page.goto("data:text/html,<title>OddsHunter Stage8</title><p>PASS</p>")
        assert page.title() == "OddsHunter Stage8"
    finally:
        browser.close()

print("STAGE8_PLAYWRIGHT_BROWSER_GATE=PASS")
PY
chown -R oddshunter:oddshunter /var/lib/oddshunter /var/log/oddshunter

# Atomic release switch.
ln -sfn "$RELEASE" /opt/oddshunter/current.new
mv -Tf /opt/oddshunter/current.new /opt/oddshunter/current

install -m 0644 "$PKG_DIR/oddshunter.service" /etc/systemd/system/oddshunter.service

cat >/usr/local/bin/oddshunter-stage8-health <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
set -a
# shellcheck disable=SC1091
source /etc/oddshunter/oddshunter.env
set +a
exec /opt/oddshunter/current/.venv-cloud/bin/python \
  /opt/oddshunter/current/stage8_health.py "$@"
EOF
chmod 0755 /usr/local/bin/oddshunter-stage8-health

cat >/usr/local/bin/oddshunter-stage8-status <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
echo "=== SERVICE ==="
systemctl --no-pager --full status oddshunter.service || true
echo
echo "=== HEALTH ==="
exec /usr/local/bin/oddshunter-stage8-health
EOF
chmod 0755 /usr/local/bin/oddshunter-stage8-status

systemctl daemon-reload
systemctl enable oddshunter.service
systemctl restart oddshunter.service

sleep 2
systemctl is-enabled oddshunter.service
systemctl is-active oddshunter.service
[[ "$(systemctl show oddshunter.service -p Restart --value)" == "always" ]]

echo "STAGE8_SYSTEMD_GATE=PASS"
echo "STAGE8_RELEASE=$RELEASE"
echo "STAGE8_INSTALL=PASS"

# Keep only three code releases. Persistent data is not inside releases.
mapfile -t OLD_RELEASES < <(find /opt/oddshunter/releases -mindepth 1 -maxdepth 1 -type d -printf '%T@ %p\n' | sort -nr | tail -n +4 | cut -d' ' -f2-)
for old in "${OLD_RELEASES[@]:-}"; do
  [[ -n "$old" ]] && rm -rf -- "$old"
done
