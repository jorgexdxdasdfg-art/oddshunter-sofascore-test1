from __future__ import annotations

import argparse
import fcntl
import json
import os
import signal
import sqlite3
import subprocess
import sys
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
DB = DATA / "oddshunter.db"
ARTIFACTS = ROOT / "artifacts"
STATE_ROOT = Path(os.environ.get("ODDSHUNTER_STATE_ROOT", "/var/lib/oddshunter"))
STATUS_FILE = STATE_ROOT / "runtime_status.json"
LOCK_FILE = STATE_ROOT / "runtime.lock"

STOP = False


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def read_json(path: Path) -> dict[str, Any]:
    obj = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(obj, dict):
        raise RuntimeError(f"JSON raíz no es objeto: {path}")
    return obj


def sqlite_health() -> dict[str, Any]:
    uri = f"file:{DB.as_posix()}?mode=ro"
    con = sqlite3.connect(uri, uri=True)
    try:
        quick = con.execute("PRAGMA quick_check;").fetchone()
        fk = con.execute("PRAGMA foreign_key_check;").fetchall()
        return {
            "quick_check": str(quick[0]) if quick else None,
            "foreign_key_errors": len(fk),
            "matches": int(con.execute("SELECT COUNT(*) FROM matches;").fetchone()[0]),
            "team_match_stats": int(con.execute("SELECT COUNT(*) FROM team_match_stats;").fetchone()[0]),
        }
    finally:
        con.close()


def run_streamed(label: str, cmd: list[str], env: dict[str, str], timeout_seconds: int) -> dict[str, Any]:
    print(f"[{utc_now()}] START {label}: {' '.join(cmd)}", flush=True)
    proc = subprocess.Popen(
        cmd,
        cwd=ROOT,
        env=env,
        text=True,
        encoding="utf-8",
        errors="replace",
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        bufsize=1,
    )
    tail: list[str] = []
    started = time.monotonic()
    assert proc.stdout is not None

    try:
        while True:
            line = proc.stdout.readline()
            if line:
                text = line.rstrip("\n")
                print(f"{label}> {text}", flush=True)
                tail.append(text)
                if len(tail) > 500:
                    tail = tail[-500:]

            rc = proc.poll()
            if rc is not None:
                # Drain remaining buffered output.
                for rest in proc.stdout:
                    text = rest.rstrip("\n")
                    print(f"{label}> {text}", flush=True)
                    tail.append(text)
                    if len(tail) > 500:
                        tail = tail[-500:]
                break

            if STOP:
                proc.terminate()

            if time.monotonic() - started > timeout_seconds:
                proc.terminate()
                try:
                    proc.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    proc.kill()
                raise RuntimeError(f"{label} excedió timeout={timeout_seconds}s")

            time.sleep(0.05)
    finally:
        if proc.poll() is None:
            proc.terminate()

    elapsed = round(time.monotonic() - started, 3)
    print(f"[{utc_now()}] END {label}: rc={proc.returncode} elapsed={elapsed}s", flush=True)
    return {"returncode": int(proc.returncode or 0), "elapsed_seconds": elapsed, "tail": tail[-120:]}


def http_json(url: str, timeout: float = 25.0) -> dict[str, Any]:
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "OddsHunter-Stage8-Runtime/1.0",
            "Accept": "application/json",
            "Cache-Control": "no-cache",
        },
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        if int(getattr(resp, "status", 200)) != 200:
            raise RuntimeError(f"HTTP {getattr(resp, 'status', '?')}: {url}")
        obj = json.loads(resp.read().decode("utf-8"))
    if not isinstance(obj, dict):
        raise RuntimeError("Respuesta HTTP JSON raíz no es objeto")
    return obj


def stage5_ok(report: dict[str, Any]) -> bool:
    counts = report.get("sync_result_counts") or {}
    criteria = report.get("criteria") or {}
    return (
        report.get("stage5_pass") is True
        and bool(criteria)
        and all(v is True for v in criteria.values())
        and int(counts.get("committed") or 0) >= 1
        and int(counts.get("technical_errors") or 0) == 0
        and int(counts.get("source_unavailable") or 0) == 0
    )


def stage6_ok(report: dict[str, Any]) -> bool:
    criteria = report.get("criteria") or {}
    remote = report.get("remote_after") or {}
    return (
        report.get("stage6_pass") is True
        and bool(criteria)
        and all(v is True for v in criteria.values())
        and remote.get("health") is True
        and report.get("training_invoked") is False
        and report.get("official_pc_db_touched") is False
    )


def run_cycle(cycle_number: int) -> dict[str, Any]:
    if not DB.is_file():
        raise FileNotFoundError(f"Falta working SQLite: {DB}")

    required_env = ["TURSO_DATABASE_URL", "TURSO_AUTH_TOKEN"]
    missing = [k for k in required_env if not os.environ.get(k)]
    if missing:
        raise RuntimeError(f"Faltan variables obligatorias: {missing}")

    env = os.environ.copy()
    env.update({
        "PYTHONUTF8": "1",
        "PYTHONIOENCODING": "utf-8",
        "ODDSHUNTER_RUNTIME_MODE": "cloud",
        "ODDSHUNTER_ALLOW_WORK_DB_WRITE": "1",
        "ODDSHUNTER_DISABLE_TRAINING": "1",
        "ODDSHUNTER_BROWSER_HEADLESS": "1",
        "ODDSHUNTER_CHROMIUM_SANDBOX": "0",
        "ODDSHUNTER_FLASHSCORE_MAX_MATCHES_PER_CYCLE":
            os.environ.get("ODDSHUNTER_FLASHSCORE_MAX_MATCHES_PER_CYCLE", "4"),
    })

    before = sqlite_health()
    if before["quick_check"] != "ok" or before["foreign_key_errors"] != 0:
        raise RuntimeError(f"SQLite pre-cycle no sano: {before}")

    py = sys.executable
    s5 = run_streamed(
        "STAGE5",
        [py, "-u", str(ROOT / "cloud_stage5_cycle.py")],
        env,
        int(os.environ.get("ODDSHUNTER_STAGE5_TIMEOUT_SECONDS", "2700")),
    )
    if s5["returncode"] != 0:
        raise RuntimeError(f"Stage5 rc={s5['returncode']}")

    stage5_path = ARTIFACTS / "cloud_stage5_cycle.json"
    if not stage5_path.is_file():
        raise RuntimeError("Stage5 terminó sin cloud_stage5_cycle.json")
    stage5 = read_json(stage5_path)
    if not stage5_ok(stage5):
        raise RuntimeError(f"Stage5 report no PASS: {stage5.get('criteria')}")

    env["ODDSHUNTER_STAGE6_ALLOW_TURSO_WRITE"] = "1"
    s6 = run_streamed(
        "STAGE6",
        [py, "-u", str(ROOT / "cloud_stage6_publish.py")],
        env,
        int(os.environ.get("ODDSHUNTER_STAGE6_TIMEOUT_SECONDS", "1800")),
    )
    if s6["returncode"] != 0:
        raise RuntimeError(f"Stage6 rc={s6['returncode']}")

    stage6_path = ARTIFACTS / "cloud_stage6_publisher.json"
    if not stage6_path.is_file():
        raise RuntimeError("Stage6 terminó sin cloud_stage6_publisher.json")
    stage6 = read_json(stage6_path)
    if not stage6_ok(stage6):
        raise RuntimeError(f"Stage6 report no PASS: {stage6.get('criteria')}")

    after = sqlite_health()
    if after["quick_check"] != "ok" or after["foreign_key_errors"] != 0:
        raise RuntimeError(f"SQLite post-cycle no sano: {after}")

    base = os.environ.get("ODDSHUNTER_MOBILE_BASE_URL", "https://oddshunter-mobile.vercel.app").rstrip("/")
    health = http_json(base + "/api/health")
    if not (
        health.get("ok") is True
        and health.get("source") == "turso"
        and health.get("read_only") is True
        and health.get("remote_health") is True
    ):
        raise RuntimeError(f"Vercel health no sano: {health}")

    return {
        "cycle_number": cycle_number,
        "completed_at": utc_now(),
        "stage5_pass": True,
        "stage6_pass": True,
        "stage5_sync_result_counts": stage5.get("sync_result_counts"),
        "stage6_remote_after": stage6.get("remote_after"),
        "stage6_mobile": stage6.get("mobile"),
        "sqlite_before": before,
        "sqlite_after": after,
        "vercel_health": health,
        "stage5_process": s5,
        "stage6_process": s6,
        "training_invoked": False,
        "official_pc_db_touched": False,
    }


def on_signal(signum: int, _frame: Any) -> None:
    global STOP
    STOP = True
    print(f"[{utc_now()}] SIGNAL={signum}; shutdown solicitado", flush=True)


def self_test() -> int:
    fake5 = {
        "stage5_pass": True,
        "criteria": {"a": True},
        "sync_result_counts": {"committed": 1, "technical_errors": 0, "source_unavailable": 0},
    }
    fake6 = {
        "stage6_pass": True,
        "criteria": {"a": True},
        "remote_after": {"health": True},
        "training_invoked": False,
        "official_pc_db_touched": False,
    }
    if not stage5_ok(fake5):
        raise RuntimeError("stage5_ok self-test")
    if not stage6_ok(fake6):
        raise RuntimeError("stage6_ok self-test")
    print("STAGE8_DAEMON_SELF_TEST=PASS")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--once", action="store_true", help="Ejecuta un ciclo y termina")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()

    if args.self_test:
        return self_test()

    STATE_ROOT.mkdir(parents=True, exist_ok=True)
    ARTIFACTS.mkdir(parents=True, exist_ok=True)

    signal.signal(signal.SIGTERM, on_signal)
    signal.signal(signal.SIGINT, on_signal)

    lock_handle = LOCK_FILE.open("a+")
    try:
        fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError as exc:
        raise RuntimeError("Ya existe otro runtime OddsHunter Stage8 activo") from exc

    interval = max(60, int(os.environ.get("ODDSHUNTER_CYCLE_INTERVAL_SECONDS", "900")))
    failure_retry = max(60, int(os.environ.get("ODDSHUNTER_FAILURE_RETRY_SECONDS", "120")))
    cycle_number = 0

    print("=" * 78, flush=True)
    print("ODDSHUNTER STAGE8 VPS RUNTIME 24/7", flush=True)
    print(f"ROOT={ROOT}", flush=True)
    print(f"DB={DB}", flush=True)
    print(f"CYCLE_INTERVAL_SECONDS={interval}", flush=True)
    print("TRAINING=DISABLED", flush=True)
    print("=" * 78, flush=True)

    while not STOP:
        cycle_number += 1
        started = utc_now()
        base_status = {
            "runtime": "OddsHunter Stage8",
            "pid": os.getpid(),
            "cycle_number": cycle_number,
            "last_cycle_started_at": started,
            "last_cycle_ok": False,
            "training_invoked": False,
            "official_pc_db_touched": False,
        }
        atomic_json(STATUS_FILE, base_status)

        try:
            result = run_cycle(cycle_number)
            status = {**base_status, **result, "last_cycle_ok": True, "last_error": None}
            atomic_json(STATUS_FILE, status)
            print(f"[{utc_now()}] CYCLE={cycle_number} PASS", flush=True)
            if args.once:
                return 0
            sleep_for = interval
        except Exception as exc:
            status = {
                **base_status,
                "completed_at": utc_now(),
                "last_cycle_ok": False,
                "last_error": f"{type(exc).__name__}: {exc}",
            }
            atomic_json(STATUS_FILE, status)
            print(f"[{utc_now()}] CYCLE={cycle_number} FAIL: {status['last_error']}", flush=True)
            if args.once:
                return 1
            sleep_for = failure_retry

        deadline = time.monotonic() + sleep_for
        while not STOP and time.monotonic() < deadline:
            time.sleep(min(1.0, max(0.0, deadline - time.monotonic())))

    print(f"[{utc_now()}] STAGE8_DAEMON_STOP=GRACEFUL", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
