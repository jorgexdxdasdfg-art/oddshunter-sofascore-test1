from __future__ import annotations

import argparse
import json
import os
import sqlite3
import subprocess
import sys
import time
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path("/opt/oddshunter/current")
STATE_ROOT = Path(os.environ.get("ODDSHUNTER_STATE_ROOT", "/var/lib/oddshunter"))
STATUS_FILE = STATE_ROOT / "runtime_status.json"
DB = ROOT / "data" / "oddshunter.db"
STAGE5_REPORT = ROOT / "artifacts" / "cloud_stage5_cycle.json"
STAGE6_REPORT = ROOT / "artifacts" / "cloud_stage6_publisher.json"
BASE_URL = os.environ.get("ODDSHUNTER_MOBILE_BASE_URL", "https://oddshunter-mobile.vercel.app").rstrip("/")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def read_json(path: Path) -> dict[str, Any]:
    obj = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(obj, dict):
        raise RuntimeError(f"JSON raíz no es objeto: {path}")
    return obj


def http_json(url: str, timeout: float = 25.0) -> dict[str, Any]:
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "OddsHunter-Stage8-Health/1.0",
            "Accept": "application/json",
            "Cache-Control": "no-cache",
        },
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        if int(getattr(resp, "status", 200)) != 200:
            raise RuntimeError(f"HTTP {getattr(resp, 'status', '?')}: {url}")
        obj = json.loads(resp.read().decode("utf-8"))
    if not isinstance(obj, dict):
        raise RuntimeError("HTTP JSON raíz no es objeto")
    return obj


def cmd_text(cmd: list[str]) -> tuple[int, str]:
    p = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    return int(p.returncode), p.stdout.strip()


def sqlite_health() -> dict[str, Any]:
    uri = f"file:{DB.as_posix()}?mode=ro"
    con = sqlite3.connect(uri, uri=True)
    try:
        quick = con.execute("PRAGMA quick_check;").fetchone()
        fk = con.execute("PRAGMA foreign_key_check;").fetchall()
        return {
            "quick_check": str(quick[0]) if quick else None,
            "foreign_key_errors": len(fk),
            "matches": int(con.execute("SELECT COUNT(*) FROM matches;").fetchone()[0]),
            "team_match_stats": int(con.execute("SELECT COUNT(*) FROM team_match_stats;").fetchone()[0]),
        }
    finally:
        con.close()


def age_seconds(iso_text: Any) -> float | None:
    try:
        d = datetime.fromisoformat(str(iso_text).replace("Z", "+00:00"))
        if d.tzinfo is None:
            d = d.replace(tzinfo=timezone.utc)
        return max(0.0, (datetime.now(timezone.utc) - d.astimezone(timezone.utc)).total_seconds())
    except Exception:
        return None


def target_probes(stage6: dict[str, Any]) -> list[dict[str, Any]]:
    mobile = stage6.get("mobile") or {}
    targets = [x for x in (mobile.get("targets") or []) if isinstance(x, str) and "/" in x]
    probes: list[dict[str, Any]] = []
    for target in targets:
        key, event_id_raw = target.rsplit("/", 1)
        event_id = int(event_id_raw)
        url = f"{BASE_URL}/api/match/{urllib.parse.quote(key, safe='')}/{event_id}"
        payload = http_json(url)
        event = payload.get("event") if isinstance(payload, dict) else None
        served = (
            isinstance(event, dict)
            and str(event.get("competition_key") or "") == key
            and int(event.get("event_id") or 0) == event_id
        )
        probes.append({
            "target": target,
            "served": served,
            "analysis_status": payload.get("analysis_status"),
            "event_status": event.get("status") if isinstance(event, dict) else None,
        })
    return probes


def evaluate(max_status_age_seconds: int = 1800) -> dict[str, Any]:
    rc_active, active = cmd_text(["systemctl", "is-active", "oddshunter.service"])
    rc_enabled, enabled = cmd_text(["systemctl", "is-enabled", "oddshunter.service"])
    _, restart_policy = cmd_text(["systemctl", "show", "oddshunter.service", "-p", "Restart", "--value"])

    status = read_json(STATUS_FILE) if STATUS_FILE.is_file() else {}
    stage5 = read_json(STAGE5_REPORT) if STAGE5_REPORT.is_file() else {}
    stage6 = read_json(STAGE6_REPORT) if STAGE6_REPORT.is_file() else {}
    local = sqlite_health() if DB.is_file() else {}

    try:
        health = http_json(BASE_URL + "/api/health")
    except Exception as exc:
        health = {"_error": f"{type(exc).__name__}: {exc}"}

    try:
        probes = target_probes(stage6) if stage6 else []
    except Exception as exc:
        probes = [{"served": False, "error": f"{type(exc).__name__}: {exc}"}]

    completed_age = age_seconds(status.get("completed_at"))
    stage5_criteria = stage5.get("criteria") or {}
    stage6_criteria = stage6.get("criteria") or {}
    sync = stage5.get("sync_result_counts") or {}

    criteria = {
        "systemd_active": rc_active == 0 and active == "active",
        "systemd_enabled": rc_enabled == 0 and enabled in {"enabled", "enabled-runtime"},
        "systemd_restart_always": restart_policy == "always",
        "runtime_status_exists": bool(status),
        "runtime_last_cycle_ok": status.get("last_cycle_ok") is True,
        "runtime_status_fresh":
            completed_age is not None and completed_age <= max_status_age_seconds,
        "stage5_pass": stage5.get("stage5_pass") is True,
        "stage5_all_criteria_true":
            bool(stage5_criteria) and all(v is True for v in stage5_criteria.values()),
        "stage5_committed_at_least_1": int(sync.get("committed") or 0) >= 1,
        "stage5_technical_errors_zero": int(sync.get("technical_errors") or 0) == 0,
        "stage5_source_unavailable_zero": int(sync.get("source_unavailable") or 0) == 0,
        "stage6_pass": stage6.get("stage6_pass") is True,
        "stage6_all_criteria_true":
            bool(stage6_criteria) and all(v is True for v in stage6_criteria.values()),
        "turso_remote_health":
            (stage6.get("remote_after") or {}).get("health") is True,
        "sqlite_quick_check_ok": local.get("quick_check") == "ok",
        "sqlite_fk_zero": int(local.get("foreign_key_errors") or -1) == 0,
        "vercel_ok": health.get("ok") is True,
        "vercel_source_turso": health.get("source") == "turso",
        "vercel_read_only": health.get("read_only") is True,
        "vercel_remote_health": health.get("remote_health") is True,
        "published_targets_exist": len(probes) >= 1,
        "published_targets_served":
            len(probes) >= 1 and all(x.get("served") is True for x in probes),
        "training_not_invoked":
            status.get("training_invoked") is False
            and stage5.get("training_invoked") is False
            and stage6.get("training_invoked") is False,
        "official_windows_db_untouched":
            status.get("official_pc_db_touched") is False
            and stage5.get("official_pc_db_touched") is False
            and stage6.get("official_pc_db_touched") is False,
    }

    return {
        "generated_at": utc_now(),
        "stage": "Stage8",
        "purpose": "VPS 24/7 runtime certification",
        "service": {
            "active": active,
            "enabled": enabled,
            "restart_policy": restart_policy,
        },
        "runtime_status": status,
        "runtime_status_age_seconds": completed_age,
        "working_sqlite": local,
        "stage5_sync_result_counts": sync,
        "stage6_remote_after": stage6.get("remote_after"),
        "stage6_mobile": stage6.get("mobile"),
        "vercel_health": health,
        "vercel_target_probes": probes,
        "criteria": criteria,
        "stage8_pass": all(criteria.values()),
    }


def self_test() -> int:
    if age_seconds(datetime.now(timezone.utc).isoformat()) is None:
        raise RuntimeError("age_seconds self-test")
    print("STAGE8_HEALTH_SELF_TEST=PASS")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wait-seconds", type=int, default=0)
    parser.add_argument("--poll-seconds", type=int, default=15)
    parser.add_argument("--max-status-age-seconds", type=int, default=1800)
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()

    if args.self_test:
        return self_test()

    deadline = time.monotonic() + max(0, args.wait_seconds)
    last: dict[str, Any] | None = None

    while True:
        try:
            last = evaluate(args.max_status_age_seconds)
        except Exception as exc:
            last = {
                "generated_at": utc_now(),
                "stage": "Stage8",
                "fatal_error": f"{type(exc).__name__}: {exc}",
                "criteria": {},
                "stage8_pass": False,
            }

        if last.get("stage8_pass") is True:
            break
        if time.monotonic() >= deadline:
            break
        time.sleep(max(1, args.poll_seconds))

    if args.json:
        print(json.dumps(last, ensure_ascii=False, indent=2))
    else:
        print("=" * 78)
        print("ODDSHUNTER STAGE8 VPS HEALTH")
        print(json.dumps(last, ensure_ascii=False, indent=2))
        print("STAGE8_PASS =", last.get("stage8_pass"))
        print("FINAL=" + ("PASS_STAGE8_VPS_24X7" if last.get("stage8_pass") else "FAIL_STAGE8_VPS_24X7"))

    return 0 if last.get("stage8_pass") else 1


if __name__ == "__main__":
    raise SystemExit(main())
